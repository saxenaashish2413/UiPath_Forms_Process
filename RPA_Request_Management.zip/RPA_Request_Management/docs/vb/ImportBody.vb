'ARG in in_SolutionFilePath S
'ARG in in_ComponentParametersJson S
'ARG in in_OverwriteUnmanagedCustomizations B
'ARG in in_PublishWorkflows B
'ARG in in_ImportJobId S
'ARG out out_Body S
'ARG out out_SizeBytes L
' Body for POST [org]/api/data/v9.2/ImportSolutionAsync. CustomizationFile is the solution zip as base64 (Edm.Binary).
' ComponentParameters is required by the action (empty array when there is nothing to override).
Dim bytes As Byte() = System.IO.File.ReadAllBytes(in_SolutionFilePath)
out_SizeBytes = bytes.LongLength
Dim body As New Newtonsoft.Json.Linq.JObject(
    New Newtonsoft.Json.Linq.JProperty("OverwriteUnmanagedCustomizations", in_OverwriteUnmanagedCustomizations),
    New Newtonsoft.Json.Linq.JProperty("PublishWorkflows", in_PublishWorkflows),
    New Newtonsoft.Json.Linq.JProperty("CustomizationFile", Convert.ToBase64String(bytes)),
    New Newtonsoft.Json.Linq.JProperty("ImportJobId", in_ImportJobId),
    New Newtonsoft.Json.Linq.JProperty("ComponentParameters", Newtonsoft.Json.Linq.JArray.Parse(If(String.IsNullOrWhiteSpace(in_ComponentParametersJson), "[]", in_ComponentParametersJson))))
out_Body = body.ToString(Newtonsoft.Json.Formatting.None)
