'ARG in in_UserName S
'ARG in in_UserType S
'ARG in in_DefaultDomain S
'ARG in in_FolderId L
'ARG in in_RoleIds LL
'ARG out out_Body S
' Body for POST odata/Folders/UiPath.Server.Configuration.OData.AssignDomainUser: adds an Active Directory user or group
' that is not in Orchestrator yet directly to a folder with its folder roles (Orchestrator creates the directory account).
Dim name As String = in_UserName.Trim()
Dim domain As String = in_DefaultDomain
If name.Contains("\") Then
    domain = name.Substring(0, name.IndexOf("\"c))
    name = name.Substring(name.IndexOf("\"c) + 1)
End If
If String.IsNullOrWhiteSpace(domain) Then Throw New UiPath.Core.BusinessRuleException("'" & in_UserName & "' has no domain; use DOMAIN\name or set Settings.DirectoryDomain.")
out_Body = New Newtonsoft.Json.Linq.JObject(New Newtonsoft.Json.Linq.JProperty("assignment", New Newtonsoft.Json.Linq.JObject(
    New Newtonsoft.Json.Linq.JProperty("Domain", domain),
    New Newtonsoft.Json.Linq.JProperty("UserName", name),
    New Newtonsoft.Json.Linq.JProperty("UserType", If(String.Equals(in_UserType, "Group", StringComparison.OrdinalIgnoreCase), "DirectoryGroup", "DirectoryUser")),
    New Newtonsoft.Json.Linq.JProperty("RolesPerFolder", New Newtonsoft.Json.Linq.JArray(New Newtonsoft.Json.Linq.JObject(
        New Newtonsoft.Json.Linq.JProperty("FolderId", in_FolderId),
        New Newtonsoft.Json.Linq.JProperty("RoleIds", New Newtonsoft.Json.Linq.JArray(in_RoleIds)))))))).ToString(Newtonsoft.Json.Formatting.None)
