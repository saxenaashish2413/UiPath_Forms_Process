'ARG in in_AssetsTable DT
'ARG in in_AssetGroup S
'ARG in in_Environment S
'ARG in in_Entity S
'ARG out out_Assets JA
' Selects the Assets sheet rows of the entity's AssetConfiguration group for the target environment (or ALL)
' and expands {Entity}/{Environment} tokens. Secret values never live in the sheet: Credential/Secret rows name a
' "vault" credential asset (ValueFromCredentialAsset) that the provisioning robot reads at run time.
Dim envName As String = in_Environment
Dim entityToken As String = System.Text.RegularExpressions.Regex.Replace(in_Entity, "[^A-Za-z0-9]", "")
Dim expand As Func(Of String, String) = Function(s) If(s, "").Replace("{Entity}", entityToken).Replace("{Environment}", envName)
Dim types As String() = {"Text", "Bool", "Integer", "Credential", "Secret", "JSON"}
out_Assets = New Newtonsoft.Json.Linq.JArray()
For Each row As DataRow In in_AssetsTable.Rows
    If Not String.Equals(Convert.ToString(row("AssetGroup")).Trim(), in_AssetGroup, StringComparison.OrdinalIgnoreCase) Then Continue For
    Dim env As String = Convert.ToString(row("Environment")).Trim()
    If Not (env.Equals("ALL", StringComparison.OrdinalIgnoreCase) OrElse env.Equals(in_Environment, StringComparison.OrdinalIgnoreCase)) Then Continue For
    Dim t As String = Convert.ToString(row("AssetType")).Trim()
    If Not types.Contains(t, StringComparer.OrdinalIgnoreCase) Then Throw New InvalidOperationException("Assets sheet: '" & t & "' is not one of " & String.Join(", ", types))
    t = types.First(Function(x) x.Equals(t, StringComparison.OrdinalIgnoreCase))
    Dim value As String = expand(Convert.ToString(row("Value")))
    Dim vault As String = expand(Convert.ToString(row("ValueFromCredentialAsset")).Trim())
    If (t = "Credential" OrElse t = "Secret") AndAlso vault = "" Then Throw New InvalidOperationException("Assets sheet: " & t & " asset '" & Convert.ToString(row("AssetName")) & "' needs ValueFromCredentialAsset; secrets are never stored in Config.xlsx.")
    If (t = "Credential" OrElse t = "Secret") AndAlso value <> "" Then Throw New InvalidOperationException("Assets sheet: remove the Value of " & t & " asset '" & Convert.ToString(row("AssetName")) & "'.")
    If t = "JSON" Then Newtonsoft.Json.Linq.JToken.Parse(value)
    If t = "Bool" AndAlso Not New String() {"true", "false"}.Contains(value.ToLowerInvariant()) Then Throw New InvalidOperationException("Assets sheet: Bool asset '" & Convert.ToString(row("AssetName")) & "' must be True or False.")
    Dim iv As Integer
    If t = "Integer" AndAlso Not Integer.TryParse(value, iv) Then Throw New InvalidOperationException("Assets sheet: Integer asset '" & Convert.ToString(row("AssetName")) & "' is not a whole number.")
    out_Assets.Add(New Newtonsoft.Json.Linq.JObject(
        New Newtonsoft.Json.Linq.JProperty("Name", expand(Convert.ToString(row("AssetName")).Trim())),
        New Newtonsoft.Json.Linq.JProperty("Type", t),
        New Newtonsoft.Json.Linq.JProperty("Value", value),
        New Newtonsoft.Json.Linq.JProperty("ValueFromCredentialAsset", vault),
        New Newtonsoft.Json.Linq.JProperty("UpdateIfExists", Convert.ToString(row("UpdateIfExists")).Trim().Equals("True", StringComparison.OrdinalIgnoreCase)),
        New Newtonsoft.Json.Linq.JProperty("Description", expand(Convert.ToString(row("Description"))))))
Next
