'ARG in in_UserJson S
'ARG in in_AllRolesJson S
'ARG in in_RequiredRoleIds LL
'ARG out out_Body S
'ARG out out_AlreadyAssigned B
' POST odata/Users(<id>)/UiPath.Server.Configuration.OData.AssignRoles REPLACES the user's tenant roles
' (documented behaviour), so the body is the union of the roles the user already has (Users.RolesList, by name)
' and the required ones.
Dim user As Newtonsoft.Json.Linq.JObject = Newtonsoft.Json.Linq.JObject.Parse(in_UserJson)
Dim allRoles As Newtonsoft.Json.Linq.JArray = CType(Newtonsoft.Json.Linq.JObject.Parse(in_AllRolesJson)("value"), Newtonsoft.Json.Linq.JArray)
Dim current As New List(Of Long)
If user("RolesList") IsNot Nothing AndAlso user("RolesList").Type = Newtonsoft.Json.Linq.JTokenType.Array Then
    For Each n As Newtonsoft.Json.Linq.JToken In user("RolesList")
        Dim m As Newtonsoft.Json.Linq.JToken = allRoles.FirstOrDefault(Function(r) String.Equals(r.Value(Of String)("Name"), n.ToString(), StringComparison.OrdinalIgnoreCase))
        If m IsNot Nothing Then current.Add(m.Value(Of Long)("Id"))
    Next
End If
out_AlreadyAssigned = in_RequiredRoleIds.All(Function(id) current.Contains(id))
Dim merged As List(Of Long) = current.Union(in_RequiredRoleIds).Distinct().ToList()
out_Body = New Newtonsoft.Json.Linq.JObject(New Newtonsoft.Json.Linq.JProperty("roleIds", New Newtonsoft.Json.Linq.JArray(merged))).ToString(Newtonsoft.Json.Formatting.None)
