'ARG in in_EntityConfigJson S
'ARG in in_LogoPath S
'ARG in in_PrefillJson S
'ARG in in_ValidationMessage S
'ARG in in_CurrentUser DSS
'ARG in in_AllowDevToProd B
'ARG out out_FormInputJson S
'ARG out out_LogoDataUri S
' Builds the data the form opens with: the entity catalogue (drives every dynamic field), the logo as a data URI
' (Forms cannot read local files), the current user, server-side validation messages and the previous values
' when the form is shown again after a failed validation.
Const placeholderSvg As String = "<svg xmlns='http://www.w3.org/2000/svg' width='260' height='48' viewBox='0 0 260 48'><rect x='1' y='1' width='46' height='46' rx='10' fill='#0B3D91'/><path d='M14 32V16h9a6 6 0 0 1 0 12h-5v4z' fill='#fff'/><text x='60' y='22' font-family='Segoe UI,Arial,sans-serif' font-size='16' font-weight='700' fill='#0B3D91'>YOUR COMPANY</text><text x='60' y='39' font-family='Segoe UI,Arial,sans-serif' font-size='10' fill='#5B6B82' letter-spacing='1.1'>RPA CENTER OF EXCELLENCE</text></svg>"
out_LogoDataUri = "data:image/svg+xml;base64," & Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(placeholderSvg))
If Not String.IsNullOrWhiteSpace(in_LogoPath) AndAlso System.IO.File.Exists(in_LogoPath) Then
    Dim mimeTypes As New Dictionary(Of String, String)(StringComparer.OrdinalIgnoreCase) From {
        {".png", "image/png"}, {".jpg", "image/jpeg"}, {".jpeg", "image/jpeg"}, {".gif", "image/gif"}, {".svg", "image/svg+xml"}}
    Dim ext As String = System.IO.Path.GetExtension(in_LogoPath)
    If mimeTypes.ContainsKey(ext) AndAlso New System.IO.FileInfo(in_LogoPath).Length <= 512000 Then
        out_LogoDataUri = "data:" & mimeTypes(ext) & ";base64," & Convert.ToBase64String(System.IO.File.ReadAllBytes(in_LogoPath))
    Else
        Console.WriteLine("CompanyLogoPath must be a PNG/JPG/GIF/SVG of at most 500 KB; using the placeholder logo.")
    End If
End If
Dim data As Newtonsoft.Json.Linq.JObject
If String.IsNullOrWhiteSpace(in_PrefillJson) Then
    data = New Newtonsoft.Json.Linq.JObject()
Else
    data = Newtonsoft.Json.JsonConvert.DeserializeObject(Of Newtonsoft.Json.Linq.JObject)(in_PrefillJson, New Newtonsoft.Json.JsonSerializerSettings With {.DateParseHandling = Newtonsoft.Json.DateParseHandling.None})
End If
data("EntityConfig") = in_EntityConfigJson
data("CompanyLogo") = out_LogoDataUri
data("ValidationMessage") = If(in_ValidationMessage, "")
data("AllowDevToProd") = in_AllowDevToProd
data("FormAction") = ""
data("RequesterAccount") = in_CurrentUser("Account")
Dim prefill As New Dictionary(Of String, String) From {{"RequesterName", "DisplayName"}, {"RequesterEmail", "Email"}, {"EmployeeID", "EmployeeID"}}
For Each kv As KeyValuePair(Of String, String) In prefill
    If String.IsNullOrWhiteSpace(data.Value(Of String)(kv.Key)) Then data(kv.Key) = in_CurrentUser(kv.Value)
Next
data("RequesterFromDirectory") = Not String.IsNullOrWhiteSpace(in_CurrentUser("Email"))
For Each k As String In New String() {"submit", "cancel"}
    data.Remove(k)
Next
out_FormInputJson = data.ToString(Newtonsoft.Json.Formatting.None)
