'ARG in in_SmtpServer S
'ARG in in_SmtpPort I
'ARG in in_EnableSsl B
'ARG in in_UserName S
'ARG in in_Password SEC
'ARG in in_From S
'ARG in in_To S
'ARG in in_Cc S
'ARG in in_Subject S
'ARG in in_HtmlBody S
'ARG in in_TimeoutSeconds I
' Plain SMTP send (internal relay). Credentials are optional: leave SmtpCredentialAsset empty for an anonymous relay.
If String.IsNullOrWhiteSpace(in_To) Then
    Console.WriteLine("No notification recipients configured; email skipped.")
    Return
End If
Using msg As New System.Net.Mail.MailMessage()
    msg.From = New System.Net.Mail.MailAddress(in_From)
    For Each a As String In in_To.Split(New Char() {";"c, ","c}, StringSplitOptions.RemoveEmptyEntries)
        msg.To.Add(a.Trim())
    Next
    For Each a As String In If(in_Cc, "").Split(New Char() {";"c, ","c}, StringSplitOptions.RemoveEmptyEntries)
        msg.CC.Add(a.Trim())
    Next
    msg.Subject = in_Subject
    msg.Body = in_HtmlBody
    msg.IsBodyHtml = True
    Using smtp As New System.Net.Mail.SmtpClient(in_SmtpServer, in_SmtpPort)
        smtp.EnableSsl = in_EnableSsl
        smtp.Timeout = Math.Max(5, in_TimeoutSeconds) * 1000
        If Not String.IsNullOrWhiteSpace(in_UserName) AndAlso in_Password IsNot Nothing Then
            smtp.Credentials = New System.Net.NetworkCredential(in_UserName, in_Password)
        Else
            smtp.UseDefaultCredentials = True
        End If
        smtp.Send(msg)
    End Using
End Using
