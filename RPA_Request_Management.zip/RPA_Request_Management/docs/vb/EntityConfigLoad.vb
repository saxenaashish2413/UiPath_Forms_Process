'ARG in in_Source S
'ARG in in_JsonText S
'ARG in in_EntitiesTable DT
'ARG out out_EntityConfigJson S
'ARG out out_EntityNames LS
' Loads the entity catalogue from EntityConfiguration.json (default) or the Entities sheet of Config.xlsx and returns
' it in one normalised JSON shape: {"entities":[{...flat fields...}]}. Inactive entities are dropped.
' Nothing entity-specific lives in the workflows; adding an entity is a data change only.
Dim required As String() = {"Entity", "PolicyRole1", "PolicyRole2", "PolicyRole3", "PolicyRole4", "BotID", "DevFolder", "UATFolder", "ProdFolder",
    "DevMachineTemplate", "UATMachineTemplate", "ProdMachineTemplate", "QueueName", "AssetConfiguration",
    "PowerAutomateDevEnvironment", "PowerAutomateUATEnvironment", "PowerAutomateProdEnvironment"}
Dim items As New Newtonsoft.Json.Linq.JArray()
If String.Equals(in_Source, "Excel", StringComparison.OrdinalIgnoreCase) Then
    For Each row As DataRow In in_EntitiesTable.Rows
        Dim o As New Newtonsoft.Json.Linq.JObject()
        For Each col As DataColumn In in_EntitiesTable.Columns
            o(col.ColumnName) = Convert.ToString(row(col)).Trim()
        Next
        items.Add(o)
    Next
ElseIf String.Equals(in_Source, "Json", StringComparison.OrdinalIgnoreCase) Then
    Dim root As Newtonsoft.Json.Linq.JObject = Newtonsoft.Json.Linq.JObject.Parse(in_JsonText)
    If root("entities") Is Nothing OrElse root("entities").Type <> Newtonsoft.Json.Linq.JTokenType.Array Then Throw New InvalidOperationException("EntityConfiguration.json must contain an ""entities"" array.")
    items = CType(root("entities"), Newtonsoft.Json.Linq.JArray)
Else
    Throw New InvalidOperationException("EntityConfigurationSource must be Json or Excel, not '" & in_Source & "'.")
End If
Dim result As New Newtonsoft.Json.Linq.JArray()
Dim errors As New List(Of String)
out_EntityNames = New List(Of String)
For Each item As Newtonsoft.Json.Linq.JToken In items
    Dim e As Newtonsoft.Json.Linq.JObject = CType(item, Newtonsoft.Json.Linq.JObject)
    Dim name As String = If(e.Value(Of String)("Entity"), "").Trim()
    Dim active As String = If(e("IsActive") Is Nothing, "true", e("IsActive").ToString())
    If Not (active.Equals("true", StringComparison.OrdinalIgnoreCase) OrElse active = "1" OrElse active.Equals("yes", StringComparison.OrdinalIgnoreCase)) Then Continue For
    For Each f As String In required
        If e(f) Is Nothing OrElse e(f).ToString().Trim() = "" Then errors.Add("Entity '" & name & "': " & f & " is empty")
    Next
    If out_EntityNames.Contains(name, StringComparer.OrdinalIgnoreCase) Then errors.Add("Entity '" & name & "' is defined twice")
    ' AllowedMovements: array or "DEV to UAT;UAT to PROD". Default: the two standard movements.
    Dim moves As New List(Of String)
    Dim mv As Newtonsoft.Json.Linq.JToken = e("AllowedMovements")
    If mv Is Nothing OrElse mv.ToString().Trim() = "" Then
        moves.AddRange(New String() {"DEV to UAT", "UAT to PROD"})
    ElseIf mv.Type = Newtonsoft.Json.Linq.JTokenType.Array Then
        moves.AddRange(mv.Select(Function(t) t.ToString().Trim()))
    Else
        moves.AddRange(mv.ToString().Split(";"c).Select(Function(s) s.Trim()).Where(Function(s) s <> ""))
    End If
    For Each m As String In moves
        If Not New String() {"DEV to UAT", "UAT to PROD", "DEV to PROD"}.Contains(m) Then errors.Add("Entity '" & name & "': unknown movement '" & m & "'")
    Next
    Dim n As New Newtonsoft.Json.Linq.JObject()
    For Each p As Newtonsoft.Json.Linq.JProperty In e.Properties()
        If p.Name <> "AllowedMovements" AndAlso p.Name <> "IsActive" Then n(p.Name) = p.Value.ToString().Trim()
    Next
    n("AllowedMovements") = New Newtonsoft.Json.Linq.JArray(moves.Distinct().ToArray())
    result.Add(n)
    out_EntityNames.Add(name)
Next
If result.Count = 0 Then errors.Add("no active entity is configured")
If errors.Count > 0 Then Throw New InvalidOperationException("Entity configuration is invalid: " & String.Join("; ", errors))
out_EntityConfigJson = New Newtonsoft.Json.Linq.JObject(New Newtonsoft.Json.Linq.JProperty("entities", result)).ToString(Newtonsoft.Json.Formatting.None)
