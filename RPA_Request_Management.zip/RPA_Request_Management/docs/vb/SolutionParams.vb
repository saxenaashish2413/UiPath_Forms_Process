'ARG in in_EnvVarsTable DT
'ARG in in_ConnRefsTable DT
'ARG in in_Entity S
'ARG in in_Environment S
'ARG out out_ComponentParametersJson S
'ARG out out_EnvironmentVariablesJson S
'ARG out out_ConnectionReferencesJson S
' Target-environment values for the solution, from Config.xlsx:
'   PA_EnvironmentVariables  Entity | Environment | SchemaName | Value
'   PA_ConnectionReferences  Entity | Environment | LogicalName | ConnectionId | ConnectorId
' Returned twice: as ImportSolutionAsync ComponentParameters (applied during import) and as plain lists that
' WF_UpdateEnvironmentVariables / WF_UpdateConnectionReferences re-apply and verify after import (idempotent).
Dim entityName As String = in_Entity
Dim envName As String = in_Environment
Dim matches As Func(Of DataRow, Boolean) = Function(r) String.Equals(Convert.ToString(r("Entity")).Trim(), entityName, StringComparison.OrdinalIgnoreCase) AndAlso
    (String.Equals(Convert.ToString(r("Environment")).Trim(), envName, StringComparison.OrdinalIgnoreCase) OrElse String.Equals(Convert.ToString(r("Environment")).Trim(), "ALL", StringComparison.OrdinalIgnoreCase))
Dim parameters As New Newtonsoft.Json.Linq.JArray()
Dim vars As New Newtonsoft.Json.Linq.JArray()
Dim refs As New Newtonsoft.Json.Linq.JArray()
For Each r As DataRow In in_EnvVarsTable.Rows.Cast(Of DataRow)().Where(matches)
    Dim schema As String = Convert.ToString(r("SchemaName")).Trim()
    Dim value As String = Convert.ToString(r("Value"))
    If System.Text.RegularExpressions.Regex.IsMatch(schema, "(?i)(secret|password)") Then Throw New InvalidOperationException("PA_EnvironmentVariables: '" & schema & "' looks like a secret. Use a Dataverse secret environment variable backed by Azure Key Vault instead.")
    parameters.Add(New Newtonsoft.Json.Linq.JObject(
        New Newtonsoft.Json.Linq.JProperty("@odata.type", "Microsoft.Dynamics.CRM.environmentvariablevalue"),
        New Newtonsoft.Json.Linq.JProperty("schemaname", schema),
        New Newtonsoft.Json.Linq.JProperty("value", value)))
    vars.Add(New Newtonsoft.Json.Linq.JObject(New Newtonsoft.Json.Linq.JProperty("schemaname", schema), New Newtonsoft.Json.Linq.JProperty("value", value)))
Next
For Each r As DataRow In in_ConnRefsTable.Rows.Cast(Of DataRow)().Where(matches)
    Dim logical As String = Convert.ToString(r("LogicalName")).Trim()
    Dim connectionId As String = Convert.ToString(r("ConnectionId")).Trim()
    Dim connectorId As String = Convert.ToString(r("ConnectorId")).Trim()
    If connectionId = "" Then Throw New InvalidOperationException("PA_ConnectionReferences: '" & logical & "' has no ConnectionId for " & in_Environment & ". Create the connection in the target environment first (API limitation: connections that need interactive sign-in cannot be created through the API).")
    parameters.Add(New Newtonsoft.Json.Linq.JObject(
        New Newtonsoft.Json.Linq.JProperty("@odata.type", "Microsoft.Dynamics.CRM.connectionreference"),
        New Newtonsoft.Json.Linq.JProperty("connectionreferencelogicalname", logical),
        New Newtonsoft.Json.Linq.JProperty("connectionid", connectionId),
        New Newtonsoft.Json.Linq.JProperty("connectorid", connectorId)))
    refs.Add(New Newtonsoft.Json.Linq.JObject(New Newtonsoft.Json.Linq.JProperty("connectionreferencelogicalname", logical), New Newtonsoft.Json.Linq.JProperty("connectionid", connectionId)))
Next
out_ComponentParametersJson = parameters.ToString(Newtonsoft.Json.Formatting.None)
out_EnvironmentVariablesJson = vars.ToString(Newtonsoft.Json.Formatting.None)
out_ConnectionReferencesJson = refs.ToString(Newtonsoft.Json.Formatting.None)
