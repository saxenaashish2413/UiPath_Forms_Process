'ARG in in_Sheets DSO
'ARG in in_ConfigFolder S
'ARG out out_Config DSO
' Builds the single Config dictionary from Config.xlsx:
'  Settings      Name | Value | Description            -> Config("<Name>")
'  Environments  Environment | OrchestratorURL | ...    -> Config("<ENV>.<Column>"), e.g. Config("UAT.OrchestratorURL")
'  other sheets  stored as DataTables                    -> Config("Table.<Sheet>")
' Relative paths in *Path settings are resolved against the Config folder. Secrets are refused: a setting whose name
' mentions a password/secret/token must name an Orchestrator credential asset (…Asset) instead of holding the value.
Dim cfg As New Dictionary(Of String, Object)(StringComparer.OrdinalIgnoreCase)
Dim settings As DataTable = CType(in_Sheets("Settings"), DataTable)
For Each row As DataRow In settings.Rows
    Dim name As String = Convert.ToString(row("Name")).Trim()
    If name = "" Then Continue For
    Dim value As String = Convert.ToString(row("Value")).Trim()
    If System.Text.RegularExpressions.Regex.IsMatch(name, "(?i)(password|secret|token|apikey)") AndAlso Not System.Text.RegularExpressions.Regex.IsMatch(name, "(?i)(asset|assetfolder|mode|url|path)$") AndAlso value <> "" Then
        Throw New InvalidOperationException("Config.xlsx Settings row '" & name & "' looks like a secret. Store secrets in Orchestrator credential assets and put the asset name in a '...Asset' setting.")
    End If
    If name.EndsWith("Path", StringComparison.OrdinalIgnoreCase) AndAlso value <> "" AndAlso Not System.IO.Path.IsPathRooted(value) AndAlso Not value.StartsWith("\\") Then
        value = System.IO.Path.GetFullPath(System.IO.Path.Combine(in_ConfigFolder, value))
    End If
    cfg(name) = value
Next
Dim envs As DataTable = CType(in_Sheets("Environments"), DataTable)
Dim envNames As New List(Of String)
For Each row As DataRow In envs.Rows
    Dim env As String = Convert.ToString(row("Environment")).Trim().ToUpperInvariant()
    If env = "" Then Continue For
    envNames.Add(env)
    For Each col As DataColumn In envs.Columns
        If col.ColumnName = "Environment" Then Continue For
        Dim v As String = Convert.ToString(row(col)).Trim()
        If col.ColumnName.IndexOf("Secret", StringComparison.OrdinalIgnoreCase) >= 0 AndAlso Not col.ColumnName.EndsWith("Asset", StringComparison.OrdinalIgnoreCase) AndAlso v <> "" Then
            Throw New InvalidOperationException("Environments column '" & col.ColumnName & "' must not hold a secret value.")
        End If
        cfg(env & "." & col.ColumnName) = v.Replace("{OrchestratorURL}", Convert.ToString(row("OrchestratorURL")).Trim().TrimEnd("/"c))
    Next
Next
cfg("Environments") = String.Join(";", envNames)
For Each k As String In in_Sheets.Keys
    If k = "Settings" OrElse k = "Environments" Then Continue For
    cfg("Table." & k) = in_Sheets(k)
Next
Dim required As String() = {"EntityConfigurationSource", "EntityConfigurationPath", "RequestStorePath", "ApiTimeoutSeconds", "RetryCount", "RetryDelaySeconds"}
Dim missing As List(Of String) = required.Where(Function(r) Not cfg.ContainsKey(r) OrElse Convert.ToString(cfg(r)) = "").ToList()
For Each env As String In New String() {"DEV", "UAT", "PROD"}
    If Not envNames.Contains(env) Then missing.Add("Environments row " & env)
Next
If missing.Count > 0 Then Throw New InvalidOperationException("Config.xlsx is missing: " & String.Join(", ", missing))
out_Config = cfg
