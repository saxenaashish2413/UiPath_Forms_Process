'ARG out out_User DSS
' The person running the attended robot: Windows account always, display name / e-mail / employee ID from
' Active Directory when the machine is domain joined (ADSI through PowerShell, no extra packages, 10 s limit).
Dim u As New Dictionary(Of String, String)(StringComparer.OrdinalIgnoreCase) From {
    {"UserName", Environment.UserName}, {"Domain", Environment.UserDomainName},
    {"Account", Environment.UserDomainName & "\" & Environment.UserName},
    {"DisplayName", ""}, {"Email", ""}, {"EmployeeID", ""}}
If OperatingSystem.IsWindows() Then
    Try
        Dim script As String = "$s=[adsisearcher]""(&(objectCategory=person)(sAMAccountName=$env:USERNAME))"";" &
            "$r=$s.FindOne();if($r){$p=$r.Properties;@{d=[string]$p['displayname'];m=[string]$p['mail'];e=[string]$p['employeeid']}|ConvertTo-Json -Compress}"
        Dim psi As New System.Diagnostics.ProcessStartInfo("powershell.exe", "-NoProfile -NonInteractive -ExecutionPolicy Bypass -Command """ & script.Replace("""", "\""") & """")
        psi.RedirectStandardOutput = True
        psi.UseShellExecute = False
        psi.CreateNoWindow = True
        Using p As System.Diagnostics.Process = System.Diagnostics.Process.Start(psi)
            Dim outText As String = p.StandardOutput.ReadToEnd()
            If p.WaitForExit(10000) AndAlso outText.Trim().StartsWith("{") Then
                Dim j As Newtonsoft.Json.Linq.JObject = Newtonsoft.Json.Linq.JObject.Parse(outText.Trim())
                u("DisplayName") = If(j.Value(Of String)("d"), "")
                u("Email") = If(j.Value(Of String)("m"), "")
                u("EmployeeID") = If(j.Value(Of String)("e"), "")
            End If
        End Using
    Catch ex As Exception
        Console.WriteLine("Directory lookup for the current user failed; the form will ask for the details. " & ex.Message)
    End Try
End If
If u("DisplayName") = "" Then u("DisplayName") = Environment.UserName
out_User = u
