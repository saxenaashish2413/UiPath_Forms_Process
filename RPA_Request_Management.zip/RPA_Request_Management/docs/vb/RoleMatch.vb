'ARG in in_RoleNames LS
'ARG in in_Json S
'ARG out out_Url S
'ARG out out_RoleIds LL
'ARG out out_RoleTypes LS
'ARG out out_Missing LS
' Role IDs are never hard-coded: names from the Roles sheet are resolved through GET odata/Roles.
' With in_Json empty it only builds the URL; with the response it returns ids/types in the order of in_RoleNames.
Dim filter As String = String.Join(" or ", in_RoleNames.Select(Function(n) "Name eq '" & n.Replace("'", "''") & "'"))
out_Url = "odata/Roles?$filter=" & Uri.EscapeDataString(If(filter = "", "Id eq 0", filter)) & "&$select=Id,Name,Type&$top=100"
out_RoleIds = New List(Of Long)
out_RoleTypes = New List(Of String)
out_Missing = New List(Of String)
If String.IsNullOrWhiteSpace(in_Json) Then Return
Dim arr As Newtonsoft.Json.Linq.JArray = CType(Newtonsoft.Json.Linq.JObject.Parse(in_Json)("value"), Newtonsoft.Json.Linq.JArray)
For Each name As String In in_RoleNames
    Dim match As Newtonsoft.Json.Linq.JToken = arr.FirstOrDefault(Function(t) String.Equals(t.Value(Of String)("Name"), name, StringComparison.OrdinalIgnoreCase))
    If match Is Nothing Then
        out_Missing.Add(name)
    Else
        out_RoleIds.Add(match.Value(Of Long)("Id"))
        out_RoleTypes.Add(If(match.Value(Of String)("Type"), "Mixed"))
    End If
Next
