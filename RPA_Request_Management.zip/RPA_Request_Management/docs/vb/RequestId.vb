'ARG in in_StorePath S
'ARG in in_Prefix S
'ARG out out_RequestId S
' Request ID = <Prefix>-<yyyy>-<NNNNN>, e.g. RPA-2026-00042. Unique across robots without a database:
' each ID is claimed by creating <store>\ids\<yyyy>\<id>.id with FileMode.CreateNew, which is atomic on NTFS and SMB.
' If two robots race for the same number, the loser gets an IOException and takes the next one.
Dim inv As System.Globalization.CultureInfo = System.Globalization.CultureInfo.InvariantCulture
Dim year As String = DateTime.Now.ToString("yyyy", inv)
Dim dir As String = System.IO.Path.Combine(in_StorePath, "ids", year)
System.IO.Directory.CreateDirectory(dir)
Dim prefix As String = If(String.IsNullOrWhiteSpace(in_Prefix), "RPA", in_Prefix.Trim()) & "-" & year & "-"
Dim maxSeq As Integer = 0
For Each file As String In System.IO.Directory.GetFiles(dir, prefix & "*.id")
    Dim n As Integer
    If Integer.TryParse(System.IO.Path.GetFileNameWithoutExtension(file).Substring(prefix.Length), System.Globalization.NumberStyles.Integer, inv, n) AndAlso n > maxSeq Then maxSeq = n
Next
out_RequestId = ""
For attempt As Integer = 1 To 50
    Dim candidate As String = prefix & (maxSeq + attempt).ToString("00000", inv)
    Try
        Using fs As New System.IO.FileStream(System.IO.Path.Combine(dir, candidate & ".id"), System.IO.FileMode.CreateNew, System.IO.FileAccess.Write, System.IO.FileShare.None)
            Dim stamp As Byte() = System.Text.Encoding.UTF8.GetBytes(Environment.MachineName & " " & Environment.UserName & " " & DateTime.UtcNow.ToString("o", inv))
            fs.Write(stamp, 0, stamp.Length)
        End Using
        out_RequestId = candidate
        Exit For
    Catch ex As System.IO.IOException When System.IO.File.Exists(System.IO.Path.Combine(dir, candidate & ".id"))
        ' taken by another robot: try the next number
    End Try
Next
If out_RequestId = "" Then Throw New InvalidOperationException("Could not reserve a Request ID in " & dir & " after 50 attempts.")
