'ARG in in_Method S
'ARG in in_Url S
'ARG in in_Body S
'ARG in in_AccessToken SEC
'ARG in in_FolderId L
'ARG in in_TenantName S
'ARG in in_ExtraHeadersJson S
'ARG in in_TimeoutSeconds I
'ARG in in_RetryCount I
'ARG in in_RetryDelaySeconds I
'ARG in in_UploadFilePath S
'ARG in in_DownloadFilePath S
'ARG out out_StatusCode I
'ARG out out_ResponseBody S
'ARG out out_CorrelationId S
'ARG out out_Attempts I
'ARG out out_DurationMs L
' Single HTTP entry point for Orchestrator, Identity and Dataverse calls.
' Headers: Authorization: Bearer <token>, Accept: application/json, Content-Type: application/json (JSON bodies),
'          X-UIPATH-OrganizationUnitId (Orchestrator folder) and X-UIPATH-TenantName when given.
' Retries ONLY transient failures: HTTP 429, 500, 502, 503, 504, timeouts and connection errors, with exponential
' back-off and the Retry-After header when the server sends one. 400/401/403/404/409 are returned at once.
' Non-2xx responses do not throw here: SendApiRequest.xaml hands them to HandleApiError.xaml.
' The token is read from the SecureString only inside this block and never logged or put in an exception.
Dim inv As System.Globalization.CultureInfo = System.Globalization.CultureInfo.InvariantCulture
Dim transientCodes As Integer() = {429, 500, 502, 503, 504}
Dim maxAttempts As Integer = Math.Max(1, in_RetryCount + 1)
Dim watch As System.Diagnostics.Stopwatch = System.Diagnostics.Stopwatch.StartNew()
Dim lastError As String = ""
out_StatusCode = 0
out_ResponseBody = ""
out_CorrelationId = ""
out_Attempts = 0
Dim extra As Newtonsoft.Json.Linq.JObject = If(String.IsNullOrWhiteSpace(in_ExtraHeadersJson), New Newtonsoft.Json.Linq.JObject(), Newtonsoft.Json.Linq.JObject.Parse(in_ExtraHeadersJson))
Using client As New System.Net.Http.HttpClient()
    client.Timeout = TimeSpan.FromSeconds(Math.Max(5, in_TimeoutSeconds))
    For attempt As Integer = 1 To maxAttempts
        out_Attempts = attempt
        Dim transient As Boolean = False
        Dim retryAfter As TimeSpan = TimeSpan.Zero
        Try
            Using request As New System.Net.Http.HttpRequestMessage(New System.Net.Http.HttpMethod(in_Method.Trim().ToUpperInvariant()), in_Url)
                If in_AccessToken IsNot Nothing Then
                    request.Headers.Authorization = New System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", New System.Net.NetworkCredential("", in_AccessToken).Password)
                End If
                request.Headers.Accept.Add(New System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"))
                If in_FolderId > 0 Then request.Headers.Add("X-UIPATH-OrganizationUnitId", in_FolderId.ToString(inv))
                If Not String.IsNullOrWhiteSpace(in_TenantName) Then request.Headers.Add("X-UIPATH-TenantName", in_TenantName.Trim())
                For Each h As Newtonsoft.Json.Linq.JProperty In extra.Properties()
                    request.Headers.TryAddWithoutValidation(h.Name, h.Value.ToString())
                Next
                If Not String.IsNullOrWhiteSpace(in_UploadFilePath) Then
                    Dim multipart As New System.Net.Http.MultipartFormDataContent()
                    Dim fileContent As New System.Net.Http.ByteArrayContent(System.IO.File.ReadAllBytes(in_UploadFilePath))
                    fileContent.Headers.ContentType = New System.Net.Http.Headers.MediaTypeHeaderValue("application/octet-stream")
                    multipart.Add(fileContent, "file", System.IO.Path.GetFileName(in_UploadFilePath))
                    request.Content = multipart
                ElseIf Not String.IsNullOrEmpty(in_Body) Then
                    request.Content = New System.Net.Http.StringContent(in_Body, System.Text.Encoding.UTF8, "application/json")
                End If
                Using response As System.Net.Http.HttpResponseMessage = client.SendAsync(request).GetAwaiter().GetResult()
                    out_StatusCode = CInt(response.StatusCode)
                    For Each headerName As String In New String() {"X-UIPATH-Correlation-Id", "x-ms-service-request-id", "REQ_ID", "x-ms-request-id", "Request-Id", "traceparent"}
                        Dim values As IEnumerable(Of String) = Nothing
                        If response.Headers.TryGetValues(headerName, values) Then
                            out_CorrelationId = String.Join(",", values)
                            Exit For
                        End If
                    Next
                    If response.Headers.RetryAfter IsNot Nothing AndAlso response.Headers.RetryAfter.Delta.HasValue Then retryAfter = response.Headers.RetryAfter.Delta.Value
                    If out_StatusCode >= 200 AndAlso out_StatusCode <= 299 AndAlso Not String.IsNullOrWhiteSpace(in_DownloadFilePath) Then
                        Dim bytes As Byte() = response.Content.ReadAsByteArrayAsync().GetAwaiter().GetResult()
                        Dim dir As String = System.IO.Path.GetDirectoryName(System.IO.Path.GetFullPath(in_DownloadFilePath))
                        System.IO.Directory.CreateDirectory(dir)
                        System.IO.File.WriteAllBytes(in_DownloadFilePath, bytes)
                        out_ResponseBody = "{""downloadedBytes"":" & bytes.Length.ToString(inv) & "}"
                    Else
                        out_ResponseBody = response.Content.ReadAsStringAsync().GetAwaiter().GetResult()
                    End If
                End Using
            End Using
            If transientCodes.Contains(out_StatusCode) Then
                transient = True
                lastError = "HTTP " & out_StatusCode.ToString(inv)
            End If
        Catch ex As System.Net.Http.HttpRequestException
            transient = True
            lastError = ex.Message
        Catch ex As System.Threading.Tasks.TaskCanceledException
            transient = True
            lastError = "timed out after " & client.Timeout.TotalSeconds.ToString(inv) & " s"
        End Try
        If Not transient Then Exit For
        If attempt < maxAttempts Then
            Dim wait As TimeSpan = TimeSpan.FromSeconds(Math.Max(0, in_RetryDelaySeconds) * Math.Pow(2, attempt - 1))
            If retryAfter > wait Then wait = retryAfter
            If wait > TimeSpan.FromSeconds(120) Then wait = TimeSpan.FromSeconds(120)
            Console.WriteLine("Transient failure on " & in_Method & " " & in_Url & " (" & lastError & "), attempt " & attempt.ToString(inv) & " of " & maxAttempts.ToString(inv) & "; retrying in " & wait.TotalSeconds.ToString(inv) & " s.")
            System.Threading.Thread.Sleep(wait)
        ElseIf out_StatusCode = 0 Then
            Throw New System.Net.Http.HttpRequestException(in_Method & " " & in_Url & " failed after " & maxAttempts.ToString(inv) & " attempt(s): " & lastError)
        End If
    Next
End Using
out_DurationMs = watch.ElapsedMilliseconds
