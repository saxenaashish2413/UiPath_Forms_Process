'ARG in in_AssetName S
'ARG in in_AssetType S
'ARG in in_Value S
'ARG in in_SecretUser S
'ARG in in_SecretValue SEC
'ARG in in_Description S
'ARG in in_ExistingId L
'ARG in in_SecretMode S
'ARG out out_Body S
'ARG out out_ApiValueType S
' Body for POST odata/Assets (create) or PUT odata/Assets(<Id>) (update). ValueScope = Global.
'  Text / JSON -> ValueType "Text",    StringValue
'  Bool        -> ValueType "Bool",    BoolValue
'  Integer     -> ValueType "Integer", IntValue
'  Credential  -> ValueType "Credential", CredentialUsername + CredentialPassword
'  Secret      -> see Settings.SecretAssetMode. "Credential" (default) stores it as a Credential asset whose password is the
'                 secret, because the 2025.10 API guide documents only Text/Bool/Int/Credential asset bodies (API limitation).
' The body contains the secret, so SendApiRequest is always called with in_LogBody = False for it.
Dim o As New Newtonsoft.Json.Linq.JObject()
If in_ExistingId > 0 Then o("Id") = in_ExistingId
o("Name") = in_AssetName
o("ValueScope") = "Global"
o("Description") = Left(If(in_Description, ""), 250)
Select Case in_AssetType
    Case "Text", "JSON"
        out_ApiValueType = "Text"
        o("StringValue") = in_Value
    Case "Bool"
        out_ApiValueType = "Bool"
        o("BoolValue") = Boolean.Parse(in_Value)
    Case "Integer"
        out_ApiValueType = "Integer"
        o("IntValue") = Integer.Parse(in_Value, System.Globalization.CultureInfo.InvariantCulture)
    Case "Credential", "Secret"
        If in_AssetType = "Secret" AndAlso Not String.Equals(in_SecretMode, "Credential", StringComparison.OrdinalIgnoreCase) Then
            Throw New UiPath.Core.BusinessRuleException("API limitation: Secret asset '" & in_AssetName & "' cannot be created through the documented Orchestrator 2025.10 asset API. Set Settings.SecretAssetMode = Credential, or create the asset in Orchestrator.")
        End If
        If in_SecretValue Is Nothing Then Throw New InvalidOperationException("No value was read for " & in_AssetType & " asset '" & in_AssetName & "'.")
        out_ApiValueType = "Credential"
        o("CredentialUsername") = If(String.IsNullOrWhiteSpace(in_SecretUser), in_AssetName, in_SecretUser)
        o("CredentialPassword") = New System.Net.NetworkCredential("", in_SecretValue).Password
    Case Else
        Throw New ArgumentException("Unsupported asset type " & in_AssetType)
End Select
o("ValueType") = out_ApiValueType
out_Body = o.ToString(Newtonsoft.Json.Formatting.None)
