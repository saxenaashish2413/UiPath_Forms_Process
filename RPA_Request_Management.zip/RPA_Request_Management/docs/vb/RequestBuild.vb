'ARG in in_FormOutputJson S
'ARG in in_EntityConfigJson S
'ARG in in_CurrentUser DSS
'ARG in in_AllowDevToProd B
'ARG out out_Request DSS
'ARG out out_Errors LS
' Server-side validation of the submitted form (never trust the client) and creation of the request object.
' The request object is a Dictionary(Of String, String) with a FIXED key set (RequestSchema below), serialised as JSON
' for the request store, notifications and the audit log.
Dim RequestSchema As String() = {"RequestID", "RequesterName", "RequesterEmail", "EmployeeID", "RequesterAccount", "Entity", "RPATool", "ProcessType",
    "PolicyRole1", "PolicyRole2", "PolicyRole3", "PolicyRole4", "SelectedPolicyRoles", "BotID", "MovementType", "SourceEnvironment", "TargetEnvironment",
    "Priority", "ApplicationName", "ProcessName", "ProcessDescription", "Description", "Severity", "RequestDescription", "BusinessJustification", "Comments",
    "PackageName", "PackageVersion", "SolutionName", "ExportAsManaged", "ProvisionForUser", "SubmissionDate", "Status", "StatusMessage"}
out_Errors = New List(Of String)
Dim errs As List(Of String) = out_Errors
Dim f As Newtonsoft.Json.Linq.JObject = Newtonsoft.Json.JsonConvert.DeserializeObject(Of Newtonsoft.Json.Linq.JObject)(in_FormOutputJson, New Newtonsoft.Json.JsonSerializerSettings With {.DateParseHandling = Newtonsoft.Json.DateParseHandling.None})
Dim g As Func(Of String, String) = Function(k) If(f(k) Is Nothing OrElse f(k).Type = Newtonsoft.Json.Linq.JTokenType.Null, "", f(k).ToString().Trim())
Dim isTrue As Func(Of String, Boolean) = Function(k) g(k).Equals("true", StringComparison.OrdinalIgnoreCase)
Dim req As New Dictionary(Of String, String)(StringComparer.OrdinalIgnoreCase)
For Each k As String In RequestSchema
    req(k) = ""
Next
Dim need As Action(Of String, String, Integer, Integer) = Sub(key, label, minLen, maxLen)
    Dim val As String = g(key)
    If val = "" Then
        errs.Add(label & " is required.")
    ElseIf val.Length < minLen OrElse val.Length > maxLen Then
        errs.Add(label & " must be " & minLen.ToString() & "-" & maxLen.ToString() & " characters.")
    End If
End Sub
Dim oneOf As Action(Of String, String, String()) = Sub(key, label, allowedValues)
    If g(key) = "" Then
        errs.Add(label & " is required.")
    ElseIf Not allowedValues.Contains(g(key)) Then
        errs.Add(label & " '" & g(key) & "' is not a valid choice.")
    End If
End Sub
' Requester
need("RequesterName", "Requester Name", 2, 100)
need("RequesterEmail", "Requester Email", 5, 254)
If g("RequesterEmail") <> "" AndAlso Not System.Text.RegularExpressions.Regex.IsMatch(g("RequesterEmail"), "^[^@\s]+@[^@\s]+\.[^@\s]+$") Then errs.Add("Requester Email is not a valid e-mail address.")
need("EmployeeID", "Employee ID", 1, 20)
If g("EmployeeID") <> "" AndAlso Not System.Text.RegularExpressions.Regex.IsMatch(g("EmployeeID"), "^[A-Za-z0-9\-]{1,20}$") Then errs.Add("Employee ID may only contain letters, digits and '-'.")
' Choices
oneOf("RPATool", "RPA Tool", New String() {"UiPath", "Power Automate"})
oneOf("ProcessType", "Process Type", New String() {"New", "Enhancement", "Bug Fix"})
oneOf("MovementType", "Movement Type", New String() {"DEV to UAT", "UAT to PROD", "DEV to PROD"})
oneOf("Priority", "Priority", New String() {"Critical", "High", "Medium", "Low"})
' Entity (must exist and be active) and entity-driven values (anti-tampering: recomputed here from configuration)
Dim root As Newtonsoft.Json.Linq.JObject = Newtonsoft.Json.Linq.JObject.Parse(in_EntityConfigJson)
Dim ent As Newtonsoft.Json.Linq.JToken = root("entities").FirstOrDefault(Function(t) String.Equals(t.Value(Of String)("Entity"), g("Entity"), StringComparison.Ordinal))
If g("Entity") = "" Then
    errs.Add("Entity is required.")
ElseIf ent Is Nothing Then
    errs.Add("Entity '" & g("Entity") & "' is not configured.")
End If
Dim moves As New Dictionary(Of String, String())(StringComparer.Ordinal) From {
    {"DEV to UAT", New String() {"DEV", "UAT"}}, {"UAT to PROD", New String() {"UAT", "PROD"}}, {"DEV to PROD", New String() {"DEV", "PROD"}}}
If ent IsNot Nothing AndAlso moves.ContainsKey(g("MovementType")) Then
    Dim allowed As List(Of String) = ent("AllowedMovements").Select(Function(t) t.ToString()).ToList()
    If Not allowed.Contains(g("MovementType")) Then errs.Add("Movement '" & g("MovementType") & "' is not allowed for " & g("Entity") & ".")
    If g("MovementType") = "DEV to PROD" AndAlso Not in_AllowDevToProd Then errs.Add("DEV to PROD is not allowed. Move to UAT first.")
    req("SourceEnvironment") = moves(g("MovementType"))(0)
    req("TargetEnvironment") = moves(g("MovementType"))(1)
    If g("SourceEnvironment") <> "" AndAlso g("SourceEnvironment") <> req("SourceEnvironment") Then errs.Add("Source Environment does not match the movement.")
    If g("TargetEnvironment") <> "" AndAlso g("TargetEnvironment") <> req("TargetEnvironment") Then errs.Add("Target Environment does not match the movement.")
End If
Dim selected As New List(Of String)
If ent IsNot Nothing Then
    For i As Integer = 1 To 4
        Dim roleName As String = If(ent.Value(Of String)("PolicyRole" & i.ToString()), "")
        req("PolicyRole" & i.ToString()) = roleName
        If g("PolicyRole" & i.ToString()) <> "" AndAlso g("PolicyRole" & i.ToString()) <> roleName Then errs.Add("Policy Role " & i.ToString() & " does not match the configuration for " & g("Entity") & ".")
        If isTrue("GrantPolicyRole" & i.ToString()) Then selected.Add(roleName)
    Next
    If selected.Count = 0 Then errs.Add("Select at least one of the four policy roles.")
    req("BotID") = If(g("RPATool") = "Power Automate", If(ent.Value(Of String)("PowerAutomateBotID"), ""), If(ent.Value(Of String)("BotID"), ""))
End If
req("SelectedPolicyRoles") = String.Join(";", selected)
' Process-type specific fields
Select Case g("ProcessType")
    Case "New"
        need("ApplicationName", "Application Name", 2, 100)
        need("ProcessName", "Process Name", 3, 100)
        need("ProcessDescription", "Process Description", 10, 2000)
        req("ProcessName") = g("ProcessName")
        req("Description") = g("ProcessDescription")
    Case "Enhancement"
        need("ExistingProcessName", "Existing Process Name", 3, 100)
        need("EnhancementDescription", "Enhancement Description", 10, 2000)
        req("ProcessName") = g("ExistingProcessName")
        req("Description") = g("EnhancementDescription")
    Case "Bug Fix"
        need("ExistingProcessName", "Existing Process Name", 3, 100)
        need("BugDescription", "Bug Description", 10, 2000)
        oneOf("Severity", "Severity", New String() {"Sev 1 - Critical", "Sev 2 - Major", "Sev 3 - Minor", "Sev 4 - Cosmetic"})
        req("ProcessName") = g("ExistingProcessName")
        req("Description") = g("BugDescription")
        req("Severity") = g("Severity")
End Select
If req("ProcessName") <> "" AndAlso Not System.Text.RegularExpressions.Regex.IsMatch(req("ProcessName"), "^[A-Za-z0-9][A-Za-z0-9 _\-\.]{2,99}$") Then errs.Add("Process Name may contain letters, digits, space, '_', '-' and '.'.")
' Tool specific fields
If g("RPATool") = "UiPath" Then
    need("PackageName", "Package Name", 2, 128)
    If g("PackageName") <> "" AndAlso Not System.Text.RegularExpressions.Regex.IsMatch(g("PackageName"), "^[A-Za-z0-9_\-\.]+$") Then errs.Add("Package Name may contain letters, digits, '_', '-' and '.'.")
    If g("PackageVersion") <> "" AndAlso Not System.Text.RegularExpressions.Regex.IsMatch(g("PackageVersion"), "^\d+(\.\d+){1,3}(-[A-Za-z0-9\.]+)?$") Then errs.Add("Package Version must look like 1.2.3 (or leave it empty to promote the version running in the source folder).")
ElseIf g("RPATool") = "Power Automate" Then
    need("SolutionName", "Solution Unique Name", 2, 64)
    If g("SolutionName") <> "" AndAlso Not System.Text.RegularExpressions.Regex.IsMatch(g("SolutionName"), "^[A-Za-z_][A-Za-z0-9_]*$") Then errs.Add("Solution Unique Name must be the solution's unique (schema) name, e.g. EntityA_Automations.")
End If
If g("ProvisionForUser") <> "" AndAlso Not System.Text.RegularExpressions.Regex.IsMatch(g("ProvisionForUser"), "^([A-Za-z0-9\-_\.]+\\[A-Za-z0-9\-_\.\$ ]+|[^@\s]+@[^@\s]+\.[^@\s]+)$") Then errs.Add("Grant access to must be DOMAIN\user or an e-mail address.")
need("RequestDescription", "Request Description", 10, 2000)
need("BusinessJustification", "Business Justification", 10, 1000)
If g("Comments").Length > 1000 Then errs.Add("Comments must be at most 1000 characters.")
' Copy the remaining values
For Each k As String In New String() {"RequesterName", "RequesterEmail", "EmployeeID", "Entity", "RPATool", "ProcessType", "MovementType", "Priority", "ApplicationName",
                                     "ProcessDescription", "RequestDescription", "BusinessJustification", "Comments", "PackageName", "PackageVersion", "SolutionName", "ProvisionForUser"}
    req(k) = g(k)
Next
req("RequesterAccount") = If(in_CurrentUser IsNot Nothing AndAlso in_CurrentUser.ContainsKey("Account"), in_CurrentUser("Account"), g("RequesterAccount"))
req("ExportAsManaged") = If(g("RPATool") = "Power Automate", If(isTrue("ExportAsManaged"), "True", "False"), "")
If g("RPATool") <> "UiPath" Then
    req("PackageName") = ""
    req("PackageVersion") = ""
End If
If g("RPATool") <> "Power Automate" Then req("SolutionName") = ""
req("SubmissionDate") = DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ssK", System.Globalization.CultureInfo.InvariantCulture)
req("Status") = If(errs.Count = 0, "Submitted", "Validation Failed")
out_Request = req
