'ARG in in_RolesTable DT
'ARG in in_PolicyRoles LS
'ARG in in_RPATool S
'ARG in in_Environment S
'ARG out out_FolderRoles LS
'ARG out out_TenantRoles LS
'ARG out out_DataverseRoles LS
'ARG out out_Unmapped LS
' Maps the business policy roles chosen in the form (e.g. "RPA Developer") to platform roles through the Roles sheet:
'   PolicyRole | RPATool | Environment (DEV/UAT/PROD/ALL) | TargetRoleName | Scope (Folder/Tenant/Dataverse)
' One policy role may map to several platform roles, and to fewer rights in PROD (least privilege).
out_FolderRoles = New List(Of String)
out_TenantRoles = New List(Of String)
out_DataverseRoles = New List(Of String)
out_Unmapped = New List(Of String)
For Each policy As String In in_PolicyRoles
    Dim hit As Boolean = False
    For Each row As DataRow In in_RolesTable.Rows
        If Not String.Equals(Convert.ToString(row("PolicyRole")).Trim(), policy, StringComparison.OrdinalIgnoreCase) Then Continue For
        If Not String.Equals(Convert.ToString(row("RPATool")).Trim(), in_RPATool, StringComparison.OrdinalIgnoreCase) Then Continue For
        Dim env As String = Convert.ToString(row("Environment")).Trim()
        If Not (env.Equals("ALL", StringComparison.OrdinalIgnoreCase) OrElse env.Equals(in_Environment, StringComparison.OrdinalIgnoreCase)) Then Continue For
        hit = True
        Dim roleName As String = Convert.ToString(row("TargetRoleName")).Trim()
        Select Case Convert.ToString(row("Scope")).Trim().ToLowerInvariant()
            Case "folder" : If Not out_FolderRoles.Contains(roleName) Then out_FolderRoles.Add(roleName)
            Case "tenant" : If Not out_TenantRoles.Contains(roleName) Then out_TenantRoles.Add(roleName)
            Case "dataverse" : If Not out_DataverseRoles.Contains(roleName) Then out_DataverseRoles.Add(roleName)
            Case Else : Throw New InvalidOperationException("Roles sheet: Scope must be Folder, Tenant or Dataverse (policy role " & policy & ").")
        End Select
    Next
    If Not hit Then out_Unmapped.Add(policy)
Next
