'ARG in in_Mode S
'ARG in in_FolderId L
'ARG in in_UserId L
'ARG in in_RoleIds LL
'ARG in in_RoleNames LS
'ARG in in_Json S
'ARG out out_Url S
'ARG out out_Body S
'ARG out out_Missing LS
'ARG out out_AlreadyAssigned B
' in_Mode = "Url":    build GET GetUsersForFolder URL
' in_Mode = "Assign": from the current folder users (in_Json) build the AssignUsers body, keeping roles the
'                     account already has on the folder (AssignUsers sets the full role list for the folder)
' in_Mode = "Verify": from a fresh GetUsersForFolder response, list required roles that are still missing
Dim inv As System.Globalization.CultureInfo = System.Globalization.CultureInfo.InvariantCulture
out_Url = "odata/Folders/UiPath.Server.Configuration.OData.GetUsersForFolder(key=" & in_FolderId.ToString(inv) & ",includeInherited=false)?$expand=UserEntity,Roles&$top=1000"
out_Body = ""
out_Missing = New List(Of String)
out_AlreadyAssigned = False
If in_Mode = "Url" Then Return

Dim existingIds As New List(Of Long)
Dim existingNames As New List(Of String)
Dim entries As Newtonsoft.Json.Linq.JArray = CType(Newtonsoft.Json.Linq.JObject.Parse(in_Json)("value"), Newtonsoft.Json.Linq.JArray)
For Each e As Newtonsoft.Json.Linq.JToken In entries
    Dim ue As Newtonsoft.Json.Linq.JToken = e("UserEntity")
    Dim uid As Long = If(ue IsNot Nothing AndAlso ue("Id") IsNot Nothing, ue.Value(Of Long)("Id"), If(e("UserId") IsNot Nothing, e.Value(Of Long)("UserId"), If(e("Id") IsNot Nothing, e.Value(Of Long)("Id"), 0L)))
    If uid <> in_UserId Then Continue For
    If e("Roles") Is Nothing Then Continue For
    For Each r As Newtonsoft.Json.Linq.JToken In e("Roles")
        ' Only roles assigned directly on this folder (not inherited) are re-sent.
        Dim origin As String = If(r.Value(Of String)("Origin"), "Assigned")
        If Not String.Equals(origin, "Assigned", StringComparison.OrdinalIgnoreCase) AndAlso in_Mode = "Assign" Then Continue For
        If r("Id") IsNot Nothing Then existingIds.Add(r.Value(Of Long)("Id"))
        If r("Name") IsNot Nothing Then existingNames.Add(r.Value(Of String)("Name"))
    Next
Next

If in_Mode = "Verify" Then
    For i As Integer = 0 To in_RoleIds.Count - 1
        Dim nm As String = If(in_RoleNames IsNot Nothing AndAlso i < in_RoleNames.Count, in_RoleNames(i), in_RoleIds(i).ToString(inv))
        If Not existingIds.Contains(in_RoleIds(i)) AndAlso Not existingNames.Contains(nm, StringComparer.OrdinalIgnoreCase) Then out_Missing.Add(nm)
    Next
    Return
End If

out_AlreadyAssigned = in_RoleIds.All(Function(id) existingIds.Contains(id))
Dim merged As List(Of Long) = existingIds.Union(in_RoleIds).Distinct().ToList()
Dim body As New Newtonsoft.Json.Linq.JObject(
    New Newtonsoft.Json.Linq.JProperty("assignments", New Newtonsoft.Json.Linq.JObject(
        New Newtonsoft.Json.Linq.JProperty("UserIds", New Newtonsoft.Json.Linq.JArray(in_UserId)),
        New Newtonsoft.Json.Linq.JProperty("RolesPerFolder", New Newtonsoft.Json.Linq.JArray(
            New Newtonsoft.Json.Linq.JObject(
                New Newtonsoft.Json.Linq.JProperty("FolderId", in_FolderId),
                New Newtonsoft.Json.Linq.JProperty("RoleIds", New Newtonsoft.Json.Linq.JArray(merged))))))))
out_Body = body.ToString(Newtonsoft.Json.Formatting.None)
