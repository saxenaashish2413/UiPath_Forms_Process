'ARG in in_ResponseBody S
'ARG in in_IdProperty S
'ARG in in_ValuePath S
'ARG out out_IsCollection B
'ARG out out_Count I
'ARG out out_FirstId L
'ARG out out_FirstKey S
'ARG out out_FirstItemJson S
'ARG out out_Value S
' Reads an OData collection ({"value":[...]}) or a single entity.
' out_FirstId: numeric id (Orchestrator), out_FirstKey: the id as text (Dataverse GUIDs).
' in_ValuePath: optional JSON path evaluated on the whole response, e.g. "value[0].ProcessVersion".
Dim idProp As String = If(String.IsNullOrWhiteSpace(in_IdProperty), "Id", in_IdProperty)
out_IsCollection = False
out_Count = 0
out_FirstId = 0
out_FirstKey = ""
out_FirstItemJson = ""
out_Value = ""
If String.IsNullOrWhiteSpace(in_ResponseBody) Then Return
Dim root As Newtonsoft.Json.Linq.JToken = Newtonsoft.Json.JsonConvert.DeserializeObject(Of Newtonsoft.Json.Linq.JToken)(in_ResponseBody, New Newtonsoft.Json.JsonSerializerSettings With {.DateParseHandling = Newtonsoft.Json.DateParseHandling.None})
Dim first As Newtonsoft.Json.Linq.JToken = Nothing
If root.Type = Newtonsoft.Json.Linq.JTokenType.Object AndAlso root("value") IsNot Nothing AndAlso root("value").Type = Newtonsoft.Json.Linq.JTokenType.Array Then
    out_IsCollection = True
    Dim arr As Newtonsoft.Json.Linq.JArray = CType(root("value"), Newtonsoft.Json.Linq.JArray)
    out_Count = arr.Count
    If arr.Count > 0 Then first = arr(0)
ElseIf root.Type = Newtonsoft.Json.Linq.JTokenType.Object Then
    out_Count = 1
    first = root
End If
If first IsNot Nothing AndAlso first.Type = Newtonsoft.Json.Linq.JTokenType.Object Then
    out_FirstItemJson = first.ToString(Newtonsoft.Json.Formatting.None)
    Dim idTok As Newtonsoft.Json.Linq.JToken = first(idProp)
    If idTok IsNot Nothing AndAlso idTok.Type <> Newtonsoft.Json.Linq.JTokenType.Null Then
        out_FirstKey = idTok.ToString()
        Dim n As Long
        If Long.TryParse(out_FirstKey, System.Globalization.NumberStyles.Integer, System.Globalization.CultureInfo.InvariantCulture, n) Then out_FirstId = n
    End If
End If
If Not String.IsNullOrWhiteSpace(in_ValuePath) Then
    Dim tok As Newtonsoft.Json.Linq.JToken = root.SelectToken(in_ValuePath)
    If tok IsNot Nothing AndAlso tok.Type <> Newtonsoft.Json.Linq.JTokenType.Null Then
        out_Value = If(tok.Type = Newtonsoft.Json.Linq.JTokenType.Object OrElse tok.Type = Newtonsoft.Json.Linq.JTokenType.Array, tok.ToString(Newtonsoft.Json.Formatting.None), tok.ToString())
    End If
End If
