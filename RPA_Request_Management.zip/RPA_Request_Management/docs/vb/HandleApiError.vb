'ARG in in_StatusCode I
'ARG in in_ResponseBody S
'ARG in in_Method S
'ARG in in_Url S
'ARG in in_ApiName S
'ARG in in_CorrelationId S
'ARG out out_Category S
'ARG out out_ErrorCode S
'ARG out out_ErrorMessage S
'ARG out out_IsTransient B
'ARG out out_Summary S
' Turns a failed HTTP response into a structured error. Understands the Orchestrator error body
' ({"message","errorCode","traceId"}), OData/Dataverse ({"error":{"code","message"}}), OAuth
' ({"error","error_description"}) and ASP.NET validation ({"title","errors"}) shapes.
Dim inv As System.Globalization.CultureInfo = System.Globalization.CultureInfo.InvariantCulture
out_ErrorCode = ""
out_ErrorMessage = ""
Select Case in_StatusCode
    Case 400 : out_Category = "Validation"
    Case 401 : out_Category = "Authentication"
    Case 403 : out_Category = "Authorization"
    Case 404 : out_Category = "NotFound"
    Case 409 : out_Category = "Conflict"
    Case 429 : out_Category = "Throttled"
    Case 500, 502, 503, 504 : out_Category = "ServerError"
    Case 0 : out_Category = "NoResponse"
    Case Else : out_Category = "HttpError"
End Select
out_IsTransient = New Integer() {429, 500, 502, 503, 504}.Contains(in_StatusCode)
Dim body As String = If(in_ResponseBody, "").Trim()
If body.StartsWith("{") Then
    Try
        Dim j As Newtonsoft.Json.Linq.JObject = Newtonsoft.Json.Linq.JObject.Parse(body)
        Dim errNode As Newtonsoft.Json.Linq.JToken = j("error")
        If errNode IsNot Nothing AndAlso errNode.Type = Newtonsoft.Json.Linq.JTokenType.Object Then
            out_ErrorCode = If(errNode.Value(Of String)("code"), "")
            out_ErrorMessage = If(errNode.Value(Of String)("message"), "")
        ElseIf errNode IsNot Nothing Then
            out_ErrorCode = errNode.ToString()
            out_ErrorMessage = If(j.Value(Of String)("error_description"), "")
        End If
        If out_ErrorMessage = "" AndAlso j("message") IsNot Nothing Then out_ErrorMessage = j("message").ToString()
        If out_ErrorCode = "" AndAlso j("errorCode") IsNot Nothing Then out_ErrorCode = j("errorCode").ToString()
        If out_ErrorMessage = "" AndAlso j("title") IsNot Nothing Then out_ErrorMessage = j("title").ToString()
        If j("errors") IsNot Nothing Then out_ErrorMessage = (out_ErrorMessage & " " & j("errors").ToString(Newtonsoft.Json.Formatting.None)).Trim()
        If String.IsNullOrEmpty(in_CorrelationId) AndAlso j("traceId") IsNot Nothing Then out_ErrorMessage = out_ErrorMessage & " (traceId " & j("traceId").ToString() & ")"
    Catch ex As Newtonsoft.Json.JsonReaderException
        out_ErrorMessage = Left(body, 500)
    End Try
Else
    out_ErrorMessage = Left(body, 500)
End If
' Strip anything that looks like a credential before the text reaches a log or an exception.
out_ErrorMessage = System.Text.RegularExpressions.Regex.Replace(out_ErrorMessage, "(?i)(bearer\s+)[A-Za-z0-9\-\._~\+/]+=*", "$1***")
out_ErrorMessage = System.Text.RegularExpressions.Regex.Replace(out_ErrorMessage, "(?i)(""?(password|secret|client_secret|access_token|token)""?\s*[:=]\s*)""?[^"",\s}]+""?", "$1***")
Dim path As String = in_Url
Dim q As Integer = path.IndexOf("?"c)
If q > 0 Then path = path.Substring(0, q)
out_Summary = "[" & in_ApiName & "] " & in_Method.ToUpperInvariant() & " " & path & " -> HTTP " & in_StatusCode.ToString(inv) & " " & out_Category &
    If(out_ErrorCode <> "", "; ErrorCode=" & out_ErrorCode, "") &
    If(out_ErrorMessage <> "", "; Message=" & Left(out_ErrorMessage, 600), "") &
    If(Not String.IsNullOrEmpty(in_CorrelationId), "; CorrelationId=" & in_CorrelationId, "")
