'ARG in in_UserName S
'ARG in in_UserType S
'ARG in in_Json S
'ARG out out_Url S
'ARG out out_UserId L
'ARG out out_Error S
' Finds a user, directory group or robot account in Orchestrator (GET odata/Users).
' in_UserName: DOMAIN\name, name or e-mail. in_UserType: User | Group | Robot.
' With in_Json empty it only builds the URL; with the response it picks exactly one match.
Dim full As String = in_UserName.Trim()
Dim shortName As String = If(full.Contains("\"), full.Substring(full.IndexOf("\"c) + 1), full)
Dim esc As Func(Of String, String) = Function(s) s.Replace("'", "''")
out_Url = "odata/Users?$filter=" & Uri.EscapeDataString("UserName eq '" & esc(full) & "' or UserName eq '" & esc(shortName) & "' or Name eq '" & esc(shortName) & "' or EmailAddress eq '" & esc(full) & "'") & "&$select=Id,UserName,Name,EmailAddress,Domain,Type&$top=20"
out_UserId = 0
out_Error = ""
If String.IsNullOrWhiteSpace(in_Json) Then Return
Dim allowedTypes As New Dictionary(Of String, String())(StringComparer.OrdinalIgnoreCase) From {
    {"User", New String() {"User", "DirectoryUser"}},
    {"Group", New String() {"DirectoryGroup", "Group"}},
    {"Robot", New String() {"Robot", "DirectoryRobot"}}}
If Not allowedTypes.ContainsKey(in_UserType) Then
    out_Error = "User type '" & in_UserType & "' is not User, Group or Robot."
    Return
End If
Dim types As String() = allowedTypes(in_UserType)
Dim candidates As List(Of Newtonsoft.Json.Linq.JToken) = CType(Newtonsoft.Json.Linq.JObject.Parse(in_Json)("value"), Newtonsoft.Json.Linq.JArray).Where(Function(t) types.Contains(If(t.Value(Of String)("Type"), "User"), StringComparer.OrdinalIgnoreCase)).ToList()
Dim exact As List(Of Newtonsoft.Json.Linq.JToken) = candidates.Where(Function(t) String.Equals(t.Value(Of String)("UserName"), full, StringComparison.OrdinalIgnoreCase) OrElse String.Equals(t.Value(Of String)("EmailAddress"), full, StringComparison.OrdinalIgnoreCase)).ToList()
If exact.Count = 0 Then exact = candidates.Where(Function(t) String.Equals(t.Value(Of String)("UserName"), shortName, StringComparison.OrdinalIgnoreCase) OrElse String.Equals(t.Value(Of String)("Name"), shortName, StringComparison.OrdinalIgnoreCase)).ToList()
If exact.Count = 1 Then
    out_UserId = exact(0).Value(Of Long)("Id")
ElseIf exact.Count > 1 Then
    out_Error = in_UserType & " '" & full & "' matches " & exact.Count.ToString() & " Orchestrator accounts; use DOMAIN\name."
End If
