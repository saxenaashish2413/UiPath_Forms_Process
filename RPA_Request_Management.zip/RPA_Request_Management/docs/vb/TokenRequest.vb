'ARG in in_TokenUrl S
'ARG in in_ClientId S
'ARG in in_ClientSecret SEC
'ARG in in_Scope S
'ARG in in_TimeoutSeconds I
'ARG in in_RetryCount I
'ARG in in_RetryDelaySeconds I
'ARG out out_AccessToken SEC
'ARG out out_ExpiresAtUtc DTM
' OAuth 2.0 client-credentials grant (RFC 6749 4.4), used for:
'  - UiPath Identity Server of a standalone Orchestrator: {OrchestratorURL}/identity/connect/token, scope e.g. "OR.Folders OR.Assets ..."
'  - Microsoft Entra ID for Dataverse: https://login.microsoftonline.com/{tenant}/oauth2/v2.0/token, scope "https://org.crm.dynamics.com/.default"
' POST application/x-www-form-urlencoded: grant_type=client_credentials&client_id=..&client_secret=..&scope=..
' The secret and the token only exist as SecureString outside this block; neither is logged.
' 400/401 (bad client or scope) are not retried; 429/5xx/timeouts are.
Dim maxAttempts As Integer = Math.Max(1, in_RetryCount + 1)
Dim status As Integer = 0
Dim body As String = ""
Dim lastError As String = ""
Using client As New System.Net.Http.HttpClient()
    client.Timeout = TimeSpan.FromSeconds(Math.Max(5, in_TimeoutSeconds))
    For attempt As Integer = 1 To maxAttempts
        Dim transient As Boolean = False
        Try
            Dim form As New Dictionary(Of String, String) From {
                {"grant_type", "client_credentials"},
                {"client_id", in_ClientId},
                {"client_secret", New System.Net.NetworkCredential("", in_ClientSecret).Password},
                {"scope", in_Scope}}
            Using content As New System.Net.Http.FormUrlEncodedContent(form)
                Using response As System.Net.Http.HttpResponseMessage = client.PostAsync(in_TokenUrl, content).GetAwaiter().GetResult()
                    status = CInt(response.StatusCode)
                    body = response.Content.ReadAsStringAsync().GetAwaiter().GetResult()
                End Using
            End Using
            If status = 429 OrElse status >= 500 Then
                transient = True
                lastError = "HTTP " & status.ToString()
            End If
        Catch ex As System.Net.Http.HttpRequestException
            transient = True
            lastError = ex.Message
        Catch ex As System.Threading.Tasks.TaskCanceledException
            transient = True
            lastError = "timed out"
        End Try
        If Not transient Then Exit For
        If attempt < maxAttempts Then
            System.Threading.Thread.Sleep(TimeSpan.FromSeconds(Math.Max(0, in_RetryDelaySeconds) * Math.Pow(2, attempt - 1)))
        Else
            Throw New System.Net.Http.HttpRequestException("Token request to " & in_TokenUrl & " failed after " & maxAttempts.ToString() & " attempt(s): " & lastError)
        End If
    Next
End Using
If status <> 200 Then
    Dim reason As String = Left(body, 300)
    Try
        Dim err As Newtonsoft.Json.Linq.JObject = Newtonsoft.Json.Linq.JObject.Parse(body)
        reason = (err.Value(Of String)("error") & " " & err.Value(Of String)("error_description")).Trim()
    Catch ex As Newtonsoft.Json.JsonReaderException
    End Try
    Throw New UnauthorizedAccessException("Token request to " & in_TokenUrl & " was rejected (HTTP " & status.ToString() & "): " & reason & ". Check the client ID, the client secret credential asset and the allowed scopes.")
End If
Dim tok As Newtonsoft.Json.Linq.JObject = Newtonsoft.Json.Linq.JObject.Parse(body)
Dim raw As String = tok.Value(Of String)("access_token")
If String.IsNullOrEmpty(raw) Then Throw New UnauthorizedAccessException("The token response from " & in_TokenUrl & " did not contain an access_token.")
out_AccessToken = New System.Net.NetworkCredential("", raw).SecurePassword
out_AccessToken.MakeReadOnly()
Dim expiresIn As Integer = If(tok("expires_in") Is Nothing, 3600, tok.Value(Of Integer)("expires_in"))
out_ExpiresAtUtc = DateTime.UtcNow.AddSeconds(expiresIn)
