'ARG in in_Json S
'ARG in in_ArrayPath S
'ARG in in_Property S
'ARG out out_Values LS
' Returns one property of every element of a JSON array, e.g. ("value", "objectid") on a solutioncomponents response.
out_Values = New List(Of String)
If String.IsNullOrWhiteSpace(in_Json) Then Return
Dim root As Newtonsoft.Json.Linq.JToken = Newtonsoft.Json.JsonConvert.DeserializeObject(Of Newtonsoft.Json.Linq.JToken)(in_Json, New Newtonsoft.Json.JsonSerializerSettings With {.DateParseHandling = Newtonsoft.Json.DateParseHandling.None})
Dim arr As Newtonsoft.Json.Linq.JToken = If(String.IsNullOrWhiteSpace(in_ArrayPath), root, root.SelectToken(in_ArrayPath))
If arr Is Nothing OrElse arr.Type <> Newtonsoft.Json.Linq.JTokenType.Array Then Return
For Each item As Newtonsoft.Json.Linq.JToken In arr
    Dim v As Newtonsoft.Json.Linq.JToken = If(String.IsNullOrWhiteSpace(in_Property), item, item(in_Property))
    If v IsNot Nothing AndAlso v.Type <> Newtonsoft.Json.Linq.JTokenType.Null Then out_Values.Add(v.ToString())
Next
