'ARG in in_ResponseBody S
'ARG in in_FilePath S
'ARG out out_SizeBytes L
'ARG out out_Sha256 S
' DownloadSolutionExportData returns {"ExportSolutionFile":"<base64 zip>"}. Saved to the artifact store with a SHA-256
' so the exact same managed package that went to UAT is the one promoted to PROD.
Dim j As Newtonsoft.Json.Linq.JObject = Newtonsoft.Json.Linq.JObject.Parse(in_ResponseBody)
Dim b64 As String = j.Value(Of String)("ExportSolutionFile")
If String.IsNullOrEmpty(b64) Then Throw New InvalidOperationException("DownloadSolutionExportData returned no ExportSolutionFile.")
Dim bytes As Byte() = Convert.FromBase64String(b64)
System.IO.Directory.CreateDirectory(System.IO.Path.GetDirectoryName(System.IO.Path.GetFullPath(in_FilePath)))
System.IO.File.WriteAllBytes(in_FilePath, bytes)
out_SizeBytes = bytes.LongLength
Using sha As System.Security.Cryptography.SHA256 = System.Security.Cryptography.SHA256.Create()
    out_Sha256 = BitConverter.ToString(sha.ComputeHash(bytes)).Replace("-", "").ToLowerInvariant()
End Using
System.IO.File.WriteAllText(in_FilePath & ".sha256", out_Sha256)
