'ARG in in_Exception EX
'ARG out out_Category S
'ARG out out_Status S
'ARG out out_Summary S
' Business rule exceptions (bad request data, disallowed movement, API limitation) -> Rejected.
' Everything else (API outage, auth failure, bug) -> Failed. The summary is masked and short enough for an e-mail.
Dim ex As Exception = in_Exception
While TypeOf ex Is System.Reflection.TargetInvocationException AndAlso ex.InnerException IsNot Nothing
    ex = ex.InnerException
End While
If TypeOf ex Is UiPath.Core.BusinessRuleException Then
    out_Category = "Business"
    out_Status = "Rejected"
Else
    out_Category = "System"
    out_Status = "Failed"
End If
Dim text As String = If(out_Category = "Business", ex.Message, ex.GetType().Name & ": " & ex.Message)
text = System.Text.RegularExpressions.Regex.Replace(text, "(?i)(bearer\s+)[A-Za-z0-9\-\._~\+/]+=*", "$1***")
text = System.Text.RegularExpressions.Regex.Replace(text, "(?i)((password|secret|client_secret|access_token|token)\s*[""']?\s*[:=]\s*[""']?)[^""',;\s}]+", "$1***")
out_Summary = Left(text, 1500)
