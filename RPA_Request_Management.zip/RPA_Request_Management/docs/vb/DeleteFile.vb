'ARG in in_Path S
' Removes a temporary file; a failure to delete is logged, not raised.
Try
    If System.IO.File.Exists(in_Path) Then System.IO.File.Delete(in_Path)
Catch ex As System.IO.IOException
    Console.WriteLine("Could not delete temporary file " & in_Path & ": " & ex.Message)
End Try
