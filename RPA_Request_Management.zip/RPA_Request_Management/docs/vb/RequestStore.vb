'ARG in in_StorePath S
'ARG io io_Request DSS
'ARG in in_Status S
'ARG in in_Message S
'ARG in in_Workflow S
'ARG out out_PreviousStatus S
' Request register: <store>\requests\<RequestID>.json = current request object + status history.
' Written to a temp file and swapped in, so readers never see a half-written file.
Dim allowed As String() = {"Submitted", "Validation Failed", "In Progress", "Provisioning", "Deployment In Progress", "UAT", "Production", "Completed", "Failed", "Rejected"}
Dim terminal As String() = {"Completed", "Failed", "Rejected", "Validation Failed"}
If Not allowed.Contains(in_Status) Then Throw New ArgumentException("Unknown request status '" & in_Status & "'. Allowed: " & String.Join(", ", allowed))
Dim id As String = io_Request("RequestID")
If String.IsNullOrWhiteSpace(id) Then Throw New InvalidOperationException("The request has no RequestID yet.")
Dim dir As String = System.IO.Path.Combine(in_StorePath, "requests")
System.IO.Directory.CreateDirectory(dir)
Dim file As String = System.IO.Path.Combine(dir, id & ".json")
Dim doc As Newtonsoft.Json.Linq.JObject
If System.IO.File.Exists(file) Then
    doc = Newtonsoft.Json.Linq.JObject.Parse(System.IO.File.ReadAllText(file))
Else
    doc = New Newtonsoft.Json.Linq.JObject(New Newtonsoft.Json.Linq.JProperty("history", New Newtonsoft.Json.Linq.JArray()))
End If
out_PreviousStatus = If(doc("request") Is Nothing, "", If(doc("request").Value(Of String)("Status"), ""))
If terminal.Contains(out_PreviousStatus) AndAlso out_PreviousStatus <> in_Status Then
    Throw New InvalidOperationException("Request " & id & " is already " & out_PreviousStatus & " and cannot move to " & in_Status & ".")
End If
io_Request("Status") = in_Status
io_Request("StatusMessage") = If(in_Message, "")
doc("request") = Newtonsoft.Json.Linq.JObject.FromObject(io_Request)
doc("updatedAt") = DateTime.Now.ToString("o", System.Globalization.CultureInfo.InvariantCulture)
CType(doc("history"), Newtonsoft.Json.Linq.JArray).Add(New Newtonsoft.Json.Linq.JObject(
    New Newtonsoft.Json.Linq.JProperty("at", doc("updatedAt").ToString()),
    New Newtonsoft.Json.Linq.JProperty("status", in_Status),
    New Newtonsoft.Json.Linq.JProperty("message", If(in_Message, "")),
    New Newtonsoft.Json.Linq.JProperty("workflow", If(in_Workflow, "")),
    New Newtonsoft.Json.Linq.JProperty("by", Environment.UserDomainName & "\" & Environment.UserName)))
Dim tmp As String = file & "." & Guid.NewGuid().ToString("N") & ".tmp"
System.IO.File.WriteAllText(tmp, doc.ToString(Newtonsoft.Json.Formatting.Indented), System.Text.Encoding.UTF8)
System.IO.File.Move(tmp, file, True)
