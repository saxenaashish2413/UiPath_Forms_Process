'ARG in in_EntityConfigJson S
'ARG in in_EntityName S
'ARG in in_RPATool S
'ARG in in_MovementType S
'ARG in in_AllowDevToProd B
'ARG out out_EntityContext DSS
' Resolves everything the backend needs for one Entity + RPA tool + movement:
' environments, folders, machine template, queue, asset group, BOT ID and Power Platform environment URLs.
Dim entityName As String = in_EntityName
Dim root As Newtonsoft.Json.Linq.JObject = Newtonsoft.Json.Linq.JObject.Parse(in_EntityConfigJson)
Dim e As Newtonsoft.Json.Linq.JToken = root("entities").FirstOrDefault(Function(t) String.Equals(t.Value(Of String)("Entity"), entityName, StringComparison.OrdinalIgnoreCase))
If e Is Nothing Then Throw New UiPath.Core.BusinessRuleException("Entity '" & in_EntityName & "' is not configured or not active.")
Dim moves As New Dictionary(Of String, String())(StringComparer.OrdinalIgnoreCase) From {
    {"DEV to UAT", New String() {"DEV", "UAT"}}, {"UAT to PROD", New String() {"UAT", "PROD"}}, {"DEV to PROD", New String() {"DEV", "PROD"}}}
If Not moves.ContainsKey(If(in_MovementType, "")) Then Throw New UiPath.Core.BusinessRuleException("Movement '" & in_MovementType & "' is not supported.")
Dim allowed As List(Of String) = e("AllowedMovements").Select(Function(t) t.ToString()).ToList()
If Not allowed.Contains(in_MovementType, StringComparer.OrdinalIgnoreCase) Then Throw New UiPath.Core.BusinessRuleException("Movement '" & in_MovementType & "' is not allowed for entity '" & in_EntityName & "'.")
If String.Equals(in_MovementType, "DEV to PROD", StringComparison.OrdinalIgnoreCase) AndAlso Not in_AllowDevToProd Then Throw New UiPath.Core.BusinessRuleException("DEV to PROD is disabled (Settings.AllowDevToProd = False).")
Dim src As String = moves(in_MovementType)(0)
Dim tgt As String = moves(in_MovementType)(1)
Dim envKey As New Dictionary(Of String, String) From {{"DEV", "Dev"}, {"UAT", "UAT"}, {"PROD", "Prod"}}
Dim v As Func(Of String, String) = Function(k) If(e.Value(Of String)(k), "")
Dim ctx As New Dictionary(Of String, String)(StringComparer.OrdinalIgnoreCase)
For Each p As Newtonsoft.Json.Linq.JProperty In CType(e, Newtonsoft.Json.Linq.JObject).Properties()
    If p.Value.Type <> Newtonsoft.Json.Linq.JTokenType.Array Then ctx("Entity." & p.Name) = p.Value.ToString()
Next
ctx("Entity") = v("Entity")
ctx("RPATool") = in_RPATool
ctx("MovementType") = in_MovementType
ctx("SourceEnvironment") = src
ctx("TargetEnvironment") = tgt
For i As Integer = 1 To 4
    ctx("PolicyRole" & i.ToString()) = v("PolicyRole" & i.ToString())
Next
ctx("UiPathBotID") = v("BotID")
ctx("PowerAutomateBotID") = v("PowerAutomateBotID")
ctx("BotID") = If(String.Equals(in_RPATool, "Power Automate", StringComparison.OrdinalIgnoreCase), v("PowerAutomateBotID"), v("BotID"))
ctx("SourceFolder") = v(envKey(src) & "Folder")
ctx("TargetFolder") = v(envKey(tgt) & "Folder")
ctx("SourceMachineTemplate") = v(envKey(src) & "MachineTemplate")
ctx("TargetMachineTemplate") = v(envKey(tgt) & "MachineTemplate")
ctx("QueueName") = v("QueueName")
ctx("AssetConfiguration") = v("AssetConfiguration")
ctx("PASourceEnvironmentUrl") = v("PowerAutomate" & envKey(src) & "Environment").TrimEnd("/"c)
ctx("PATargetEnvironmentUrl") = v("PowerAutomate" & envKey(tgt) & "Environment").TrimEnd("/"c)
ctx("PowerAutomateSolution") = v("PowerAutomateSolution")
ctx("NotificationEmail") = v("NotificationEmail")
out_EntityContext = ctx
