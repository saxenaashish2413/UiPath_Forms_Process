'ARG in in_Request DSS
'ARG in in_Outcome S
'ARG in in_Details DSS
'ARG out out_Subject S
'ARG out out_HtmlBody S
' HTML e-mail for Submitted / Completed / Failed / Rejected. Values are HTML-encoded; no secrets are ever in in_Details.
Dim enc As Func(Of String, String) = Function(s) System.Net.WebUtility.HtmlEncode(If(s, ""))
Dim r As Dictionary(Of String, String) = in_Request
Dim pick As Func(Of String, String) = Function(k) If(r.ContainsKey(k), r(k), "")
Dim colors As New Dictionary(Of String, String) From {{"Completed", "#067647"}, {"Submitted", "#0B3D91"}, {"Failed", "#B42318"}, {"Rejected", "#B54708"}}
Dim color As String = If(colors.ContainsKey(in_Outcome), colors(in_Outcome), "#344054")
out_Subject = "[" & pick("RequestID") & "] " & pick("RPATool") & " " & pick("MovementType") & " for " & pick("Entity") & " - " & in_Outcome
Dim rows As New System.Text.StringBuilder()
Dim keys As String() = {"RequestID", "Entity", "RPATool", "ProcessType", "ProcessName", "MovementType", "Priority", "BotID", "SelectedPolicyRoles", "PackageName", "PackageVersion", "SolutionName", "RequesterName", "SubmissionDate", "Status"}
For Each k As String In keys
    If pick(k) <> "" Then rows.Append("<tr><td style='padding:4px 12px 4px 0;color:#5B6B82'>" & enc(k) & "</td><td style='padding:4px 0'>" & enc(pick(k)) & "</td></tr>")
Next
If in_Details IsNot Nothing Then
    For Each kv As KeyValuePair(Of String, String) In in_Details
        rows.Append("<tr><td style='padding:4px 12px 4px 0;color:#5B6B82'>" & enc(kv.Key) & "</td><td style='padding:4px 0'>" & enc(kv.Value) & "</td></tr>")
    Next
End If
out_HtmlBody = "<div style='font-family:Segoe UI,Arial,sans-serif;font-size:14px;color:#101828'>" &
    "<div style='border-left:4px solid " & color & ";padding:8px 12px;background:#F8FAFC;margin-bottom:12px'><b>" & enc(in_Outcome) & "</b> &middot; " & enc(pick("StatusMessage")) & "</div>" &
    "<table style='border-collapse:collapse'>" & rows.ToString() & "</table>" &
    "<p style='color:#5B6B82;font-size:12px'>Sent by the RPA Request Management robot. Do not reply.</p></div>"
