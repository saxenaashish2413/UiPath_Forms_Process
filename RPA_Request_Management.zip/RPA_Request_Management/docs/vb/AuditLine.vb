'ARG in in_Request DSS
'ARG in in_Workflow S
'ARG in in_Operation S
'ARG in in_Status S
'ARG in in_Level S
'ARG in in_Message S
'ARG in in_AuditFolder S
'ARG out out_LogLine S
' One structured audit record per major step: written to the robot log (via Log Message) and appended to
' <AuditFolder>\audit-yyyyMMdd.jsonl. Secrets are masked before anything is written.
Dim inv As System.Globalization.CultureInfo = System.Globalization.CultureInfo.InvariantCulture
Dim r As Dictionary(Of String, String) = If(in_Request, New Dictionary(Of String, String))
Dim pick As Func(Of String, String) = Function(k) If(r.ContainsKey(k), r(k), "")
Dim msg As String = If(in_Message, "")
msg = System.Text.RegularExpressions.Regex.Replace(msg, "(?i)(bearer\s+)[A-Za-z0-9\-\._~\+/]+=*", "$1***")
msg = System.Text.RegularExpressions.Regex.Replace(msg, "(?i)((password|secret|client_secret|access_token|token|apikey)\s*[""']?\s*[:=]\s*[""']?)[^""',;\s}]+", "$1***")
Dim o As New Newtonsoft.Json.Linq.JObject(
    New Newtonsoft.Json.Linq.JProperty("timestamp", DateTime.Now.ToString("o", inv)),
    New Newtonsoft.Json.Linq.JProperty("level", If(in_Level, "Info")),
    New Newtonsoft.Json.Linq.JProperty("requestId", pick("RequestID")),
    New Newtonsoft.Json.Linq.JProperty("entity", pick("Entity")),
    New Newtonsoft.Json.Linq.JProperty("rpaTool", pick("RPATool")),
    New Newtonsoft.Json.Linq.JProperty("processType", pick("ProcessType")),
    New Newtonsoft.Json.Linq.JProperty("sourceEnvironment", pick("SourceEnvironment")),
    New Newtonsoft.Json.Linq.JProperty("targetEnvironment", pick("TargetEnvironment")),
    New Newtonsoft.Json.Linq.JProperty("workflow", If(in_Workflow, "")),
    New Newtonsoft.Json.Linq.JProperty("operation", If(in_Operation, "")),
    New Newtonsoft.Json.Linq.JProperty("status", If(in_Status, "")),
    New Newtonsoft.Json.Linq.JProperty("message", msg),
    New Newtonsoft.Json.Linq.JProperty("robot", Environment.MachineName & "\" & Environment.UserName))
out_LogLine = o.ToString(Newtonsoft.Json.Formatting.None)
If Not String.IsNullOrWhiteSpace(in_AuditFolder) Then
    System.IO.Directory.CreateDirectory(in_AuditFolder)
    Dim file As String = System.IO.Path.Combine(in_AuditFolder, "audit-" & DateTime.Now.ToString("yyyyMMdd", inv) & ".jsonl")
    For attempt As Integer = 1 To 5
        Try
            System.IO.File.AppendAllText(file, out_LogLine & Environment.NewLine, System.Text.Encoding.UTF8)
            Exit For
        Catch ex As System.IO.IOException When attempt < 5
            System.Threading.Thread.Sleep(200 * attempt)
        End Try
    Next
End If
