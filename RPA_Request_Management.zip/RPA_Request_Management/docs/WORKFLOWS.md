# Workflows and arguments

Generated from the XAML files. Types are XAML type names (x:String = String, scg:Dictionary = Dictionary, s:Security.SecureString = SecureString).

## Main.xaml

Entry point. Loads configuration and entities, shows the UiPath Form until it validates (or is cancelled), creates the Request ID, runs the backend (provisioning + code movement) and shows the final status. Pass in_RequestJson to run unattended without the form.

| Argument | Direction | Type | Description |
|---|---|---|---|
| in_ConfigPath | In | `x:String` | Default: Config\Config.xlsx in the project folder. |
| in_RequestJson | In | `x:String` | Optional: form-shaped JSON for unattended runs (no form shown). |
| out_RequestID | Out | `x:String` |  |
| out_Status | Out | `x:String` |  |

## Forms\RPARequestForm.xaml

Shows the UiPath Form with Show Form (Continue workflow execution = Off) and Forms\RPARequestForm.uiform. Bindings: In FormInputJson = in_FormInputJson, Out FormOutputJson = out_FormOutputJson. All dynamic behaviour runs inside the form.

| Argument | Direction | Type | Description |
|---|---|---|---|
| in_FormInputJson | In | `x:String` | Initial data: entity catalogue, logo, user, previous values, validation message. |
| in_EntityConfigJson | In | `x:String` |  |
| in_LogoDataUri | In | `x:String` |  |
| in_ValidationMessage | In | `x:String` |  |
| out_FormOutputJson | Out | `x:String` |  |
| out_Dismissed | Out | `x:Boolean` |  |
| out_SelectedButton | Out | `x:String` |  |

## Workflows\WF_AddOrchestratorUser.xaml

Ensures a user / group / robot account exists in Orchestrator, gives it access to the folder and assigns roles: the four policy roles via WF_AssignRoles, or explicit Orchestrator roles (used for the BOT robot account).

| Argument | Direction | Type | Description |
|---|---|---|---|
| in_Config | In | `scg:Dictionary(x:String, x:Object)` | Configuration dictionary from GetConfiguration.xaml. |
| in_ApiContext | In | `scg:Dictionary(x:String, x:Object)` | API context from WF_GetOrchestratorToken / WF_GetPowerPlatformToken (base URL, token as SecureString, timeouts). |
| in_Request | In | `scg:Dictionary(x:String, x:String)` | Request object (for audit fields RequestID, Entity, RPATool, ...). |
| in_UserName | In | `x:String` |  |
| in_UserType | In | `x:String` | User \| Group \| Robot |
| in_FolderID | In | `x:Int64` |  |
| in_PolicyRoles | In | `scg:List(x:String)` | Policy roles (mapped through the Roles sheet). |
| in_DirectRoleNames | In | `scg:List(x:String)` | Orchestrator folder roles used as-is (BOT). |
| in_Environment | In | `x:String` |  |
| out_UserID | Out | `x:Int64` |  |
| out_AssignedRoleIDs | Out | `scg:List(x:Int64)` |  |

## Workflows\WF_AssignRoles.xaml

Maps the policy roles chosen in the form to Orchestrator roles (Roles sheet, per environment) and grants them on the folder / tenant.

| Argument | Direction | Type | Description |
|---|---|---|---|
| in_Config | In | `scg:Dictionary(x:String, x:Object)` | Configuration dictionary from GetConfiguration.xaml. |
| in_ApiContext | In | `scg:Dictionary(x:String, x:Object)` | API context from WF_GetOrchestratorToken / WF_GetPowerPlatformToken (base URL, token as SecureString, timeouts). |
| in_Request | In | `scg:Dictionary(x:String, x:String)` | Request object (for audit fields RequestID, Entity, RPATool, ...). |
| in_UserID | In | `x:Int64` |  |
| in_FolderID | In | `x:Int64` |  |
| in_RoleNames | In | `scg:List(x:String)` | Policy role names from the form. |
| in_Environment | In | `x:String` |  |
| out_Success | Out | `x:Boolean` |  |
| out_AssignedRoleIDs | Out | `scg:List(x:Int64)` |  |

## Workflows\WF_CreateMachineTemplate.xaml

Ensures the entity machine template of the target environment exists (Machines sheet row or '*' default) and is associated with the target folder.

| Argument | Direction | Type | Description |
|---|---|---|---|
| in_Config | In | `scg:Dictionary(x:String, x:Object)` | Configuration dictionary from GetConfiguration.xaml. |
| in_ApiContext | In | `scg:Dictionary(x:String, x:Object)` | API context from WF_GetOrchestratorToken / WF_GetPowerPlatformToken (base URL, token as SecureString, timeouts). |
| in_Request | In | `scg:Dictionary(x:String, x:String)` | Request object (for audit fields RequestID, Entity, RPATool, ...). |
| in_MachineTemplateName | In | `x:String` |  |
| in_Environment | In | `x:String` |  |
| in_FolderID | In | `x:Int64` |  |
| in_Entity | In | `x:String` |  |
| in_BotID | In | `x:String` |  |
| out_MachineTemplateID | Out | `x:Int64` |  |

## Workflows\WF_CreateOrchestratorAssets.xaml

Creates/updates the entity's asset set (Assets sheet group = entity AssetConfiguration) in the target folder. Credential/Secret values are copied from vault credential assets and never logged.

| Argument | Direction | Type | Description |
|---|---|---|---|
| in_Config | In | `scg:Dictionary(x:String, x:Object)` | Configuration dictionary from GetConfiguration.xaml. |
| in_ApiContext | In | `scg:Dictionary(x:String, x:Object)` | API context from WF_GetOrchestratorToken / WF_GetPowerPlatformToken (base URL, token as SecureString, timeouts). |
| in_Request | In | `scg:Dictionary(x:String, x:String)` | Request object (for audit fields RequestID, Entity, RPATool, ...). |
| in_EntityContext | In | `scg:Dictionary(x:String, x:String)` |  |
| in_FolderID | In | `x:Int64` |  |
| in_Environment | In | `x:String` |  |
| out_AssetIDs | Out | `scg:Dictionary(x:String, x:String)` | Asset name -> Id |
| out_Count | Out | `x:Int32` |  |

## Workflows\WF_CreateOrchestratorFolder.xaml

Idempotently ensures a folder path (e.g. UAT/Entity A/Finance) exists, creating each missing level, and returns the Folder ID of the last level.

| Argument | Direction | Type | Description |
|---|---|---|---|
| in_Config | In | `scg:Dictionary(x:String, x:Object)` | Configuration dictionary from GetConfiguration.xaml. |
| in_ApiContext | In | `scg:Dictionary(x:String, x:Object)` | API context from WF_GetOrchestratorToken / WF_GetPowerPlatformToken (base URL, token as SecureString, timeouts). |
| in_Request | In | `scg:Dictionary(x:String, x:String)` | Request object (for audit fields RequestID, Entity, RPATool, ...). |
| in_FolderName | In | `x:String` | Folder name or path, levels separated by '/'. |
| in_ParentFolderID | In | `x:Int64` | 0 = start at the top. |
| in_Description | In | `x:String` |  |
| in_Environment | In | `x:String` |  |
| in_Entity | In | `x:String` |  |
| out_FolderID | Out | `x:Int64` |  |

## Workflows\WF_CreateOrchestratorQueue.xaml

Ensures the entity queue exists in the target folder with the settings of the Queues sheet (row for the queue, or the '*' default row).

| Argument | Direction | Type | Description |
|---|---|---|---|
| in_Config | In | `scg:Dictionary(x:String, x:Object)` | Configuration dictionary from GetConfiguration.xaml. |
| in_ApiContext | In | `scg:Dictionary(x:String, x:Object)` | API context from WF_GetOrchestratorToken / WF_GetPowerPlatformToken (base URL, token as SecureString, timeouts). |
| in_Request | In | `scg:Dictionary(x:String, x:String)` | Request object (for audit fields RequestID, Entity, RPATool, ...). |
| in_QueueName | In | `x:String` |  |
| in_Description | In | `x:String` |  |
| in_FolderID | In | `x:Int64` |  |
| in_Entity | In | `x:String` |  |
| out_QueueID | Out | `x:Int64` |  |

## Workflows\WF_CreateRequestID.xaml

Generates the Request ID, stores it on the request object and registers the request as Submitted.

| Argument | Direction | Type | Description |
|---|---|---|---|
| in_Config | In | `scg:Dictionary(x:String, x:Object)` | Configuration dictionary from GetConfiguration.xaml. |
| io_Request | In/Out | `scg:Dictionary(x:String, x:String)` | Request object; Status/StatusMessage are updated in place. |
| out_RequestID | Out | `x:String` |  |

## Workflows\WF_LoadEntityConfiguration.xaml

Resolves the selected entity for the chosen RPA tool and movement: policy roles, BOT ID, source/target environment, folders, machine template, queue, asset group, Power Platform environment URLs.

| Argument | Direction | Type | Description |
|---|---|---|---|
| in_Config | In | `scg:Dictionary(x:String, x:Object)` | Configuration dictionary from GetConfiguration.xaml. |
| in_EntityConfigJson | In | `x:String` |  |
| in_Entity | In | `x:String` |  |
| in_RPATool | In | `x:String` |  |
| in_MovementType | In | `x:String` |  |
| out_EntityContext | Out | `scg:Dictionary(x:String, x:String)` |  |

## Workflows\WF_MovePowerAutomateCode.xaml

Promotes a Power Automate solution DEV -> UAT or UAT -> PROD with the Dataverse Web API: export (from DEV, or reuse the DEV artifact for UAT -> PROD), import with environment variables and connection references, re-apply/verify both, turn flows on, validate. Rollback: API limitation (a managed solution cannot be downgraded); fix forward or uninstall.

| Argument | Direction | Type | Description |
|---|---|---|---|
| in_Config | In | `scg:Dictionary(x:String, x:Object)` | Configuration dictionary from GetConfiguration.xaml. |
| in_Request | In | `scg:Dictionary(x:String, x:String)` | Request object (for audit fields RequestID, Entity, RPATool, ...). |
| in_EntityContext | In | `scg:Dictionary(x:String, x:String)` |  |
| out_DeploymentStatus | Out | `x:String` |  |
| out_DeploymentMessage | Out | `x:String` |  |
| out_SolutionVersion | Out | `x:String` |  |

## Workflows\WF_MoveUiPathCode.xaml

Promotes a UiPath process DEV -> UAT or UAT -> PROD through the Orchestrator API: source/target folder, package version (given, or the one running in the source folder), package availability (transferred between feeds when needed), create/update the process in the target folder, verify, roll back on failed verification.

| Argument | Direction | Type | Description |
|---|---|---|---|
| in_Config | In | `scg:Dictionary(x:String, x:Object)` | Configuration dictionary from GetConfiguration.xaml. |
| in_Request | In | `scg:Dictionary(x:String, x:String)` | Request object (for audit fields RequestID, Entity, RPATool, ...). |
| in_EntityContext | In | `scg:Dictionary(x:String, x:String)` |  |
| in_TargetContext | In | `scg:Dictionary(x:String, x:Object)` | Target Orchestrator context. |
| in_Entity | In | `x:String` |  |
| in_ProcessName | In | `x:String` |  |
| in_SourceEnvironment | In | `x:String` |  |
| in_TargetEnvironment | In | `x:String` |  |
| in_FolderID | In | `x:Int64` | Target folder (from provisioning). |
| in_PackageName | In | `x:String` |  |
| in_Version | In | `x:String` | Empty = version running in the source folder. |
| out_DeploymentStatus | Out | `x:String` | Deployed \| AlreadyDeployed |
| out_DeploymentMessage | Out | `x:String` |  |
| out_PackageVersion | Out | `x:String` |  |

## Workflows\WF_ProcessRequest.xaml

End-to-end backend for one validated request: entity resolution, provisioning (folder, assets, queue, machine template, user, policy roles, BOT), code movement for the selected tool, statuses and completion e-mail. Can also run unattended (second entry point).

| Argument | Direction | Type | Description |
|---|---|---|---|
| in_Config | In | `scg:Dictionary(x:String, x:Object)` | Configuration dictionary from GetConfiguration.xaml. |
| io_Request | In/Out | `scg:Dictionary(x:String, x:String)` | Request object; Status/StatusMessage are updated in place. |
| in_EntityConfigJson | In | `x:String` |  |
| out_FinalStatus | Out | `x:String` |  |
| out_Summary | Out | `x:String` |  |

## Workflows\WF_SendNotification.xaml

E-mails the requester (and the CoE / entity mailbox in Cc) through SMTP. A failure to send is logged as a warning and never fails the request.

| Argument | Direction | Type | Description |
|---|---|---|---|
| in_Config | In | `scg:Dictionary(x:String, x:Object)` | Configuration dictionary from GetConfiguration.xaml. |
| in_Request | In | `scg:Dictionary(x:String, x:String)` | Request object (for audit fields RequestID, Entity, RPATool, ...). |
| in_Outcome | In | `x:String` | Submitted \| Completed \| Failed \| Rejected |
| in_Details | In | `scg:Dictionary(x:String, x:String)` |  |
| in_Cc | In | `x:String` | Extra recipients, e.g. the entity mailbox. |

## Workflows\WF_ShowRequestForm.xaml

Prepares the form data (entity catalogue, configurable logo as Base64 data URI, current user, previous values and server-side validation messages) and shows the form.

| Argument | Direction | Type | Description |
|---|---|---|---|
| in_Config | In | `scg:Dictionary(x:String, x:Object)` | Configuration dictionary from GetConfiguration.xaml. |
| in_EntityConfigJson | In | `x:String` |  |
| in_CurrentUser | In | `scg:Dictionary(x:String, x:String)` |  |
| in_PrefillJson | In | `x:String` | Previous submission when re-showing after validation errors. |
| in_ValidationMessage | In | `x:String` |  |
| out_FormOutputJson | Out | `x:String` |  |
| out_Cancelled | Out | `x:Boolean` |  |

## Workflows\WF_UpdateRequestStatus.xaml

Sets the request status (Submitted, Validation Failed, In Progress, Provisioning, Deployment In Progress, UAT, Production, Completed, Failed, Rejected), persists it with history and audits it.

| Argument | Direction | Type | Description |
|---|---|---|---|
| in_Config | In | `scg:Dictionary(x:String, x:Object)` | Configuration dictionary from GetConfiguration.xaml. |
| io_Request | In/Out | `scg:Dictionary(x:String, x:String)` | Request object; Status/StatusMessage are updated in place. |
| in_Status | In | `x:String` |  |
| in_Message | In | `x:String` |  |
| in_Workflow | In | `x:String` |  |

## Workflows\WF_ValidateRequest.xaml

Validates the submitted form on the server (mandatory fields, formats, entity/movement/role rules, anti-tampering) and builds the request object.

| Argument | Direction | Type | Description |
|---|---|---|---|
| in_Config | In | `scg:Dictionary(x:String, x:Object)` | Configuration dictionary from GetConfiguration.xaml. |
| in_FormOutputJson | In | `x:String` |  |
| in_EntityConfigJson | In | `x:String` |  |
| in_CurrentUser | In | `scg:Dictionary(x:String, x:String)` |  |
| out_IsValid | Out | `x:Boolean` |  |
| out_Request | Out | `scg:Dictionary(x:String, x:String)` |  |
| out_ValidationMessage | Out | `x:String` |  |

## Orchestrator\WF_AddUser.xaml

Finds a user / directory group / robot account (GET odata/Users). When missing: directory users and groups are added to the folder with POST odata/Folders/UiPath.Server.Configuration.OData.AssignDomainUser; robot accounts can be created with POST identity/api/RobotAccount. API limitation: no documented API creates LOCAL users on standalone 2025.10, so that case stops with a clear message.

| Argument | Direction | Type | Description |
|---|---|---|---|
| in_ApiContext | In | `scg:Dictionary(x:String, x:Object)` | API context from WF_GetOrchestratorToken / WF_GetPowerPlatformToken (base URL, token as SecureString, timeouts). |
| in_UserName | In | `x:String` | DOMAIN\name, e-mail or robot account name. |
| in_UserType | In | `x:String` | User \| Group \| Robot |
| in_FolderID | In | `x:Int64` |  |
| in_FolderRoleIds | In | `scg:List(x:Int64)` | Roles used when the directory account is added to the folder. |
| in_AllowDirectoryAdd | In | `x:Boolean` |  |
| in_DefaultDomain | In | `x:String` |  |
| in_IdentityContext | In | `scg:Dictionary(x:String, x:Object)` | Identity API context (only for robot account creation). |
| in_PartitionGlobalId | In | `x:String` | Organization ID for Identity API. |
| out_UserID | Out | `x:Int64` |  |
| out_Created | Out | `x:Boolean` |  |

## Orchestrator\WF_AssignRoles.xaml

Grants roles to an Orchestrator user/group/robot without removing what it already has. Folder roles: GetUsersForFolder -> merge -> POST Folders/AssignUsers -> verify. Tenant roles: GET Users(<id>)?$select=RolesList -> merge -> POST Users(<id>)/AssignRoles (that call replaces the list, hence the merge).

| Argument | Direction | Type | Description |
|---|---|---|---|
| in_ApiContext | In | `scg:Dictionary(x:String, x:Object)` | API context from WF_GetOrchestratorToken / WF_GetPowerPlatformToken (base URL, token as SecureString, timeouts). |
| in_UserID | In | `x:Int64` |  |
| in_FolderID | In | `x:Int64` |  |
| in_FolderRoleNames | In | `scg:List(x:String)` |  |
| in_TenantRoleNames | In | `scg:List(x:String)` |  |
| out_AssignedRoleIDs | Out | `scg:List(x:Int64)` |  |
| out_Success | Out | `x:Boolean` |  |

## Orchestrator\WF_CreateAsset.xaml

Idempotent asset create/update in a folder. GET odata/Assets?$filter=Name eq '...' (folder header) -> POST odata/Assets or PUT odata/Assets(<Id>) when UpdateIfExists. Secret values are only in the request body, which is never logged.

| Argument | Direction | Type | Description |
|---|---|---|---|
| in_ApiContext | In | `scg:Dictionary(x:String, x:Object)` | API context from WF_GetOrchestratorToken / WF_GetPowerPlatformToken (base URL, token as SecureString, timeouts). |
| in_FolderID | In | `x:Int64` |  |
| in_AssetName | In | `x:String` |  |
| in_AssetType | In | `x:String` | Text \| Bool \| Integer \| JSON \| Credential \| Secret |
| in_Value | In | `x:String` | Value for Text/Bool/Integer/JSON. |
| in_SecretUser | In | `x:String` | Credential username. |
| in_SecretValue | In | `ss:SecureString` | Credential password / secret. |
| in_UpdateIfExists | In | `x:Boolean` |  |
| in_Description | In | `x:String` |  |
| in_SecretMode | In | `x:String` | Settings.SecretAssetMode |
| out_AssetID | Out | `x:Int64` |  |
| out_Action | Out | `x:String` | Created \| Updated \| Unchanged |

## Orchestrator\WF_CreateFolder.xaml

Idempotent folder creation under a parent: GET odata/Folders?$filter=DisplayName eq '<name>' and ParentId eq <id|null>; if missing POST odata/Folders {DisplayName, Description, ProvisionType: Automatic, PermissionModel: FineGrained, ParentId}. HTTP 409 (created concurrently) is resolved by reading it again.

| Argument | Direction | Type | Description |
|---|---|---|---|
| in_ApiContext | In | `scg:Dictionary(x:String, x:Object)` | API context from WF_GetOrchestratorToken / WF_GetPowerPlatformToken (base URL, token as SecureString, timeouts). |
| in_FolderName | In | `x:String` | Display name of ONE folder level. |
| in_ParentFolderID | In | `x:Int64` | 0 = top level. |
| in_Description | In | `x:String` |  |
| out_FolderID | Out | `x:Int64` |  |
| out_Created | Out | `x:Boolean` |  |

## Orchestrator\WF_CreateMachine.xaml

Idempotent machine template: GET odata/Machines?$filter=Name eq '...' -> POST odata/Machines {Name, Description, Type: Template, UnattendedSlots, NonProductionSlots}; then assigns it to the folder with POST odata/Folders/UiPath.Server.Configuration.OData.AssignMachines unless GetAssignedMachines already lists it.

| Argument | Direction | Type | Description |
|---|---|---|---|
| in_ApiContext | In | `scg:Dictionary(x:String, x:Object)` | API context from WF_GetOrchestratorToken / WF_GetPowerPlatformToken (base URL, token as SecureString, timeouts). |
| in_MachineName | In | `x:String` |  |
| in_Description | In | `x:String` |  |
| in_UnattendedSlots | In | `x:Int32` |  |
| in_NonProductionSlots | In | `x:Int32` |  |
| in_FolderID | In | `x:Int64` | Folder to associate, 0 = none. |
| out_MachineID | Out | `x:Int64` |  |
| out_Created | Out | `x:Boolean` |  |

## Orchestrator\WF_CreateQueue.xaml

Idempotent queue creation. GET odata/QueueDefinitions?$filter=Name eq '...' (folder header) -> POST odata/QueueDefinitions {Name, Description, MaxNumberOfRetries, AcceptAutomaticallyRetry, EnforceUniqueReference}. Existing queues are not changed; differing settings are logged as a warning.

| Argument | Direction | Type | Description |
|---|---|---|---|
| in_ApiContext | In | `scg:Dictionary(x:String, x:Object)` | API context from WF_GetOrchestratorToken / WF_GetPowerPlatformToken (base URL, token as SecureString, timeouts). |
| in_FolderID | In | `x:Int64` |  |
| in_QueueName | In | `x:String` |  |
| in_Description | In | `x:String` |  |
| in_MaxNumberOfRetries | In | `x:Int32` |  |
| in_AcceptAutomaticallyRetry | In | `x:Boolean` |  |
| in_EnforceUniqueReference | In | `x:Boolean` |  |
| out_QueueID | Out | `x:Int64` |  |
| out_Created | Out | `x:Boolean` |  |

## Orchestrator\WF_DeployRelease.xaml

Creates or updates the process (release) in a folder to an exact package version and verifies it. GET odata/Releases?$filter=ProcessKey eq '<pkg>' and Name eq '<name>' -> POST odata/Releases (new) or POST Releases(<id>)/UiPath.Server.Configuration.OData.UpdateToSpecificPackageVersion {packageVersion}. If verification fails after an update it rolls back to the previous version.

| Argument | Direction | Type | Description |
|---|---|---|---|
| in_ApiContext | In | `scg:Dictionary(x:String, x:Object)` | API context from WF_GetOrchestratorToken / WF_GetPowerPlatformToken (base URL, token as SecureString, timeouts). |
| in_FolderID | In | `x:Int64` |  |
| in_ProcessName | In | `x:String` | Process (release) name in the folder. |
| in_PackageId | In | `x:String` |  |
| in_Version | In | `x:String` |  |
| in_Description | In | `x:String` |  |
| out_ReleaseID | Out | `x:Int64` |  |
| out_PreviousVersion | Out | `x:String` |  |
| out_Action | Out | `x:String` | Created \| Updated \| AlreadyDeployed |

## Orchestrator\WF_GetFolder.xaml

Finds a folder by full path (FullyQualifiedName, e.g. UAT/Entity A). Read-only. GET odata/Folders?$filter=FullyQualifiedName eq '...'

| Argument | Direction | Type | Description |
|---|---|---|---|
| in_ApiContext | In | `scg:Dictionary(x:String, x:Object)` | API context from WF_GetOrchestratorToken / WF_GetPowerPlatformToken (base URL, token as SecureString, timeouts). |
| in_FolderPath | In | `x:String` |  |
| out_FolderID | Out | `x:Int64` | 0 when the folder does not exist. |

## Orchestrator\WF_GetOrchestratorToken.xaml

Authenticates to the Orchestrator of one environment (DEV/UAT/PROD) with OAuth client credentials (External Application). Client ID and token URL come from the Environments sheet; the client secret is the Password of an Orchestrator credential asset. Returns an API context: BaseUrl, AccessToken (SecureString), expiry, tenant, timeouts, retry settings.

| Argument | Direction | Type | Description |
|---|---|---|---|
| in_Config | In | `scg:Dictionary(x:String, x:Object)` | Configuration dictionary from GetConfiguration.xaml. |
| in_Environment | In | `x:String` | DEV \| UAT \| PROD |
| in_Purpose | In | `x:String` | Orchestrator (default, OR.* scopes) or Identity (Identity Server API, PM.* scopes). |
| out_ApiContext | Out | `scg:Dictionary(x:String, x:Object)` |  |

## Orchestrator\WF_GetRoleIds.xaml

Resolves Orchestrator role names to IDs and types (Tenant / Folder / Mixed) with GET odata/Roles. Role IDs are never hard-coded.

| Argument | Direction | Type | Description |
|---|---|---|---|
| in_ApiContext | In | `scg:Dictionary(x:String, x:Object)` | API context from WF_GetOrchestratorToken / WF_GetPowerPlatformToken (base URL, token as SecureString, timeouts). |
| in_RoleNames | In | `scg:List(x:String)` |  |
| out_RoleIds | Out | `scg:List(x:Int64)` |  |
| out_RoleTypes | Out | `scg:List(x:String)` |  |

## Orchestrator\WF_TransferPackage.xaml

Makes a package version available in the target feed. Checks GET Processes/GetProcessVersions(processId='<id>') in the target; if absent, verifies it in the source, downloads it (GET Processes/DownloadPackage(key='<id>:<version>')) and uploads it (POST Processes/UploadPackage, multipart field 'file'). When DEV/UAT/PROD share one tenant feed this is a no-op.

| Argument | Direction | Type | Description |
|---|---|---|---|
| in_SourceContext | In | `scg:Dictionary(x:String, x:Object)` |  |
| in_TargetContext | In | `scg:Dictionary(x:String, x:Object)` |  |
| in_PackageId | In | `x:String` |  |
| in_Version | In | `x:String` |  |
| in_SourceFolderID | In | `x:Int64` | For folder-level feeds. |
| in_TargetFolderID | In | `x:Int64` |  |
| in_TempFolder | In | `x:String` |  |
| out_Action | Out | `x:String` | AlreadyInTargetFeed \| Uploaded |

## PowerAutomate\WF_ActivateFlows.xaml

Turns on the cloud flows of a solution: solutioncomponents (componenttype 29) -> workflows(<id>) with category 5 and statecode 0 -> PATCH {statecode: 1, statuscode: 2}.

| Argument | Direction | Type | Description |
|---|---|---|---|
| in_ApiContext | In | `scg:Dictionary(x:String, x:Object)` | API context from WF_GetOrchestratorToken / WF_GetPowerPlatformToken (base URL, token as SecureString, timeouts). |
| in_SolutionName | In | `x:String` |  |
| out_Activated | Out | `x:Int32` |  |
| out_Failures | Out | `scg:List(x:String)` |  |

## PowerAutomate\WF_AssignSecurityRoles.xaml

Grants Dataverse security roles (mapped from the policy roles) to a user in the target environment: systemusers by domainname -> roles by name in the root business unit -> POST systemusers(<id>)/systemuserroles_association/$ref. API limitation: users must already be synchronised from Entra ID into the environment.

| Argument | Direction | Type | Description |
|---|---|---|---|
| in_ApiContext | In | `scg:Dictionary(x:String, x:Object)` | API context from WF_GetOrchestratorToken / WF_GetPowerPlatformToken (base URL, token as SecureString, timeouts). |
| in_UserPrincipalName | In | `x:String` |  |
| in_RoleNames | In | `scg:List(x:String)` |  |
| out_Assigned | Out | `scg:List(x:String)` |  |

## PowerAutomate\WF_ExportSolution.xaml

Exports a solution from the source environment: POST ExportSolutionAsync {SolutionName, Managed} -> wait for the async operation -> POST DownloadSolutionExportData {ExportJobId} -> zip saved to the artifact store with SHA-256. API limitation: a MANAGED solution cannot be exported.

| Argument | Direction | Type | Description |
|---|---|---|---|
| in_Config | In | `scg:Dictionary(x:String, x:Object)` | Configuration dictionary from GetConfiguration.xaml. |
| in_ApiContext | In | `scg:Dictionary(x:String, x:Object)` | API context from WF_GetOrchestratorToken / WF_GetPowerPlatformToken (base URL, token as SecureString, timeouts). |
| in_SolutionName | In | `x:String` |  |
| in_Managed | In | `x:Boolean` |  |
| in_ArtifactFolder | In | `x:String` |  |
| out_SolutionVersion | Out | `x:String` |  |
| out_FilePath | Out | `x:String` |  |
| out_Sha256 | Out | `x:String` |  |

## PowerAutomate\WF_GetPowerPlatformToken.xaml

Microsoft Entra ID client-credentials token for one Dataverse environment (scope <environment URL>/.default). Tenant ID and client ID from Settings; the client secret is the Password of an Orchestrator credential asset. The app registration must be an application user with a security role in every environment.

| Argument | Direction | Type | Description |
|---|---|---|---|
| in_Config | In | `scg:Dictionary(x:String, x:Object)` | Configuration dictionary from GetConfiguration.xaml. |
| in_EnvironmentUrl | In | `x:String` | e.g. https://enta-uat.crm4.dynamics.com |
| out_ApiContext | Out | `scg:Dictionary(x:String, x:Object)` |  |

## PowerAutomate\WF_GetSolution.xaml

Reads a solution by unique name: GET solutions?$filter=uniquename eq '<name>'&$select=solutionid,uniquename,version,ismanaged

| Argument | Direction | Type | Description |
|---|---|---|---|
| in_ApiContext | In | `scg:Dictionary(x:String, x:Object)` | API context from WF_GetOrchestratorToken / WF_GetPowerPlatformToken (base URL, token as SecureString, timeouts). |
| in_SolutionName | In | `x:String` |  |
| out_Exists | Out | `x:Boolean` |  |
| out_SolutionId | Out | `x:String` |  |
| out_Version | Out | `x:String` |  |
| out_IsManaged | Out | `x:Boolean` |  |

## PowerAutomate\WF_ImportSolution.xaml

Imports a solution zip into the target environment: POST ImportSolutionAsync {OverwriteUnmanagedCustomizations, PublishWorkflows, CustomizationFile (base64), ImportJobId, ComponentParameters (environment variable values + connection references)} -> wait. Skips the import when the same or a newer version is installed (idempotent).

| Argument | Direction | Type | Description |
|---|---|---|---|
| in_Config | In | `scg:Dictionary(x:String, x:Object)` | Configuration dictionary from GetConfiguration.xaml. |
| in_ApiContext | In | `scg:Dictionary(x:String, x:Object)` | API context from WF_GetOrchestratorToken / WF_GetPowerPlatformToken (base URL, token as SecureString, timeouts). |
| in_SolutionFilePath | In | `x:String` |  |
| in_SolutionName | In | `x:String` |  |
| in_SolutionVersion | In | `x:String` |  |
| in_ComponentParametersJson | In | `x:String` |  |
| in_OverwriteUnmanagedCustomizations | In | `x:Boolean` |  |
| in_PublishWorkflows | In | `x:Boolean` |  |
| out_Action | Out | `x:String` | Imported \| AlreadyInstalled |

## PowerAutomate\WF_UpdateConnectionReferences.xaml

Points connection references at the target environment's connections: GET connectionreferences?$filter=connectionreferencelogicalname eq '...' -> PATCH connectionreferences(<id>) {connectionid}. API limitation: the connections themselves must exist (created by a service account); OAuth connections cannot be created through the API.

| Argument | Direction | Type | Description |
|---|---|---|---|
| in_ApiContext | In | `scg:Dictionary(x:String, x:Object)` | API context from WF_GetOrchestratorToken / WF_GetPowerPlatformToken (base URL, token as SecureString, timeouts). |
| in_ConnectionReferencesJson | In | `x:String` |  |
| out_Changed | Out | `x:Int32` |  |

## PowerAutomate\WF_UpdateEnvironmentVariables.xaml

Sets environment variable values in the target: GET environmentvariabledefinitions?$filter=schemaname eq '...'&$expand=environmentvariabledefinition_environmentvariablevalue; PATCH environmentvariablevalues(<id>) {value} or POST environmentvariablevalues {schemaname, value, EnvironmentVariableDefinitionId@odata.bind}.

| Argument | Direction | Type | Description |
|---|---|---|---|
| in_ApiContext | In | `scg:Dictionary(x:String, x:Object)` | API context from WF_GetOrchestratorToken / WF_GetPowerPlatformToken (base URL, token as SecureString, timeouts). |
| in_VariablesJson | In | `x:String` | [{"schemaname":"...","value":"..."}] |
| out_Changed | Out | `x:Int32` |  |

## PowerAutomate\WF_ValidateDeployment.xaml

Post-deployment checks in the target: solution version, every cloud flow on, connection references bound, environment variable values as configured.

| Argument | Direction | Type | Description |
|---|---|---|---|
| in_ApiContext | In | `scg:Dictionary(x:String, x:Object)` | API context from WF_GetOrchestratorToken / WF_GetPowerPlatformToken (base URL, token as SecureString, timeouts). |
| in_SolutionName | In | `x:String` |  |
| in_ExpectedVersion | In | `x:String` |  |
| in_EnvironmentVariablesJson | In | `x:String` |  |
| in_ConnectionReferencesJson | In | `x:String` |  |
| in_RequireFlowsOn | In | `x:Boolean` |  |
| out_IsValid | Out | `x:Boolean` |  |
| out_Problems | Out | `scg:List(x:String)` |  |

## PowerAutomate\WF_WaitForAsyncOperation.xaml

Polls GET asyncoperations(<id>)?$select=statecode,statuscode,message,friendlymessage until statecode = 3 (Completed). statuscode 30 = Succeeded, 31 = Failed, 32 = Canceled.

| Argument | Direction | Type | Description |
|---|---|---|---|
| in_ApiContext | In | `scg:Dictionary(x:String, x:Object)` | API context from WF_GetOrchestratorToken / WF_GetPowerPlatformToken (base URL, token as SecureString, timeouts). |
| in_AsyncOperationId | In | `x:String` |  |
| in_OperationName | In | `x:String` |  |
| in_PollSeconds | In | `x:Int32` |  |
| in_TimeoutMinutes | In | `x:Int32` |  |
| out_Succeeded | Out | `x:Boolean` |  |
| out_Message | Out | `x:String` |  |

## Framework\Exceptions\WF_HandleException.xaml

Central exception handler: business rule -> Rejected, anything else -> Failed. Logs (masked), updates the request status and e-mails the requester. Never throws itself.

| Argument | Direction | Type | Description |
|---|---|---|---|
| in_Config | In | `scg:Dictionary(x:String, x:Object)` | Configuration dictionary from GetConfiguration.xaml. |
| in_Exception | In | `s:Exception` |  |
| io_Request | In/Out | `scg:Dictionary(x:String, x:String)` | Request object; Status/StatusMessage are updated in place. |
| in_Workflow | In | `x:String` |  |
| out_Status | Out | `x:String` |  |
| out_Summary | Out | `x:String` |  |

## Framework\Logging\SetLogContext.xaml

Adds RequestID, Entity, RPATool, ProcessType, SourceEnvironment and TargetEnvironment as custom log fields, so every later log line of the job carries them (searchable in Orchestrator/Kibana).

| Argument | Direction | Type | Description |
|---|---|---|---|
| in_Request | In | `scg:Dictionary(x:String, x:String)` | Request object (for audit fields RequestID, Entity, RPATool, ...). |

## Framework\Utilities\GenerateRequestID.xaml

Reserves the next Request ID <Prefix>-<yyyy>-<NNNNN> in the request store (safe with several robots).

| Argument | Direction | Type | Description |
|---|---|---|---|
| in_StorePath | In | `x:String` |  |
| in_Prefix | In | `x:String` |  |
| out_RequestID | Out | `x:String` |  |

## Framework\Utilities\GetConfiguration.xaml

Reads Config.xlsx (all sheets) into one dictionary: settings as Config("Name"), environments as Config("UAT.OrchestratorURL"), tables as Config("Table.Roles").

| Argument | Direction | Type | Description |
|---|---|---|---|
| in_ConfigPath | In | `x:String` | Full path of Config.xlsx. |
| out_Config | Out | `scg:Dictionary(x:String, x:Object)` |  |

## Framework\Utilities\GetCurrentUser.xaml

Current Windows user and, on domain machines, display name, e-mail and employee ID from Active Directory.

| Argument | Direction | Type | Description |
|---|---|---|---|
| out_User | Out | `scg:Dictionary(x:String, x:String)` | UserName, Domain, Account, DisplayName, Email, EmployeeID |

## Framework\Utilities\GetEntityConfiguration.xaml

Loads the entity catalogue from EntityConfiguration.json (EntityConfigurationSource = Json) or the Entities sheet (Excel) and validates it.

| Argument | Direction | Type | Description |
|---|---|---|---|
| in_Config | In | `scg:Dictionary(x:String, x:Object)` | Configuration dictionary from GetConfiguration.xaml. |
| out_EntityConfigJson | Out | `x:String` | {}{"entities":[...]} normalised. |
| out_EntityNames | Out | `scg:List(x:String)` |  |

## Framework\Utilities\GetToken.xaml

OAuth 2.0 client-credentials token for UiPath Identity Server or Microsoft Entra ID. Secret in, token out, both SecureString; nothing sensitive is logged.

| Argument | Direction | Type | Description |
|---|---|---|---|
| in_TokenUrl | In | `x:String` | Token endpoint. |
| in_ClientId | In | `x:String` | Confidential client / app registration ID. |
| in_ClientSecret | In | `ss:SecureString` | Client secret read from an Orchestrator credential asset. |
| in_Scope | In | `x:String` | Space separated scopes. |
| in_TimeoutSeconds | In | `x:Int32` |  |
| in_RetryCount | In | `x:Int32` |  |
| in_RetryDelaySeconds | In | `x:Int32` |  |
| out_AccessToken | Out | `ss:SecureString` | Bearer token (SecureString). |
| out_ExpiresAtUtc | Out | `s:DateTime` |  |

## Framework\Utilities\HandleApiError.xaml

Classifies a failed HTTP response (400/401/403/404/409/429/5xx), extracts API error code, message and correlation ID, logs it and (optionally) throws.

| Argument | Direction | Type | Description |
|---|---|---|---|
| in_StatusCode | In | `x:Int32` |  |
| in_ResponseBody | In | `x:String` |  |
| in_Method | In | `x:String` |  |
| in_Url | In | `x:String` |  |
| in_ApiName | In | `x:String` |  |
| in_CorrelationId | In | `x:String` |  |
| in_ThrowOnError | In | `x:Boolean` | True = throw after logging. |
| out_Category | Out | `x:String` | Validation \| Authentication \| Authorization \| NotFound \| Conflict \| Throttled \| ServerError \| HttpError |
| out_ErrorCode | Out | `x:String` |  |
| out_ErrorMessage | Out | `x:String` |  |
| out_IsTransient | Out | `x:Boolean` |  |
| out_Summary | Out | `x:String` |  |

## Framework\Utilities\ParseApiResponse.xaml

Reads an OData collection or entity: item count, first Id (numeric or GUID), first item JSON and any value by JSON path.

| Argument | Direction | Type | Description |
|---|---|---|---|
| in_ResponseBody | In | `x:String` |  |
| in_IdProperty | In | `x:String` | Default Id; Dataverse e.g. solutionid. |
| in_ValuePath | In | `x:String` | Optional JSON path, e.g. value[0].ProcessVersion. |
| out_IsCollection | Out | `x:Boolean` |  |
| out_Count | Out | `x:Int32` |  |
| out_FirstId | Out | `x:Int64` |  |
| out_FirstKey | Out | `x:String` |  |
| out_FirstItemJson | Out | `x:String` |  |
| out_Value | Out | `x:String` |  |

## Framework\Utilities\SendApiRequest.xaml

Every REST call goes through here: URL, headers (Authorization: Bearer, Accept/Content-Type: application/json, X-UIPATH-OrganizationUnitId), token refresh, retry of 429/5xx with back-off, structured error handling and safe logging.

| Argument | Direction | Type | Description |
|---|---|---|---|
| in_ApiContext | In | `scg:Dictionary(x:String, x:Object)` | API context from WF_GetOrchestratorToken / WF_GetPowerPlatformToken (base URL, token as SecureString, timeouts). |
| in_Method | In | `x:String` | GET / POST / PUT / PATCH / DELETE |
| in_RelativeUrl | In | `x:String` | Relative to the context BaseUrl (e.g. odata/Folders?$filter=...) or absolute. |
| in_Body | In | `x:String` | JSON body or empty. |
| in_FolderID | In | `x:Int64` | Orchestrator folder (X-UIPATH-OrganizationUnitId), 0 = none. |
| in_AcceptStatusCodes | In | `x:String` | Non-2xx codes the caller handles itself, e.g. "404,409". |
| in_LogBody | In | `x:Boolean` | False for bodies that contain secrets or binary data. |
| in_UploadFilePath | In | `x:String` | Send this file as multipart/form-data field 'file'. |
| in_DownloadFilePath | In | `x:String` | Save a 2xx response body to this file. |
| out_StatusCode | Out | `x:Int32` |  |
| out_ResponseBody | Out | `x:String` |  |
| out_CorrelationId | Out | `x:String` |  |

## Framework\Utilities\WriteAuditLog.xaml

Structured audit record (RequestID, Entity, RPA Tool, Process Type, Source/Target Environment, Workflow, Operation, Status) to the robot log and the audit file. Secrets are masked.

| Argument | Direction | Type | Description |
|---|---|---|---|
| in_Config | In | `scg:Dictionary(x:String, x:Object)` | Configuration dictionary from GetConfiguration.xaml. |
| in_Request | In | `scg:Dictionary(x:String, x:String)` | Request object (for audit fields RequestID, Entity, RPATool, ...). |
| in_Workflow | In | `x:String` |  |
| in_Operation | In | `x:String` |  |
| in_Status | In | `x:String` |  |
| in_Level | In | `x:String` | Info \| Warn \| Error |
| in_Message | In | `x:String` |  |
