# RPA_Request_Management

UiPath Studio 2025.10.17 project (Windows, VB.NET) for RPA requests and code movement:

* one dynamic **UiPath Form** (entity-driven roles, BOT ID, folders, machine template, queue, assets, Power Automate environments; UiPath / Power Automate and New / Enhancement / Bug Fix sections; DEV → UAT, UAT → PROD, DEV → PROD only when configured),
* server-side validation, Request ID `RPA-yyyy-NNNNN`, request register, audit log and e-mail notifications,
* provisioning in standalone **Orchestrator 2025.10** through its REST API (folder, assets, queue, machine template, user and BOT robot account with roles),
* code movement: **UiPath** packages and processes between Orchestrators, **Power Automate** solutions between Dataverse environments (export, import, environment variables, connection references, flows on, validation).

## Quick start

1. Open `project.json` in Studio 2025.10.17 and let it restore UiPath.System.Activities 26.2.7, UiPath.Excel.Activities 3.4.1 and UiPath.Form.Activities 25.10.0.
2. Fill `Config/Config.xlsx` (Environments, Settings) and `Config/EntityConfiguration.json`. Replace `Config/company-logo.svg` with your logo or point `CompanyLogoPath` to it.
3. Create the Orchestrator credential assets listed in `docs/SOLUTION_GUIDE.md` section 4. No secret ever goes in the workbook; the robot refuses to start if one does.
4. Run `Main.xaml`. For unattended runs pass the form JSON in `in_RequestJson`.

## The form

`Forms/RPARequestForm.uiform` is the form and `Forms/RPARequestForm.xaml` shows it with **Show Form** (Continue workflow execution = Off). Nothing to set up: double-click the `.uiform` to open it in the Form Designer. Show Form binds two keys only:

* `FormInputJson`, In: entity catalogue, logo, requester, previous values and validation message. The form unpacks it itself.
* `FormOutputJson`, Out: the whole submission as JSON, with `FormAction = "Cancel"` for the Cancel button. Closing the window leaves it empty, which is treated as Cancel.

If Studio ever says it cannot find the form, select `RPARequestForm` again in the Show Form activity's form list.

Read `docs/SOLUTION_GUIDE.md` for the architecture, every API call, the API limitations, the test results and the production checklist, and `docs/WORKFLOWS.md` for every workflow with its arguments.
