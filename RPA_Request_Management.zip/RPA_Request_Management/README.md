# RPA_Request_Management

UiPath Studio 2025.10.17 project (Windows, VB.NET) for RPA requests and code movement:

* one dynamic **UiPath Form** (entity-driven roles, BOT ID, folders, machine template, queue, assets, Power Automate environments; UiPath / Power Automate and New / Enhancement / Bug Fix sections; DEV → UAT, UAT → PROD, DEV → PROD only when configured),
* server-side validation, Request ID `RPA-yyyy-NNNNN`, request register, audit log and e-mail notifications,
* provisioning in standalone **Orchestrator 2025.10** through its REST API (folder, assets, queue, machine template, user and BOT robot account with roles),
* code movement: **UiPath** packages and processes between Orchestrators, **Power Automate** solutions between Dataverse environments (export, import, environment variables, connection references, flows on, validation).

## Quick start

1. Open `project.json` in Studio 2025.10.17 and let it restore UiPath.System.Activities 26.2.7, UiPath.Excel.Activities 3.4.1 and UiPath.Form.Activities 25.10.2.
2. Open `Forms/RPARequestForm.xaml` → Create Form → Open Form Designer → import `Forms/RPARequestForm.form.json` → Save.
3. Fill `Config/Config.xlsx` (Environments, Settings) and `Config/EntityConfiguration.json`. Replace `Config/company-logo.svg` with your logo or point `CompanyLogoPath` to it.
4. Create the Orchestrator credential assets listed in `docs/SOLUTION_GUIDE.md` section 4. No secret ever goes in the workbook; the robot refuses to start if one does.
5. Run `Main.xaml`. For unattended runs pass the form JSON in `in_RequestJson`.

Read `docs/SOLUTION_GUIDE.md` for the architecture, every API call, the API limitations, the test results and the production checklist, and `docs/WORKFLOWS.md` for every workflow with its arguments.
