# RPA Automation Management

A UiPath Forms based request and deployment solution for UiPath and Power Automate automations.

A requester picks the Automation Tool (UiPath or Power Automate), the Process Type (New, Enhancement or Bug Fix), the deployment path (Dev to UAT or UAT to Prod) and a Bot ID, then clicks **Fetch Details**. The robot resolves the Bot ID through a configuration file or, if it is not listed there, finds it in the Dev Orchestrator or Dev Dataverse environment; it then reads the real state from the Orchestrator (2025.10, standalone) or Dataverse REST APIs through UiPath's HTTP Request activity, and shows it in the form. The requester reviews it, edits what is allowed, validates and submits. Every submission becomes an auditable request in an Orchestrator queue. Dev to UAT can deploy straight away. UAT to Prod waits for an approval from someone other than the requester.

## What is in this folder

| Item | What it is |
|---|---|
| `RPA_Automation_Management/` | The UiPath Studio project (Windows, VB.NET). Open `project.json` in Studio 25.10. |
| `RPA_Automation_Management/Form/AutomationManagement.uiform` | The UiPath Form (Forms 25.10). |
| `RPA_Automation_Management/Config/Settings.json` | Environments, authentication, timeouts and retries, approvals, role mappings and deployment rules. This is a template with `<...>` placeholders. |
| `RPA_Automation_Management/Config/BotMapping.json` | The Bot ID mapping (optional template; Bot IDs not listed here are looked up in Dev). |
| `RPA_Automation_Management/docs/WORKFLOWS.md` | Every workflow with its arguments. |
| `SOLUTION_GUIDE.md` | Setup, API list, permission checklist, governance, test evidence and what is still to be verified. **Start here.** |
| `verification/` | Test logs, form screenshots, and the generator and test sources. |
| `RPA_Automation_Management.zip` | Everything above in one file. |

## Entry points

| Entry point | Who runs it | What it does |
|---|---|---|
| `Main.xaml` | Requester (attended) | Opens the form. Fetch, edit, validate and submit. |
| `ExecuteDeployment.xaml` | Unattended robot or operator | Executes one submitted request by reference. For Prod it checks the approval again. |
| `ApproveRequest.xaml` | Approver (attended) | Records Approved or Rejected for a request. Approving does not deploy. |

## Status

Everything was built and tested **offline**. There was no access to a real Orchestrator, Dataverse or Studio.

* All 40 XAML files load with the real UiPath.System.Activities 26.2.7, UiPath.Form.Activities 25.10.0, UiPath.WebAPI.Activities 2.4.0 and UiPath.Platform 25.10 assemblies, and every VB expression compiles (`verification/xaml-validation.log`).
* The form runs in Chromium with the form.io bundle shipped in UiPath.Studio.Forms.Runtime 25.10.0: 57 of 57 checks pass (`verification/form-browser-tests.log`).
* The workflow logic was tested end to end against **mock** Orchestrator, Identity Server, Entra ID and Dataverse APIs: 93 of 93 checks pass (`verification/workflow-tests.log`). These are mocked results, not results from your environments.

Orchestrator sign-in uses the tenant name with an Orchestrator username and password kept in a Credential asset (standalone `api/Account/Authenticate`); an external application can be used instead per environment.

Before using it for real, follow the "First run in your environment" steps in `SOLUTION_GUIDE.md`. Nothing in this solution has been run against a production system.
