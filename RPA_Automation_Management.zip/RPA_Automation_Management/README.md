# RPA_Automation_Management (UiPath Studio project)

Entry points:
- `Main.xaml`: the requester opens the form.
- `ExecuteDeployment.xaml`: executes a submitted request.
- `ApproveRequest.xaml`: the approver records a decision.

Folders:

| Folder | Contents |
|---|---|
| `Form/` | AutomationManagement.uiform and its controller workflow |
| `Framework/` | Configuration, access tokens, REST calls with the HTTP Request activity (Send_Http_Request.xaml), API error handling, paging, audit |
| `Providers/UiPath/` | Orchestrator 2025.10 REST: Dev discovery, fetch, deploy package, assets, queues, access |
| `Providers/PowerAutomate/` | Dataverse Web API: Dev discovery, solution details, flows, export and import |
| `Requests/` | Validation, submission, approval checks, execution and results (governance queues) |
| `Config/` | Settings.json and BotMapping.json (templates; no secrets; the mapping is optional when Dev discovery is on) |
| `Data/` | Audit files and stored managed solutions, created at run time |
| `docs/WORKFLOWS.md` | Every workflow and its arguments |

Setup, permissions, test evidence and the first-run checklist are in `SOLUTION_GUIDE.md`, next to this project folder.
