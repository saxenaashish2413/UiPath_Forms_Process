Created at run time. Keep out of source control: audit files and managed solution files are written here.
