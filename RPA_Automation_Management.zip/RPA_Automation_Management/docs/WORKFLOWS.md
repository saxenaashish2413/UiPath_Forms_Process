# Workflows

Generated from the same model that renders the XAML files, so arguments here match the files.

## (entry points)

### Main.xaml

Requester entry point (attended): loads the configuration and opens the Automation Management form. Submitting creates an auditable request; only Dev to UAT (when settings allow) is deployed straight away; Prod always waits for approval and ExecuteDeployment.xaml.

| Direction | Argument | Type | Description |
|---|---|---|---|
| In | `in_SettingsPath` | String | Settings file; empty = Config\Settings.json. |
| In | `in_BotMappingPath` | String | Bot ID mapping; empty = Config\BotMapping.json. |
| Out | `out_Outcome` | String | Cancelled / Submitted / Deployed / DeploymentFailed / ConfigurationError |
| Out | `out_RequestReference` | String | Reference of the submitted request, if any. |

### ExecuteDeployment.xaml

Deployment entry point (unattended or operator): executes one submitted request by reference after re-validating it, including the approval and previous-stage checks for Prod. The job faults when the request is rejected or fails, so Orchestrator shows it; the outcome is also in the results queue and the audit file.

| Direction | Argument | Type | Description |
|---|---|---|---|
| In | `in_SettingsPath` | String | Settings file; empty = Config\Settings.json. |
| In | `in_BotMappingPath` | String | Bot ID mapping; empty = Config\BotMapping.json. |
| In | `in_RequestReference` | String | Request reference (AM/...). |
| Out | `out_Status` | String | Succeeded / AlreadyDeployed / Rejected / Failed |
| Out | `out_Message` | String | Outcome. |

### ApproveRequest.xaml

Approver entry point (attended): records Approved or Rejected for a submitted request in the approvals queue (reference APR|<request reference>). Only approvers listed for the target environment may decide, never the requester (segregation of duties), and a request is decided once. Approving does not deploy.

| Direction | Argument | Type | Description |
|---|---|---|---|
| In | `in_SettingsPath` | String | Settings file; empty = Config\Settings.json. |
| In | `in_BotMappingPath` | String | Bot ID mapping; empty = Config\BotMapping.json. |
| In | `in_RequestReference` | String | Request reference (AM/...). |
| In | `in_Decision` | String | Approved / Rejected |
| In | `in_Comment` | String | Reason / CAB reference. |
| Out | `out_Message` | String | Outcome. |

## Form

### Form/Automation_Form_Controller.xaml

Shows Form\AutomationManagement.uiform (Show Form with 'Continue workflow execution' = On) and reacts to its buttons and selection changes with a Trigger Scope: Fetch Details, Edit Configuration, Validate, Submit Request, Cancel, and Automation Tool / Process Type / Deployment Path changes. Business logic lives in Requests\ and Providers\; this workflow only moves values between the form and them.

| Direction | Argument | Type | Description |
|---|---|---|---|
| In | `in_Config` | JObject | Settings + bot mapping from Framework\Load_Configuration.xaml. |
| In | `in_Session` | Dictionary(Of String, Object) | Run context shared by all workflows: token cache, user, request reference, step list. Never persisted. |
| In | `in_RequestedBy` | String | Requester (DOMAIN\user). |
| Out | `out_Outcome` | String | Cancelled / Submitted / Deployed / DeploymentFailed |
| Out | `out_RequestReference` | String | Reference of the submitted request. |

## Framework

### Framework/Load_Configuration.xaml

Reads Config\Settings.json and Config\BotMapping.json, merges them and checks the structure. Returns a message instead of throwing so the caller can tell the user; no credentials are read here.

| Direction | Argument | Type | Description |
|---|---|---|---|
| In | `in_SettingsPath` | String | Settings file (absolute or relative to the project folder). |
| In | `in_BotMappingPath` | String | Bot ID mapping file. |
| Out | `out_Config` | JObject | Merged configuration; Nothing when out_ErrorMessage is set. |
| Out | `out_ErrorMessage` | String | Empty when usable. |

### Framework/Get_Access_Token.xaml

Returns a bearer token for one provider and environment. UiPath, per environment (settings authMode): UsernamePassword = standalone Orchestrator POST {orchestrator}/api/Account/Authenticate with tenancyName, usernameOrEmailAddress and password (Credential asset: Username = Orchestrator user, Password = its password; token valid for tokenLifetimeMinutes), or ClientCredentials = Identity Server {orchestrator}/identity/connect/token (Credential asset: Username = client ID, Password = client secret). Power Automate: Microsoft Entra ID client credentials. The token is cached in in_Session only and never logged; the password is never logged or stored.

| Direction | Argument | Type | Description |
|---|---|---|---|
| In | `in_Config` | JObject | Settings + bot mapping from Framework\Load_Configuration.xaml. |
| In | `in_Session` | Dictionary(Of String, Object) | Run context shared by all workflows: token cache, user, request reference, step list. Never persisted. |
| In | `in_Provider` | String | UiPath / PowerAutomate |
| In | `in_Environment` | String | Dev / UAT / Prod |
| Out | `out_AccessToken` | System.Security.SecureString | Bearer token. |

### Framework/Handle_API_Exception.xaml

Classifies a failed HTTP response and throws the matching exception: 401/403 -> UnauthorizedAccessException (never retried), 400/404/409 -> BusinessRuleException, everything else -> Exception. The message carries method, path, status, error code and correlation ID, with anything that looks like a credential masked.

| Direction | Argument | Type | Description |
|---|---|---|---|
| In | `in_StatusCode` | Integer | HTTP status. |
| In | `in_ResponseBody` | String | Response body. |
| In | `in_Method` | String | HTTP method. |
| In | `in_Url` | String | Request URL (query string is dropped from the message). |
| In | `in_ApiName` | String | Operation name for the log. |
| In | `in_CorrelationId` | String | Server correlation ID. |

### Framework/Send_Http_Request.xaml

Sends one REST call with the UiPath HTTP Request activity (UiPath.WebAPI.Activities). Bearer token authentication, the given headers, JSON body (POST/PUT/PATCH), multipart upload (field 'file') or download to a file. Transient failures (408, 429, 500, 502, 503, 504 and connection errors) are retried by the activity with exponential back-off and Retry-After. Other statuses are returned to the caller, never thrown here. Nothing is logged here.

| Direction | Argument | Type | Description |
|---|---|---|---|
| In | `in_Method` | String | GET, POST, PUT, PATCH or DELETE. |
| In | `in_Url` | String | Absolute URL. |
| In | `in_Headers` | Dictionary(Of String, String) | Request headers (Accept, tenant, folder, ...). |
| In | `in_AccessToken` | System.Security.SecureString | Bearer token (HTTP Request authentication: OAuth token). |
| In | `in_Body` | String | JSON body; empty for none. |
| In | `in_UploadFilePath` | String | File sent as multipart field 'file'; empty for none. |
| In | `in_DownloadFilePath` | String | Save the response to this file; empty for none. |
| In | `in_TimeoutSeconds` | Integer | Timeout for the call including retries. |
| In | `in_RetryCount` | Integer | Retries after the first attempt. |
| In | `in_RetryDelaySeconds` | Integer | First retry delay. |
| Out | `out_StatusCode` | Integer | HTTP status; 0 = no response (timeout). |
| Out | `out_ResponseBody` | String | Response text. |
| Out | `out_CorrelationId` | String | Server correlation/request ID header. |
| Out | `out_DurationMs` | Long | Duration. |

### Framework/Send_Api_Request.xaml

Single entry point for every Orchestrator and Dataverse call. Resolves the environment URL, adds the bearer token, the folder header (X-UIPATH-OrganizationUnitId) and the tenant header, sends the call with the UiPath HTTP Request activity (Framework\Send_Http_Request.xaml, which retries only transient failures), re-authenticates once on 401, logs method/path/status/duration (never bodies or tokens) and hands non-accepted error statuses to Handle_API_Exception.xaml.

| Direction | Argument | Type | Description |
|---|---|---|---|
| In | `in_Config` | JObject | Settings + bot mapping from Framework\Load_Configuration.xaml. |
| In | `in_Session` | Dictionary(Of String, Object) | Run context shared by all workflows: token cache, user, request reference, step list. Never persisted. |
| In | `in_Provider` | String | UiPath / PowerAutomate |
| In | `in_Environment` | String | Dev / UAT / Prod |
| In | `in_Method` | String | GET, POST, PUT, PATCH or DELETE. |
| In | `in_Url` | String | Path relative to the environment base URL (e.g. odata/Assets?...) or an absolute URL (paging links). |
| In | `in_FolderId` | Long | Orchestrator folder ID for folder-scoped calls; 0 = none. |
| In | `in_Body` | String | JSON body; empty for none. Never logged. |
| In | `in_ApiName` | String | Operation name for logs and errors. |
| In | `in_AcceptStatuses` | String | Comma-separated non-2xx statuses the caller handles itself, e.g. "404,409". |
| In | `in_UploadFilePath` | String | File sent as multipart field 'file' (package upload); empty for none. |
| In | `in_DownloadFilePath` | String | Save a 2xx response body to this file (package download); empty for none. |
| Out | `out_StatusCode` | Integer | HTTP status. |
| Out | `out_ResponseBody` | String | Response body. |

### Framework/Get_OData_Collection.xaml

Reads every page of an OData collection. Orchestrator: $top/$skip with settings.http.pageSize until a short page. Dataverse: follows @odata.nextLink. Stops at settings.http.maxPages with a warning.

| Direction | Argument | Type | Description |
|---|---|---|---|
| In | `in_Config` | JObject | Settings + bot mapping from Framework\Load_Configuration.xaml. |
| In | `in_Session` | Dictionary(Of String, Object) | Run context shared by all workflows: token cache, user, request reference, step list. Never persisted. |
| In | `in_Provider` | String | UiPath / PowerAutomate |
| In | `in_Environment` | String | Dev / UAT / Prod |
| In | `in_Url` | String | Relative collection URL, may already contain $filter/$select (no $top/$skip). |
| In | `in_FolderId` | Long | Folder header; 0 = none. |
| In | `in_ApiName` | String | Operation name. |
| In | `in_PageMode` | String | skip (Orchestrator) / nextLink (Dataverse) |
| In | `in_AcceptNotFound` | Boolean | True: HTTP 404 returns an empty list instead of failing. |
| Out | `out_Items` | JArray | All items. |

### Framework/Write_Audit_Log.xaml

Writes one audit record (JSON line in settings.audit.folder, robot log line and the run's step list). Request reference, Bot ID and user come from in_Session. Never pass secret values.

| Direction | Argument | Type | Description |
|---|---|---|---|
| In | `in_Config` | JObject | Settings + bot mapping from Framework\Load_Configuration.xaml. |
| In | `in_Session` | Dictionary(Of String, Object) | Run context shared by all workflows: token cache, user, request reference, step list. Never persisted. |
| In | `in_Operation` | String | What was done, e.g. 'UAT asset INV_ApiBaseUrl'. |
| In | `in_Status` | String | Started / Succeeded / NoChange / Failed / Rejected / Submitted / Approved ... |
| In | `in_Message` | String | Safe, human-readable detail. |
| In | `in_Data` | JObject | Optional structured detail (no secrets); Nothing for none. |

## Providers

### Providers/UiPath/Get_Folder.xaml

Finds a folder by its full path. GET odata/Folders?$filter=FullyQualifiedName eq '<path>'. out_FolderId = 0 when the folder does not exist or the API account cannot see it.

| Direction | Argument | Type | Description |
|---|---|---|---|
| In | `in_Config` | JObject | Settings + bot mapping from Framework\Load_Configuration.xaml. |
| In | `in_Session` | Dictionary(Of String, Object) | Run context shared by all workflows: token cache, user, request reference, step list. Never persisted. |
| In | `in_Environment` | String | Dev / UAT / Prod |
| In | `in_FolderPath` | String | Full folder path, e.g. Finance/Invoice. |
| Out | `out_FolderId` | Long | Folder ID or 0. |
| Out | `out_FolderJson` | String | Folder record (JSON) or empty. |

### Providers/UiPath/Get_Process_Details.xaml

Reads a process (release) in a folder by name. GET odata/Releases?$filter=Name eq '<name>' with the folder header.

| Direction | Argument | Type | Description |
|---|---|---|---|
| In | `in_Config` | JObject | Settings + bot mapping from Framework\Load_Configuration.xaml. |
| In | `in_Session` | Dictionary(Of String, Object) | Run context shared by all workflows: token cache, user, request reference, step list. Never persisted. |
| In | `in_Environment` | String | Dev / UAT / Prod |
| In | `in_FolderId` | Long | Orchestrator folder ID (sent as X-UIPATH-OrganizationUnitId). |
| In | `in_ProcessName` | String | Process (release) name. |
| Out | `out_ReleaseJson` | String | Release record (Id, Key, Name, ProcessKey, ProcessVersion, Description) or empty. |

### Providers/UiPath/Get_Package_Details.xaml

Lists the versions of a package in the environment's feed. GET odata/Processes/UiPath.Server.Configuration.OData.GetProcessVersions(processId='<packageId>') (plus ?feedId=<guid> when settings uipath.environments.<env>.feedId is set for a folder feed). A package that is not in the feed returns an empty list.

| Direction | Argument | Type | Description |
|---|---|---|---|
| In | `in_Config` | JObject | Settings + bot mapping from Framework\Load_Configuration.xaml. |
| In | `in_Session` | Dictionary(Of String, Object) | Run context shared by all workflows: token cache, user, request reference, step list. Never persisted. |
| In | `in_Environment` | String | Dev / UAT / Prod |
| In | `in_PackageId` | String | Package ID (NuGet ID). |
| Out | `out_VersionsJson` | String | JSON array of {Key, Version, Published, IsLatestVersion}. |

### Providers/UiPath/Get_Asset_Details.xaml

Lists the assets of a folder WITHOUT credential fields: GET odata/Assets?$select=Id,Name,ValueType,ValueScope,StringValue,IntValue,BoolValue,Description (folder header, paged). Credential usernames/passwords are never requested.

| Direction | Argument | Type | Description |
|---|---|---|---|
| In | `in_Config` | JObject | Settings + bot mapping from Framework\Load_Configuration.xaml. |
| In | `in_Session` | Dictionary(Of String, Object) | Run context shared by all workflows: token cache, user, request reference, step list. Never persisted. |
| In | `in_Environment` | String | Dev / UAT / Prod |
| In | `in_FolderId` | Long | Orchestrator folder ID (sent as X-UIPATH-OrganizationUnitId). |
| Out | `out_AssetsJson` | String | JSON array of assets. |

### Providers/UiPath/Get_Queue_Details.xaml

Lists the queues of a folder: GET odata/QueueDefinitions?$select=Id,Name,Description,MaxNumberOfRetries,AcceptAutomaticallyRetry,EnforceUniqueReference (folder header, paged).

| Direction | Argument | Type | Description |
|---|---|---|---|
| In | `in_Config` | JObject | Settings + bot mapping from Framework\Load_Configuration.xaml. |
| In | `in_Session` | Dictionary(Of String, Object) | Run context shared by all workflows: token cache, user, request reference, step list. Never persisted. |
| In | `in_Environment` | String | Dev / UAT / Prod |
| In | `in_FolderId` | Long | Orchestrator folder ID (sent as X-UIPATH-OrganizationUnitId). |
| Out | `out_QueuesJson` | String | JSON array of queue definitions. |

### Providers/UiPath/Get_User_Access.xaml

Users, groups and robot accounts with roles on a folder: GET odata/Folders/UiPath.Server.Configuration.OData.GetUsersForFolder(key=<folderId>,includeInherited=<bool>)?$expand=UserEntity,Roles (paged).

| Direction | Argument | Type | Description |
|---|---|---|---|
| In | `in_Config` | JObject | Settings + bot mapping from Framework\Load_Configuration.xaml. |
| In | `in_Session` | Dictionary(Of String, Object) | Run context shared by all workflows: token cache, user, request reference, step list. Never persisted. |
| In | `in_Environment` | String | Dev / UAT / Prod |
| In | `in_FolderId` | Long | Orchestrator folder ID (sent as X-UIPATH-OrganizationUnitId). |
| In | `in_IncludeInherited` | Boolean | True to include access inherited from parent folders (display); False for direct assignments (merging). |
| Out | `out_UsersJson` | String | JSON array of {UserEntity, Roles}. |

### Providers/UiPath/Discover_Bot_In_Dev.xaml

Finds a Bot ID that is not in BotMapping.json in the Dev Orchestrator (settings uipath.discovery). GET odata/Folders (paged), then in each folder to search GET odata/Releases?$filter=Name eq '<id>' or ProcessKey eq '<id>' or contains(Description,'<id>') (fields from uipath.discovery.matchOn). Exactly one matching process is required; its folder's assets and queues (GET odata/Assets, odata/QueueDefinitions) complete an entry shaped like a mapping entry. A folder the API account cannot read is skipped and reported. Read-only.

| Direction | Argument | Type | Description |
|---|---|---|---|
| In | `in_Config` | JObject | Settings + bot mapping from Framework\Load_Configuration.xaml. |
| In | `in_Session` | Dictionary(Of String, Object) | Run context shared by all workflows: token cache, user, request reference, step list. Never persisted. |
| In | `in_BotId` | String | Bot ID typed in the form. |
| Out | `out_Bot` | JObject | Discovered entry (same shape as a BotMapping.json entry) or Nothing. |
| Out | `out_Message` | String | Empty when found; otherwise why not. |

### Providers/UiPath/Fetch_Bot_Configuration.xaml

UiPath provider: resolves the mapped folders in Dev, UAT and Prod, reads the process, package versions and deployment status in each, and for New requests the Dev assets, queues and folder access plus their state in the target environment of the selected path. UAT/Prod read failures are reported per environment; a Dev failure makes the result an error. Only what the API account may read is returned.

| Direction | Argument | Type | Description |
|---|---|---|---|
| In | `in_Config` | JObject | Settings + bot mapping from Framework\Load_Configuration.xaml. |
| In | `in_Session` | Dictionary(Of String, Object) | Run context shared by all workflows: token cache, user, request reference, step list. Never persisted. |
| In | `in_Bot` | JObject | Bot ID mapping entry. |
| In | `in_ProcessType` | String | New / Enhancement / Bug Fix |
| In | `in_DeploymentPath` | String | Deployment path name from settings. |
| Out | `out_Details` | JObject | Details for the form (see BuildUiPathDetails). |

### Providers/UiPath/Update_Asset_Configuration.xaml

Applies one approved asset row in the target folder, idempotently: reads the current asset, then creates it, updates it (only when the value differs) or leaves it, and reads it back. Credential values are read with Get Credential from the approved secret source named in the Bot ID mapping (assets.secretSource.<env>) and sent straight to Orchestrator; they never reach the form, the request, logs or the audit.

| Direction | Argument | Type | Description |
|---|---|---|---|
| In | `in_Config` | JObject | Settings + bot mapping from Framework\Load_Configuration.xaml. |
| In | `in_Session` | Dictionary(Of String, Object) | Run context shared by all workflows: token cache, user, request reference, step list. Never persisted. |
| In | `in_Environment` | String | Dev / UAT / Prod |
| In | `in_FolderId` | Long | Orchestrator folder ID (sent as X-UIPATH-OrganizationUnitId). |
| In | `in_Bot` | JObject | Bot ID mapping entry (secret sources). |
| In | `in_Asset` | JObject | Approved asset row from the request (name, type, action, proposedValue, isSecret...). |
| Out | `out_Change` | String | Created / Updated / NoChange |
| Out | `out_Message` | String | Safe detail. |

### Providers/UiPath/Validate_Queue_Configuration.xaml

Checks one approved queue row against the target folder and, when in_ApplyChanges, creates it or updates its settings idempotently (GET odata/QueueDefinitions?$filter=Name eq ..., then POST or PUT odata/QueueDefinitions), then reads it back. An existing queue is never recreated.

| Direction | Argument | Type | Description |
|---|---|---|---|
| In | `in_Config` | JObject | Settings + bot mapping from Framework\Load_Configuration.xaml. |
| In | `in_Session` | Dictionary(Of String, Object) | Run context shared by all workflows: token cache, user, request reference, step list. Never persisted. |
| In | `in_Environment` | String | Dev / UAT / Prod |
| In | `in_FolderId` | Long | Orchestrator folder ID (sent as X-UIPATH-OrganizationUnitId). |
| In | `in_Queue` | JObject | Approved queue row (name, proposedName, action, settings). |
| In | `in_ApplyChanges` | Boolean | False = check only. |
| Out | `out_Change` | String | Created / Updated / NoChange / WouldCreate / WouldUpdate |
| Out | `out_Message` | String | Safe detail. |

### Providers/UiPath/Validate_User_Access.xaml

Checks and (when in_ApplyChanges) grants folder access for approved rows. Accounts must already exist (GET odata/Users?$filter=UserName eq ...); roles are resolved by name (GET odata/Roles). Because AssignUsers sets an account's complete role list on the folder, current direct roles are merged in so nothing is removed; then GetUsersForFolder is read again to verify. Unknown accounts or roles are reported, never created.

| Direction | Argument | Type | Description |
|---|---|---|---|
| In | `in_Config` | JObject | Settings + bot mapping from Framework\Load_Configuration.xaml. |
| In | `in_Session` | Dictionary(Of String, Object) | Run context shared by all workflows: token cache, user, request reference, step list. Never persisted. |
| In | `in_Environment` | String | Dev / UAT / Prod |
| In | `in_FolderId` | Long | Orchestrator folder ID (sent as X-UIPATH-OrganizationUnitId). |
| In | `in_Rows` | JArray | Approved access rows (name, type, accessLevel, action). |
| In | `in_ApplyChanges` | Boolean | False = check only. |
| Out | `out_Results` | JArray | Per account: {name, status: Granted/NoChange/Verified/Failed, message}. |

### Providers/UiPath/Deploy_Package.xaml

Moves one package version to the target and points the process at it. 1) target feed already has the version -> skip transfer; otherwise the version must exist in the source feed, is downloaded (GET Processes/DownloadPackage(key='<id>:<version>')), its SHA-256 recorded, and uploaded (POST Processes/UploadPackage, multipart 'file'; 409 = already there) and the target feed is re-checked. 2) process in the target folder: same version -> no change; other version -> POST Releases(<id>)/UiPath.Server.Configuration.OData.UpdateToSpecificPackageVersion; missing -> created (POST odata/Releases) only for New requests. 3) the process is read back; a wrong version restores the previous one and fails. Assets, queues and access are NOT touched here.

| Direction | Argument | Type | Description |
|---|---|---|---|
| In | `in_Config` | JObject | Settings + bot mapping from Framework\Load_Configuration.xaml. |
| In | `in_Session` | Dictionary(Of String, Object) | Run context shared by all workflows: token cache, user, request reference, step list. Never persisted. |
| In | `in_Request` | JObject | Validated request. |
| In | `in_TargetFolderId` | Long | Target folder ID. |
| In | `in_Result` | JObject | Result object; steps are added to its 'objects' list and keys package*/release*. |

### Providers/UiPath/Execute_UiPath_Deployment.xaml

Runs an approved UiPath request against its target: package + process (Deploy_Package.xaml) for every type; for New requests also the approved assets, queues and folder access, each checked first and changed only as approved. Each object is recorded; if any object fails the run fails after the rest were attempted, and a re-run resumes safely because every step is idempotent.

| Direction | Argument | Type | Description |
|---|---|---|---|
| In | `in_Config` | JObject | Settings + bot mapping from Framework\Load_Configuration.xaml. |
| In | `in_Session` | Dictionary(Of String, Object) | Run context shared by all workflows: token cache, user, request reference, step list. Never persisted. |
| In | `in_Bot` | JObject | Bot ID mapping entry. |
| In | `in_Request` | JObject | Validated request. |
| In | `in_Details` | JObject | Fresh details (target folder ID). |
| Out | `out_Result` | JObject | Result with 'objects'. |

### Providers/UiPath/Deploy_Dev_To_UAT.xaml

Dev -> UAT for UiPath. Option A: no approval unless the Dev to UAT path in settings requires one. Then Execute_UiPath_Deployment.xaml (package for every type; assets, queues and access only for New).

| Direction | Argument | Type | Description |
|---|---|---|---|
| In | `in_Config` | JObject | Settings + bot mapping from Framework\Load_Configuration.xaml. |
| In | `in_Session` | Dictionary(Of String, Object) | Run context shared by all workflows: token cache, user, request reference, step list. Never persisted. |
| In | `in_Bot` | JObject | Bot ID mapping entry. |
| In | `in_Request` | JObject | Validated request. |
| In | `in_Details` | JObject | Fresh details. |
| Out | `out_Result` | JObject | Result. |

### Providers/UiPath/Deploy_UAT_To_Prod.xaml

UAT -> Prod for UiPath. Option B: refuses to run unless Requests\Check_Approval.xaml confirms the approval and the successful UAT deployment of this exact version (checked again here, not only at submission). Then Execute_UiPath_Deployment.xaml (package for every type; assets, queues and access only for New).

| Direction | Argument | Type | Description |
|---|---|---|---|
| In | `in_Config` | JObject | Settings + bot mapping from Framework\Load_Configuration.xaml. |
| In | `in_Session` | Dictionary(Of String, Object) | Run context shared by all workflows: token cache, user, request reference, step list. Never persisted. |
| In | `in_Bot` | JObject | Bot ID mapping entry. |
| In | `in_Request` | JObject | Validated request. |
| In | `in_Details` | JObject | Fresh details. |
| Out | `out_Result` | JObject | Result. |

### Providers/PowerAutomate/PA_Get_Solution_Details.xaml

Reads environment details and one solution. GET RetrieveCurrentOrganization(AccessType=@p)?@p=Microsoft.Dynamics.CRM.EndpointAccessType'Default' (environment name and ID) and GET solutions?$filter=uniquename eq '<name>'&$select=solutionid,uniquename,friendlyname,version,ismanaged,description,modifiedon.

| Direction | Argument | Type | Description |
|---|---|---|---|
| In | `in_Config` | JObject | Settings + bot mapping from Framework\Load_Configuration.xaml. |
| In | `in_Session` | Dictionary(Of String, Object) | Run context shared by all workflows: token cache, user, request reference, step list. Never persisted. |
| In | `in_Environment` | String | Dev / UAT / Prod |
| In | `in_SolutionUniqueName` | String | Solution unique name. |
| Out | `out_OrgJson` | String | RetrieveCurrentOrganization response. |
| Out | `out_SolutionJson` | String | solutions collection response. |

### Providers/PowerAutomate/PA_Get_Flows.xaml

Cloud flows in a solution: GET solutioncomponents?$filter=_solutionid_value eq <id> and componenttype eq 29&$select=objectid (component type 29 = Workflow), then GET workflows?$filter=category eq 5 and (workflowid eq ... or ...)&$select=workflowid,name,statecode,statuscode.

| Direction | Argument | Type | Description |
|---|---|---|---|
| In | `in_Config` | JObject | Settings + bot mapping from Framework\Load_Configuration.xaml. |
| In | `in_Session` | Dictionary(Of String, Object) | Run context shared by all workflows: token cache, user, request reference, step list. Never persisted. |
| In | `in_Environment` | String | Dev / UAT / Prod |
| In | `in_SolutionId` | String | solutionid (GUID). |
| Out | `out_FlowsJson` | String | JSON array of workflow records. |

### Providers/PowerAutomate/PA_Discover_Solution_In_Dev.xaml

Finds a Bot ID that is not in BotMapping.json in the Dev Dataverse environment (settings powerAutomate.discovery): GET solutions?$filter=ismanaged eq false and (uniquename eq '<id>' or contains(description,'<id>'))&$select=solutionid,uniquename,friendlyname,version,ismanaged,description. Exactly one solution is required. Read-only.

| Direction | Argument | Type | Description |
|---|---|---|---|
| In | `in_Config` | JObject | Settings + bot mapping from Framework\Load_Configuration.xaml. |
| In | `in_Session` | Dictionary(Of String, Object) | Run context shared by all workflows: token cache, user, request reference, step list. Never persisted. |
| In | `in_BotId` | String | Bot ID typed in the form. |
| Out | `out_Bot` | JObject | Discovered entry (same shape as a BotMapping.json entry) or Nothing. |
| Out | `out_Message` | String | Empty when found; otherwise why not. |

### Providers/PowerAutomate/PA_Fetch_Bot_Configuration.xaml

Power Automate provider: reads the mapped solution in Dev, UAT and Prod (version, managed state, environment name), the cloud flows of the Dev solution, and which versions already have a managed export in the artifact store. Nothing is shown that the API did not return.

| Direction | Argument | Type | Description |
|---|---|---|---|
| In | `in_Config` | JObject | Settings + bot mapping from Framework\Load_Configuration.xaml. |
| In | `in_Session` | Dictionary(Of String, Object) | Run context shared by all workflows: token cache, user, request reference, step list. Never persisted. |
| In | `in_Bot` | JObject | Bot ID mapping entry. |
| In | `in_ProcessType` | String | New / Enhancement / Bug Fix |
| In | `in_DeploymentPath` | String | Deployment path name. |
| Out | `out_Details` | JObject | Details for the form. |

### Providers/PowerAutomate/PA_Deploy_Solution.xaml

Deploys a solution version. Dev -> UAT: checks the Dev version, POST ExportSolution {SolutionName, Managed: true}, stores the managed file with its SHA-256 in the artifact store. UAT -> Prod: loads that stored file (hash checked) and requires the same version to be installed in UAT. Then POST ImportSolutionAsync {CustomizationFile, OverwriteUnmanagedCustomizations: false, PublishWorkflows: true, ImportJobId, ComponentParameters: []}, polls asyncoperations(<id>) until statecode 3 (statuscode 30 = succeeded) and reads the target solution version back. Skipped when the target already has the version (idempotent). Approval for Prod is checked by the caller.

| Direction | Argument | Type | Description |
|---|---|---|---|
| In | `in_Config` | JObject | Settings + bot mapping from Framework\Load_Configuration.xaml. |
| In | `in_Session` | Dictionary(Of String, Object) | Run context shared by all workflows: token cache, user, request reference, step list. Never persisted. |
| In | `in_Request` | JObject | Validated request. |
| Out | `out_Result` | JObject | Result with 'objects'. |

## Requests

### Requests/Get_Governance_Queue.xaml

Resolves a governance queue (requests, approvals or results) in settings.governance.folderPath of the governance Orchestrator. The queues must exist with 'Enforce unique reference' on; they are not created automatically.

| Direction | Argument | Type | Description |
|---|---|---|---|
| In | `in_Config` | JObject | Settings + bot mapping from Framework\Load_Configuration.xaml. |
| In | `in_Session` | Dictionary(Of String, Object) | Run context shared by all workflows: token cache, user, request reference, step list. Never persisted. |
| In | `in_QueueName` | String | Queue name. |
| Out | `out_FolderId` | Long | Folder ID. |
| Out | `out_QueueId` | Long | QueueDefinition ID. |

### Requests/Find_Queue_Item.xaml

Finds the newest non-deleted item with a given reference in a governance queue: GET odata/QueueItems?$filter=QueueDefinitionId eq <id> and Reference eq '<ref>'&$orderby=Id desc (folder header).

| Direction | Argument | Type | Description |
|---|---|---|---|
| In | `in_Config` | JObject | Settings + bot mapping from Framework\Load_Configuration.xaml. |
| In | `in_Session` | Dictionary(Of String, Object) | Run context shared by all workflows: token cache, user, request reference, step list. Never persisted. |
| In | `in_QueueName` | String | Queue name. |
| In | `in_Reference` | String | Reference. |
| Out | `out_Found` | Boolean | True when found. |
| Out | `out_ItemJson` | String | Queue item JSON (Id, Status, Reference, SpecificContent, CreationTime). |

### Requests/Add_Queue_Item.xaml

Adds a governance record once: looks the reference up first, then POST odata/Queues/UiPathODataSvc.AddQueueItem {itemData: {Name, Priority, Reference, SpecificContent}}. An existing reference (look-up hit or HTTP 409 from the unique-reference queue) is reported as a duplicate and nothing is added.

| Direction | Argument | Type | Description |
|---|---|---|---|
| In | `in_Config` | JObject | Settings + bot mapping from Framework\Load_Configuration.xaml. |
| In | `in_Session` | Dictionary(Of String, Object) | Run context shared by all workflows: token cache, user, request reference, step list. Never persisted. |
| In | `in_QueueName` | String | Queue name. |
| In | `in_Reference` | String | Unique reference. |
| In | `in_Content` | JObject | Specific content (objects are stored as JSON text). |
| Out | `out_Duplicate` | Boolean | True when the reference already existed. |
| Out | `out_ItemJson` | String | New or existing item. |

### Requests/Check_Approval.xaml

Governance gate for a request's deployment path (settings.deploymentPaths): requiresApproval -> an 'Approved' record APR|<request reference> in the approvals queue, for the same version, by an approver listed for the target environment who is not the requester (segregation of duties); requiresSuccessfulPreviousStage -> a success record of the previous stage (e.g. Dev to UAT) for the same Bot ID and version.

| Direction | Argument | Type | Description |
|---|---|---|---|
| In | `in_Config` | JObject | Settings + bot mapping from Framework\Load_Configuration.xaml. |
| In | `in_Session` | Dictionary(Of String, Object) | Run context shared by all workflows: token cache, user, request reference, step list. Never persisted. |
| In | `in_Request` | JObject | Request. |
| Out | `out_Satisfied` | Boolean | True when every rule is met. |
| Out | `out_Messages` | JArray | What is missing or confirmed, for the user. |

### Requests/Validate_Deployment_Request.xaml

Validates a request: rule checks (ValidateRequest code: required fields per process type, version available in the source, target folder, downgrade, process existence, asset/queue conflicts, secret handling, allowed access levels, editor authorization) and live checks: duplicate submission (Form mode) and approval/previous stage (notes in Form mode, errors in Execute mode). Validation never changes anything.

| Direction | Argument | Type | Description |
|---|---|---|---|
| In | `in_Config` | JObject | Settings + bot mapping from Framework\Load_Configuration.xaml. |
| In | `in_Session` | Dictionary(Of String, Object) | Run context shared by all workflows: token cache, user, request reference, step list. Never persisted. |
| In | `in_Request` | JObject | Request from BuildRequest. |
| In | `in_Details` | JObject | Details fetched for this request. |
| In | `in_Mode` | String | Form / Execute |
| In | `in_IsEditor` | Boolean | Requester may change configuration. |
| Out | `out_IsValid` | Boolean | No errors. |
| Out | `out_Errors` | JArray | Errors. |
| Out | `out_Warnings` | JArray | Warnings. |
| Out | `out_Notes` | JArray | Approval/governance notes. |

### Requests/Fetch_Provider_Details.xaml

Resolves the Bot ID through the mapping (or, when it is not mapped and <provider>.discovery.enabled is true, finds it in Dev: Providers\UiPath\Discover_Bot_In_Dev.xaml / Providers\PowerAutomate\PA_Discover_Solution_In_Dev.xaml) and calls the provider for the selected Automation Tool: UiPath -> Providers\UiPath\Fetch_Bot_Configuration.xaml, Power Automate -> Providers\PowerAutomate\PA_Fetch_Bot_Configuration.xaml. The two integrations never share API logic.

| Direction | Argument | Type | Description |
|---|---|---|---|
| In | `in_Config` | JObject | Settings + bot mapping from Framework\Load_Configuration.xaml. |
| In | `in_Session` | Dictionary(Of String, Object) | Run context shared by all workflows: token cache, user, request reference, step list. Never persisted. |
| In | `in_Tool` | String | UiPath / Power Automate |
| In | `in_BotId` | String | Bot ID. |
| In | `in_ProcessType` | String | New / Enhancement / Bug Fix |
| In | `in_DeploymentPath` | String | Deployment path. |
| Out | `out_Found` | Boolean | Details usable. |
| Out | `out_Bot` | JObject | Mapping entry. |
| Out | `out_Details` | JObject | Details (Nothing when the Bot ID did not resolve). |
| Out | `out_Message` | String | Message for the user. |

### Requests/Submit_Request.xaml

Records a validated request in the requests queue (auditable register). Reference = AM|<tool>|<BotID>|<type>|<path>|<version>, so the same request cannot be submitted twice. Submitting never deploys by itself.

| Direction | Argument | Type | Description |
|---|---|---|---|
| In | `in_Config` | JObject | Settings + bot mapping from Framework\Load_Configuration.xaml. |
| In | `in_Session` | Dictionary(Of String, Object) | Run context shared by all workflows: token cache, user, request reference, step list. Never persisted. |
| In | `in_Request` | JObject | Validated request. |
| Out | `out_Duplicate` | Boolean | Already submitted. |
| Out | `out_RequestId` | String | New request ID (GUID). |

### Requests/Record_Deployment_Result.xaml

Adds the outcome to the results queue: success -> RES|<tool>|<BotID>|<path>|<version>|OK (unique: the evidence the next stage checks), failure -> RES|...|FAILED|<timestamp>. Content holds the result objects and the run's audit steps.

| Direction | Argument | Type | Description |
|---|---|---|---|
| In | `in_Config` | JObject | Settings + bot mapping from Framework\Load_Configuration.xaml. |
| In | `in_Session` | Dictionary(Of String, Object) | Run context shared by all workflows: token cache, user, request reference, step list. Never persisted. |
| In | `in_Request` | JObject | Request. |
| In | `in_Status` | String | Succeeded / Failed / Rejected |
| In | `in_Message` | String | Outcome message. |
| In | `in_Result` | JObject | Result object (may be Nothing). |

### Requests/Execute_Request.xaml

Executes a submitted request by reference: reads it from the requests queue, stops if this version was already deployed successfully, fetches fresh details, validates again (Execute mode: approval and previous stage are mandatory), dispatches to the provider and path (UiPath Deploy_Dev_To_UAT / Deploy_UAT_To_Prod, Power Automate PA_Deploy_Solution), verifies, and records the result and audit. Failures are recorded, never silent.

| Direction | Argument | Type | Description |
|---|---|---|---|
| In | `in_Config` | JObject | Settings + bot mapping from Framework\Load_Configuration.xaml. |
| In | `in_Session` | Dictionary(Of String, Object) | Run context shared by all workflows: token cache, user, request reference, step list. Never persisted. |
| In | `in_RequestReference` | String | Request reference (AM/...). |
| Out | `out_Status` | String | Succeeded / AlreadyDeployed / Rejected / Failed |
| Out | `out_Message` | String | Outcome. |
| Out | `out_Result` | JObject | Result object with 'objects' (Nothing when not executed). |
