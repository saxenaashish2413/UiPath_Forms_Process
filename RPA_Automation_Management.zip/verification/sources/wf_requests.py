"""Requests\\*.xaml: provider dispatch, validation, the auditable request register (Orchestrator queues), approvals and execution."""
from xamlgen import Workflow, Arg, Var, Seq, Assign, Log, If, Try, ForEach, Invoke, Code, Throw, Rethrow
from formacts import Switch
from wf_framework import CFG, q, odq, ctx, api, collection, audit

APIV = [Var("intStatus", "I"), Var("strBody", "S")]
GOV_ENV = 'in_Config.SelectToken("governance.orchestratorEnvironment").ToString()'


def res_base(req, path=None):
    path = path or f'{req}.Value(Of String)("deploymentPath")'
    return (f'Left("RES|" & If({req}.Value(Of String)("automationTool") = "UiPath", "UIP", "PA") & "|" & {req}.Value(Of String)("botId").ToUpperInvariant() & "|" & '
            f'{path} & "|" & {req}.SelectToken("package.requestedVersion").ToString(), 100)')


def ok_ref(req):
    """Reference of the success record for tool+bot+path+version (independent of process type)."""
    return res_base(req) + ' & "|OK"'


def ok_ref_prev(req, prev):
    return res_base(req, prev) + ' & "|OK"'


def apr_ref(req):
    return f'Left("APR|" & {req}.Value(Of String)("reference"), 128)'


def find(queue, ref, found, item, name):
    return Invoke("Requests/Find_Queue_Item.xaml", ctx(in_QueueName=queue, in_Reference=ref, out_Found=found, out_ItemJson=item), name=name)


def build():
    Workflow("Requests/Get_Governance_Queue.xaml",
             "Resolves a governance queue (requests, approvals or results) in settings.governance.folderPath of the governance "
             "Orchestrator. The queues must exist with 'Enforce unique reference' on; they are not created automatically.",
             CFG + [Arg("in", "in_QueueName", "S", "Queue name."), Arg("out", "out_FolderId", "L", "Folder ID."), Arg("out", "out_QueueId", "L", "QueueDefinition ID.")],
             Seq("Get governance queue", [
                 Assign("strKey", '"queue:" & in_QueueName', "S"),
                 If("in_Session.ContainsKey(strKey)",
                    Seq("From cache", [Assign("out_FolderId", 'CLng(in_Session(strKey & ":folder"))', "L"), Assign("out_QueueId", "CLng(in_Session(strKey))", "L")]),
                    Seq("Look up", [
                        Invoke("Providers/UiPath/Get_Folder.xaml", ctx(in_Environment=GOV_ENV, in_FolderPath='in_Config.SelectToken("governance.folderPath").ToString()', out_FolderId="out_FolderId", out_FolderJson="strJson"), name="Governance folder"),
                        If("out_FolderId = 0", Throw('New BusinessRuleException("Governance folder " & in_Config.SelectToken("governance.folderPath").ToString() & " was not found in " & ' + GOV_ENV + ' & ".")', "Folder missing")),
                        api("GET", '"odata/QueueDefinitions?$filter=" & Uri.EscapeDataString("Name eq \'" & ' + odq("in_QueueName") + ' & "\'") & "&$select=Id,Name,EnforceUniqueReference"', "GET governance queue", env=GOV_ENV, folder="out_FolderId"),
                        Assign("jaItems", "New JArray()", "JA"),
                        Code("ParsePage", {"in_ResponseBody": "strBody", "io_Items": "jaItems", "out_NextUrl": "strNext", "out_PageCount": "intCount"}, "Read queue"),
                        If("jaItems.Count = 0", Throw('New BusinessRuleException("Governance queue " & in_QueueName & " does not exist in " & in_Config.SelectToken("governance.folderPath").ToString() & ". Create it with Enforce unique reference.")', "Queue missing")),
                        If('Not jaItems(0).Value(Of Boolean)("EnforceUniqueReference")', Log("Warn", '"Governance queue " & in_QueueName & " does not enforce unique references; duplicate protection relies on the look-up only."')),
                        Assign("out_QueueId", 'jaItems(0).Value(Of Long)("Id")', "L"),
                        Assign("in_Session(strKey)", "out_QueueId", "O", "Cache queue ID"),
                        Assign('in_Session(strKey & ":folder")', "out_FolderId", "O", "Cache folder ID")]))
             ], vars=APIV + [Var("strKey", "S"), Var("strJson", "S"), Var("jaItems", "JA"), Var("strNext", "S"), Var("intCount", "I")]))

    Workflow("Requests/Find_Queue_Item.xaml",
             "Finds the newest non-deleted item with a given reference in a governance queue: GET odata/QueueItems?$filter="
             "QueueDefinitionId eq <id> and Reference eq '<ref>'&$orderby=Id desc (folder header).",
             CFG + [Arg("in", "in_QueueName", "S", "Queue name."), Arg("in", "in_Reference", "S", "Reference."),
                    Arg("out", "out_Found", "B", "True when found."), Arg("out", "out_ItemJson", "S", "Queue item JSON (Id, Status, Reference, SpecificContent, CreationTime).")],
             Seq("Find queue item", [
                 Invoke("Requests/Get_Governance_Queue.xaml", ctx(in_QueueName="in_QueueName", out_FolderId="lngFolder", out_QueueId="lngQueue"), name="Resolve queue"),
                 api("GET", '"odata/QueueItems?$filter=" & Uri.EscapeDataString("QueueDefinitionId eq " & lngQueue.ToString() & " and Reference eq \'" & ' + odq("in_Reference") + ' & "\'") & "&$orderby=Id%20desc&$top=20&$select=Id,Status,Reference,SpecificContent,CreationTime"',
                     "GET odata/QueueItems by reference", env=GOV_ENV, folder="lngFolder"),
                 Assign("jaItems", "New JArray()", "JA"),
                 Code("ParsePage", {"in_ResponseBody": "strBody", "io_Items": "jaItems", "out_NextUrl": "strNext", "out_PageCount": "intCount"}, "Read items"),
                 Assign("joItem", 'jaItems.Children(Of JObject)().FirstOrDefault(Function(i) i.Value(Of String)("Status") <> "Deleted")', "JO", "Newest non-deleted"),
                 Assign("out_Found", "joItem IsNot Nothing", "B"),
                 Assign("out_ItemJson", 'If(joItem Is Nothing, "", joItem.ToString(Newtonsoft.Json.Formatting.None))', "S"),
             ], vars=APIV + [Var("lngFolder", "L"), Var("lngQueue", "L"), Var("jaItems", "JA"), Var("strNext", "S"), Var("intCount", "I"), Var("joItem", "JO")]))

    Workflow("Requests/Add_Queue_Item.xaml",
             "Adds a governance record once: looks the reference up first, then POST odata/Queues/UiPathODataSvc.AddQueueItem "
             "{itemData: {Name, Priority, Reference, SpecificContent}}. An existing reference (look-up hit or HTTP 409 from the "
             "unique-reference queue) is reported as a duplicate and nothing is added.",
             CFG + [Arg("in", "in_QueueName", "S", "Queue name."), Arg("in", "in_Reference", "S", "Unique reference."),
                    Arg("in", "in_Content", "JO", "Specific content (objects are stored as JSON text)."),
                    Arg("out", "out_Duplicate", "B", "True when the reference already existed."), Arg("out", "out_ItemJson", "S", "New or existing item.")],
             Seq("Add queue item", [
                 find("in_QueueName", "in_Reference", "out_Duplicate", "out_ItemJson", "Already recorded?"),
                 If("Not out_Duplicate", Seq("Add", [
                     Invoke("Requests/Get_Governance_Queue.xaml", ctx(in_QueueName="in_QueueName", out_FolderId="lngFolder", out_QueueId="lngQueue"), name="Resolve queue"),
                     Code("QueueItem", {"in_Mode": '"body"', "in_QueueName": "in_QueueName", "in_Reference": "in_Reference", "in_Content": "in_Content", "in_ItemJson": '""', "out_Body": "strItem", "out_Content": "joIgnore"}, "Queue item body"),
                     api("POST", '"odata/Queues/UiPathODataSvc.AddQueueItem"', "POST Queues/AddQueueItem", env=GOV_ENV, folder="lngFolder", body="strItem", accept='"409"'),
                     If("intStatus = 409", Seq("Duplicate reference", [Assign("out_Duplicate", "True", "B"), find("in_QueueName", "in_Reference", "boolFound", "out_ItemJson", "Read existing item")]),
                        Assign("out_ItemJson", "strBody", "S"))]))
             ], vars=APIV + [Var("lngFolder", "L"), Var("lngQueue", "L"), Var("strItem", "S"), Var("joIgnore", "JO"), Var("boolFound", "B")]))

    Workflow("Requests/Check_Approval.xaml",
             "Governance gate for a request's deployment path (settings.deploymentPaths): "
             "requiresApproval -> an 'Approved' record APR|<request reference> in the approvals queue, for the same version, by an "
             "approver listed for the target environment who is not the requester (segregation of duties); "
             "requiresSuccessfulPreviousStage -> a success record of the previous stage (e.g. Dev to UAT) for the same Bot ID and version.",
             CFG + [Arg("in", "in_Request", "JO", "Request."), Arg("out", "out_Satisfied", "B", "True when every rule is met."),
                    Arg("out", "out_Messages", "JA", "What is missing or confirmed, for the user.")],
             Seq("Check approval", [
                 Assign("out_Messages", "New JArray()", "JA"),
                 Assign("out_Satisfied", "True", "B"),
                 Assign("joPath", 'in_Config("deploymentPaths").Children(Of JObject)().First(Function(p) p.Value(Of String)("name") = in_Request.Value(Of String)("deploymentPath"))', "JO"),
                 Assign("strVersion", 'in_Request.SelectToken("package.requestedVersion").ToString()', "S"),
                 If('joPath.Value(Of Boolean)("requiresApproval")', Seq("Approval required", [
                     find('in_Config.SelectToken("governance.approvalsQueue").ToString()', apr_ref("in_Request"), "boolFound", "strItem", "Find approval"),
                     If("Not boolFound",
                        Seq("No approval", [Assign("out_Satisfied", "False", "B"), Assign("strNote", '"Approval by " & String.Join(" or ", If(TryCast(in_Config.SelectToken("authorization.approvers." & in_Request.Value(Of String)("targetEnvironment")), JArray), New JArray()).Values(Of String)()) & " is required before deployment to " & in_Request.Value(Of String)("targetEnvironment") & " (run ApproveRequest.xaml with reference " & in_Request.Value(Of String)("reference") & ")."', "S"),
                                             Code("JsonPut", {"in_Target": "joNotes", "in_Key": '"approval"', "in_Json": "strNote"}, "Note")]),
                        Seq("Check approval record", [
                            Code("QueueItem", {"in_Mode": '"parse"', "in_QueueName": '""', "in_Reference": '""', "in_Content": "Nothing", "in_ItemJson": "strItem", "out_Body": "strIgnore", "out_Content": "joApproval"}, "Read approval"),
                            Code("CheckAuthorization", {"in_User": 'joApproval.Value(Of String)("Approver")', "in_Allowed": 'TryCast(in_Config.SelectToken("authorization.approvers." & in_Request.Value(Of String)("targetEnvironment")), JArray)', "out_Allowed": "boolApprover"}, "Approver still authorized?"),
                            Assign("strNote", 'If(joApproval.Value(Of String)("Decision") <> "Approved", "The request was " & joApproval.Value(Of String)("Decision").ToLowerInvariant() & " by " & joApproval.Value(Of String)("Approver") & ": " & joApproval.Value(Of String)("Comment"), '
                                              'If(joApproval.Value(Of String)("ApprovedVersion") <> strVersion, "The approval is for version " & joApproval.Value(Of String)("ApprovedVersion") & ", not " & strVersion & ".", '
                                              'If(CBool(in_Config.SelectToken("authorization.segregationOfDuties")) AndAlso String.Equals(joApproval.Value(Of String)("Approver"), in_Request.Value(Of String)("requestedBy"), StringComparison.OrdinalIgnoreCase), "The requester cannot approve their own request.", '
                                              'If(Not boolApprover, joApproval.Value(Of String)("Approver") & " is no longer an approver for " & in_Request.Value(Of String)("targetEnvironment") & ".", ""))))', "S", "Approval problems"),
                            If('strNote <> ""', Seq("Approval not valid", [Assign("out_Satisfied", "False", "B"), Code("JsonPut", {"in_Target": "joNotes", "in_Key": '"approval"', "in_Json": "strNote"}, "Note")]),
                               Code("JsonPut", {"in_Target": "joNotes", "in_Key": '"approval"', "in_Json": '"Approved by " & joApproval.Value(Of String)("Approver") & " on " & joApproval.Value(Of String)("ApprovedAtUtc") & "."'}, "Note"))]))])),
                 If('joPath.Value(Of Boolean)("requiresSuccessfulPreviousStage")', Seq("Previous stage required", [
                     find('in_Config.SelectToken("governance.resultsQueue").ToString()', ok_ref_prev("in_Request", 'joPath.Value(Of String)("previousStage")'), "boolFound", "strItem", "Find previous stage success"),
                     If("Not boolFound",
                        Seq("No evidence", [Assign("out_Satisfied", "False", "B"), Code("JsonPut", {"in_Target": "joNotes", "in_Key": '"previousStage"', "in_Json": '"No successful " & joPath.Value(Of String)("previousStage") & " deployment of version " & strVersion & " is recorded for this Bot ID."'}, "Note")]),
                        Code("JsonPut", {"in_Target": "joNotes", "in_Key": '"previousStage"', "in_Json": 'joPath.Value(Of String)("previousStage") & " deployment of " & strVersion & " succeeded."'}, "Note"))])),
                 Assign("out_Messages", "New JArray(joNotes.Properties().Select(Function(p) p.Value.ToString()))", "JA"),
             ], vars=[Var("joPath", "JO"), Var("strVersion", "S"), Var("boolFound", "B"), Var("strItem", "S"), Var("strNote", "S"), Var("joApproval", "JO"),
                      Var("boolApprover", "B"), Var("strIgnore", "S"), Var("joNotes", "JO", "New JObject()")]))

    Workflow("Requests/Validate_Deployment_Request.xaml",
             "Validates a request: rule checks (ValidateRequest code: required fields per process type, version available in the "
             "source, target folder, downgrade, process existence, asset/queue conflicts, secret handling, allowed access levels, "
             "editor authorization) and live checks: duplicate submission (Form mode) and approval/previous stage (notes in Form "
             "mode, errors in Execute mode). Validation never changes anything.",
             CFG + [Arg("in", "in_Request", "JO", "Request from BuildRequest."), Arg("in", "in_Details", "JO", "Details fetched for this request."),
                    Arg("in", "in_Mode", "S", "Form | Execute"), Arg("in", "in_IsEditor", "B", "Requester may change configuration."),
                    Arg("out", "out_IsValid", "B", "No errors."), Arg("out", "out_Errors", "JA", "Errors."), Arg("out", "out_Warnings", "JA", "Warnings."),
                    Arg("out", "out_Notes", "JA", "Approval/governance notes.")],
             Seq("Validate deployment request", [
                 Code("ValidateRequest", {"in_Config": "in_Config", "in_Request": "in_Request", "in_Details": "in_Details", "in_IsEditor": "in_IsEditor",
                                          "out_Errors": "out_Errors", "out_Warnings": "out_Warnings"}, "Rule checks"),
                 Assign("out_Notes", "New JArray()", "JA"),
                 If("out_Errors.Count = 0", Try("Live checks", Seq("Live checks", [
                     If('in_Mode = "Form"', Seq("Duplicate submission?", [
                         find('in_Config.SelectToken("governance.requestsQueue").ToString()', 'in_Request.Value(Of String)("reference")', "boolFound", "strItem", "Find existing request"),
                         If("boolFound", Assign("out_Errors", 'New JArray(out_Errors.Concat(New JToken() {New JValue("Duplicate submission: this request (" & in_Request.Value(Of String)("reference") & ") was already submitted on " & JObject.Parse(strItem).Value(Of String)("CreationTime") & ". Ask the RPA CoE to execute or reject it instead of submitting again.")}))', "JA", "Duplicate"))])),
                     Invoke("Requests/Check_Approval.xaml", ctx(in_Request="in_Request", out_Satisfied="boolApproved", out_Messages="jaMessages"), name="Check approval"),
                     If('in_Mode = "Execute" AndAlso Not boolApproved',
                        Assign("out_Errors", 'New JArray(out_Errors.Concat(jaMessages.Where(Function(m) Not m.ToString().EndsWith("succeeded.") AndAlso Not m.ToString().StartsWith("Approved by"))))', "JA", "Governance not met"),
                        Assign("out_Notes", "jaMessages", "JA"))]),
                     [("EX", "exLive", Assign("out_Errors", 'New JArray(out_Errors.Concat(New JToken() {New JValue("Live validation could not run: " & exLive.Message)}))', "JA", "Live check failed"))])),
                 Assign("out_IsValid", "out_Errors.Count = 0", "B"),
                 Log("Info", '"Validation of " & in_Request.Value(Of String)("reference") & " (" & in_Mode & "): " & If(out_IsValid, "valid", out_Errors.Count.ToString() & " error(s): " & String.Join(" | ", out_Errors.Values(Of String)()))'),
             ], vars=[Var("boolFound", "B"), Var("strItem", "S"), Var("boolApproved", "B"), Var("jaMessages", "JA")]))

    Workflow("Requests/Fetch_Provider_Details.xaml",
             "Resolves the Bot ID through the mapping (or, when it is not mapped and <provider>.discovery.enabled is true, finds it "
             "in Dev: Providers\\UiPath\\Discover_Bot_In_Dev.xaml / Providers\\PowerAutomate\\PA_Discover_Solution_In_Dev.xaml) and calls the provider for the selected Automation Tool: UiPath -> "
             "Providers\\UiPath\\Fetch_Bot_Configuration.xaml, Power Automate -> Providers\\PowerAutomate\\PA_Fetch_Bot_Configuration.xaml. "
             "The two integrations never share API logic.",
             CFG + [Arg("in", "in_Tool", "S", "UiPath | Power Automate"), Arg("in", "in_BotId", "S", "Bot ID."),
                    Arg("in", "in_ProcessType", "S", "New | Enhancement | Bug Fix"), Arg("in", "in_DeploymentPath", "S", "Deployment path."),
                    Arg("out", "out_Found", "B", "Details usable."), Arg("out", "out_Bot", "JO", "Mapping entry."),
                    Arg("out", "out_Details", "JO", "Details (Nothing when the Bot ID did not resolve)."), Arg("out", "out_Message", "S", "Message for the user.")],
             Seq("Fetch provider details", [
                 Assign("out_Found", "False", "B"), Assign("out_Details", "Nothing", "JO"),
                 Code("ResolveBot", {"in_Config": "in_Config", "in_Tool": "in_Tool", "in_BotId": "in_BotId", "out_Bot": "out_Bot", "out_Error": "out_Message", "out_NotMapped": "boolNotMapped"}, "Resolve Bot ID mapping"),
                 Assign("boolDiscover", 'boolNotMapped AndAlso in_Config.SelectToken(If(in_Tool = "UiPath", "uipath", "powerAutomate") & ".discovery.enabled") IsNot Nothing AndAlso CBool(in_Config.SelectToken(If(in_Tool = "UiPath", "uipath", "powerAutomate") & ".discovery.enabled"))', "B", "Search Dev when not mapped?"),
                 If("boolDiscover", Assign("out_Message", '""', "S", "Not mapped: Dev discovery follows")),
                 If('out_Message = "" AndAlso Not in_Config("deploymentPaths").Children(Of JObject)().Any(Function(p) p.Value(Of String)("name") = in_DeploymentPath)',
                    Assign("out_Message", '"Select a Deployment Path."', "S")),
                 If('out_Message = "" AndAlso Not New String() {"New", "Enhancement", "Bug Fix"}.Contains(in_ProcessType)', Assign("out_Message", '"Select a Process Type."', "S")),
                 If('out_Message = "" AndAlso boolDiscover', Try("Try Dev discovery",
                     Switch("Discover in which Dev?", "in_Tool", {
                         "UiPath": Invoke("Providers/UiPath/Discover_Bot_In_Dev.xaml", ctx(in_BotId="in_BotId", out_Bot="out_Bot", out_Message="out_Message"), name="Search Dev Orchestrator"),
                         "Power Automate": Invoke("Providers/PowerAutomate/PA_Discover_Solution_In_Dev.xaml", ctx(in_BotId="in_BotId", out_Bot="out_Bot", out_Message="out_Message"), name="Search Dev Dataverse")},
                         default=Throw('New BusinessRuleException("Unsupported automation tool " & in_Tool)', "Unsupported tool")),
                     [("EX", "exDiscover", Seq("Discovery failed", [
                         Log("Error", '"Dev discovery for " & in_Tool & " " & in_BotId & " failed: " & exDiscover.ToString()'),
                         Assign("out_Bot", "Nothing", "JO"),
                         Assign("out_Message", '"Bot ID \'" & in_BotId.Trim() & "\' is not in the Bot ID mapping and Dev could not be searched: " & exDiscover.Message', "S")]))])),
                 If('out_Message = ""', Try("Try provider", Seq("Call provider", [
                     Switch("Which provider?", "in_Tool", {
                         "UiPath": Invoke("Providers/UiPath/Fetch_Bot_Configuration.xaml", ctx(in_Bot="out_Bot", in_ProcessType="in_ProcessType", in_DeploymentPath="in_DeploymentPath", out_Details="out_Details"), name="UiPath provider"),
                         "Power Automate": Invoke("Providers/PowerAutomate/PA_Fetch_Bot_Configuration.xaml", ctx(in_Bot="out_Bot", in_ProcessType="in_ProcessType", in_DeploymentPath="in_DeploymentPath", out_Details="out_Details"), name="Power Automate provider")},
                         default=Throw('New BusinessRuleException("Unsupported automation tool " & in_Tool)', "Unsupported tool")),
                     Assign("out_Found", 'out_Details.Value(Of String)("status") = "Found"', "B"),
                     Assign("out_Message", 'out_Details.Value(Of String)("message") & If(String.IsNullOrEmpty(out_Bot.Value(Of String)("source")), "", " " & out_Bot.Value(Of String)("source"))', "S"),
                     Code("JsonPut", {"in_Target": "out_Details", "in_Key": '"message"', "in_Json": "out_Message"}, "Message shown in the form")]),
                     [("EX", "exFetch", Seq("Provider failed", [
                         Log("Error", '"Fetching details for " & in_Tool & " " & in_BotId & " failed: " & exFetch.ToString()'),
                         Assign("out_Details", "Nothing", "JO"),
                         Assign("out_Message", '"Details could not be retrieved: " & exFetch.Message', "S")]))]),
                    Log("Warn", '"Bot ID look-up: " & out_Message'))
             ], vars=[Var("boolNotMapped", "B"), Var("boolDiscover", "B")]))

    Workflow("Requests/Submit_Request.xaml",
             "Records a validated request in the requests queue (auditable register). Reference = AM|<tool>|<BotID>|<type>|<path>|"
             "<version>, so the same request cannot be submitted twice. Submitting never deploys by itself.",
             CFG + [Arg("in", "in_Request", "JO", "Validated request."), Arg("out", "out_Duplicate", "B", "Already submitted."),
                    Arg("out", "out_RequestId", "S", "New request ID (GUID).")],
             Seq("Submit request", [
                 Assign("out_RequestId", "Guid.NewGuid().ToString()", "S"),
                 Code("JsonPut", {"in_Target": "in_Request", "in_Key": '"requestId"', "in_Json": "out_RequestId"}, "Request ID"),
                 Assign("joContent", 'New JObject(New JProperty("RequestId", out_RequestId), New JProperty("BotId", in_Request.Value(Of String)("botId")), New JProperty("AutomationTool", in_Request.Value(Of String)("automationTool")), New JProperty("ProcessType", in_Request.Value(Of String)("processType")), New JProperty("DeploymentPath", in_Request.Value(Of String)("deploymentPath")), New JProperty("RequestedVersion", in_Request.SelectToken("package.requestedVersion").ToString()), New JProperty("RequestedBy", in_Request.Value(Of String)("requestedBy")), New JProperty("RequestJson", in_Request))', "JO", "Specific content"),
                 Assign("in_Session(\"requestReference\")", 'in_Request.Value(Of String)("reference")', "O", "Audit context: reference"),
                 Assign("in_Session(\"botId\")", 'in_Request.Value(Of String)("botId")', "O", "Audit context: Bot ID"),
                 Invoke("Requests/Add_Queue_Item.xaml", ctx(in_QueueName='in_Config.SelectToken("governance.requestsQueue").ToString()', in_Reference='in_Request.Value(Of String)("reference")', in_Content="joContent", out_Duplicate="out_Duplicate", out_ItemJson="strItem"), name="Add request"),
                 audit('"Request " & in_Request.Value(Of String)("reference")', 'If(out_Duplicate, "Rejected", "Submitted")', 'If(out_Duplicate, "Duplicate submission refused", "Submitted by " & in_Request.Value(Of String)("requestedBy") & " (request ID " & out_RequestId & ")")'),
             ], vars=[Var("joContent", "JO"), Var("strItem", "S")]))

    Workflow("Requests/Record_Deployment_Result.xaml",
             "Adds the outcome to the results queue: success -> RES|<tool>|<BotID>|<path>|<version>|OK (unique: the evidence the next "
             "stage checks), failure -> RES|...|FAILED|<timestamp>. Content holds the result objects and the run's audit steps.",
             CFG + [Arg("in", "in_Request", "JO", "Request."), Arg("in", "in_Status", "S", "Succeeded | Failed | Rejected"),
                    Arg("in", "in_Message", "S", "Outcome message."), Arg("in", "in_Result", "JO", "Result object (may be Nothing).")],
             Seq("Record deployment result", [
                 Assign("strRef", 'If(in_Status = "Succeeded", ' + ok_ref("in_Request") + ', ' + res_base("in_Request") + ' & "|" & in_Status.ToUpperInvariant() & "|" & DateTime.UtcNow.ToString("yyyyMMddHHmmssfff"))', "S", "Result reference"),
                 Assign("joContent", 'New JObject(New JProperty("RequestReference", in_Request.Value(Of String)("reference")), New JProperty("Status", in_Status), New JProperty("Message", in_Message), New JProperty("Version", in_Request.SelectToken("package.requestedVersion").ToString()), New JProperty("ExecutedBy", If(in_Session.ContainsKey("user"), in_Session("user").ToString(), "")), New JProperty("ExecutedAtUtc", DateTime.UtcNow.ToString("o")), New JProperty("ResultJson", If(in_Result, New JObject())), New JProperty("StepsJson", If(in_Session.ContainsKey("steps"), CType(in_Session("steps"), JArray), New JArray())))', "JO"),
                 Invoke("Requests/Add_Queue_Item.xaml", ctx(in_QueueName='in_Config.SelectToken("governance.resultsQueue").ToString()', in_Reference="strRef", in_Content="joContent", out_Duplicate="boolDuplicate", out_ItemJson="strItem"), name="Add result"),
                 Log("Info", '"Deployment result recorded: " & strRef & If(boolDuplicate, " (already recorded)", "")'),
             ], vars=[Var("strRef", "S"), Var("joContent", "JO"), Var("boolDuplicate", "B"), Var("strItem", "S")]))

    Workflow("Requests/Execute_Request.xaml",
             "Executes a submitted request by reference: reads it from the requests queue, stops if this version was already "
             "deployed successfully, fetches fresh details, validates again (Execute mode: approval and previous stage are "
             "mandatory), dispatches to the provider and path (UiPath Deploy_Dev_To_UAT / Deploy_UAT_To_Prod, Power Automate "
             "PA_Deploy_Solution), verifies, and records the result and audit. Failures are recorded, never silent.",
             CFG + [Arg("in", "in_RequestReference", "S", "Request reference (AM|...)."),
                    Arg("out", "out_Status", "S", "Succeeded | AlreadyDeployed | Rejected | Failed"), Arg("out", "out_Message", "S", "Outcome."),
                    Arg("out", "out_Result", "JO", "Result object with 'objects' (Nothing when not executed).")],
             Seq("Execute request", [
                 Assign("out_Result", "Nothing", "JO"),
                 Assign("in_Session(\"requestReference\")", "in_RequestReference", "O"),
                 Assign("in_Session(\"steps\")", "New JArray()", "O", "New step list"),
                 find('in_Config.SelectToken("governance.requestsQueue").ToString()', "in_RequestReference", "boolFound", "strItem", "Find request"),
                 If("Not boolFound", Seq("Unknown request", [Assign("out_Status", '"Rejected"', "S"), Assign("out_Message", '"Request " & in_RequestReference & " was not found in the requests queue."', "S"),
                                                              audit('"Execute " & in_RequestReference', '"Rejected"', "out_Message")]),
                    Seq("Execute", [
                        Code("QueueItem", {"in_Mode": '"parse"', "in_QueueName": '""', "in_Reference": '""', "in_Content": "Nothing", "in_ItemJson": "strItem", "out_Body": "strIgnore", "out_Content": "joItem"}, "Read request"),
                        Assign("joRequest", 'CType(joItem("Request"), JObject)', "JO"),
                        Assign("in_Session(\"botId\")", 'joRequest.Value(Of String)("botId")', "O"),
                        audit('"Execute " & in_RequestReference', '"Started"', '"Deployment " & joRequest.Value(Of String)("deploymentPath") & " of version " & joRequest.SelectToken("package.requestedVersion").ToString() & " started"'),
                        Try("Try execute", Seq("Validate and deploy", [
                            find('in_Config.SelectToken("governance.resultsQueue").ToString()', ok_ref("joRequest"), "boolDone", "strDone", "Already deployed?"),
                            If("boolDone",
                               Seq("Already deployed", [Assign("out_Status", '"AlreadyDeployed"', "S"), Assign("out_Message", '"Version " & joRequest.SelectToken("package.requestedVersion").ToString() & " was already deployed successfully on this path (" & JObject.Parse(strDone).Value(Of String)("CreationTime") & "). Nothing was changed."', "S")]),
                               Seq("Deploy", [
                                   Invoke("Requests/Fetch_Provider_Details.xaml", ctx(in_Tool='joRequest.Value(Of String)("automationTool")', in_BotId='joRequest.Value(Of String)("botId")', in_ProcessType='joRequest.Value(Of String)("processType")',
                                                                                     in_DeploymentPath='joRequest.Value(Of String)("deploymentPath")', out_Found="boolDetails", out_Bot="joBot", out_Details="joDetails", out_Message="strMessage"), name="Fresh details"),
                                   If("Not boolDetails", Throw('New BusinessRuleException("Details could not be confirmed before deployment: " & strMessage)', "Details missing")),
                                   Code("CheckAuthorization", {"in_User": 'joRequest.Value(Of String)("requestedBy")', "in_Allowed": 'TryCast(in_Config.SelectToken("authorization.configurationEditors"), JArray)', "out_Allowed": "boolEditor"}, "Requester is a configuration editor?"),
                                   Invoke("Requests/Validate_Deployment_Request.xaml", ctx(in_Request="joRequest", in_Details="joDetails", in_Mode='"Execute"', in_IsEditor="boolEditor",
                                                                                            out_IsValid="boolValid", out_Errors="jaErrors", out_Warnings="jaWarnings", out_Notes="jaNotes"), name="Validate (Execute mode)"),
                                   If("Not boolValid", Throw('New BusinessRuleException("Validation failed: " & String.Join(" ", jaErrors.Values(Of String)()))', "Stop: validation failed")),
                                   Switch("Which provider and path?", 'joRequest.Value(Of String)("automationTool") & "|" & joRequest.Value(Of String)("targetEnvironment")', {
                                       "UiPath|UAT": Invoke("Providers/UiPath/Deploy_Dev_To_UAT.xaml", ctx(in_Bot="joBot", in_Request="joRequest", in_Details="joDetails", out_Result="out_Result"), name="Dev to UAT"),
                                       "UiPath|Prod": Invoke("Providers/UiPath/Deploy_UAT_To_Prod.xaml", ctx(in_Bot="joBot", in_Request="joRequest", in_Details="joDetails", out_Result="out_Result"), name="UAT to Prod"),
                                       "Power Automate|UAT": Invoke("Providers/PowerAutomate/PA_Deploy_Solution.xaml", ctx(in_Request="joRequest", out_Result="out_Result"), name="Power Automate Dev to UAT"),
                                       "Power Automate|Prod": Invoke("Providers/PowerAutomate/PA_Deploy_Solution.xaml", ctx(in_Request="joRequest", out_Result="out_Result"), name="Power Automate UAT to Prod")},
                                       default=Throw('New BusinessRuleException("Deployment path " & joRequest.Value(Of String)("deploymentPath") & " is not supported for " & joRequest.Value(Of String)("automationTool") & ".")', "Unsupported path")),
                                   Assign("out_Status", '"Succeeded"', "S"),
                                   Assign("out_Message", '"Deployed version " & out_Result.Value(Of String)("deployedVersion") & " to " & joRequest.Value(Of String)("targetEnvironment") & " and verified."', "S"),
                                   Invoke("Requests/Record_Deployment_Result.xaml", ctx(in_Request="joRequest", in_Status='"Succeeded"', in_Message="out_Message", in_Result="out_Result"), name="Record success")]))]),
                            [("BRE", "exRule", Seq("Rejected", [
                                Assign("out_Status", '"Rejected"', "S"), Assign("out_Message", "exRule.Message", "S"),
                                audit('"Execute " & in_RequestReference', '"Rejected"', "exRule.Message"),
                                Invoke("Requests/Record_Deployment_Result.xaml", ctx(in_Request="joRequest", in_Status='"Rejected"', in_Message="exRule.Message", in_Result="out_Result"), name="Record rejection")])),
                             ("EX", "exRun", Seq("Failed", [
                                 Assign("out_Status", '"Failed"', "S"), Assign("out_Message", "exRun.Message", "S"),
                                 Log("Error", '"Deployment of " & in_RequestReference & " failed: " & exRun.ToString()'),
                                 audit('"Execute " & in_RequestReference', '"Failed"', "exRun.Message"),
                                 Try("Try record failure", Invoke("Requests/Record_Deployment_Result.xaml", ctx(in_Request="joRequest", in_Status='"Failed"', in_Message="exRun.Message", in_Result="out_Result"), name="Record failure"),
                                     [("EX", "exRecord", Log("Error", '"The failure could not be recorded in the results queue (it is in the audit file): " & exRecord.Message'))])]))]),
                        audit('"Execute " & in_RequestReference', "out_Status", "out_Message")]))
             ], vars=[Var("boolFound", "B"), Var("strItem", "S"), Var("strIgnore", "S"), Var("joItem", "JO"), Var("joRequest", "JO"), Var("boolDone", "B"), Var("strDone", "S"),
                      Var("boolDetails", "B"), Var("joBot", "JO"), Var("joDetails", "JO"), Var("strMessage", "S"), Var("boolEditor", "B"), Var("boolValid", "B"),
                      Var("jaErrors", "JA"), Var("jaWarnings", "JA"), Var("jaNotes", "JA")]))
