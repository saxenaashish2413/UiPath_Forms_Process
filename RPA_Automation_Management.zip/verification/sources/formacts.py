"""UiPath Forms (Form.Activities 25.10) and Trigger Scope activities for xamlgen.
Activity and property names were read from the decompiled UiPath.Forms.Activities 25.10.0 and
UiPath.System.Activities 26.2.4 assemblies:
  ShowFormActivity: FormId, IsAsync, Title, Arguments (Dictionary<string, Argument>)
  GetFormFieldsActivity: FormId, Arguments (Dictionary<string, OutArgument>)
  SetFormFieldsActivity: FormId, Arguments (Dictionary<string, InArgument>), null values are skipped
  CloseFormActivity: FormId
  FormTriggerActivity<T>: FormId, Event ("click.<buttonKey>", "changed.<fieldKey>", "window.closed")
  TriggerScope: SchedulingMode, Triggers (List<Activity>), Action (ActivityAction<TriggerArgs> "args")
  Break: stops the enclosing TriggerScope (TriggerScope implements IBreakable)
"""
from xml.sax.saxutils import escape
from xamlgen import Act, a, X, T

FORM_ID = "8f1c2a7e-5b3d-4e69-a0c4-7d2e9b6f1a35"


def _dict(p, kind, items):
    out = [f'{p}  <scg:Dictionary x:TypeArguments="x:String, {kind}">']
    for k, (typ, expr) in items.items():
        tag = {"Argument": "InArgument", "InArgument": "InArgument", "OutArgument": "OutArgument"}[kind]
        out.append(f'{p}    <{tag} x:TypeArguments="{T[typ][0]}" x:Key="{k}">{escape(X(expr))}</{tag}>')
    out.append(f"{p}  </scg:Dictionary>")
    return out


class ShowFormAsync(Act):
    """Show Form with 'Continue workflow execution' (IsAsync=True): the form stays open while a Trigger Scope reacts to it."""

    def __init__(self, name, title, inputs, doc=""):
        self.name, self.title, self.inputs, self.doc = name, title, inputs, doc   # inputs: {fieldKey: expr} (String)

    def xaml(self, ind):
        p = " " * ind
        out = [f'{p}<uf:ShowFormActivity DisplayName={a(self.name)} FormId="{FORM_ID}" IsAsync="True"'
               + (f' sap2010:Annotation.AnnotationText={a(self.doc)}' if self.doc else "") + ">",
               f'{p}  <uf:ShowFormActivity.Title>', f'{p}    <InArgument x:TypeArguments="x:String">{escape(X(self.title))}</InArgument>',
               f'{p}  </uf:ShowFormActivity.Title>', f'{p}  <uf:ShowFormActivity.Arguments>']
        out += _dict(p + "  ", "Argument", {k: ("S", v) for k, v in self.inputs.items()})
        out += [f'{p}  </uf:ShowFormActivity.Arguments>', f'{p}</uf:ShowFormActivity>']
        return "\n".join(out)

    def vb(self, ind, ctx):
        items = ", ".join(f'{{"{k}", CObj({v})}}' for k, v in self.inputs.items())
        return " " * ind + f"TestHost.ShowForm({self.title}, New Dictionary(Of String, Object) From {{{items}}})"


class GetFields(Act):
    def __init__(self, name, fields):
        self.name, self.fields = name, fields   # {fieldKey: variable} (String variables)

    def xaml(self, ind):
        p = " " * ind
        out = [f'{p}<uf:GetFormFieldsActivity DisplayName={a(self.name)} FormId="{FORM_ID}">', f'{p}  <uf:GetFormFieldsActivity.Arguments>']
        out += _dict(p + "  ", "OutArgument", {k: ("S", v) for k, v in self.fields.items()})
        out += [f'{p}  </uf:GetFormFieldsActivity.Arguments>', f'{p}</uf:GetFormFieldsActivity>']
        return "\n".join(out)

    def vb(self, ind, ctx):
        return "\n".join(" " * ind + f'{v} = TestHost.GetField("{k}")' for k, v in self.fields.items())


class SetFields(Act):
    def __init__(self, name, fields):
        self.name, self.fields = name, fields   # {fieldKey: String expression}; never Nothing (Set Form Fields skips nulls)

    def xaml(self, ind):
        p = " " * ind
        out = [f'{p}<uf:SetFormFieldsActivity DisplayName={a(self.name)} FormId="{FORM_ID}">', f'{p}  <uf:SetFormFieldsActivity.Arguments>']
        out += _dict(p + "  ", "InArgument", {k: ("S", v) for k, v in self.fields.items()})
        out += [f'{p}  </uf:SetFormFieldsActivity.Arguments>', f'{p}</uf:SetFormFieldsActivity>']
        return "\n".join(out)

    def vb(self, ind, ctx):
        items = ", ".join(f'{{"{k}", CObj({v})}}' for k, v in self.fields.items())
        return " " * ind + f'TestHost.SetFields("{self.name}", New Dictionary(Of String, Object) From {{{items}}})'


class CloseForm(Act):
    def __init__(self, name="Close Form"):
        self.name = name

    def xaml(self, ind):
        return " " * ind + f'<uf:CloseFormActivity DisplayName={a(self.name)} FormId="{FORM_ID}" />'

    def vb(self, ind, ctx):
        return " " * ind + "TestHost.CloseForm()"


class Break(Act):
    def __init__(self, name="Break (stop listening to the form)"):
        self.name = name

    def xaml(self, ind):
        return " " * ind + f'<ui:Break DisplayName={a(self.name)} />'

    def vb(self, ind, ctx):
        return " " * ind + "Exit Do"


class Switch(Act):
    def __init__(self, name, expr, cases, default=None):
        self.name, self.expr, self.cases, self.default = name, expr, cases, default   # cases: {key: Act}

    def walk(self):
        yield self
        for c in self.cases.values():
            yield from c.walk()
        if self.default:
            yield from self.default.walk()

    def xaml(self, ind):
        p = " " * ind
        out = [f'{p}<Switch x:TypeArguments="x:String" DisplayName={a(self.name)} Expression={a(X(self.expr))}>']
        if self.default:
            out += [f"{p}  <Switch.Default>", self.default.xaml(ind + 4), f"{p}  </Switch.Default>"]
        for k, c in self.cases.items():
            x = c.xaml(ind + 2)
            first_end = x.index(">")
            if x[first_end - 1] == "/":
                first_end -= 1
            out.append(x[:first_end] + f' x:Key={a(k)}' + x[first_end:])
        out.append(f"{p}</Switch>")
        return "\n".join(out)

    def vb(self, ind, ctx):
        p = " " * ind
        out = [f"{p}Select Case {self.expr}"]
        for k, c in self.cases.items():
            out += [f'{p}    Case "{k}"', c.vb(ind + 8, ctx)]
        if self.default:
            out += [f"{p}    Case Else", self.default.vb(ind + 8, ctx)]
        out.append(f"{p}End Select")
        return "\n".join(out)


class TriggerScope(Act):
    """Trigger Scope listening to Form Trigger events. Action receives 'args' (UiPath.Platform.Triggers.TriggerArgs);
    args.TriggerName is the DisplayName of the Form Trigger that fired (TriggerArgs.FillDetails)."""

    def __init__(self, name, triggers, action, mode="Sequential", doc=""):
        self.name, self.triggers, self.action, self.mode, self.doc = name, triggers, action, mode, doc   # triggers: [(DisplayName, Event)]

    def walk(self):
        yield self
        yield from self.action.walk()

    def xaml(self, ind):
        p = " " * ind
        out = [f'{p}<ui:TriggerScope DisplayName={a(self.name)} SchedulingMode="{self.mode}"'
               + (f' sap2010:Annotation.AnnotationText={a(self.doc)}' if self.doc else "") + ">",
               f"{p}  <ui:TriggerScope.Action>", f'{p}    <ActivityAction x:TypeArguments="upt:TriggerArgs">',
               f"{p}      <ActivityAction.Argument>", f'{p}        <DelegateInArgument x:TypeArguments="upt:TriggerArgs" Name="args" />',
               f"{p}      </ActivityAction.Argument>", self.action.xaml(ind + 6), f"{p}    </ActivityAction>", f"{p}  </ui:TriggerScope.Action>",
               f"{p}  <ui:TriggerScope.Triggers>"]
        for dn, ev in self.triggers:
            out.append(f'{p}    <uf:FormTriggerActivity x:TypeArguments="uf:FormInfoTriggerEventArgs" DisplayName={a(dn)} Event={a(ev)} FormId="{FORM_ID}" />')
        out += [f"{p}  </ui:TriggerScope.Triggers>", f"{p}</ui:TriggerScope>"]
        return "\n".join(out)

    def vb(self, ind, ctx):
        p = " " * ind
        names = ", ".join(f'"{dn}"' for dn, _ in self.triggers)
        return (f"{p}Dim args As UiPath.Platform.Triggers.TriggerArgs = Nothing\n"
                f"{p}TestHost.RegisterTriggers({names})\n"
                f"{p}Do While TestHost.NextTrigger(args)\n{self.action.vb(ind + 4, ctx)}\n{p}Loop")
