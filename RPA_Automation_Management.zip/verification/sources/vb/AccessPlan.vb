'ARG in in_Mode S
'ARG in in_Config JO
'ARG in in_Rows JA
'ARG in in_Accounts JA
'ARG in in_Roles JA
'ARG in in_FolderUsers JA
'ARG in in_FolderId L
'ARG out out_Bodies JA
'ARG out out_Results JA
' Folder access for approved "Grant" rows. Access level -> Orchestrator roles via roleMappings.
'  plan  : one AssignUsers body per account. AssignUsers sets the account's complete role list on the folder,
'          so roles it already has there are kept (merged), never removed. Accounts that already have every role get no body.
'  verify: re-reads GetUsersForFolder and reports per account whether every required role is now present.
' Unknown accounts or roles are reported and never created.
Dim inv As System.Globalization.CultureInfo = System.Globalization.CultureInfo.InvariantCulture
out_Bodies = New Newtonsoft.Json.Linq.JArray()
out_Results = New Newtonsoft.Json.Linq.JArray()
Dim roleMap As Newtonsoft.Json.Linq.JObject = CType(in_Config("roleMappings"), Newtonsoft.Json.Linq.JObject)
For Each row As Newtonsoft.Json.Linq.JObject In in_Rows.Children(Of Newtonsoft.Json.Linq.JObject)()
    If row.Value(Of String)("action") <> "Grant" Then Continue For
    Dim name As String = row.Value(Of String)("name")
    Dim res As New Newtonsoft.Json.Linq.JObject()
    res("name") = name
    Dim acct As Newtonsoft.Json.Linq.JObject = If(in_Accounts, New Newtonsoft.Json.Linq.JArray()).Children(Of Newtonsoft.Json.Linq.JObject)().FirstOrDefault(Function(a) String.Equals(a.Value(Of String)("UserName"), name, StringComparison.OrdinalIgnoreCase) OrElse String.Equals(a.Value(Of String)("Name"), name, StringComparison.OrdinalIgnoreCase))
    Dim need As List(Of String) = If(TryCast(roleMap(row.Value(Of String)("accessLevel")), Newtonsoft.Json.Linq.JArray), New Newtonsoft.Json.Linq.JArray()).Values(Of String)().ToList()
    Dim current As Newtonsoft.Json.Linq.JObject = If(acct Is Nothing, Nothing, If(in_FolderUsers, New Newtonsoft.Json.Linq.JArray()).Children(Of Newtonsoft.Json.Linq.JObject)().FirstOrDefault(Function(u) u.SelectToken("UserEntity.Id") IsNot Nothing AndAlso u.SelectToken("UserEntity.Id").ToObject(Of Long)() = acct.Value(Of Long)("Id")))
    Dim have As List(Of Newtonsoft.Json.Linq.JObject) = If(current Is Nothing, New List(Of Newtonsoft.Json.Linq.JObject), If(TryCast(current("Roles"), Newtonsoft.Json.Linq.JArray), New Newtonsoft.Json.Linq.JArray()).Children(Of Newtonsoft.Json.Linq.JObject)().ToList())
    Dim missing As List(Of String) = need.Where(Function(r) Not have.Any(Function(h) String.Equals(h.Value(Of String)("Name"), r, StringComparison.OrdinalIgnoreCase))).ToList()
    If acct Is Nothing Then
        res("status") = "Failed"
        res("message") = "Account " & name & " does not exist in the target Orchestrator; add it (or its directory group) first."
    ElseIf in_Mode = "verify" Then
        res("status") = If(missing.Count = 0, "Verified", "Failed")
        res("message") = If(missing.Count = 0, "Has " & String.Join(", ", need), "Still missing: " & String.Join(", ", missing))
    ElseIf missing.Count = 0 Then
        res("status") = "NoChange"
        res("message") = "Already has " & String.Join(", ", need)
    Else
        Dim unknown As List(Of String) = missing.Where(Function(r) Not in_Roles.Children(Of Newtonsoft.Json.Linq.JObject)().Any(Function(x) String.Equals(x.Value(Of String)("Name"), r, StringComparison.OrdinalIgnoreCase))).ToList()
        If unknown.Count > 0 Then
            res("status") = "Failed"
            res("message") = "Role(s) " & String.Join(", ", unknown) & " do not exist in the target Orchestrator."
        Else
            Dim ids As New List(Of Long)
            ids.AddRange(have.Where(Function(h) Not String.Equals(h.Value(Of String)("Origin"), "Inherited", StringComparison.OrdinalIgnoreCase)).Select(Function(h) h.Value(Of Long)("Id")))
            ids.AddRange(missing.Select(Function(r) in_Roles.Children(Of Newtonsoft.Json.Linq.JObject)().First(Function(x) String.Equals(x.Value(Of String)("Name"), r, StringComparison.OrdinalIgnoreCase)).Value(Of Long)("Id")))
            Dim body As New Newtonsoft.Json.Linq.JObject(New Newtonsoft.Json.Linq.JProperty("assignments", New Newtonsoft.Json.Linq.JObject(
                New Newtonsoft.Json.Linq.JProperty("UserIds", New Newtonsoft.Json.Linq.JArray(acct.Value(Of Long)("Id"))),
                New Newtonsoft.Json.Linq.JProperty("RolesPerFolder", New Newtonsoft.Json.Linq.JArray(New Newtonsoft.Json.Linq.JObject(
                    New Newtonsoft.Json.Linq.JProperty("FolderId", in_FolderId),
                    New Newtonsoft.Json.Linq.JProperty("RoleIds", New Newtonsoft.Json.Linq.JArray(ids.Distinct().ToArray()))))))))
            out_Bodies.Add(body.ToString(Newtonsoft.Json.Formatting.None))
            res("status") = "Granted"
            res("message") = "Added " & String.Join(", ", missing)
        End If
    End If
    out_Results.Add(res)
Next
