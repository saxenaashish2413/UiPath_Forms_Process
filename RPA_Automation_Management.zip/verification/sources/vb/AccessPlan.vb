'ARG in in_Mode S
'ARG in in_Config JO
'ARG in in_Rows JA
'ARG in in_Accounts JA
'ARG in in_Roles JA
'ARG in in_FolderUsers JA
'ARG in in_FolderId L
'ARG out out_Bodies JA
'ARG out out_Results JA
' Folder access for approved "Grant" rows; the access level is turned into Orchestrator roles through settings roleMappings. Mode plan: one AssignUsers body per account. AssignUsers sets the account's complete role list on the folder, so roles it already has there are kept (merged), never removed; accounts that already have every role get no body. Mode verify: re-reads the folder access and reports per account whether every required role is now present. Unknown accounts or roles are reported and never created.
out_Bodies = New JArray()
out_Results = New JArray()
' Access level -> role names, from settings
Dim roleMap As JObject = CType(in_Config("roleMappings"), JObject)
' Only rows the requester chose to grant
For Each row As JObject In in_Rows.Children(Of JObject)().Where(Function(x) x.Value(Of String)("action") = "Grant")
    ' Account (user or group) name from the row
    Dim name As String = row.Value(Of String)("name")
    ' Result for this account
    Dim res As New JObject()
    res("name") = name
    ' The account as it exists in the target Orchestrator (Nothing when it does not)
    Dim acct As JObject = If(in_Accounts, New JArray()).Children(Of JObject)().FirstOrDefault(Function(a) String.Equals(a.Value(Of String)("UserName"), name, StringComparison.OrdinalIgnoreCase) OrElse String.Equals(a.Value(Of String)("Name"), name, StringComparison.OrdinalIgnoreCase))
    ' Roles the chosen access level needs
    Dim need As List(Of String) = If(TryCast(roleMap(row.Value(Of String)("accessLevel")), JArray), New JArray()).Values(Of String)().ToList()
    ' The account's current entry on the folder, if any
    Dim current As JObject = If(acct Is Nothing, Nothing, If(in_FolderUsers, New JArray()).Children(Of JObject)().FirstOrDefault(Function(u) u.SelectToken("UserEntity.Id") IsNot Nothing AndAlso u.SelectToken("UserEntity.Id").ToObject(Of Long)() = acct.Value(Of Long)("Id")))
    ' Roles it already has on the folder
    Dim have As List(Of JObject) = If(current Is Nothing, New List(Of JObject), If(TryCast(current("Roles"), JArray), New JArray()).Children(Of JObject)().ToList())
    ' Needed roles it does not have yet
    Dim missing As List(Of String) = need.Where(Function(r) Not have.Any(Function(h) String.Equals(h.Value(Of String)("Name"), r, StringComparison.OrdinalIgnoreCase))).ToList()
    If acct Is Nothing Then
        ' Accounts are never created
        res("status") = "Failed"
        res("message") = "Account " & name & " does not exist in the target Orchestrator; add it (or its directory group) first."
    ElseIf in_Mode = "verify" Then
        ' Verify: are all needed roles there now?
        res("status") = If(missing.Count = 0, "Verified", "Failed")
        res("message") = If(missing.Count = 0, "Has " & String.Join(", ", need), "Still missing: " & String.Join(", ", missing))
    ElseIf missing.Count = 0 Then
        ' Nothing to add
        res("status") = "NoChange"
        res("message") = "Already has " & String.Join(", ", need)
    Else
        ' Needed roles that do not exist in the target Orchestrator
        Dim unknown As List(Of String) = missing.Where(Function(r) Not in_Roles.Children(Of JObject)().Any(Function(x) String.Equals(x.Value(Of String)("Name"), r, StringComparison.OrdinalIgnoreCase))).ToList()
        If unknown.Count > 0 Then
            ' Roles are never created
            res("status") = "Failed"
            res("message") = "Role(s) " & String.Join(", ", unknown) & " do not exist in the target Orchestrator."
        Else
            ' Role ids to set: the account's own (not inherited) roles plus the missing ones
            Dim ids As List(Of Long) = have.Where(Function(h) Not String.Equals(h.Value(Of String)("Origin"), "Inherited", StringComparison.OrdinalIgnoreCase)).Select(Function(h) h.Value(Of Long)("Id")).Concat(missing.Select(Function(r) in_Roles.Children(Of JObject)().First(Function(x) String.Equals(x.Value(Of String)("Name"), r, StringComparison.OrdinalIgnoreCase)).Value(Of Long)("Id"))).Distinct().ToList()
            ' AssignUsers body for this account and folder
            out_Bodies.Add(New JObject(New JProperty("assignments", New JObject(New JProperty("UserIds", New JArray(acct.Value(Of Long)("Id"))), New JProperty("RolesPerFolder", New JArray(New JObject(New JProperty("FolderId", in_FolderId), New JProperty("RoleIds", New JArray(ids.ToArray())))))))).ToString(Newtonsoft.Json.Formatting.None))
            res("status") = "Granted"
            res("message") = "Added " & String.Join(", ", missing)
        End If
    End If
    ' Keep the result for this account
    out_Results.Add(res)
Next
