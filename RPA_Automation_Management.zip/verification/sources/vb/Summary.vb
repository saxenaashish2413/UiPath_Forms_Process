'ARG in in_Request JO
'ARG in in_Errors JA
'ARG in in_Warnings JA
'ARG in in_Notes JA
'ARG out out_Html S
' Review summary shown in the form (all values HTML-encoded). Lists what will change, nothing is changed here.
Dim E As Func(Of String, String) = Function(t) System.Net.WebUtility.HtmlEncode(If(t, ""))
Dim R As Func(Of String, String) = Function(k) If(in_Request.SelectToken(k)?.ToString(), "")
Dim pa As Boolean = R("automationTool") = "Power Automate"
Dim sb As New System.Text.StringBuilder()
sb.Append("<table class=""am-summary"">")
Dim Row As Action(Of String, String) = Sub(k, v) sb.Append("<tr><th>" & E(k) & "</th><td>" & E(v) & "</td></tr>")
Row("Bot ID", R("botId"))
Row("Automation Tool", R("automationTool"))
Row("Process Type", R("processType"))
Row(If(pa, "Solution", "Process Name"), R("package.processName"))
Row(If(pa, "Solution (unique name)", "Package Name"), R("package.packageName"))
Row("Requested Version", R("package.requestedVersion"))
Row("Deployment Path", R("deploymentPath") & " (" & R("sourceEnvironment") & " " & ChrW(8594) & " " & R("targetEnvironment") & ")")
Row("Version in " & R("targetEnvironment") & " now", If(R("package.targetVersionAtRequest") = "", "none", R("package.targetVersionAtRequest")))
If R("enhancement.description") <> "" Then Row("Enhancement", R("enhancement.description")) : Row("Change Reference", R("enhancement.changeReference"))
If R("bugFix.description") <> "" Then Row("Bug", R("bugFix.description")) : Row("Incident Reference", R("bugFix.incidentReference"))
Dim cfg As Newtonsoft.Json.Linq.JObject = TryCast(in_Request("configuration"), Newtonsoft.Json.Linq.JObject)
If cfg IsNot Nothing Then
    Row("Process name in target", cfg.Value(Of String)("processName"))
    Row("Target folder", cfg.Value(Of String)("targetFolder"))
    Dim a As String = String.Join("; ", cfg("assets").Children(Of Newtonsoft.Json.Linq.JObject)().Where(Function(x) x.Value(Of String)("action") = "Create" OrElse x.Value(Of String)("action") = "Update").Select(Function(x) x.Value(Of String)("action") & " " & x.Value(Of String)("name") & If(x.Value(Of Boolean)("isSecret"), " (value from approved secret source)", "")))
    Row("Assets to configure", If(a = "", "none", a))
    Dim q As String = String.Join("; ", cfg("queues").Children(Of Newtonsoft.Json.Linq.JObject)().Where(Function(x) x.Value(Of String)("action") = "Create" OrElse x.Value(Of String)("action") = "Update").Select(Function(x) x.Value(Of String)("action") & " " & x.Value(Of String)("proposedName")))
    Row("Queues to configure", If(q = "", "none", q))
    Dim u As String = String.Join("; ", cfg("access").Children(Of Newtonsoft.Json.Linq.JObject)().Where(Function(x) x.Value(Of String)("action") = "Grant").Select(Function(x) x.Value(Of String)("name") & ": " & x.Value(Of String)("accessLevel")))
    Row("User/group access changes", If(u = "", "none", u))
End If
sb.Append("</table>")
Dim List As Action(Of String, String, Newtonsoft.Json.Linq.JArray) = Sub(title, cls, items)
    If items Is Nothing OrElse items.Count = 0 Then Return
    sb.Append("<div class=""" & cls & """><b>" & E(title) & "</b><ul>")
    For Each i As Newtonsoft.Json.Linq.JToken In items
        sb.Append("<li>" & E(i.ToString()) & "</li>")
    Next
    sb.Append("</ul></div>")
End Sub
List("Validation errors", "am-errors", in_Errors)
List("Warnings", "am-warnings", in_Warnings)
List("Notes", "am-notes", in_Notes)
If (in_Errors Is Nothing OrElse in_Errors.Count = 0) Then sb.Append("<div class=""am-ok""><b>Validation passed.</b></div>")
out_Html = sb.ToString()
