'ARG in in_Request JO
'ARG in in_Errors JA
'ARG in in_Warnings JA
'ARG in in_Notes JA
'ARG out out_Html S
' Review summary shown in the form (all values HTML-encoded). Lists what will change; nothing is changed here.
' Table rows as (label, value) pairs
Dim rows As New List(Of String())
' Power Automate requests name a solution instead of a process
Dim pa As Boolean = Convert.ToString(in_Request.SelectToken("automationTool")) = "Power Automate"
rows.Add(New String() {"Bot ID", Convert.ToString(in_Request.SelectToken("botId"))})
rows.Add(New String() {"Automation Tool", Convert.ToString(in_Request.SelectToken("automationTool"))})
rows.Add(New String() {"Process Type", Convert.ToString(in_Request.SelectToken("processType"))})
rows.Add(New String() {If(pa, "Solution", "Process Name"), Convert.ToString(in_Request.SelectToken("package.processName"))})
rows.Add(New String() {If(pa, "Solution (unique name)", "Package Name"), Convert.ToString(in_Request.SelectToken("package.packageName"))})
rows.Add(New String() {"Requested Version", Convert.ToString(in_Request.SelectToken("package.requestedVersion"))})
rows.Add(New String() {"Deployment Path", Convert.ToString(in_Request.SelectToken("deploymentPath")) & " (" & Convert.ToString(in_Request.SelectToken("sourceEnvironment")) & " " & ChrW(8594) & " " & Convert.ToString(in_Request.SelectToken("targetEnvironment")) & ")"})
rows.Add(New String() {"Version in " & Convert.ToString(in_Request.SelectToken("targetEnvironment")) & " now", If(Convert.ToString(in_Request.SelectToken("package.targetVersionAtRequest")) = "", "none", Convert.ToString(in_Request.SelectToken("package.targetVersionAtRequest")))})
' Enhancement details, when given
If Convert.ToString(in_Request.SelectToken("enhancement.description")) <> "" Then
    rows.Add(New String() {"Enhancement", Convert.ToString(in_Request.SelectToken("enhancement.description"))})
    rows.Add(New String() {"Change Reference", Convert.ToString(in_Request.SelectToken("enhancement.changeReference"))})
End If
' Bug fix details, when given
If Convert.ToString(in_Request.SelectToken("bugFix.description")) <> "" Then
    rows.Add(New String() {"Bug", Convert.ToString(in_Request.SelectToken("bugFix.description"))})
    rows.Add(New String() {"Incident Reference", Convert.ToString(in_Request.SelectToken("bugFix.incidentReference"))})
End If
' Configuration changes (New requests only)
Dim cfg As JObject = TryCast(in_Request("configuration"), JObject)
If cfg IsNot Nothing Then
    rows.Add(New String() {"Process name in target", cfg.Value(Of String)("processName")})
    rows.Add(New String() {"Target folder", cfg.Value(Of String)("targetFolder")})
    ' Assets that will be created or updated
    Dim a As String = String.Join("; ", cfg("assets").Children(Of JObject)().Where(Function(x) x.Value(Of String)("action") = "Create" OrElse x.Value(Of String)("action") = "Update").Select(Function(x) x.Value(Of String)("action") & " " & x.Value(Of String)("name") & If(x.Value(Of Boolean)("isSecret"), " (value from approved secret source)", "")))
    rows.Add(New String() {"Assets to configure", If(a = "", "none", a)})
    ' Queues that will be created or updated
    Dim q As String = String.Join("; ", cfg("queues").Children(Of JObject)().Where(Function(x) x.Value(Of String)("action") = "Create" OrElse x.Value(Of String)("action") = "Update").Select(Function(x) x.Value(Of String)("action") & " " & x.Value(Of String)("proposedName")))
    rows.Add(New String() {"Queues to configure", If(q = "", "none", q)})
    ' Accounts that will get access
    Dim u As String = String.Join("; ", cfg("access").Children(Of JObject)().Where(Function(x) x.Value(Of String)("action") = "Grant").Select(Function(x) x.Value(Of String)("name") & ": " & x.Value(Of String)("accessLevel")))
    rows.Add(New String() {"User/group access changes", If(u = "", "none", u)})
End If
' Table of all rows, every value HTML-encoded
out_Html = "<table class=""am-summary"">" & String.Concat(rows.Select(Function(r) "<tr><th>" & System.Net.WebUtility.HtmlEncode(r(0)) & "</th><td>" & System.Net.WebUtility.HtmlEncode(If(r(1), "")) & "</td></tr>")) & "</table>"
' Validation errors, warnings and notes as lists
If in_Errors IsNot Nothing AndAlso in_Errors.Count > 0 Then out_Html &= "<div class=""am-errors""><b>Validation errors</b><ul>" & String.Concat(in_Errors.Select(Function(i) "<li>" & System.Net.WebUtility.HtmlEncode(i.ToString()) & "</li>")) & "</ul></div>"
If in_Warnings IsNot Nothing AndAlso in_Warnings.Count > 0 Then out_Html &= "<div class=""am-warnings""><b>Warnings</b><ul>" & String.Concat(in_Warnings.Select(Function(i) "<li>" & System.Net.WebUtility.HtmlEncode(i.ToString()) & "</li>")) & "</ul></div>"
If in_Notes IsNot Nothing AndAlso in_Notes.Count > 0 Then out_Html &= "<div class=""am-notes""><b>Notes</b><ul>" & String.Concat(in_Notes.Select(Function(i) "<li>" & System.Net.WebUtility.HtmlEncode(i.ToString()) & "</li>")) & "</ul></div>"
' Success line when there are no errors
If in_Errors Is Nothing OrElse in_Errors.Count = 0 Then out_Html &= "<div class=""am-ok""><b>Validation passed.</b></div>"
