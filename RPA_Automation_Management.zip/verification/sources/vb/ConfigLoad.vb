'ARG in in_SettingsPath S
'ARG in in_BotMappingPath S
'ARG out out_Config JO
'ARG out out_Error S
' Reads Config\Settings.json and Config\BotMapping.json (paths absolute or relative to the project folder),
' merges the bot list into the settings object (out_Config("bots")) and checks the structure the workflows rely on.
' out_Error is empty when the configuration is usable; otherwise it lists every problem (no secrets are read here).
out_Config = Nothing
out_Error = ""
Dim problems As New List(Of String)
Dim Full As Func(Of String, String) = Function(p) If(System.IO.Path.IsPathRooted(p), p, System.IO.Path.Combine(Environment.CurrentDirectory, p))
Dim settingsFile As String = Full(If(in_SettingsPath, ""))
Dim mappingFile As String = Full(If(in_BotMappingPath, ""))
For Each f As String In New String() {settingsFile, mappingFile}
    If Not System.IO.File.Exists(f) Then problems.Add("file not found: " & f)
Next
If problems.Count > 0 Then
    out_Error = String.Join("; ", problems)
    Return
End If
Dim cfg As Newtonsoft.Json.Linq.JObject
Dim map As Newtonsoft.Json.Linq.JObject
Try
    cfg = Newtonsoft.Json.Linq.JObject.Parse(System.IO.File.ReadAllText(settingsFile))
    map = Newtonsoft.Json.Linq.JObject.Parse(System.IO.File.ReadAllText(mappingFile))
Catch ex As Newtonsoft.Json.JsonReaderException
    out_Error = "configuration is not valid JSON: " & ex.Message
    Return
End Try
Dim envs As String() = {"Dev", "UAT", "Prod"}
For Each env As String In envs
    Dim e As Newtonsoft.Json.Linq.JToken = cfg.SelectToken("uipath.environments." & env)
    If e Is Nothing Then
        problems.Add("uipath.environments." & env & " is missing")
    Else
        For Each k As String In New String() {"orchestratorUrl", "tokenUrl", "credentialAsset", "credentialFolder", "scope"}
            If String.IsNullOrWhiteSpace(e.Value(Of String)(k)) Then problems.Add("uipath.environments." & env & "." & k & " is empty")
        Next
    End If
    If String.IsNullOrWhiteSpace(cfg.SelectToken("powerAutomate.environments." & env & ".environmentUrl")?.ToString()) Then problems.Add("powerAutomate.environments." & env & ".environmentUrl is empty")
Next
For Each k As String In New String() {"governance.orchestratorEnvironment", "governance.folderPath", "governance.requestsQueue", "governance.approvalsQueue", "governance.resultsQueue", "audit.folder", "security.maskedValueText"}
    If String.IsNullOrWhiteSpace(cfg.SelectToken(k)?.ToString()) Then problems.Add(k & " is empty")
Next
Dim paths As Newtonsoft.Json.Linq.JArray = TryCast(cfg("deploymentPaths"), Newtonsoft.Json.Linq.JArray)
If paths Is Nothing OrElse paths.Count = 0 Then
    problems.Add("deploymentPaths must be a non-empty array")
Else
    For Each p As Newtonsoft.Json.Linq.JObject In paths.Children(Of Newtonsoft.Json.Linq.JObject)()
        If Not envs.Contains(p.Value(Of String)("source")) OrElse Not envs.Contains(p.Value(Of String)("target")) Then problems.Add("deployment path '" & p.Value(Of String)("name") & "' must use Dev, UAT or Prod as source and target")
        If p.Value(Of String)("source") = p.Value(Of String)("target") Then problems.Add("deployment path '" & p.Value(Of String)("name") & "' has the same source and target")
        If p.Value(Of String)("target") = "Prod" AndAlso Not p.Value(Of Boolean)("requiresApproval") Then problems.Add("deployment path '" & p.Value(Of String)("name") & "' targets Prod and must have requiresApproval = true")
        If p.Value(Of String)("target") = "Prod" AndAlso p.Value(Of Boolean)("autoExecuteAfterSubmit") Then problems.Add("deployment path '" & p.Value(Of String)("name") & "' targets Prod and cannot use autoExecuteAfterSubmit")
    Next
End If
For Each t As String In New String() {"New", "Enhancement", "Bug Fix"}
    If cfg.SelectToken("requestRules['" & t & "'].requiredFields") Is Nothing Then problems.Add("requestRules." & t & ".requiredFields is missing")
Next
If TryCast(cfg("roleMappings"), Newtonsoft.Json.Linq.JObject) Is Nothing Then problems.Add("roleMappings must be an object")
Dim bots As Newtonsoft.Json.Linq.JArray = TryCast(map("bots"), Newtonsoft.Json.Linq.JArray)
If bots Is Nothing Then
    problems.Add("BotMapping.json: 'bots' must be an array")
Else
    Dim seen As New HashSet(Of String)(StringComparer.OrdinalIgnoreCase)
    For Each b As Newtonsoft.Json.Linq.JObject In bots.Children(Of Newtonsoft.Json.Linq.JObject)()
        Dim id As String = If(b.Value(Of String)("botId"), "").Trim()
        Dim ids As New List(Of String) From {id}
        If TypeOf b("aliases") Is Newtonsoft.Json.Linq.JArray Then ids.AddRange(b("aliases").Values(Of String)())
        For Each i As String In ids
            If i = "" Then
                problems.Add("BotMapping.json: a bot has an empty botId/alias")
            ElseIf Not seen.Add(i) Then
                problems.Add("BotMapping.json: Bot ID or alias '" & i & "' is used twice")
            End If
        Next
        Dim tool As String = b.Value(Of String)("automationTool")
        If tool = "UiPath" Then
            For Each k As String In New String() {"uipath.processName", "uipath.packageId", "uipath.folders.Dev", "uipath.folders.UAT", "uipath.folders.Prod"}
                If String.IsNullOrWhiteSpace(b.SelectToken(k)?.ToString()) Then problems.Add("BotMapping.json: " & id & " " & k & " is empty")
            Next
        ElseIf tool = "Power Automate" Then
            If String.IsNullOrWhiteSpace(b.SelectToken("powerAutomate.solutionUniqueName")?.ToString()) Then problems.Add("BotMapping.json: " & id & " powerAutomate.solutionUniqueName is empty")
        Else
            problems.Add("BotMapping.json: " & id & " has unsupported automationTool '" & tool & "'")
        End If
    Next
    cfg("bots") = bots
End If
If problems.Count > 0 Then
    out_Error = String.Join("; ", problems)
Else
    out_Config = cfg
End If
