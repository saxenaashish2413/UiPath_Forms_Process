'ARG in in_SettingsPath S
'ARG in in_BotMappingPath S
'ARG out out_Config JO
'ARG out out_Error S
' Reads Config\Settings.json and Config\BotMapping.json (paths absolute or relative to the project folder), merges the bot list into the settings object (out_Config("bots")) and checks the structure the workflows rely on. out_Error is empty when the configuration is usable; otherwise it lists every problem. No credentials are read here.
out_Config = Nothing
out_Error = ""
' Every problem found; all are reported together
Dim problems As New List(Of String)
' Full paths of the two files (relative paths are under the project folder)
Dim settingsFile As String = If(System.IO.Path.IsPathRooted(If(in_SettingsPath, "")), If(in_SettingsPath, ""), System.IO.Path.Combine(Environment.CurrentDirectory, If(in_SettingsPath, "")))
Dim mappingFile As String = If(System.IO.Path.IsPathRooted(If(in_BotMappingPath, "")), If(in_BotMappingPath, ""), System.IO.Path.Combine(Environment.CurrentDirectory, If(in_BotMappingPath, "")))
' Both files must exist
If Not System.IO.File.Exists(settingsFile) Then problems.Add("file not found: " & settingsFile)
If Not System.IO.File.Exists(mappingFile) Then problems.Add("file not found: " & mappingFile)
Dim cfg As JObject = Nothing
Dim map As JObject = Nothing
' Read both files as JSON
If problems.Count = 0 Then
    Try
        cfg = JObject.Parse(System.IO.File.ReadAllText(settingsFile))
        map = JObject.Parse(System.IO.File.ReadAllText(mappingFile))
    Catch ex As JsonReaderException
        problems.Add("configuration is not valid JSON: " & ex.Message)
    End Try
End If
' Check the structure only when both files were read
If problems.Count = 0 Then
    ' Each environment needs its Orchestrator and Dataverse settings
    For Each env As String In New String() {"Dev", "UAT", "Prod"}
        Dim e As JToken = cfg.SelectToken("uipath.environments." & env)
        If e Is Nothing Then
            problems.Add("uipath.environments." & env & " is missing")
        Else
            ' Sign-in mode: UsernamePassword or ClientCredentials
            Dim mode As String = If(e.Value(Of String)("authMode"), "ClientCredentials")
            If mode <> "ClientCredentials" AndAlso mode <> "UsernamePassword" Then problems.Add("uipath.environments." & env & ".authMode must be UsernamePassword or ClientCredentials")
            If mode = "UsernamePassword" AndAlso String.IsNullOrWhiteSpace(e.Value(Of String)("tenantName")) Then problems.Add("uipath.environments." & env & ".tenantName is empty (needed to sign in with username and password)")
            ' Required keys for that mode
            For Each k As String In If(mode = "UsernamePassword", New String() {"orchestratorUrl", "credentialAsset", "credentialFolder"}, New String() {"orchestratorUrl", "tokenUrl", "credentialAsset", "credentialFolder", "scope"})
                If String.IsNullOrWhiteSpace(e.Value(Of String)(k)) Then problems.Add("uipath.environments." & env & "." & k & " is empty")
            Next
        End If
        If String.IsNullOrWhiteSpace(Convert.ToString(cfg.SelectToken("powerAutomate.environments." & env & ".environmentUrl"))) Then problems.Add("powerAutomate.environments." & env & ".environmentUrl is empty")
    Next
    ' Governance, audit and masking settings must be filled in
    For Each k As String In New String() {"governance.orchestratorEnvironment", "governance.folderPath", "governance.requestsQueue", "governance.approvalsQueue", "governance.resultsQueue", "audit.folder", "security.maskedValueText"}
        If String.IsNullOrWhiteSpace(Convert.ToString(cfg.SelectToken(k))) Then problems.Add(k & " is empty")
    Next
    ' Deployment paths: valid environments, and Prod always behind an approval
    Dim paths As JArray = TryCast(cfg("deploymentPaths"), JArray)
    If paths Is Nothing OrElse paths.Count = 0 Then
        problems.Add("deploymentPaths must be a non-empty array")
    Else
        For Each p As JObject In paths.Children(Of JObject)()
            If Not New String() {"Dev", "UAT", "Prod"}.Contains(p.Value(Of String)("source")) OrElse Not New String() {"Dev", "UAT", "Prod"}.Contains(p.Value(Of String)("target")) Then problems.Add("deployment path '" & p.Value(Of String)("name") & "' must use Dev, UAT or Prod as source and target")
            If p.Value(Of String)("source") = p.Value(Of String)("target") Then problems.Add("deployment path '" & p.Value(Of String)("name") & "' has the same source and target")
            If p.Value(Of String)("target") = "Prod" AndAlso Not p.Value(Of Boolean)("requiresApproval") Then problems.Add("deployment path '" & p.Value(Of String)("name") & "' targets Prod and must have requiresApproval = true")
            If p.Value(Of String)("target") = "Prod" AndAlso p.Value(Of Boolean)("autoExecuteAfterSubmit") Then problems.Add("deployment path '" & p.Value(Of String)("name") & "' targets Prod and cannot use autoExecuteAfterSubmit")
        Next
    End If
    ' Field rules per Process Type
    For Each t As String In New String() {"New", "Enhancement", "Bug Fix"}
        If cfg.SelectToken("requestRules['" & t & "'].requiredFields") Is Nothing Then problems.Add("requestRules." & t & ".requiredFields is missing")
    Next
    If TryCast(cfg("roleMappings"), JObject) Is Nothing Then problems.Add("roleMappings must be an object")
    ' Dev discovery settings: only known matchOn fields
    For Each d As KeyValuePair(Of String, String()) In New Dictionary(Of String, String()) From {{"uipath.discovery", New String() {"Name", "ProcessKey", "Description"}}, {"powerAutomate.discovery", New String() {"uniquename", "friendlyname", "description"}}}
        If cfg.SelectToken(d.Key) IsNot Nothing AndAlso TryCast(cfg.SelectToken(d.Key), JObject) Is Nothing Then problems.Add(d.Key & " must be an object")
        If TypeOf cfg.SelectToken(d.Key & ".matchOn") Is JArray Then
            For Each f As String In cfg.SelectToken(d.Key & ".matchOn").Values(Of String)().Where(Function(x) Not d.Value.Contains(x, StringComparer.OrdinalIgnoreCase))
                problems.Add(d.Key & ".matchOn: '" & f & "' is not supported (use " & String.Join(", ", d.Value) & ")")
            Next
        End If
    Next
    ' Bot ID mapping (optional entries)
    Dim bots As JArray = TryCast(map("bots"), JArray)
    If bots Is Nothing Then
        problems.Add("BotMapping.json: 'bots' must be an array")
    Else
        ' Bot IDs and aliases seen so far (to find duplicates)
        Dim seen As New List(Of String)
        For Each b As JObject In bots.Children(Of JObject)()
            Dim id As String = If(b.Value(Of String)("botId"), "").Trim()
            ' The Bot ID and its aliases
            Dim ids As List(Of String) = New String() {id}.Concat(If(TryCast(b("aliases"), JArray), New JArray()).Values(Of String)()).ToList()
            For Each i As String In ids
                If i = "" Then
                    problems.Add("BotMapping.json: a bot has an empty botId/alias")
                ElseIf seen.Contains(i, StringComparer.OrdinalIgnoreCase) Then
                    problems.Add("BotMapping.json: Bot ID or alias '" & i & "' is used twice")
                Else
                    seen.Add(i)
                End If
            Next
            ' Each entry needs the section for its tool
            Dim tool As String = b.Value(Of String)("automationTool")
            If tool = "UiPath" Then
                For Each k As String In New String() {"uipath.processName", "uipath.packageId", "uipath.folders.Dev", "uipath.folders.UAT", "uipath.folders.Prod"}
                    If String.IsNullOrWhiteSpace(Convert.ToString(b.SelectToken(k))) Then problems.Add("BotMapping.json: " & id & " " & k & " is empty")
                Next
            ElseIf tool = "Power Automate" Then
                If String.IsNullOrWhiteSpace(Convert.ToString(b.SelectToken("powerAutomate.solutionUniqueName"))) Then problems.Add("BotMapping.json: " & id & " powerAutomate.solutionUniqueName is empty")
            Else
                problems.Add("BotMapping.json: " & id & " has unsupported automationTool '" & tool & "'")
            End If
        Next
        ' Merge the bot list into the settings
        cfg("bots") = bots
    End If
End If
' Return the configuration, or every problem found
If problems.Count > 0 Then
    out_Error = String.Join("; ", problems)
Else
    out_Config = cfg
End If
