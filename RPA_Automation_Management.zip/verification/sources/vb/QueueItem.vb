'ARG in in_Mode S
'ARG in in_QueueName S
'ARG in in_Reference S
'ARG in in_Content JO
'ARG in in_ItemJson S
'ARG out out_Body S
'ARG out out_Content JO
' Governance queue items (requests, approvals, results) in the Orchestrator named by settings.governance. Mode body: builds the POST odata/Queues/UiPathODataSvc.AddQueueItem body (SpecificContent values are strings; objects are stored as JSON text). Mode parse: reads SpecificContent of a queue item, with RequestJson/ResultJson parsed back into objects.
out_Body = ""
out_Content = Nothing
' Build the AddQueueItem body
If in_Mode = "body" Then
    ' Queue item fields must be text: objects and arrays are stored as JSON text
    Dim sc As New JObject()
    For Each p As JProperty In in_Content.Properties()
        sc(p.Name) = If(p.Value.Type = JTokenType.Object OrElse p.Value.Type = JTokenType.Array, p.Value.ToString(Newtonsoft.Json.Formatting.None), p.Value.ToString())
    Next
    ' Queue name, priority and the unique reference that prevents duplicates
    Dim item As New JObject()
    item("Name") = in_QueueName
    item("Priority") = "Normal"
    item("Reference") = in_Reference
    item("SpecificContent") = sc
    out_Body = New JObject(New JProperty("itemData", item)).ToString(Newtonsoft.Json.Formatting.None)
ElseIf in_Mode = "parse" Then
    ' The queue item returned by Orchestrator
    Dim it As JObject = JObject.Parse(in_ItemJson)
    Dim content As JObject = If(TryCast(it("SpecificContent"), JObject), New JObject())
    Dim res As New JObject()
    For Each p As JProperty In content.Properties()
        ' Fields ending in "Json" that hold an object are turned back into objects (RequestJson -> Request)
        If p.Name.EndsWith("Json") AndAlso If(p.Value.Type = JTokenType.Null, "", p.Value.ToString()).TrimStart().StartsWith("{") Then
            res(p.Name.Substring(0, p.Name.Length - 4)) = JObject.Parse(p.Value.ToString())
        Else
            res(p.Name) = If(p.Value.Type = JTokenType.Null, "", p.Value.ToString())
        End If
    Next
    ' Keep the queue item's own Id, status and reference
    res("queueItemId") = it("Id")
    res("queueItemStatus") = it("Status")
    res("reference") = it("Reference")
    out_Content = res
Else
    Throw New ArgumentException("QueueItem mode " & in_Mode)
End If
