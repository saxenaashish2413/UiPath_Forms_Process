'ARG in in_Mode S
'ARG in in_QueueName S
'ARG in in_Reference S
'ARG in in_Content JO
'ARG in in_ItemJson S
'ARG out out_Body S
'ARG out out_Content JO
' Governance queue items (requests, approvals, results) in the Orchestrator named by settings.governance.
'  body : POST odata/Queues/UiPathODataSvc.AddQueueItem body; SpecificContent values are strings (objects as JSON text)
'  parse: SpecificContent of a queue item, with RequestJson/ResultJson parsed back into objects
out_Body = ""
out_Content = Nothing
If in_Mode = "body" Then
    Dim sc As New Newtonsoft.Json.Linq.JObject()
    For Each p As Newtonsoft.Json.Linq.JProperty In in_Content.Properties()
        sc(p.Name) = If(p.Value.Type = Newtonsoft.Json.Linq.JTokenType.Object OrElse p.Value.Type = Newtonsoft.Json.Linq.JTokenType.Array, p.Value.ToString(Newtonsoft.Json.Formatting.None), p.Value.ToString())
    Next
    Dim item As New Newtonsoft.Json.Linq.JObject()
    item("Name") = in_QueueName
    item("Priority") = "Normal"
    item("Reference") = in_Reference
    item("SpecificContent") = sc
    out_Body = New Newtonsoft.Json.Linq.JObject(New Newtonsoft.Json.Linq.JProperty("itemData", item)).ToString(Newtonsoft.Json.Formatting.None)
ElseIf in_Mode = "parse" Then
    Dim it As Newtonsoft.Json.Linq.JObject = Newtonsoft.Json.Linq.JObject.Parse(in_ItemJson)
    Dim sc As Newtonsoft.Json.Linq.JObject = If(TryCast(it("SpecificContent"), Newtonsoft.Json.Linq.JObject), New Newtonsoft.Json.Linq.JObject())
    Dim res As New Newtonsoft.Json.Linq.JObject()
    For Each p As Newtonsoft.Json.Linq.JProperty In sc.Properties()
        Dim v As String = If(p.Value.Type = Newtonsoft.Json.Linq.JTokenType.Null, "", p.Value.ToString())
        If p.Name.EndsWith("Json") AndAlso v.TrimStart().StartsWith("{") Then
            res(p.Name.Substring(0, p.Name.Length - 4)) = Newtonsoft.Json.Linq.JObject.Parse(v)
        Else
            res(p.Name) = v
        End If
    Next
    res("queueItemId") = it("Id")
    res("queueItemStatus") = it("Status")
    res("reference") = it("Reference")
    out_Content = res
Else
    Throw New ArgumentException("QueueItem mode " & in_Mode)
End If
