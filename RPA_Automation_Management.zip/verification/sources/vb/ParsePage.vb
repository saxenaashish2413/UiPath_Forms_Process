'ARG in in_ResponseBody S
'ARG io io_Items JA
'ARG out out_NextUrl S
'ARG out out_PageCount I
' Appends one page of an OData collection ({"value":[...]}) to io_Items. out_NextUrl = @odata.nextLink when the server pages that way (Dataverse); empty otherwise. out_PageCount = number of items on this page (Orchestrator paging uses $top/$skip and stops when a page is short).
' Start the list on the first page
If io_Items Is Nothing Then io_Items = New JArray()
out_NextUrl = ""
out_PageCount = 0
' An empty response adds nothing
If Not String.IsNullOrWhiteSpace(in_ResponseBody) Then
    ' Parse the response; dates are kept as text exactly as the API sent them
    Dim root As JObject = Newtonsoft.Json.JsonConvert.DeserializeObject(Of JObject)(in_ResponseBody, New Newtonsoft.Json.JsonSerializerSettings With {.DateParseHandling = Newtonsoft.Json.DateParseHandling.None})
    Dim arr As JArray = TryCast(root("value"), JArray)
    ' Add every item of this page to the list
    If arr IsNot Nothing Then
        For Each item As JToken In arr
            io_Items.Add(item)
        Next
        out_PageCount = arr.Count
    End If
    ' Link to the next page, if the server returned one
    out_NextUrl = If(root.Value(Of String)("@odata.nextLink"), "")
End If
