'ARG in in_ResponseBody S
'ARG io io_Items JA
'ARG out out_NextUrl S
'ARG out out_PageCount I
' Appends one page of an OData collection ({"value":[...]}) to io_Items.
' out_NextUrl = @odata.nextLink when the server pages that way (Dataverse); empty otherwise.
' out_PageCount = number of items on this page (Orchestrator paging uses $top/$skip and stops when a page is short).
If io_Items Is Nothing Then io_Items = New Newtonsoft.Json.Linq.JArray()
out_NextUrl = ""
out_PageCount = 0
If String.IsNullOrWhiteSpace(in_ResponseBody) Then Return
Dim root As Newtonsoft.Json.Linq.JObject = Newtonsoft.Json.JsonConvert.DeserializeObject(Of Newtonsoft.Json.Linq.JObject)(in_ResponseBody, New Newtonsoft.Json.JsonSerializerSettings With {.DateParseHandling = Newtonsoft.Json.DateParseHandling.None})
Dim arr As Newtonsoft.Json.Linq.JArray = TryCast(root("value"), Newtonsoft.Json.Linq.JArray)
If arr IsNot Nothing Then
    For Each item As Newtonsoft.Json.Linq.JToken In arr
        io_Items.Add(item)
    Next
    out_PageCount = arr.Count
End If
out_NextUrl = If(root.Value(Of String)("@odata.nextLink"), "")
