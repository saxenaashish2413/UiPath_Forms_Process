'ARG in in_Config JO
'ARG in in_Form JO
'ARG in in_Details JO
'ARG in in_RequestedBy S
'ARG out out_Request JO
' Builds the auditable request object from the form values and the fetched details. Only fields that apply to the selected Process Type are kept (requestRules); hidden or stale values are dropped. Read-only values (Dev values, target state) always come from in_Details, never from the form; from the form only the editable columns are taken (action, proposed value/name, access level). Secret values are never part of a request.
' Form values, trimmed (empty when the field is empty)
Dim tool As String = Convert.ToString(in_Form("AutomationTool")).Trim()
Dim ptype As String = Convert.ToString(in_Form("ProcessType")).Trim()
Dim pathName As String = Convert.ToString(in_Form("DeploymentPath")).Trim()
Dim version As String = Convert.ToString(in_Form("RequestedVersion")).Trim()
' The selected deployment path from settings
Dim path As JObject = in_Config("deploymentPaths").Children(Of JObject)().FirstOrDefault(Function(x) x.Value(Of String)("name") = pathName)
' The details fetched by Fetch Details (empty when none)
Dim det As JObject = If(in_Details, New JObject())
' Request header: tool, type, Bot ID, path, who and when
Dim r As New JObject()
r("schemaVersion") = "1.0"
r("automationTool") = tool
r("processType") = ptype
' The canonical Bot ID from the details (the user may have typed an alias or other casing)
r("botId") = If(String.IsNullOrEmpty(det.Value(Of String)("botId")), Convert.ToString(in_Form("BotId")).Trim().ToUpperInvariant(), det.Value(Of String)("botId"))
r("deploymentPath") = pathName
r("sourceEnvironment") = If(path Is Nothing, "", path.Value(Of String)("source"))
r("targetEnvironment") = If(path Is Nothing, "", path.Value(Of String)("target"))
r("requestedBy") = in_RequestedBy
r("requestedAtUtc") = DateTime.UtcNow.ToString("o", System.Globalization.CultureInfo.InvariantCulture)
' Package: names from Dev, the requested version, and the versions deployed when the request was made
Dim pk As New JObject()
pk("processName") = Convert.ToString(det.SelectToken("process.processName"))
pk("packageName") = Convert.ToString(det.SelectToken("process.packageName"))
pk("requestedVersion") = version
pk("sourceVersionAtRequest") = Convert.ToString(det.SelectToken("environments." & r.Value(Of String)("sourceEnvironment") & ".deployedVersion"))
pk("targetVersionAtRequest") = Convert.ToString(det.SelectToken("environments." & r.Value(Of String)("targetEnvironment") & ".deployedVersion"))
r("package") = pk
' Fields that only apply to Enhancement or Bug Fix
If ptype = "Enhancement" Then
    r("enhancement") = New JObject(New JProperty("description", Convert.ToString(in_Form("EnhancementDescription")).Trim()), New JProperty("changeReference", Convert.ToString(in_Form("ChangeReference")).Trim()))
ElseIf ptype = "Bug Fix" Then
    r("bugFix") = New JObject(New JProperty("description", Convert.ToString(in_Form("BugDescription")).Trim()), New JProperty("incidentReference", Convert.ToString(in_Form("IncidentReference")).Trim()))
End If
' Configuration (assets, queues, access) only for types that include it (New) and only for UiPath
If CBool(If(in_Config.SelectToken("requestRules['" & ptype & "'].includeConfiguration"), New JValue(False))) AndAlso tool = "UiPath" Then
    Dim cfg As New JObject()
    ' Process name and target folder: the requester's proposal, or the fetched values
    Dim origName As String = pk.Value(Of String)("processName")
    Dim origFolder As String = Convert.ToString(det.SelectToken("environments." & r.Value(Of String)("targetEnvironment") & ".folderPath"))
    cfg("processName") = If(Convert.ToString(in_Form("ProposedProcessName")).Trim() = "", origName, Convert.ToString(in_Form("ProposedProcessName")).Trim())
    cfg("targetFolder") = If(Convert.ToString(in_Form("ProposedTargetFolder")).Trim() = "", origFolder, Convert.ToString(in_Form("ProposedTargetFolder")).Trim())
    cfg("additionalConfiguration") = Convert.ToString(in_Form("AdditionalConfig")).Trim()
    ' True when the requester changed anything (only configuration editors may)
    Dim edited As Boolean = cfg.Value(Of String)("processName") <> origName OrElse cfg.Value(Of String)("targetFolder") <> origFolder OrElse cfg.Value(Of String)("additionalConfiguration") <> ""
    ' The three grids as the form sent them (JSON text); unreadable text counts as no edits
    Dim formAssets As New List(Of JObject)
    Dim formQueues As New List(Of JObject)
    Dim formAccess As New List(Of JObject)
    Try
        If Convert.ToString(in_Form("AssetsProposedJson")).Trim() <> "" Then formAssets = JArray.Parse(Convert.ToString(in_Form("AssetsProposedJson"))).Children(Of JObject)().ToList()
    Catch ex As JsonReaderException
        formAssets = New List(Of JObject)
    End Try
    Try
        If Convert.ToString(in_Form("QueuesProposedJson")).Trim() <> "" Then formQueues = JArray.Parse(Convert.ToString(in_Form("QueuesProposedJson"))).Children(Of JObject)().ToList()
    Catch ex As JsonReaderException
        formQueues = New List(Of JObject)
    End Try
    Try
        If Convert.ToString(in_Form("AccessProposedJson")).Trim() <> "" Then formAccess = JArray.Parse(Convert.ToString(in_Form("AccessProposedJson"))).Children(Of JObject)().ToList()
    Catch ex As JsonReaderException
        formAccess = New List(Of JObject)
    End Try
    ' Assets: fetched row + the editable columns from the form
    Dim assets As New JArray()
    For Each a As JObject In If(TryCast(det("assets"), JArray), New JArray()).Children(Of JObject)()
        ' The same row in the form grid
        Dim fa As JObject = formAssets.FirstOrDefault(Function(x) String.Equals(x.Value(Of String)("name"), a.Value(Of String)("name"), StringComparison.OrdinalIgnoreCase))
        Dim row As New JObject()
        row("name") = a("name")
        row("type") = a("type")
        row("isSecret") = a("isSecret")
        row("required") = a("required")
        row("targetExists") = a("targetExists")
        row("targetStatus") = a("targetStatus")
        row("hasSecretSource") = a("hasSecretSource")
        row("description") = a("description")
        row("action") = If(If(fa Is Nothing, Nothing, fa.Value(Of String)("action")), a.Value(Of String)("action"))
        ' Secret values are never taken from the form: they come from the approved secret source at deployment time
        row("proposedValue") = If(a.Value(Of Boolean)("isSecret"), "", If(If(fa Is Nothing, Nothing, fa.Value(Of String)("proposedValue")), a.Value(Of String)("proposedValue")))
        If row.Value(Of String)("action") <> a.Value(Of String)("action") OrElse row.Value(Of String)("proposedValue") <> If(a.Value(Of Boolean)("isSecret"), "", a.Value(Of String)("proposedValue")) Then edited = True
        assets.Add(row)
    Next
    ' Queues: fetched row + action and proposed name from the form
    Dim queues As New JArray()
    For Each q As JObject In If(TryCast(det("queues"), JArray), New JArray()).Children(Of JObject)()
        Dim fq As JObject = formQueues.FirstOrDefault(Function(x) String.Equals(x.Value(Of String)("name"), q.Value(Of String)("name"), StringComparison.OrdinalIgnoreCase))
        Dim qrow As JObject = CType(q.DeepClone(), JObject)
        qrow("action") = If(If(fq Is Nothing, Nothing, fq.Value(Of String)("action")), q.Value(Of String)("action"))
        qrow("proposedName") = If(If(fq Is Nothing, Nothing, fq.Value(Of String)("proposedName")), q.Value(Of String)("proposedName")).Trim()
        qrow.Remove("savedStatus")
        If qrow.Value(Of String)("action") <> q.Value(Of String)("action") OrElse qrow.Value(Of String)("proposedName") <> q.Value(Of String)("proposedName") Then edited = True
        queues.Add(qrow)
    Next
    ' Access: fetched row + action and access level from the form
    Dim access As New JArray()
    For Each u As JObject In If(TryCast(det("access"), JArray), New JArray()).Children(Of JObject)()
        Dim fu As JObject = formAccess.FirstOrDefault(Function(x) String.Equals(x.Value(Of String)("name"), u.Value(Of String)("name"), StringComparison.OrdinalIgnoreCase))
        Dim urow As JObject = CType(u.DeepClone(), JObject)
        urow("action") = If(If(fu Is Nothing, Nothing, fu.Value(Of String)("action")), u.Value(Of String)("action"))
        urow("accessLevel") = If(If(fu Is Nothing, Nothing, fu.Value(Of String)("accessLevel")), u.Value(Of String)("accessLevel"))
        urow.Remove("savedStatus")
        If urow.Value(Of String)("action") <> u.Value(Of String)("action") OrElse urow.Value(Of String)("accessLevel") <> u.Value(Of String)("accessLevel") Then edited = True
        access.Add(urow)
    Next
    cfg("assets") = assets
    cfg("queues") = queues
    cfg("access") = access
    cfg("editedByRequester") = edited
    r("configuration") = cfg
End If
' Unique reference: the same request cannot be submitted twice
r("reference") = Left("AM|" & If(tool = "UiPath", "UIP", "PA") & "|" & r.Value(Of String)("botId").ToUpperInvariant() & "|" & ptype & "|" & pathName & "|" & version, 128)
out_Request = r
