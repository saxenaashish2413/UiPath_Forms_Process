'ARG in in_Config JO
'ARG in in_Form JO
'ARG in in_Details JO
'ARG in in_RequestedBy S
'ARG out out_Request JO
' Builds the auditable request object from the form values and the fetched details.
' Only fields that apply to the selected Process Type are kept (requestRules); hidden or stale values are dropped.
' Read-only values (Dev values, target state) always come from in_Details, never from the form; from the form only the
' editable columns are taken (action, proposed value/name, access level). Secret values are never part of a request.
Dim inv As System.Globalization.CultureInfo = System.Globalization.CultureInfo.InvariantCulture
Dim F As Func(Of String, String) = Function(k) If(in_Form(k) Is Nothing OrElse in_Form(k).Type = Newtonsoft.Json.Linq.JTokenType.Null, "", in_Form(k).ToString().Trim())
Dim tool As String = F("AutomationTool")
Dim ptype As String = F("ProcessType")
Dim pathName As String = F("DeploymentPath")
Dim path As Newtonsoft.Json.Linq.JObject = in_Config("deploymentPaths").Children(Of Newtonsoft.Json.Linq.JObject)().FirstOrDefault(Function(x) x.Value(Of String)("name") = pathName)
Dim r As New Newtonsoft.Json.Linq.JObject()
r("schemaVersion") = "1.0"
r("automationTool") = tool
r("processType") = ptype
' The canonical Bot ID from the mapping (the user may have typed an alias or other casing).
r("botId") = If(in_Details Is Nothing OrElse String.IsNullOrEmpty(in_Details.Value(Of String)("botId")), F("BotId").ToUpperInvariant(), in_Details.Value(Of String)("botId"))
r("deploymentPath") = pathName
r("sourceEnvironment") = If(path Is Nothing, "", path.Value(Of String)("source"))
r("targetEnvironment") = If(path Is Nothing, "", path.Value(Of String)("target"))
r("requestedBy") = in_RequestedBy
r("requestedAtUtc") = DateTime.UtcNow.ToString("o", inv)
Dim version As String = F("RequestedVersion")
Dim det As Newtonsoft.Json.Linq.JObject = If(in_Details, New Newtonsoft.Json.Linq.JObject())
Dim pk As New Newtonsoft.Json.Linq.JObject()
pk("processName") = If(det.SelectToken("process.processName")?.ToString(), "")
pk("packageName") = If(det.SelectToken("process.packageName")?.ToString(), "")
pk("requestedVersion") = version
pk("sourceVersionAtRequest") = If(det.SelectToken("environments." & r.Value(Of String)("sourceEnvironment") & ".deployedVersion")?.ToString(), "")
pk("targetVersionAtRequest") = If(det.SelectToken("environments." & r.Value(Of String)("targetEnvironment") & ".deployedVersion")?.ToString(), "")
r("package") = pk
If ptype = "Enhancement" Then
    r("enhancement") = New Newtonsoft.Json.Linq.JObject(New Newtonsoft.Json.Linq.JProperty("description", F("EnhancementDescription")), New Newtonsoft.Json.Linq.JProperty("changeReference", F("ChangeReference")))
ElseIf ptype = "Bug Fix" Then
    r("bugFix") = New Newtonsoft.Json.Linq.JObject(New Newtonsoft.Json.Linq.JProperty("description", F("BugDescription")), New Newtonsoft.Json.Linq.JProperty("incidentReference", F("IncidentReference")))
End If
Dim includeCfg As Boolean = CBool(If(in_Config.SelectToken("requestRules['" & ptype & "'].includeConfiguration"), New Newtonsoft.Json.Linq.JValue(False)))
If includeCfg AndAlso tool = "UiPath" Then
    Dim Rows As Func(Of String, List(Of Newtonsoft.Json.Linq.JObject)) = Function(k)
        Dim t As String = F(k)
        If t = "" Then Return New List(Of Newtonsoft.Json.Linq.JObject)
        Try
            Return Newtonsoft.Json.Linq.JArray.Parse(t).Children(Of Newtonsoft.Json.Linq.JObject)().ToList()
        Catch ex As Newtonsoft.Json.JsonReaderException
            Return New List(Of Newtonsoft.Json.Linq.JObject)
        End Try
    End Function
    Dim Pick As Func(Of List(Of Newtonsoft.Json.Linq.JObject), String, Newtonsoft.Json.Linq.JObject) = Function(l, n) l.FirstOrDefault(Function(x) String.Equals(x.Value(Of String)("name"), n, StringComparison.OrdinalIgnoreCase))
    Dim cfg As New Newtonsoft.Json.Linq.JObject()
    Dim edited As Boolean = False
    Dim origName As String = pk.Value(Of String)("processName")
    Dim origFolder As String = If(det.SelectToken("environments." & r.Value(Of String)("targetEnvironment") & ".folderPath")?.ToString(), "")
    cfg("processName") = If(F("ProposedProcessName") = "", origName, F("ProposedProcessName"))
    cfg("targetFolder") = If(F("ProposedTargetFolder") = "", origFolder, F("ProposedTargetFolder"))
    cfg("additionalConfiguration") = F("AdditionalConfig")
    edited = cfg.Value(Of String)("processName") <> origName OrElse cfg.Value(Of String)("targetFolder") <> origFolder OrElse F("AdditionalConfig") <> ""
    Dim formAssets As List(Of Newtonsoft.Json.Linq.JObject) = Rows("AssetsProposedJson")
    Dim assets As New Newtonsoft.Json.Linq.JArray()
    For Each a As Newtonsoft.Json.Linq.JObject In If(TryCast(det("assets"), Newtonsoft.Json.Linq.JArray), New Newtonsoft.Json.Linq.JArray()).Children(Of Newtonsoft.Json.Linq.JObject)()
        Dim fa As Newtonsoft.Json.Linq.JObject = Pick(formAssets, a.Value(Of String)("name"))
        Dim row As New Newtonsoft.Json.Linq.JObject()
        row("name") = a("name") : row("type") = a("type") : row("isSecret") = a("isSecret") : row("required") = a("required")
        row("targetExists") = a("targetExists") : row("targetStatus") = a("targetStatus") : row("hasSecretSource") = a("hasSecretSource")
        row("description") = a("description")
        row("action") = If(fa?.Value(Of String)("action"), a.Value(Of String)("action"))
        ' Secret values are never taken from the form: they come from the approved secret source at deployment time.
        row("proposedValue") = If(a.Value(Of Boolean)("isSecret"), "", If(fa?.Value(Of String)("proposedValue"), a.Value(Of String)("proposedValue")))
        If row.Value(Of String)("action") <> a.Value(Of String)("action") OrElse row.Value(Of String)("proposedValue") <> If(a.Value(Of Boolean)("isSecret"), "", a.Value(Of String)("proposedValue")) Then edited = True
        assets.Add(row)
    Next
    Dim formQueues As List(Of Newtonsoft.Json.Linq.JObject) = Rows("QueuesProposedJson")
    Dim queues As New Newtonsoft.Json.Linq.JArray()
    For Each q As Newtonsoft.Json.Linq.JObject In If(TryCast(det("queues"), Newtonsoft.Json.Linq.JArray), New Newtonsoft.Json.Linq.JArray()).Children(Of Newtonsoft.Json.Linq.JObject)()
        Dim fq As Newtonsoft.Json.Linq.JObject = Pick(formQueues, q.Value(Of String)("name"))
        Dim row As Newtonsoft.Json.Linq.JObject = CType(q.DeepClone(), Newtonsoft.Json.Linq.JObject)
        row("action") = If(fq?.Value(Of String)("action"), q.Value(Of String)("action"))
        row("proposedName") = If(fq?.Value(Of String)("proposedName"), q.Value(Of String)("proposedName")).Trim()
        row.Remove("savedStatus")
        If row.Value(Of String)("action") <> q.Value(Of String)("action") OrElse row.Value(Of String)("proposedName") <> q.Value(Of String)("proposedName") Then edited = True
        queues.Add(row)
    Next
    Dim formAccess As List(Of Newtonsoft.Json.Linq.JObject) = Rows("AccessProposedJson")
    Dim access As New Newtonsoft.Json.Linq.JArray()
    For Each u As Newtonsoft.Json.Linq.JObject In If(TryCast(det("access"), Newtonsoft.Json.Linq.JArray), New Newtonsoft.Json.Linq.JArray()).Children(Of Newtonsoft.Json.Linq.JObject)()
        Dim fu As Newtonsoft.Json.Linq.JObject = Pick(formAccess, u.Value(Of String)("name"))
        Dim row As Newtonsoft.Json.Linq.JObject = CType(u.DeepClone(), Newtonsoft.Json.Linq.JObject)
        row("action") = If(fu?.Value(Of String)("action"), u.Value(Of String)("action"))
        row("accessLevel") = If(fu?.Value(Of String)("accessLevel"), u.Value(Of String)("accessLevel"))
        row.Remove("savedStatus")
        If row.Value(Of String)("action") <> u.Value(Of String)("action") OrElse row.Value(Of String)("accessLevel") <> u.Value(Of String)("accessLevel") Then edited = True
        access.Add(row)
    Next
    cfg("assets") = assets
    cfg("queues") = queues
    cfg("access") = access
    cfg("editedByRequester") = edited
    r("configuration") = cfg
End If
Dim toolCode As String = If(tool = "UiPath", "UIP", "PA")
r("reference") = Left("AM|" & toolCode & "|" & r.Value(Of String)("botId").ToUpperInvariant() & "|" & ptype & "|" & pathName & "|" & version, 128)
out_Request = r
