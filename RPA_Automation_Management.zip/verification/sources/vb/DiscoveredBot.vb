'ARG in in_Config JO
'ARG in in_Tool S
'ARG in in_BotId S
'ARG in in_Mode S
'ARG in in_Candidates JA
'ARG in in_Match JO
'ARG in in_AssetsJson S
'ARG in in_QueuesJson S
'ARG out out_Match JO
'ARG out out_Bot JO
'ARG out out_Error S
' Dev discovery, step 2. Mode "select" keeps the candidates the API returned that really match the Bot ID (exact name, package ID or unique name ignoring case, or the Bot ID as a whole word in the description). Exactly one is required: none means not found, several means the user is told which ones, so nothing is guessed. UiPath candidates are {folder, release}; Power Automate candidates are solution records. Mode "build" turns the match into the same shape as a BotMapping.json entry, so the rest of the solution works unchanged: UAT/Prod folders are the Dev folder path, or the prefix mapping in settings uipath.discovery.folderMap.<env>; assets and queues of the Dev folder are listed as required (settings includeFolderAssets / includeFolderQueues); Credential assets get their approved secret source from the staging convention in uipath.discovery.secretStaging ({asset} and {env} in assetNamePattern). No secret value is read here.
' Nothing found yet
out_Match = Nothing
out_Bot = Nothing
out_Error = ""
' The Bot ID typed by the user, and which provider's discovery settings apply
Dim id As String = If(in_BotId, "").Trim()
Dim uip As Boolean = in_Tool = "UiPath"
Dim disc As JObject = If(TryCast(in_Config.SelectToken(If(uip, "uipath.discovery", "powerAutomate.discovery")), JObject), New JObject())
' Pattern that finds the Bot ID as a whole word inside a description
Dim wordPattern As String = "(?<![A-Za-z0-9_.-])" & System.Text.RegularExpressions.Regex.Escape(id) & "(?![A-Za-z0-9_-])"
' Select mode: keep only the candidates that really match
If in_Mode = "select" Then
    ' Fields to compare (settings matchOn), lower case
    Dim fields As List(Of String) = If(TryCast(disc("matchOn"), JArray), New JArray()).Values(Of String)().Select(Function(f) f.ToLowerInvariant()).ToList()
    ' Defaults when matchOn is empty
    If fields.Count = 0 Then fields = If(uip, New List(Of String) From {"name", "processkey", "description"}, New List(Of String) From {"uniquename", "description"})
    Dim hits As New List(Of JObject)
    ' Check each candidate returned by the API
    For Each c As JObject In If(in_Candidates, New JArray()).Children(Of JObject)()
        ' The record to compare: the release (UiPath) or the solution (Power Automate)
        Dim rec As JObject = If(uip, TryCast(c("release"), JObject), c)
        If rec IsNot Nothing Then
            ' Match when any field equals the Bot ID, or the description contains it as a word
            Dim ok As Boolean = fields.Any(Function(f) If(f = "description", System.Text.RegularExpressions.Regex.IsMatch(If(rec.Value(Of String)(If(uip, "Description", "description")), ""), wordPattern, System.Text.RegularExpressions.RegexOptions.IgnoreCase),
                String.Equals(If(rec.Properties().Where(Function(p) p.Name.Equals(f, StringComparison.OrdinalIgnoreCase)).Select(Function(p) p.Value.ToString()).FirstOrDefault(), "").Trim(), id, StringComparison.OrdinalIgnoreCase)))
            If ok Then hits.Add(c)
        End If
    Next
    ' Exactly one match is accepted; otherwise the user gets a clear message
    If hits.Count = 0 Then
        out_Error = "Bot ID '" & id & "' is not in the Bot ID mapping and no " & If(uip, "process in the Dev Orchestrator", "unmanaged solution in the Dev Power Platform environment") &
                    " matches it (" & If(uip, "process name, package ID or the Bot ID in the process description", "unique name or the Bot ID in the solution description") & "). Check the ID, or ask the RPA CoE to register it in BotMapping.json."
    ElseIf hits.Count > 1 Then
        out_Error = "Bot ID '" & id & "' matches more than one " & If(uip, "process", "solution") & " in Dev: " & String.Join("; ", hits.Select(Function(h) If(uip, h.SelectToken("folder.FullyQualifiedName").ToString() & " / " & h.SelectToken("release.Name").ToString() & " (package " & h.SelectToken("release.ProcessKey").ToString() & ")", h.Value(Of String)("uniquename") & " (" & h.Value(Of String)("friendlyname") & ")"))) & ". Ask the RPA CoE to register the right one in BotMapping.json."
    Else
        out_Match = CType(hits(0).DeepClone(), JObject)
    End If
Else
    ' Build mode: a mapping entry for the matched process or solution
    Dim b As New JObject()
    b("botId") = id
    b("aliases") = New JArray()
    b("automationTool") = in_Tool
    If uip Then
        ' UiPath: process name, package ID and Dev folder from the release found in Dev
        Dim rel As JObject = CType(in_Match("release"), JObject)
        Dim devPath As String = in_Match.SelectToken("folder.FullyQualifiedName").ToString()
        b("description") = If(rel.Value(Of String)("Description"), "")
        b("source") = "Not in the Bot ID mapping: found in Dev as process " & rel.Value(Of String)("Name") & " in folder " & devPath & "."
        Dim u As New JObject()
        u("processName") = rel.Value(Of String)("Name")
        u("packageId") = rel.Value(Of String)("ProcessKey")
        Dim folders As New JObject()
        folders("Dev") = devPath
        ' UAT and Prod folder: the longest matching prefix in folderMap, or the same path as Dev
        For Each env As String In New String() {"UAT", "Prod"}
            Dim map As JObject = If(TryCast(disc.SelectToken("folderMap." & env), JObject), New JObject())
            Dim best As JProperty = map.Properties().Where(Function(p) Not p.Name.StartsWith("_") AndAlso (devPath.Equals(p.Name, StringComparison.OrdinalIgnoreCase) OrElse devPath.StartsWith(p.Name.TrimEnd("/"c) & "/", StringComparison.OrdinalIgnoreCase))).OrderByDescending(Function(p) p.Name.Length).FirstOrDefault()
            folders(env) = If(best Is Nothing, devPath, best.Value.ToString().TrimEnd("/"c) & devPath.Substring(best.Name.TrimEnd("/"c).Length))
        Next
        u("folders") = folders
        ' Secret staging convention for Credential assets
        Dim staging As JObject = TryCast(disc("secretStaging"), JObject)
        Dim assets As New JArray()
        ' Assets of the Dev folder (names and types only; no values)
        If disc.Value(Of Boolean?)("includeFolderAssets").GetValueOrDefault(True) AndAlso Not String.IsNullOrWhiteSpace(in_AssetsJson) Then
            For Each a As JObject In JArray.Parse(in_AssetsJson).Children(Of JObject)()
                Dim e As New JObject()
                e("name") = a.Value(Of String)("Name")
                e("required") = True
                ' Credential assets: name of the approved staging asset per environment
                If a.Value(Of String)("ValueType") = "Credential" AndAlso staging IsNot Nothing AndAlso Not String.IsNullOrWhiteSpace(staging.Value(Of String)("assetNamePattern")) Then
                    Dim src As New JObject()
                    For Each env2 As String In New String() {"UAT", "Prod"}
                        src(env2) = New JObject(New JProperty("assetName", staging.Value(Of String)("assetNamePattern").Replace("{asset}", a.Value(Of String)("Name")).Replace("{env}", env2)), New JProperty("folderPath", staging.Value(Of String)("folderPath")))
                    Next
                    e("secretSource") = src
                End If
                assets.Add(e)
            Next
        End If
        u("assets") = assets
        Dim queues As New JArray()
        ' Queues of the Dev folder
        If disc.Value(Of Boolean?)("includeFolderQueues").GetValueOrDefault(True) AndAlso Not String.IsNullOrWhiteSpace(in_QueuesJson) Then
            For Each q As JObject In JArray.Parse(in_QueuesJson).Children(Of JObject)()
                queues.Add(New JObject(New JProperty("name", q.Value(Of String)("Name")), New JProperty("required", True)))
            Next
        End If
        u("queues") = queues
        u("access") = New JArray()
        b("uipath") = u
    Else
        ' Power Automate: the unmanaged solution found in Dev
        b("description") = If(in_Match.Value(Of String)("description"), "")
        b("source") = "Not in the Bot ID mapping: found in Dev as solution " & in_Match.Value(Of String)("uniquename") & "."
        b("powerAutomate") = New JObject(New JProperty("solutionUniqueName", in_Match.Value(Of String)("uniquename")), New JProperty("flows", New JArray()))
    End If
    out_Bot = b
End If
