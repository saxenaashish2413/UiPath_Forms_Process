'ARG in in_Config JO
'ARG in in_Tool S
'ARG in in_BotId S
'ARG in in_Mode S
'ARG in in_Candidates JA
'ARG in in_Match JO
'ARG in in_AssetsJson S
'ARG in in_QueuesJson S
'ARG out out_Match JO
'ARG out out_Bot JO
'ARG out out_Error S
' Dev discovery, step 2.
'  select: keeps the candidates the API returned that really match the Bot ID (exact name/package ID/unique name, ignoring
'          case, or the Bot ID as a whole word in the description). Exactly one is required: none -> not found, several ->
'          the user is told which ones, so nothing is guessed. UiPath candidates are {folder, release}; Power Automate
'          candidates are solution records.
'  build:  turns the match into the same shape as a BotMapping.json entry, so the rest of the solution works unchanged.
'          UAT/Prod folders = the Dev folder path, or the prefix mapping in settings uipath.discovery.folderMap.<env>.
'          Assets and queues of the Dev folder are listed as required (settings includeFolderAssets / includeFolderQueues).
'          Credential assets get their approved secret source from the staging convention in uipath.discovery.secretStaging
'          ({asset} and {env} in assetNamePattern); no secret value is read here.
out_Match = Nothing
out_Bot = Nothing
out_Error = ""
Dim id As String = If(in_BotId, "").Trim()
Dim uip As Boolean = in_Tool = "UiPath"
Dim disc As Newtonsoft.Json.Linq.JObject = If(TryCast(in_Config.SelectToken(If(uip, "uipath.discovery", "powerAutomate.discovery")), Newtonsoft.Json.Linq.JObject), New Newtonsoft.Json.Linq.JObject())
Dim word As New System.Text.RegularExpressions.Regex("(?<![A-Za-z0-9_.-])" & System.Text.RegularExpressions.Regex.Escape(id) & "(?![A-Za-z0-9_-])", System.Text.RegularExpressions.RegexOptions.IgnoreCase)
Dim Eq As Func(Of String, Boolean) = Function(v) String.Equals(If(v, "").Trim(), id, StringComparison.OrdinalIgnoreCase)
If in_Mode = "select" Then
    Dim fields As List(Of String) = If(TryCast(disc("matchOn"), Newtonsoft.Json.Linq.JArray), New Newtonsoft.Json.Linq.JArray()).Values(Of String)().Select(Function(f) f.ToLowerInvariant()).ToList()
    If fields.Count = 0 Then fields = If(uip, New List(Of String) From {"name", "processkey", "description"}, New List(Of String) From {"uniquename", "description"})
    Dim hits As New List(Of Newtonsoft.Json.Linq.JObject)
    For Each c As Newtonsoft.Json.Linq.JObject In If(in_Candidates, New Newtonsoft.Json.Linq.JArray()).Children(Of Newtonsoft.Json.Linq.JObject)()
        Dim rec As Newtonsoft.Json.Linq.JObject = If(uip, TryCast(c("release"), Newtonsoft.Json.Linq.JObject), c)
        If rec Is Nothing Then Continue For
        Dim ok As Boolean = fields.Any(Function(f) If(f = "description", word.IsMatch(If(rec.Value(Of String)(If(uip, "Description", "description")), "")),
                                                     Eq(rec.Properties().Where(Function(p) p.Name.Equals(f, StringComparison.OrdinalIgnoreCase)).Select(Function(p) p.Value.ToString()).FirstOrDefault())))
        If ok Then hits.Add(c)
    Next
    Dim Label As Func(Of Newtonsoft.Json.Linq.JObject, String) = Function(c) If(uip, c.SelectToken("folder.FullyQualifiedName").ToString() & " / " & c.SelectToken("release.Name").ToString() & " (package " & c.SelectToken("release.ProcessKey").ToString() & ")",
                                                                                   c.Value(Of String)("uniquename") & " (" & c.Value(Of String)("friendlyname") & ")")
    If hits.Count = 0 Then
        out_Error = "Bot ID '" & id & "' is not in the Bot ID mapping and no " & If(uip, "process in the Dev Orchestrator", "unmanaged solution in the Dev Power Platform environment") &
                    " matches it (" & If(uip, "process name, package ID or the Bot ID in the process description", "unique name or the Bot ID in the solution description") & "). Check the ID, or ask the RPA CoE to register it in BotMapping.json."
    ElseIf hits.Count > 1 Then
        out_Error = "Bot ID '" & id & "' matches more than one " & If(uip, "process", "solution") & " in Dev: " & String.Join("; ", hits.Select(Label)) & ". Ask the RPA CoE to register the right one in BotMapping.json."
    Else
        out_Match = CType(hits(0).DeepClone(), Newtonsoft.Json.Linq.JObject)
    End If
    Return
End If
' build
Dim b As New Newtonsoft.Json.Linq.JObject()
b("botId") = id
b("aliases") = New Newtonsoft.Json.Linq.JArray()
b("automationTool") = in_Tool
If uip Then
    Dim rel As Newtonsoft.Json.Linq.JObject = CType(in_Match("release"), Newtonsoft.Json.Linq.JObject)
    Dim devPath As String = in_Match.SelectToken("folder.FullyQualifiedName").ToString()
    b("description") = If(rel.Value(Of String)("Description"), "")
    b("source") = "Not in the Bot ID mapping: found in Dev as process " & rel.Value(Of String)("Name") & " in folder " & devPath & "."
    Dim u As New Newtonsoft.Json.Linq.JObject()
    u("processName") = rel.Value(Of String)("Name")
    u("packageId") = rel.Value(Of String)("ProcessKey")
    Dim folders As New Newtonsoft.Json.Linq.JObject()
    folders("Dev") = devPath
    For Each env As String In New String() {"UAT", "Prod"}
        Dim map As Newtonsoft.Json.Linq.JObject = If(TryCast(disc.SelectToken("folderMap." & env), Newtonsoft.Json.Linq.JObject), New Newtonsoft.Json.Linq.JObject())
        Dim best As Newtonsoft.Json.Linq.JProperty = map.Properties().Where(Function(p) Not p.Name.StartsWith("_") AndAlso (devPath.Equals(p.Name, StringComparison.OrdinalIgnoreCase) OrElse devPath.StartsWith(p.Name.TrimEnd("/"c) & "/", StringComparison.OrdinalIgnoreCase))).OrderByDescending(Function(p) p.Name.Length).FirstOrDefault()
        folders(env) = If(best Is Nothing, devPath, best.Value.ToString().TrimEnd("/"c) & devPath.Substring(best.Name.TrimEnd("/"c).Length))
    Next
    u("folders") = folders
    Dim staging As Newtonsoft.Json.Linq.JObject = TryCast(disc("secretStaging"), Newtonsoft.Json.Linq.JObject)
    Dim assets As New Newtonsoft.Json.Linq.JArray()
    If disc.Value(Of Boolean?)("includeFolderAssets").GetValueOrDefault(True) AndAlso Not String.IsNullOrWhiteSpace(in_AssetsJson) Then
        For Each a As Newtonsoft.Json.Linq.JObject In Newtonsoft.Json.Linq.JArray.Parse(in_AssetsJson).Children(Of Newtonsoft.Json.Linq.JObject)()
            Dim e As New Newtonsoft.Json.Linq.JObject()
            e("name") = a.Value(Of String)("Name")
            e("required") = True
            If a.Value(Of String)("ValueType") = "Credential" AndAlso staging IsNot Nothing AndAlso Not String.IsNullOrWhiteSpace(staging.Value(Of String)("assetNamePattern")) Then
                Dim src As New Newtonsoft.Json.Linq.JObject()
                For Each env As String In New String() {"UAT", "Prod"}
                    src(env) = New Newtonsoft.Json.Linq.JObject(
                        New Newtonsoft.Json.Linq.JProperty("assetName", staging.Value(Of String)("assetNamePattern").Replace("{asset}", a.Value(Of String)("Name")).Replace("{env}", env)),
                        New Newtonsoft.Json.Linq.JProperty("folderPath", staging.Value(Of String)("folderPath")))
                Next
                e("secretSource") = src
            End If
            assets.Add(e)
        Next
    End If
    u("assets") = assets
    Dim queues As New Newtonsoft.Json.Linq.JArray()
    If disc.Value(Of Boolean?)("includeFolderQueues").GetValueOrDefault(True) AndAlso Not String.IsNullOrWhiteSpace(in_QueuesJson) Then
        For Each q As Newtonsoft.Json.Linq.JObject In Newtonsoft.Json.Linq.JArray.Parse(in_QueuesJson).Children(Of Newtonsoft.Json.Linq.JObject)()
            queues.Add(New Newtonsoft.Json.Linq.JObject(New Newtonsoft.Json.Linq.JProperty("name", q.Value(Of String)("Name")), New Newtonsoft.Json.Linq.JProperty("required", True)))
        Next
    End If
    u("queues") = queues
    u("access") = New Newtonsoft.Json.Linq.JArray()
    b("uipath") = u
Else
    b("description") = If(in_Match.Value(Of String)("description"), "")
    b("source") = "Not in the Bot ID mapping: found in Dev as solution " & in_Match.Value(Of String)("uniquename") & "."
    b("powerAutomate") = New Newtonsoft.Json.Linq.JObject(New Newtonsoft.Json.Linq.JProperty("solutionUniqueName", in_Match.Value(Of String)("uniquename")), New Newtonsoft.Json.Linq.JProperty("flows", New Newtonsoft.Json.Linq.JArray()))
End If
out_Bot = b
