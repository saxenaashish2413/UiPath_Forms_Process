'ARG in in_Path S
'ARG in in_Delete B
'ARG out out_Sha256 S
' SHA-256 of a downloaded package (recorded in the audit so source and target can be compared); optionally deletes the temp file.
out_Sha256 = ""
If Not System.IO.File.Exists(in_Path) Then Return
out_Sha256 = BitConverter.ToString(System.Security.Cryptography.SHA256.HashData(System.IO.File.ReadAllBytes(in_Path))).Replace("-", "").ToLowerInvariant()
If in_Delete Then System.IO.File.Delete(in_Path)
