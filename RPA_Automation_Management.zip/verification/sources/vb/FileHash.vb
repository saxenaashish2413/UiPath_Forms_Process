'ARG in in_Path S
'ARG in in_Delete B
'ARG out out_Sha256 S
' SHA-256 of a downloaded package (recorded in the audit so source and target can be compared); optionally deletes the temporary file.
' Empty result when the file does not exist
out_Sha256 = ""
' Only hash a file that exists
If System.IO.File.Exists(in_Path) Then
    ' Compute the SHA-256 of the file as lower-case hex
    out_Sha256 = BitConverter.ToString(System.Security.Cryptography.SHA256.HashData(System.IO.File.ReadAllBytes(in_Path))).Replace("-", "").ToLowerInvariant()
    ' Delete the temporary file when asked
    If in_Delete Then System.IO.File.Delete(in_Path As String)
End If
