'ARG in in_User S
'ARG in in_Allowed JA
'ARG out out_Allowed B
' True when in_User is listed (DOMAIN\user, case-insensitive), the list contains "*", or - on a Windows robot - the current Windows identity is a member of a listed group. Only the robot user's own groups can be checked.
' Not allowed unless a rule below matches
out_Allowed = False
' Nothing configured means nobody is allowed
If in_Allowed IsNot Nothing Then
    ' Listed by name, or everyone ("*") allowed
    out_Allowed = in_Allowed.Values(Of String)().Any(Function(entry) entry = "*" OrElse String.Equals(entry, in_User, StringComparison.OrdinalIgnoreCase))
    ' Otherwise check Windows group membership of the robot user (only possible for the user the robot runs as)
    If Not out_Allowed AndAlso OperatingSystem.IsWindows() AndAlso String.Equals(System.Security.Principal.WindowsIdentity.GetCurrent().Name, in_User, StringComparison.OrdinalIgnoreCase) Then
        For Each entry As String In in_Allowed.Values(Of String)()
            Try
                ' Member of this group?
                If Not out_Allowed Then out_Allowed = New System.Security.Principal.WindowsPrincipal(System.Security.Principal.WindowsIdentity.GetCurrent()).IsInRole(entry)
            Catch ex As SystemException
                ' A name that is not a Windows group: skip it
            End Try
        Next
    End If
End If
