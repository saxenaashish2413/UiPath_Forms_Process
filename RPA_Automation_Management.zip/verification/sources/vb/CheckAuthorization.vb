'ARG in in_User S
'ARG in in_Allowed JA
'ARG out out_Allowed B
' True when in_User is listed (DOMAIN\user, case-insensitive), the list contains "*", or - on a Windows robot - the
' current Windows identity is a member of a listed group (WindowsPrincipal.IsInRole). Only the robot user's own groups can be checked.
out_Allowed = False
If in_Allowed Is Nothing Then Return
For Each entry As String In in_Allowed.Values(Of String)()
    If entry = "*" OrElse String.Equals(entry, in_User, StringComparison.OrdinalIgnoreCase) Then
        out_Allowed = True
        Return
    End If
Next
If OperatingSystem.IsWindows() Then
    Dim ident As System.Security.Principal.WindowsIdentity = System.Security.Principal.WindowsIdentity.GetCurrent()
    If String.Equals(ident.Name, in_User, StringComparison.OrdinalIgnoreCase) Then
        Dim principal As New System.Security.Principal.WindowsPrincipal(ident)
        For Each entry As String In in_Allowed.Values(Of String)()
            Try
                If principal.IsInRole(entry) Then
                    out_Allowed = True
                    Return
                End If
            Catch ex As System.SystemException
            End Try
        Next
    End If
End If
