'ARG in in_Mode S
'ARG in in_Session DSO
'ARG in in_Key S
'ARG io io_Token SEC
'ARG in in_ExpiresAtUtc DTM
'ARG out out_Found B
' In-memory token cache for one run (never written to disk or logs).
'  get : out_Found = True and io_Token set when a token exists that is valid for at least 2 more minutes
'  put : stores io_Token until in_ExpiresAtUtc
'  drop: forgets the token (used after HTTP 401 so the next call re-authenticates)
out_Found = False
Dim tk As String = "token:" & in_Key
Dim ek As String = "tokenExpiresUtc:" & in_Key
Select Case in_Mode
    Case "get"
        If in_Session.ContainsKey(tk) AndAlso in_Session.ContainsKey(ek) AndAlso CDate(in_Session(ek)) > DateTime.UtcNow.AddMinutes(2) Then
            io_Token = CType(in_Session(tk), System.Security.SecureString)
            out_Found = True
        End If
    Case "put"
        in_Session(tk) = io_Token
        in_Session(ek) = in_ExpiresAtUtc
        out_Found = True
    Case "drop"
        in_Session.Remove(tk)
        in_Session.Remove(ek)
    Case Else
        Throw New ArgumentException("TokenCache mode " & in_Mode)
End Select
