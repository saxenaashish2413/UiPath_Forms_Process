'ARG in in_Mode S
'ARG in in_Session DSO
'ARG in in_Key S
'ARG io io_Token SEC
'ARG in in_ExpiresAtUtc DTM
'ARG out out_Found B
' In-memory token cache for one run (never written to disk or logs). Mode "get": out_Found = True and io_Token set when a token exists that is valid for at least 2 more minutes. Mode "put": stores io_Token until in_ExpiresAtUtc. Mode "drop": forgets the token (used after HTTP 401 so the next call signs in again).
out_Found = False
' Names of the two cache entries for this provider and environment
Dim tk As String = "token:" & in_Key
Dim ek As String = "tokenExpiresUtc:" & in_Key
' Get: reuse the cached token when it is still valid for more than 2 minutes
If in_Mode = "get" Then
    If in_Session.ContainsKey(tk) AndAlso in_Session.ContainsKey(ek) AndAlso CDate(in_Session(ek)) > DateTime.UtcNow.AddMinutes(2) Then
        io_Token = CType(in_Session(tk), System.Security.SecureString)
        out_Found = True
    End If
ElseIf in_Mode = "put" Then
    ' Put: keep the new token and its expiry time
    in_Session(tk) = io_Token
    in_Session(ek) = in_ExpiresAtUtc
    out_Found = True
ElseIf in_Mode = "drop" Then
    ' Drop: forget the token so the next call signs in again
    in_Session.Remove(tk)
    in_Session.Remove(ek)
Else
    Throw New ArgumentException("TokenCache mode " & in_Mode)
End If
