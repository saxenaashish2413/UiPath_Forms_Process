'ARG in in_Mode S
'ARG in in_Store S
'ARG in in_Solution S
'ARG in in_Version S
'ARG in in_Base64 S
'ARG out out_Base64 S
'ARG out out_Sha256 S
'ARG out out_Versions JA
' Managed solution files exported from Dev, kept per version so UAT -> Prod imports exactly what UAT received.
'  save : writes <store>\<solution>_<version>_managed.zip and a .sha256 file next to it
'  load : reads the file back and checks the SHA-256 (fails if the file was changed)
'  list : versions present in the store for this solution
Dim dir As String = If(System.IO.Path.IsPathRooted(in_Store), in_Store, System.IO.Path.Combine(Environment.CurrentDirectory, in_Store))
Dim safe As String = System.Text.RegularExpressions.Regex.Replace(in_Solution, "[^A-Za-z0-9_]", "_")
Dim file As String = System.IO.Path.Combine(dir, safe & "_" & If(in_Version, "").Replace("/", "_") & "_managed.zip")
out_Base64 = ""
out_Sha256 = ""
out_Versions = New Newtonsoft.Json.Linq.JArray()
Dim Hash As Func(Of Byte(), String) = Function(b) BitConverter.ToString(System.Security.Cryptography.SHA256.HashData(b)).Replace("-", "").ToLowerInvariant()
Select Case in_Mode
    Case "save"
        System.IO.Directory.CreateDirectory(dir)
        Dim bytes As Byte() = Convert.FromBase64String(in_Base64)
        System.IO.File.WriteAllBytes(file, bytes)
        out_Sha256 = Hash(bytes)
        System.IO.File.WriteAllText(file & ".sha256", out_Sha256)
    Case "load"
        If Not System.IO.File.Exists(file) Then Throw New System.IO.FileNotFoundException("Managed solution file for " & in_Solution & " " & in_Version & " is not in the artifact store (" & dir & "). Run Dev to UAT for this version first.")
        Dim bytes As Byte() = System.IO.File.ReadAllBytes(file)
        out_Sha256 = Hash(bytes)
        If System.IO.File.Exists(file & ".sha256") AndAlso System.IO.File.ReadAllText(file & ".sha256").Trim() <> out_Sha256 Then Throw New System.Security.SecurityException("The stored solution file " & file & " does not match its recorded SHA-256; it was changed after export.")
        out_Base64 = Convert.ToBase64String(bytes)
    Case "list"
        If System.IO.Directory.Exists(dir) Then
            For Each f As String In System.IO.Directory.GetFiles(dir, safe & "_*_managed.zip")
                Dim n As String = System.IO.Path.GetFileName(f)
                out_Versions.Add(n.Substring(safe.Length + 1, n.Length - safe.Length - 1 - "_managed.zip".Length))
            Next
        End If
    Case Else
        Throw New ArgumentException("SolutionArtifact mode " & in_Mode)
End Select
