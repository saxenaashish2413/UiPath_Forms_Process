'ARG in in_Mode S
'ARG in in_Store S
'ARG in in_Solution S
'ARG in in_Version S
'ARG in in_Base64 S
'ARG out out_Base64 S
'ARG out out_Sha256 S
'ARG out out_Versions JA
' Managed solution files exported from Dev, kept per version so UAT -> Prod imports exactly what UAT received. Mode save: writes <store>\<solution>_<version>_managed.zip and a .sha256 file next to it. Mode load: reads the file back and checks the SHA-256 (fails if the file was changed). Mode list: versions present in the store for this solution.
' Artifact folder (relative paths are under the project folder)
Dim dir As String = If(System.IO.Path.IsPathRooted(in_Store), in_Store, System.IO.Path.Combine(Environment.CurrentDirectory, in_Store))
' Solution name made safe for a file name
Dim safe As String = System.Text.RegularExpressions.Regex.Replace(in_Solution, "[^A-Za-z0-9_]", "_")
' File for this solution and version
Dim file As String = System.IO.Path.Combine(dir, safe & "_" & If(in_Version, "").Replace("/", "_") & "_managed.zip")
out_Base64 = ""
out_Sha256 = ""
out_Versions = New JArray()
' Save: write the exported file and its SHA-256
If in_Mode = "save" Then
    System.IO.Directory.CreateDirectory(dir As String)
    System.IO.File.WriteAllBytes(file As String, Convert.FromBase64String(in_Base64) As Byte())
    out_Sha256 = BitConverter.ToString(System.Security.Cryptography.SHA256.HashData(Convert.FromBase64String(in_Base64))).Replace("-", "").ToLowerInvariant()
    System.IO.File.WriteAllText(file & ".sha256" As String, out_Sha256 As String)
ElseIf in_Mode = "load" Then
    ' The file must have been stored by an earlier Dev to UAT run
    If Not System.IO.File.Exists(file) Then Throw New System.IO.FileNotFoundException("Managed solution file for " & in_Solution & " " & in_Version & " is not in the artifact store (" & dir & "). Run Dev to UAT for this version first.")
    ' SHA-256 of the stored file
    out_Sha256 = BitConverter.ToString(System.Security.Cryptography.SHA256.HashData(System.IO.File.ReadAllBytes(file))).Replace("-", "").ToLowerInvariant()
    ' Refuse a file that changed after export
    If System.IO.File.Exists(file & ".sha256") AndAlso System.IO.File.ReadAllText(file & ".sha256").Trim() <> out_Sha256 Then Throw New System.Security.SecurityException("The stored solution file " & file & " does not match its recorded SHA-256; it was changed after export.")
    out_Base64 = Convert.ToBase64String(System.IO.File.ReadAllBytes(file))
ElseIf in_Mode = "list" Then
    ' Versions = the part of each file name between "<solution>_" and "_managed.zip"
    If System.IO.Directory.Exists(dir) Then out_Versions = New JArray(System.IO.Directory.GetFiles(dir, safe & "_*_managed.zip").Select(Function(f) System.IO.Path.GetFileName(f)).Select(Function(n) n.Substring(safe.Length + 1, n.Length - safe.Length - 1 - "_managed.zip".Length)).ToArray())
Else
    Throw New ArgumentException("SolutionArtifact mode " & in_Mode)
End If
