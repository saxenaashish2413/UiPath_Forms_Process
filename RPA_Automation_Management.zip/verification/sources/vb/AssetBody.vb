'ARG in in_Asset JO
'ARG in in_TargetAssetJson S
'ARG in in_CredentialUser S
'ARG in in_CredentialPassword SEC
'ARG out out_Method S
'ARG out out_Url S
'ARG out out_Body S
'ARG out out_Change S
' Decides the idempotent operation for one approved asset row and builds the Orchestrator body.
'  Create + missing in target           -> POST odata/Assets
'  Create + already there (earlier run) -> NoChange (never duplicated, never overwritten)
'  Update + exists                      -> PUT odata/Assets(<Id>) only when the value differs (Credential: always, value unknown)
'  Keep/Skip                            -> NoChange
' Credential values come from the approved secret source (in_CredentialUser/in_CredentialPassword); out_Body then
' contains the secret and must never be logged (Send_Api_Request does not log bodies).
out_Method = ""
out_Url = ""
out_Body = ""
out_Change = "NoChange"
Dim act As String = in_Asset.Value(Of String)("action")
Dim typ As String = in_Asset.Value(Of String)("type")
Dim value As String = If(in_Asset.Value(Of String)("proposedValue"), "")
Dim tgt As Newtonsoft.Json.Linq.JObject = If(String.IsNullOrWhiteSpace(in_TargetAssetJson), Nothing, Newtonsoft.Json.Linq.JObject.Parse(in_TargetAssetJson))
If act <> "Create" AndAlso act <> "Update" Then Return
If act = "Create" AndAlso tgt IsNot Nothing Then Return
If act = "Update" AndAlso tgt Is Nothing Then Throw New InvalidOperationException("Asset " & in_Asset.Value(Of String)("name") & " no longer exists in the target; the request must be validated again.")
If tgt IsNot Nothing AndAlso tgt.Value(Of String)("ValueType") <> typ Then Throw New InvalidOperationException("Asset " & in_Asset.Value(Of String)("name") & " exists in the target with type " & tgt.Value(Of String)("ValueType") & " instead of " & typ & "; not changed.")
Dim body As New Newtonsoft.Json.Linq.JObject()
If tgt IsNot Nothing Then body("Id") = tgt("Id")
body("Name") = in_Asset.Value(Of String)("name")
body("ValueScope") = "Global"
body("ValueType") = typ
If Not String.IsNullOrEmpty(in_Asset.Value(Of String)("description")) Then body("Description") = in_Asset.Value(Of String)("description")
Select Case typ
    Case "Text"
        If tgt IsNot Nothing AndAlso tgt.Value(Of String)("StringValue") = value Then Return
        body("StringValue") = value
    Case "Integer"
        Dim n As Integer = Integer.Parse(value, System.Globalization.CultureInfo.InvariantCulture)
        If tgt IsNot Nothing AndAlso tgt.Value(Of Integer)("IntValue") = n Then Return
        body("IntValue") = n
    Case "Bool"
        Dim b As Boolean = Boolean.Parse(value)
        If tgt IsNot Nothing AndAlso tgt.Value(Of Boolean)("BoolValue") = b Then Return
        body("BoolValue") = b
    Case "Credential"
        If in_CredentialPassword Is Nothing OrElse String.IsNullOrEmpty(in_CredentialUser) Then Throw New InvalidOperationException("No value from the approved secret source for credential asset " & in_Asset.Value(Of String)("name") & ".")
        body("CredentialUsername") = in_CredentialUser
        body("CredentialPassword") = New System.Net.NetworkCredential("", in_CredentialPassword).Password
    Case Else
        Throw New InvalidOperationException("Asset type " & typ & " is not supported for migration.")
End Select
out_Body = body.ToString(Newtonsoft.Json.Formatting.None)
If tgt Is Nothing Then
    out_Method = "POST"
    out_Url = "odata/Assets"
    out_Change = "Created"
Else
    out_Method = "PUT"
    out_Url = "odata/Assets(" & tgt.Value(Of Long)("Id").ToString(System.Globalization.CultureInfo.InvariantCulture) & ")"
    out_Change = "Updated"
End If
