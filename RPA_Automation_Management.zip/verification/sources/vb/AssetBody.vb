'ARG in in_Asset JO
'ARG in in_TargetAssetJson S
'ARG in in_CredentialUser S
'ARG in in_CredentialPassword SEC
'ARG out out_Method S
'ARG out out_Url S
'ARG out out_Body S
'ARG out out_Change S
' Decides the idempotent operation for one approved asset row and builds the Orchestrator body. Create + missing in target -> POST odata/Assets. Create + already there (earlier run) -> NoChange (never duplicated, never overwritten). Update + exists -> PUT odata/Assets(<Id>) only when the value differs (Credential: always, its value cannot be read). Keep/Skip -> NoChange. Credential values come from the approved secret source (in_CredentialUser/in_CredentialPassword); out_Body then contains the secret and is never logged.
' Default: nothing to send
out_Method = ""
out_Url = ""
out_Body = ""
out_Change = "NoChange"
' Action chosen in the form, asset type and the value to set
Dim act As String = in_Asset.Value(Of String)("action")
Dim typ As String = in_Asset.Value(Of String)("type")
Dim value As String = If(in_Asset.Value(Of String)("proposedValue"), "")
' The asset as it is in the target now (Nothing when it does not exist)
Dim tgt As JObject = If(String.IsNullOrWhiteSpace(in_TargetAssetJson), Nothing, JObject.Parse(in_TargetAssetJson))
' Update needs the asset to exist
If act = "Update" AndAlso tgt Is Nothing Then Throw New InvalidOperationException("Asset " & in_Asset.Value(Of String)("name") & " no longer exists in the target; the request must be validated again.")
' Only Create of a missing asset, or Update of an existing one, can change anything
If (act = "Create" AndAlso tgt Is Nothing) OrElse (act = "Update" AndAlso tgt IsNot Nothing) Then
    ' Never change the type of an existing asset
    If tgt IsNot Nothing AndAlso tgt.Value(Of String)("ValueType") <> typ Then Throw New InvalidOperationException("Asset " & in_Asset.Value(Of String)("name") & " exists in the target with type " & tgt.Value(Of String)("ValueType") & " instead of " & typ & "; not changed.")
    ' Asset body: name, global scope, type and description
    Dim body As New JObject()
    If tgt IsNot Nothing Then body("Id") = tgt("Id")
    body("Name") = in_Asset.Value(Of String)("name")
    body("ValueScope") = "Global"
    body("ValueType") = typ
    If Not String.IsNullOrEmpty(in_Asset.Value(Of String)("description")) Then body("Description") = in_Asset.Value(Of String)("description")
    ' True when the target already holds this value (then nothing is sent)
    Dim same As Boolean = False
    If typ = "Text" Then
        same = tgt IsNot Nothing AndAlso tgt.Value(Of String)("StringValue") = value
        body("StringValue") = value
    ElseIf typ = "Integer" Then
        same = tgt IsNot Nothing AndAlso tgt.Value(Of Integer)("IntValue") = Integer.Parse(value, System.Globalization.CultureInfo.InvariantCulture)
        body("IntValue") = Integer.Parse(value, System.Globalization.CultureInfo.InvariantCulture)
    ElseIf typ = "Bool" Then
        same = tgt IsNot Nothing AndAlso tgt.Value(Of Boolean)("BoolValue") = Boolean.Parse(value)
        body("BoolValue") = Boolean.Parse(value)
    ElseIf typ = "Credential" Then
        ' The credential comes only from the approved secret source
        If in_CredentialPassword Is Nothing OrElse String.IsNullOrEmpty(in_CredentialUser) Then Throw New InvalidOperationException("No value from the approved secret source for credential asset " & in_Asset.Value(Of String)("name") & ".")
        body("CredentialUsername") = in_CredentialUser
        body("CredentialPassword") = New System.Net.NetworkCredential("", in_CredentialPassword).Password
    Else
        Throw New InvalidOperationException("Asset type " & typ & " is not supported for migration.")
    End If
    ' Send only when the value differs
    If Not same Then
        out_Body = body.ToString(Newtonsoft.Json.Formatting.None)
        ' Missing: create it (POST); existing: update it (PUT)
        If tgt Is Nothing Then
            out_Method = "POST"
            out_Url = "odata/Assets"
            out_Change = "Created"
        Else
            out_Method = "PUT"
            out_Url = "odata/Assets(" & tgt.Value(Of Long)("Id").ToString(System.Globalization.CultureInfo.InvariantCulture) & ")"
            out_Change = "Updated"
        End If
    End If
End If
