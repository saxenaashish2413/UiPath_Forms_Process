'ARG in in_RowsJson S
'ARG in in_Result JO
'ARG in in_Kind S
'ARG in in_Request JO
'ARG out out_RowsJson S
' Fills the "Saved in target" column of a form grid from the deployment result, so the form shows retrieved (Dev), proposed and saved values side by side. The proposed columns are refreshed from the submitted request (what was deployed).
' The grid rows currently shown in the form
Dim rows As JArray = If(String.IsNullOrWhiteSpace(in_RowsJson), New JArray(), JArray.Parse(in_RowsJson))
' What the deployment did per object (may be empty when nothing ran)
Dim objs As JArray = If(in_Result Is Nothing, Nothing, TryCast(in_Result("objects"), JArray))
' Which section of the request holds these rows
Dim section As String = If(in_Kind = "Asset", "assets", If(in_Kind = "Queue", "queues", "access"))
' The rows as they were submitted
Dim reqRows As JArray = If(in_Request Is Nothing, Nothing, TryCast(in_Request.SelectToken("configuration." & section), JArray))
For Each r As JObject In rows.Children(Of JObject)()
    ' The submitted version of this row
    Dim rq As JObject = If(reqRows Is Nothing, Nothing, reqRows.Children(Of JObject)().FirstOrDefault(Function(x) String.Equals(x.Value(Of String)("name"), r.Value(Of String)("name"), StringComparison.OrdinalIgnoreCase)))
    If rq IsNot Nothing Then
        For Each f As String In New String() {"action", "proposedValue", "proposedName", "accessLevel"}
            ' Show the submitted value (never a secret's proposed value)
            If rq(f) IsNot Nothing AndAlso Not (f = "proposedValue" AndAlso r.Value(Of Boolean)("isSecret")) Then r(f) = rq(f)
        Next
    End If
    ' Name the deployment used for this object (queues may be renamed)
    Dim key As String = If(in_Kind = "Queue", If(r.Value(Of String)("proposedName"), r.Value(Of String)("name")), r.Value(Of String)("name"))
    ' The last result recorded for this object
    Dim o As JObject = If(objs Is Nothing, Nothing, objs.Children(Of JObject)().LastOrDefault(Function(x) x.Value(Of String)("kind") = in_Kind AndAlso String.Equals(x.Value(Of String)("name"), key, StringComparison.OrdinalIgnoreCase)))
    ' Saved column: what happened, or "Not changed"
    r("savedStatus") = If(o Is Nothing, "Not changed", o.Value(Of String)("change") & If(o.Value(Of String)("message") <> "", ": " & o.Value(Of String)("message"), ""))
Next
' Send the updated rows back to the form
out_RowsJson = rows.ToString(Newtonsoft.Json.Formatting.None)
