'ARG in in_RowsJson S
'ARG in in_Result JO
'ARG in in_Kind S
'ARG in in_Request JO
'ARG out out_RowsJson S
' Fills the "Saved in target" column of a form grid from the deployment result, so the form shows retrieved (Dev),
' proposed and saved values side by side. The proposed columns are refreshed from the submitted request (what was deployed).
Dim rows As Newtonsoft.Json.Linq.JArray = If(String.IsNullOrWhiteSpace(in_RowsJson), New Newtonsoft.Json.Linq.JArray(), Newtonsoft.Json.Linq.JArray.Parse(in_RowsJson))
Dim objs As Newtonsoft.Json.Linq.JArray = If(in_Result Is Nothing, Nothing, TryCast(in_Result("objects"), Newtonsoft.Json.Linq.JArray))
Dim section As String = If(in_Kind = "Asset", "assets", If(in_Kind = "Queue", "queues", "access"))
Dim reqRows As Newtonsoft.Json.Linq.JArray = If(in_Request Is Nothing, Nothing, TryCast(in_Request.SelectToken("configuration." & section), Newtonsoft.Json.Linq.JArray))
For Each r As Newtonsoft.Json.Linq.JObject In rows.Children(Of Newtonsoft.Json.Linq.JObject)()
    Dim rq As Newtonsoft.Json.Linq.JObject = If(reqRows Is Nothing, Nothing, reqRows.Children(Of Newtonsoft.Json.Linq.JObject)().FirstOrDefault(Function(x) String.Equals(x.Value(Of String)("name"), r.Value(Of String)("name"), StringComparison.OrdinalIgnoreCase)))
    If rq IsNot Nothing Then
        For Each f As String In New String() {"action", "proposedValue", "proposedName", "accessLevel"}
            If rq(f) IsNot Nothing AndAlso Not (f = "proposedValue" AndAlso r.Value(Of Boolean)("isSecret")) Then r(f) = rq(f)
        Next
    End If
    Dim key As String = If(in_Kind = "Queue", If(r.Value(Of String)("proposedName"), r.Value(Of String)("name")), r.Value(Of String)("name"))
    Dim o As Newtonsoft.Json.Linq.JObject = If(objs Is Nothing, Nothing, objs.Children(Of Newtonsoft.Json.Linq.JObject)().LastOrDefault(Function(x) x.Value(Of String)("kind") = in_Kind AndAlso String.Equals(x.Value(Of String)("name"), key, StringComparison.OrdinalIgnoreCase)))
    r("savedStatus") = If(o Is Nothing, "Not changed", o.Value(Of String)("change") & If(o.Value(Of String)("message") <> "", ": " & o.Value(Of String)("message"), ""))
Next
out_RowsJson = rows.ToString(Newtonsoft.Json.Formatting.None)
