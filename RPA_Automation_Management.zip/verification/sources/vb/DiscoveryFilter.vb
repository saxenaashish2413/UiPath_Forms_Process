'ARG in in_Config JO
'ARG in in_Tool S
'ARG in in_BotId S
'ARG in in_FoldersJson S
'ARG out out_Filter S
'ARG out out_Folders JA
' Dev discovery, step 1: builds the OData $filter that finds a Bot ID that is not in BotMapping.json, from the settings <provider>.discovery.matchOn list. UiPath: release Name / ProcessKey (package ID) equal to the Bot ID, or the Bot ID in the release Description. Power Automate: unmanaged solution uniquename / friendlyname equal to the Bot ID, or the Bot ID in the solution description. For UiPath, out_Folders = the Dev folders to search (settings uipath.discovery.searchFolders and their subfolders; every folder the API account can see when the list is empty).
' The Bot ID with single quotes doubled, so it is safe inside the OData filter
Dim id As String = If(in_BotId, "").Trim().Replace("'", "''")
Dim uip As Boolean = in_Tool = "UiPath"
Dim disc As JObject = If(TryCast(in_Config.SelectToken(If(uip, "uipath.discovery", "powerAutomate.discovery")), JObject), New JObject())
' Fields to search (settings matchOn)
Dim fields As List(Of String) = If(TryCast(disc("matchOn"), JArray), New JArray()).Values(Of String)().ToList()
' Defaults when matchOn is empty
If fields.Count = 0 Then fields = If(uip, New List(Of String) From {"Name", "ProcessKey", "Description"}, New List(Of String) From {"uniquename", "description"})
' One filter condition per field: "contains" for the description, "eq" for the others
Dim parts As New List(Of String)
For Each f As String In fields
    If f.Equals("Description", StringComparison.OrdinalIgnoreCase) Then
        parts.Add("contains(" & If(uip, "Description", "description") & ",'" & id & "')")
    Else
        parts.Add(f & " eq '" & id & "'")
    End If
Next
' Join the conditions with "or" (Power Automate: unmanaged solutions only)
out_Filter = If(uip, String.Join(" or ", parts), "ismanaged eq false and (" & String.Join(" or ", parts) & ")")
out_Folders = New JArray()
' UiPath: keep only the folders under the configured search roots
If uip AndAlso Not String.IsNullOrWhiteSpace(in_FoldersJson) Then
    Dim roots As List(Of String) = If(TryCast(disc("searchFolders"), JArray), New JArray()).Values(Of String)().Where(Function(r) Not String.IsNullOrWhiteSpace(r)).Select(Function(r) r.Trim().TrimEnd("/"c)).ToList()
    For Each folder As JObject In JArray.Parse(in_FoldersJson).Children(Of JObject)()
        Dim fp As String = If(folder.Value(Of String)("FullyQualifiedName"), "")
        If roots.Count = 0 OrElse roots.Any(Function(r) fp.Equals(r, StringComparison.OrdinalIgnoreCase) OrElse fp.StartsWith(r & "/", StringComparison.OrdinalIgnoreCase)) Then out_Folders.Add(folder)
    Next
End If
