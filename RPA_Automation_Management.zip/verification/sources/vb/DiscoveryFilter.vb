'ARG in in_Config JO
'ARG in in_Tool S
'ARG in in_BotId S
'ARG in in_FoldersJson S
'ARG out out_Filter S
'ARG out out_Folders JA
' Dev discovery, step 1: builds the OData $filter that finds a Bot ID that is not in BotMapping.json, from the settings
' <provider>.discovery.matchOn list. UiPath: release Name / ProcessKey (package ID) equal to the Bot ID, or the Bot ID in
' the release Description. Power Automate: unmanaged solution uniquename / friendlyname equal to the Bot ID, or the Bot ID
' in the solution description. For UiPath, out_Folders = the Dev folders to search (settings uipath.discovery.searchFolders
' and their subfolders; every folder the API account can see when the list is empty).
Dim id As String = If(in_BotId, "").Trim().Replace("'", "''")
Dim uip As Boolean = in_Tool = "UiPath"
Dim disc As Newtonsoft.Json.Linq.JObject = If(TryCast(in_Config.SelectToken(If(uip, "uipath.discovery", "powerAutomate.discovery")), Newtonsoft.Json.Linq.JObject), New Newtonsoft.Json.Linq.JObject())
Dim fields As List(Of String) = If(TryCast(disc("matchOn"), Newtonsoft.Json.Linq.JArray), New Newtonsoft.Json.Linq.JArray()).Values(Of String)().ToList()
If fields.Count = 0 Then fields = If(uip, New List(Of String) From {"Name", "ProcessKey", "Description"}, New List(Of String) From {"uniquename", "description"})
Dim parts As New List(Of String)
For Each f As String In fields
    If f.Equals("Description", StringComparison.OrdinalIgnoreCase) Then
        parts.Add("contains(" & If(uip, "Description", "description") & ",'" & id & "')")
    Else
        parts.Add(f & " eq '" & id & "'")
    End If
Next
out_Filter = If(uip, String.Join(" or ", parts), "ismanaged eq false and (" & String.Join(" or ", parts) & ")")
out_Folders = New Newtonsoft.Json.Linq.JArray()
If uip AndAlso Not String.IsNullOrWhiteSpace(in_FoldersJson) Then
    Dim roots As List(Of String) = If(TryCast(disc("searchFolders"), Newtonsoft.Json.Linq.JArray), New Newtonsoft.Json.Linq.JArray()).Values(Of String)().Where(Function(r) Not String.IsNullOrWhiteSpace(r)).Select(Function(r) r.Trim().TrimEnd("/"c)).ToList()
    For Each f As Newtonsoft.Json.Linq.JObject In Newtonsoft.Json.Linq.JArray.Parse(in_FoldersJson).Children(Of Newtonsoft.Json.Linq.JObject)()
        Dim p As String = If(f.Value(Of String)("FullyQualifiedName"), "")
        If roots.Count = 0 OrElse roots.Any(Function(r) p.Equals(r, StringComparison.OrdinalIgnoreCase) OrElse p.StartsWith(r & "/", StringComparison.OrdinalIgnoreCase)) Then out_Folders.Add(f)
    Next
End If
