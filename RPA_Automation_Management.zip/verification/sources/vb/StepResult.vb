'ARG in in_Result JO
'ARG in in_Kind S
'ARG in in_Name S
'ARG in in_Change S
'ARG in in_Message S
' Adds {kind, name, change, message} to in_Result("objects"); change is Created, Updated, NoChange, Granted, Verified or Failed. The form's Saved column and the audit read this list.
' Create the "objects" list the first time
If Not TypeOf in_Result("objects") Is JArray Then in_Result("objects") = New JArray()
' Add one line for this object (kind, name, what changed, message)
CType(in_Result("objects"), JArray).Add(New JObject(New JProperty("kind", in_Kind), New JProperty("name", in_Name), New JProperty("change", in_Change), New JProperty("message", If(in_Message, ""))))
