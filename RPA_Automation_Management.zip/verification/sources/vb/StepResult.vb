'ARG in in_Result JO
'ARG in in_Kind S
'ARG in in_Name S
'ARG in in_Change S
'ARG in in_Message S
' Adds {kind, name, change, message} to in_Result("objects"); change is Created, Updated, NoChange, Granted, Verified or Failed.
If Not TypeOf in_Result("objects") Is Newtonsoft.Json.Linq.JArray Then in_Result("objects") = New Newtonsoft.Json.Linq.JArray()
CType(in_Result("objects"), Newtonsoft.Json.Linq.JArray).Add(New Newtonsoft.Json.Linq.JObject(
    New Newtonsoft.Json.Linq.JProperty("kind", in_Kind), New Newtonsoft.Json.Linq.JProperty("name", in_Name),
    New Newtonsoft.Json.Linq.JProperty("change", in_Change), New Newtonsoft.Json.Linq.JProperty("message", If(in_Message, ""))))
