'ARG in in_Config JO
'ARG in in_Request JO
'ARG in in_Details JO
'ARG in in_IsEditor B
'ARG out out_Errors JA
'ARG out out_Warnings JA
' Rule checks that need no API call (the live checks - duplicate request, approval, UAT evidence - run in Validate_Deployment_Request.xaml). Every message is written for the requester. When a check makes the later checks meaningless, the flag canContinue is set to False and the remaining checks are skipped.
' Start with empty error and warning lists
out_Errors = New JArray()
out_Warnings = New JArray()
' The three main choices made on the form
Dim tool As String = Convert.ToString(in_Request.SelectToken("automationTool")).Trim()
Dim ptype As String = Convert.ToString(in_Request.SelectToken("processType")).Trim()
Dim pathName As String = Convert.ToString(in_Request.SelectToken("deploymentPath")).Trim()
Dim canContinue As Boolean = True
' Automation Tool must be UiPath or Power Automate
If Not New String() {"UiPath", "Power Automate"}.Contains(tool) Then out_Errors.Add("Automation Tool '" & tool & "' is not supported.")
' Rules for the chosen Process Type (settings requestRules)
Dim rules As JToken = in_Config.SelectToken("requestRules['" & ptype & "']")
' No rules means no Process Type was chosen: stop here
If rules Is Nothing Then
    out_Errors.Add("Select a Process Type (New, Enhancement or Bug Fix).")
    canContinue = False
End If
' The chosen deployment path (Dev to UAT or UAT to Prod) from settings
Dim path As JObject = in_Config("deploymentPaths").Children(Of JObject)().FirstOrDefault(Function(x) x.Value(Of String)("name") = pathName)
' Mandatory fields, length limits and reference formats
If canContinue Then
    ' Deployment Path must be one of the configured paths
    If path Is Nothing Then out_Errors.Add("Select a Deployment Path (" & String.Join(" or ", in_Config("deploymentPaths").Children(Of JObject)().Select(Function(x) x.Value(Of String)("name"))) & ").")
    ' Form field name -> location in the request JSON
    Dim fieldMap As New Dictionary(Of String, String) From {
        {"BotId", "botId"}, {"DeploymentPath", "deploymentPath"}, {"RequestedVersion", "package.requestedVersion"},
        {"EnhancementDescription", "enhancement.description"}, {"ChangeReference", "enhancement.changeReference"},
        {"BugDescription", "bugFix.description"}, {"IncidentReference", "bugFix.incidentReference"}}
    ' Form field name -> label the requester sees
    Dim labels As New Dictionary(Of String, String) From {
        {"BotId", "Bot ID"}, {"DeploymentPath", "Deployment Path"}, {"RequestedVersion", If(tool = "Power Automate", "Requested Solution Version", "Requested Package Version")},
        {"EnhancementDescription", "Enhancement Description"}, {"ChangeReference", "Change or Request Reference"},
        {"BugDescription", "Bug Description"}, {"IncidentReference", "Incident or Defect Reference"}}
    ' Every field this Process Type requires must be filled in
    For Each reqField As String In rules("requiredFields").Values(Of String)()
        If fieldMap.ContainsKey(reqField) AndAlso Convert.ToString(in_Request.SelectToken(fieldMap(reqField))).Trim() = "" AndAlso Not (reqField = "DeploymentPath" AndAlso path Is Nothing) Then out_Errors.Add(labels(reqField) & " is required.")
    Next
    ' Descriptions are limited to 2000 characters
    For Each descKey As String In New String() {"enhancement.description", "bugFix.description"}
        If Convert.ToString(in_Request.SelectToken(descKey)).Trim().Length > 2000 Then out_Errors.Add("Description is longer than 2000 characters.")
    Next
    ' Change and incident references: 3-40 letters, digits or - _ . /
    For Each refKey As String In New String() {"enhancement.changeReference", "bugFix.incidentReference"}
        If Convert.ToString(in_Request.SelectToken(refKey)).Trim() <> "" AndAlso Not System.Text.RegularExpressions.Regex.IsMatch(Convert.ToString(in_Request.SelectToken(refKey)).Trim(), "^[A-Za-z0-9][A-Za-z0-9_./-]{2,39}$") Then out_Errors.Add("Reference '" & Convert.ToString(in_Request.SelectToken(refKey)).Trim() & "' must be 3-40 letters, digits or - _ . /")
    Next
    ' The fetched details must exist and belong to this request
    If in_Details Is Nothing OrElse in_Details.Value(Of String)("status") <> "Found" Then
        out_Errors.Add("Fetch the details for this Bot ID first; the request cannot be validated without them.")
        canContinue = False
    ElseIf Not String.Equals(in_Details.Value(Of String)("botId"), Convert.ToString(in_Request.SelectToken("botId")).Trim(), StringComparison.OrdinalIgnoreCase) OrElse in_Details.Value(Of String)("tool") <> tool OrElse in_Details.Value(Of String)("processType") <> ptype OrElse in_Details.Value(Of String)("deploymentPath") <> pathName Then
        out_Errors.Add("The details shown were fetched for a different Bot ID, tool, process type or deployment path. Click Fetch Details again.")
        canContinue = False
    End If
End If
' Version, environment and configuration checks (need a valid path and matching details)
If canContinue AndAlso path IsNot Nothing Then
    ' Source and target environment of the path, and what was read from them
    Dim src As String = path.Value(Of String)("source")
    Dim tgt As String = path.Value(Of String)("target")
    Dim envs As JToken = in_Details("environments")
    Dim version As String = Convert.ToString(in_Request.SelectToken("package.requestedVersion")).Trim()
    Dim srcVersions As List(Of String) = If(TryCast(in_Details("sourceVersions"), JArray), New JArray()).Values(Of String)().ToList()
    Dim pkgWord As String = If(tool = "Power Automate", "solution", "package")
    ' Source and target must have been readable
    If envs(src).Value(Of String)("error") <> "" Then out_Errors.Add("The source environment " & src & " could not be read: " & envs(src).Value(Of String)("error"))
    If envs(tgt).Value(Of String)("error") <> "" Then out_Errors.Add("The target environment " & tgt & " could not be read: " & envs(tgt).Value(Of String)("error"))
    ' The requested version must exist in the source environment
    If version <> "" AndAlso Not srcVersions.Contains(version) Then out_Errors.Add("Version " & version & " of the " & pkgWord & " is not available in " & src & If(srcVersions.Count > 0, " (available: " & String.Join(", ", srcVersions.Take(10)) & ")", "") & ".")
    ' Power Automate from Dev: only the current Dev solution version can be exported
    If tool = "Power Automate" AndAlso src = "Dev" AndAlso version <> "" AndAlso version <> envs("Dev").Value(Of String)("deployedVersion") Then out_Errors.Add("Only the current Dev solution version (" & envs("Dev").Value(Of String)("deployedVersion") & ") can be exported.")
    ' Power Automate from UAT: the version must be the one installed in UAT
    If tool = "Power Automate" AndAlso src <> "Dev" AndAlso version <> "" AndAlso version <> envs(src).Value(Of String)("deployedVersion") Then out_Errors.Add("Version " & version & " is not the version installed in " & src & " (" & envs(src).Value(Of String)("deployedVersion") & ").")
    ' UiPath from UAT: the version must be the one deployed and tested in UAT
    If tool = "UiPath" AndAlso src <> "Dev" AndAlso version <> "" AndAlso version <> envs(src).Value(Of String)("deployedVersion") Then out_Errors.Add("Version " & version & " is not the version deployed and tested in " & src & " (" & If(envs(src).Value(Of String)("deployedVersion") = "", "none", envs(src).Value(Of String)("deployedVersion")) & ").")
    ' The target folder (UiPath) or environment (Power Automate) must exist; it is never created here
    If Not envs(tgt).Value(Of Boolean)("folderExists") AndAlso envs(tgt).Value(Of String)("error") = "" Then out_Errors.Add(If(tool = "UiPath", "Target folder '" & envs(tgt).Value(Of String)("folderPath") & "' does not exist in " & tgt & " or is not visible to the API account. Create it first (folders are not created by this workflow).", "Target environment " & tgt & " is not reachable."))
    Dim tgtVersion As String = envs(tgt).Value(Of String)("deployedVersion")
    ' Enhancement and Bug Fix need the process or solution to exist in the target already
    If ptype <> "New" AndAlso Not envs(tgt).Value(Of Boolean)("releaseExists") AndAlso envs(tgt).Value(Of String)("error") = "" Then out_Errors.Add("The " & If(tool = "UiPath", "process", "solution") & " does not exist in " & tgt & " yet. Submit it as a New request.")
    ' Compare the requested version with the target version (numbers padded so 1.10 sorts after 1.9)
    If version <> "" AndAlso tgtVersion <> "" Then
        ' Same version: allowed, only verified
        If version = tgtVersion Then
            out_Warnings.Add("Version " & version & " is already deployed in " & tgt & "; the deployment will only verify it.")
        ElseIf String.CompareOrdinal(String.Join(".", version.Split("."c).Select(Function(seg) If(System.Text.RegularExpressions.Regex.IsMatch(seg, "^[0-9]+$"), seg.PadLeft(10, "0"c), seg))), String.Join(".", tgtVersion.Split("."c).Select(Function(seg) If(System.Text.RegularExpressions.Regex.IsMatch(seg, "^[0-9]+$"), seg.PadLeft(10, "0"c), seg)))) < 0 Then
            out_Errors.Add("Version " & version & " is older than the version in " & tgt & " (" & tgtVersion & "). Downgrades are not allowed through this request.")
        End If
    End If
    ' New request for a process that already exists: it will be updated
    If ptype = "New" AndAlso envs(tgt).Value(Of Boolean)("releaseExists") Then out_Warnings.Add("The process already exists in " & tgt & " (version " & tgtVersion & "); it will be updated, not recreated.")
    ' Configuration grid (assets, queues, access) sent with the request
    Dim cfg As JObject = TryCast(in_Request("configuration"), JObject)
    ' Configuration changes are only allowed for New requests
    If ptype <> "New" AndAlso cfg IsNot Nothing Then out_Errors.Add("Configuration changes are only allowed for New requests.")
    If cfg IsNot Nothing Then
        ' Only configuration editors may change the grid
        If cfg.Value(Of Boolean)("editedByRequester") AndAlso Not in_IsEditor Then out_Errors.Add("You are not authorized to change the configuration. Only configuration editors may change assets, queues, access or process mapping.")
        If cfg.Value(Of String)("processName") = "" Then out_Errors.Add("Process Name cannot be empty.")
        ' The folder comes from the Bot ID mapping, not from the request
        If cfg.Value(Of String)("targetFolder") <> envs(tgt).Value(Of String)("folderPath") Then out_Errors.Add("Target folder '" & cfg.Value(Of String)("targetFolder") & "' differs from the folder mapped for " & tgt & " ('" & envs(tgt).Value(Of String)("folderPath") & "'). Folder mappings are changed in the Bot ID mapping, not per request.")
        ' Check each asset row: action, existence in the target, value type and secret handling
        For Each asset As JObject In cfg("assets").Children(Of JObject)()
            Dim n As String = asset.Value(Of String)("name")
            Dim act As String = asset.Value(Of String)("action")
            Dim exists As Boolean = asset.Value(Of Boolean)("targetExists")
            Dim typ As String = asset.Value(Of String)("type")
            Dim proposed As String = Convert.ToString(asset("proposedValue"))
            If Not New String() {"Create", "Update", "Keep", "Skip"}.Contains(act) Then out_Errors.Add("Asset " & n & ": unknown action '" & act & "'.")
            If act = "Create" AndAlso exists Then out_Errors.Add("Asset " & n & " already exists in " & tgt & ". Choose Keep or Update (Create would duplicate it).")
            If act = "Update" AndAlso Not exists Then out_Errors.Add("Asset " & n & " does not exist in " & tgt & "; choose Create.")
            If (act = "Keep" OrElse act = "Skip") AndAlso Not exists AndAlso asset.Value(Of Boolean)("required") Then out_Errors.Add("Asset " & n & " is required by the process but missing in " & tgt & ". Choose Create.")
            ' Values are only checked for Create and Update
            If act = "Create" OrElse act = "Update" Then
                ' Sensitive assets: only Credential assets with an approved secret source; no value is ever typed in the form
                If asset.Value(Of Boolean)("isSecret") Then
                    If typ <> "Credential" Then
                        out_Errors.Add("Asset " & n & " (" & typ & ") holds a sensitive value. Only Credential assets can be set from an approved secret source; set this one in Orchestrator.")
                    ElseIf Not asset.Value(Of Boolean)("hasSecretSource") Then
                        out_Errors.Add("Asset " & n & " is a Credential; no approved secret source is configured for " & tgt & " in the Bot ID mapping (secretSource." & tgt & ").")
                    End If
                ElseIf typ = "Integer" AndAlso Not (System.Text.RegularExpressions.Regex.IsMatch(proposed, "^\s*[+-]?[0-9]{1,10}\s*$") AndAlso CLng(proposed.Trim()) >= Integer.MinValue AndAlso CLng(proposed.Trim()) <= Integer.MaxValue) Then
                    out_Errors.Add("Asset " & n & ": '" & proposed & "' is not a whole number.")
                ElseIf typ = "Bool" AndAlso Not New String() {"true", "false"}.Contains(proposed.ToLowerInvariant()) Then
                    out_Errors.Add("Asset " & n & ": value must be true or false.")
                ElseIf typ = "Text" AndAlso proposed = "" Then
                    out_Errors.Add("Asset " & n & ": enter a value.")
                ElseIf Not New String() {"Text", "Integer", "Bool", "Credential"}.Contains(typ) Then
                    out_Errors.Add("Asset " & n & ": type " & typ & " cannot be migrated by this workflow; configure it in Orchestrator.")
                End If
            End If
        Next
        ' Check each queue row: action, existence in the target and the queue name
        For Each queue As JObject In cfg("queues").Children(Of JObject)()
            Dim n As String = queue.Value(Of String)("name")
            Dim act As String = queue.Value(Of String)("action")
            Dim exists As Boolean = queue.Value(Of Boolean)("targetExists")
            If Not New String() {"Create", "Update", "Keep", "Skip"}.Contains(act) Then out_Errors.Add("Queue " & n & ": unknown action '" & act & "'.")
            If act = "Create" AndAlso exists AndAlso queue.Value(Of String)("proposedName") = n Then out_Errors.Add("Queue " & n & " already exists in " & tgt & ". Choose Keep or Update.")
            If act = "Update" AndAlso Not exists Then out_Errors.Add("Queue " & n & " does not exist in " & tgt & "; choose Create.")
            If (act = "Keep" OrElse act = "Skip") AndAlso Not exists AndAlso queue.Value(Of Boolean)("required") Then out_Errors.Add("Queue " & n & " is required by the process but missing in " & tgt & ". Choose Create.")
            If Not System.Text.RegularExpressions.Regex.IsMatch(Convert.ToString(queue("proposedName")), "^[A-Za-z0-9][A-Za-z0-9 _.-]{0,127}$") Then out_Errors.Add("Queue name '" & queue.Value(Of String)("proposedName") & "' is not valid.")
            If queue.Value(Of String)("proposedName") <> n AndAlso act <> "Create" Then out_Errors.Add("Queue " & n & ": a different queue name can only be used with Create.")
        Next
        ' Access levels allowed in the target environment (settings allowedAccessLevels)
        Dim allowed As List(Of String) = If(TryCast(in_Config.SelectToken("allowedAccessLevels." & tgt), JArray), New JArray()).Values(Of String)().ToList()
        ' Check each access row that asks for a change
        For Each user As JObject In cfg("access").Children(Of JObject)()
            Dim act As String = user.Value(Of String)("action")
            ' Rows marked "No change" need no check
            If act <> "No change" Then
                If act <> "Grant" Then
                    out_Errors.Add("Access for " & user.Value(Of String)("name") & ": unknown action '" & act & "'.")
                ElseIf Not allowed.Contains(user.Value(Of String)("accessLevel")) Then
                    out_Errors.Add("Unauthorized access change: access level '" & user.Value(Of String)("accessLevel") & "' for " & user.Value(Of String)("name") & " is not allowed in " & tgt & " (allowed: " & String.Join(", ", allowed) & ").")
                ElseIf in_Config.SelectToken("roleMappings['" & user.Value(Of String)("accessLevel") & "']") Is Nothing Then
                    out_Errors.Add("Access level '" & user.Value(Of String)("accessLevel") & "' has no role mapping.")
                End If
                If Not New String() {"DirectoryUser", "DirectoryGroup", "User", "Group", "Robot", "DirectoryRobot", "DirectoryExternalApplication"}.Contains(user.Value(Of String)("type")) Then out_Errors.Add("Access for " & user.Value(Of String)("name") & ": account type '" & user.Value(Of String)("type") & "' is not supported.")
            End If
        Next
    End If
    ' Pass on the warnings collected while fetching the details
    For Each fetchWarning As JToken In If(TryCast(in_Details("warnings"), JArray), New JArray())
        out_Warnings.Add(fetchWarning)
    Next
End If
