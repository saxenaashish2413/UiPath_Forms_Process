'ARG in in_Config JO
'ARG in in_Request JO
'ARG in in_Details JO
'ARG in in_IsEditor B
'ARG out out_Errors JA
'ARG out out_Warnings JA
' Rule checks that need no API call (the live checks - duplicate request, approval, UAT evidence - run in
' Validate_Deployment_Request.xaml). Every message is written for the requester.
out_Errors = New Newtonsoft.Json.Linq.JArray()
out_Warnings = New Newtonsoft.Json.Linq.JArray()
Dim errs As Newtonsoft.Json.Linq.JArray = out_Errors
Dim warns As Newtonsoft.Json.Linq.JArray = out_Warnings
Dim R As Func(Of String, String) = Function(k) If(in_Request.SelectToken(k)?.ToString(), "").Trim()
Dim tool As String = R("automationTool")
Dim ptype As String = R("processType")
Dim pathName As String = R("deploymentPath")
Dim VKey As Func(Of String, String) = Function(v) String.Join(".", v.Split("."c).Select(Function(seg) If(seg.All(AddressOf Char.IsDigit) AndAlso seg <> "", seg.PadLeft(10, "0"c), seg)))
If Not New String() {"UiPath", "Power Automate"}.Contains(tool) Then errs.Add("Automation Tool '" & tool & "' is not supported.")
Dim rules As Newtonsoft.Json.Linq.JToken = in_Config.SelectToken("requestRules['" & ptype & "']")
If rules Is Nothing Then
    errs.Add("Select a Process Type (New, Enhancement or Bug Fix).")
    Return
End If
Dim path As Newtonsoft.Json.Linq.JObject = in_Config("deploymentPaths").Children(Of Newtonsoft.Json.Linq.JObject)().FirstOrDefault(Function(x) x.Value(Of String)("name") = pathName)
If path Is Nothing Then errs.Add("Select a Deployment Path (" & String.Join(" or ", in_Config("deploymentPaths").Children(Of Newtonsoft.Json.Linq.JObject)().Select(Function(x) x.Value(Of String)("name"))) & ").")
Dim fieldMap As New Dictionary(Of String, String) From {
    {"BotId", "botId"}, {"DeploymentPath", "deploymentPath"}, {"RequestedVersion", "package.requestedVersion"},
    {"EnhancementDescription", "enhancement.description"}, {"ChangeReference", "enhancement.changeReference"},
    {"BugDescription", "bugFix.description"}, {"IncidentReference", "bugFix.incidentReference"}}
Dim labels As New Dictionary(Of String, String) From {
    {"BotId", "Bot ID"}, {"DeploymentPath", "Deployment Path"}, {"RequestedVersion", If(tool = "Power Automate", "Requested Solution Version", "Requested Package Version")},
    {"EnhancementDescription", "Enhancement Description"}, {"ChangeReference", "Change or Request Reference"},
    {"BugDescription", "Bug Description"}, {"IncidentReference", "Incident or Defect Reference"}}
For Each f As String In rules("requiredFields").Values(Of String)()
    If fieldMap.ContainsKey(f) AndAlso R(fieldMap(f)) = "" AndAlso Not (f = "DeploymentPath" AndAlso path Is Nothing) Then errs.Add(labels(f) & " is required.")
Next
For Each k As String In New String() {"enhancement.description", "bugFix.description"}
    If R(k).Length > 2000 Then errs.Add("Description is longer than 2000 characters.")
Next
For Each k As String In New String() {"enhancement.changeReference", "bugFix.incidentReference"}
    If R(k) <> "" AndAlso Not System.Text.RegularExpressions.Regex.IsMatch(R(k), "^[A-Za-z0-9][A-Za-z0-9_./-]{2,39}$") Then errs.Add("Reference '" & R(k) & "' must be 3-40 letters, digits or - _ . /")
Next
' ---- details must belong to this request
If in_Details Is Nothing OrElse in_Details.Value(Of String)("status") <> "Found" Then
    errs.Add("Fetch the details for this Bot ID first; the request cannot be validated without them.")
    Return
End If
If Not String.Equals(in_Details.Value(Of String)("botId"), R("botId"), StringComparison.OrdinalIgnoreCase) OrElse in_Details.Value(Of String)("tool") <> tool OrElse in_Details.Value(Of String)("processType") <> ptype OrElse in_Details.Value(Of String)("deploymentPath") <> pathName Then
    errs.Add("The details shown were fetched for a different Bot ID, tool, process type or deployment path. Click Fetch Details again.")
    Return
End If
If path Is Nothing Then Return
Dim src As String = path.Value(Of String)("source")
Dim tgt As String = path.Value(Of String)("target")
Dim envs As Newtonsoft.Json.Linq.JToken = in_Details("environments")
Dim version As String = R("package.requestedVersion")
Dim srcVersions As List(Of String) = If(TryCast(in_Details("sourceVersions"), Newtonsoft.Json.Linq.JArray), New Newtonsoft.Json.Linq.JArray()).Values(Of String)().ToList()
Dim pkgWord As String = If(tool = "Power Automate", "solution", "package")
If envs(src).Value(Of String)("error") <> "" Then errs.Add("The source environment " & src & " could not be read: " & envs(src).Value(Of String)("error"))
If envs(tgt).Value(Of String)("error") <> "" Then errs.Add("The target environment " & tgt & " could not be read: " & envs(tgt).Value(Of String)("error"))
If version <> "" AndAlso Not srcVersions.Contains(version) Then
    errs.Add("Version " & version & " of the " & pkgWord & " is not available in " & src & If(srcVersions.Count > 0, " (available: " & String.Join(", ", srcVersions.Take(10)) & ")", "") & ".")
End If
If tool = "Power Automate" AndAlso src = "Dev" AndAlso version <> "" AndAlso version <> envs("Dev").Value(Of String)("deployedVersion") Then errs.Add("Only the current Dev solution version (" & envs("Dev").Value(Of String)("deployedVersion") & ") can be exported.")
If tool = "Power Automate" AndAlso src <> "Dev" AndAlso version <> "" AndAlso version <> envs(src).Value(Of String)("deployedVersion") Then errs.Add("Version " & version & " is not the version installed in " & src & " (" & envs(src).Value(Of String)("deployedVersion") & ").")
If tool = "UiPath" AndAlso src <> "Dev" AndAlso version <> "" AndAlso version <> envs(src).Value(Of String)("deployedVersion") Then errs.Add("Version " & version & " is not the version deployed and tested in " & src & " (" & If(envs(src).Value(Of String)("deployedVersion") = "", "none", envs(src).Value(Of String)("deployedVersion")) & ").")
If Not envs(tgt).Value(Of Boolean)("folderExists") AndAlso envs(tgt).Value(Of String)("error") = "" Then errs.Add(If(tool = "UiPath", "Target folder '" & envs(tgt).Value(Of String)("folderPath") & "' does not exist in " & tgt & " or is not visible to the API account. Create it first (folders are not created by this workflow).", "Target environment " & tgt & " is not reachable."))
Dim tgtVersion As String = envs(tgt).Value(Of String)("deployedVersion")
If ptype <> "New" AndAlso Not envs(tgt).Value(Of Boolean)("releaseExists") AndAlso envs(tgt).Value(Of String)("error") = "" Then
    errs.Add("The " & If(tool = "UiPath", "process", "solution") & " does not exist in " & tgt & " yet. Submit it as a New request.")
End If
If version <> "" AndAlso tgtVersion <> "" Then
    If version = tgtVersion Then
        warns.Add("Version " & version & " is already deployed in " & tgt & "; the deployment will only verify it.")
    ElseIf String.CompareOrdinal(VKey(version), VKey(tgtVersion)) < 0 Then
        errs.Add("Version " & version & " is older than the version in " & tgt & " (" & tgtVersion & "). Downgrades are not allowed through this request.")
    End If
End If
If ptype = "New" AndAlso envs(tgt).Value(Of Boolean)("releaseExists") Then warns.Add("The process already exists in " & tgt & " (version " & tgtVersion & "); it will be updated, not recreated.")
' ---- configuration (New + UiPath)
Dim cfg As Newtonsoft.Json.Linq.JObject = TryCast(in_Request("configuration"), Newtonsoft.Json.Linq.JObject)
If ptype <> "New" AndAlso cfg IsNot Nothing Then errs.Add("Configuration changes are only allowed for New requests.")
If cfg IsNot Nothing Then
    If cfg.Value(Of Boolean)("editedByRequester") AndAlso Not in_IsEditor Then errs.Add("You are not authorized to change the configuration. Only configuration editors may change assets, queues, access or process mapping.")
    If cfg.Value(Of String)("processName") = "" Then errs.Add("Process Name cannot be empty.")
    If cfg.Value(Of String)("targetFolder") <> envs(tgt).Value(Of String)("folderPath") Then errs.Add("Target folder '" & cfg.Value(Of String)("targetFolder") & "' differs from the folder mapped for " & tgt & " ('" & envs(tgt).Value(Of String)("folderPath") & "'). Folder mappings are changed in the Bot ID mapping, not per request.")
    For Each a As Newtonsoft.Json.Linq.JObject In cfg("assets").Children(Of Newtonsoft.Json.Linq.JObject)()
        Dim n As String = a.Value(Of String)("name")
        Dim act As String = a.Value(Of String)("action")
        Dim exists As Boolean = a.Value(Of Boolean)("targetExists")
        Dim typ As String = a.Value(Of String)("type")
        If Not New String() {"Create", "Update", "Keep", "Skip"}.Contains(act) Then errs.Add("Asset " & n & ": unknown action '" & act & "'.")
        If act = "Create" AndAlso exists Then errs.Add("Asset " & n & " already exists in " & tgt & ". Choose Keep or Update (Create would duplicate it).")
        If act = "Update" AndAlso Not exists Then errs.Add("Asset " & n & " does not exist in " & tgt & "; choose Create.")
        If (act = "Keep" OrElse act = "Skip") AndAlso Not exists AndAlso a.Value(Of Boolean)("required") Then errs.Add("Asset " & n & " is required by the process but missing in " & tgt & ". Choose Create.")
        If (act = "Create" OrElse act = "Update") Then
            If a.Value(Of Boolean)("isSecret") Then
                If typ <> "Credential" Then
                    errs.Add("Asset " & n & " (" & typ & ") holds a sensitive value. Only Credential assets can be set from an approved secret source; set this one in Orchestrator.")
                ElseIf Not a.Value(Of Boolean)("hasSecretSource") Then
                    errs.Add("Asset " & n & " is a Credential; no approved secret source is configured for " & tgt & " in the Bot ID mapping (secretSource." & tgt & ").")
                End If
            ElseIf typ = "Integer" AndAlso Not Integer.TryParse(a.Value(Of String)("proposedValue"), Nothing) Then
                errs.Add("Asset " & n & ": '" & a.Value(Of String)("proposedValue") & "' is not a whole number.")
            ElseIf typ = "Bool" AndAlso Not New String() {"true", "false"}.Contains(a.Value(Of String)("proposedValue").ToLowerInvariant()) Then
                errs.Add("Asset " & n & ": value must be true or false.")
            ElseIf typ = "Text" AndAlso a.Value(Of String)("proposedValue") = "" Then
                errs.Add("Asset " & n & ": enter a value.")
            ElseIf Not New String() {"Text", "Integer", "Bool", "Credential"}.Contains(typ) Then
                errs.Add("Asset " & n & ": type " & typ & " cannot be migrated by this workflow; configure it in Orchestrator.")
            End If
        End If
    Next
    For Each q As Newtonsoft.Json.Linq.JObject In cfg("queues").Children(Of Newtonsoft.Json.Linq.JObject)()
        Dim n As String = q.Value(Of String)("name")
        Dim act As String = q.Value(Of String)("action")
        Dim exists As Boolean = q.Value(Of Boolean)("targetExists")
        If Not New String() {"Create", "Update", "Keep", "Skip"}.Contains(act) Then errs.Add("Queue " & n & ": unknown action '" & act & "'.")
        If act = "Create" AndAlso exists AndAlso q.Value(Of String)("proposedName") = n Then errs.Add("Queue " & n & " already exists in " & tgt & ". Choose Keep or Update.")
        If act = "Update" AndAlso Not exists Then errs.Add("Queue " & n & " does not exist in " & tgt & "; choose Create.")
        If (act = "Keep" OrElse act = "Skip") AndAlso Not exists AndAlso q.Value(Of Boolean)("required") Then errs.Add("Queue " & n & " is required by the process but missing in " & tgt & ". Choose Create.")
        If Not System.Text.RegularExpressions.Regex.IsMatch(q.Value(Of String)("proposedName"), "^[A-Za-z0-9][A-Za-z0-9 _.-]{0,127}$") Then errs.Add("Queue name '" & q.Value(Of String)("proposedName") & "' is not valid.")
        If q.Value(Of String)("proposedName") <> n AndAlso act <> "Create" Then errs.Add("Queue " & n & ": a different queue name can only be used with Create.")
    Next
    Dim allowed As List(Of String) = If(TryCast(in_Config.SelectToken("allowedAccessLevels." & tgt), Newtonsoft.Json.Linq.JArray), New Newtonsoft.Json.Linq.JArray()).Values(Of String)().ToList()
    For Each u As Newtonsoft.Json.Linq.JObject In cfg("access").Children(Of Newtonsoft.Json.Linq.JObject)()
        Dim act As String = u.Value(Of String)("action")
        If act = "No change" Then Continue For
        If act <> "Grant" Then
            errs.Add("Access for " & u.Value(Of String)("name") & ": unknown action '" & act & "'.")
        ElseIf Not allowed.Contains(u.Value(Of String)("accessLevel")) Then
            errs.Add("Unauthorized access change: access level '" & u.Value(Of String)("accessLevel") & "' for " & u.Value(Of String)("name") & " is not allowed in " & tgt & " (allowed: " & String.Join(", ", allowed) & ").")
        ElseIf in_Config.SelectToken("roleMappings['" & u.Value(Of String)("accessLevel") & "']") Is Nothing Then
            errs.Add("Access level '" & u.Value(Of String)("accessLevel") & "' has no role mapping.")
        End If
        If Not New String() {"DirectoryUser", "DirectoryGroup", "User", "Group", "Robot", "DirectoryRobot", "DirectoryExternalApplication"}.Contains(u.Value(Of String)("type")) Then errs.Add("Access for " & u.Value(Of String)("name") & ": account type '" & u.Value(Of String)("type") & "' is not supported.")
    Next
End If
For Each w As Newtonsoft.Json.Linq.JToken In If(TryCast(in_Details("warnings"), Newtonsoft.Json.Linq.JArray), New Newtonsoft.Json.Linq.JArray())
    warns.Add(w)
Next
