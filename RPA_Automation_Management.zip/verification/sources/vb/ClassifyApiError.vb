'ARG in in_StatusCode I
'ARG in in_ResponseBody S
'ARG in in_Method S
'ARG in in_Url S
'ARG in in_ApiName S
'ARG in in_CorrelationId S
'ARG out out_Category S
'ARG out out_ErrorCode S
'ARG out out_ErrorMessage S
'ARG out out_IsTransient B
'ARG out out_Summary S
' Turns a failed HTTP response into a structured error. Understands the Orchestrator error body ({"message","errorCode","traceId"}), OData/Dataverse ({"error":{"code","message"}}), OAuth ({"error","error_description"}) and ASP.NET validation ({"title","errors"}) shapes.
out_ErrorCode = ""
out_ErrorMessage = ""
' Category from the HTTP status
out_Category = If(in_StatusCode = 400, "Validation", If(in_StatusCode = 401, "Authentication", If(in_StatusCode = 403, "Authorization", If(in_StatusCode = 404, "NotFound", If(in_StatusCode = 409, "Conflict", If(in_StatusCode = 429, "Throttled", If(New Integer() {500, 502, 503, 504}.Contains(in_StatusCode), "ServerError", If(in_StatusCode = 0, "NoResponse", "HttpError"))))))))
' Throttling and server errors are temporary
out_IsTransient = New Integer() {429, 500, 502, 503, 504}.Contains(in_StatusCode)
' Response body text
Dim body As String = If(in_ResponseBody, "").Trim()
' Plain text body: keep the first 500 characters
out_ErrorMessage = Left(body, 500)
' JSON body: read the error code and message from the known shapes
If body.StartsWith("{") Then
    Try
        Dim j As JObject = JObject.Parse(body)
        ' OData/Dataverse {"error":{...}} or OAuth {"error":"..."}
        Dim errNode As JToken = j("error")
        out_ErrorMessage = ""
        If errNode IsNot Nothing AndAlso errNode.Type = JTokenType.Object Then
            out_ErrorCode = If(errNode.Value(Of String)("code"), "")
            out_ErrorMessage = If(errNode.Value(Of String)("message"), "")
        ElseIf errNode IsNot Nothing Then
            out_ErrorCode = errNode.ToString()
            out_ErrorMessage = If(j.Value(Of String)("error_description"), "")
        End If
        ' Orchestrator {"message","errorCode"}
        If out_ErrorMessage = "" AndAlso j("message") IsNot Nothing Then out_ErrorMessage = j("message").ToString()
        If out_ErrorCode = "" AndAlso j("errorCode") IsNot Nothing Then out_ErrorCode = j("errorCode").ToString()
        ' ASP.NET validation {"title","errors"}
        If out_ErrorMessage = "" AndAlso j("title") IsNot Nothing Then out_ErrorMessage = j("title").ToString()
        If j("errors") IsNot Nothing Then out_ErrorMessage = (out_ErrorMessage & " " & j("errors").ToString(Newtonsoft.Json.Formatting.None)).Trim()
        ' Orchestrator trace id, when there is no correlation header
        If String.IsNullOrEmpty(in_CorrelationId) AndAlso j("traceId") IsNot Nothing Then out_ErrorMessage = out_ErrorMessage & " (traceId " & j("traceId").ToString() & ")"
    Catch ex As JsonReaderException
        ' Not valid JSON: keep the text
        out_ErrorMessage = Left(body, 500)
    End Try
End If
' Strip anything that looks like a credential before the text reaches a log or an exception
out_ErrorMessage = System.Text.RegularExpressions.Regex.Replace(System.Text.RegularExpressions.Regex.Replace(out_ErrorMessage, "(?i)(bearer\s+)[A-Za-z0-9\-\._~\+/]+=*", "$1***"), "(?i)(""?(password|secret|client_secret|access_token|token)""?\s*[:=]\s*)""?[^"",\s}]+""?", "$1***")
' One-line summary for the log: operation, method, path without query string, status, code, message, correlation id
out_Summary = "[" & in_ApiName & "] " & in_Method.ToUpperInvariant() & " " & If(in_Url.IndexOf("?"c) > 0, in_Url.Substring(0, in_Url.IndexOf("?"c)), in_Url) & " -> HTTP " & in_StatusCode.ToString(System.Globalization.CultureInfo.InvariantCulture) & " " & out_Category & If(out_ErrorCode <> "", "; ErrorCode=" & out_ErrorCode, "") & If(out_ErrorMessage <> "", "; Message=" & Left(out_ErrorMessage, 600), "") & If(Not String.IsNullOrEmpty(in_CorrelationId), "; CorrelationId=" & in_CorrelationId, "")
