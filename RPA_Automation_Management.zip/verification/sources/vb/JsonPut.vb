'ARG in in_Target JO
'ARG in in_Key S
'ARG in in_Json S
' Stores a raw API result in in_Target under in_Key: parsed JSON when in_Json is JSON, the plain text otherwise, null when empty.
' Start with an empty (null) value
Dim v As JToken = JValue.CreateNull()
' Trimmed text, to see what kind of value it is
Dim t As String = If(in_Json, "").Trim()
' Non-empty text is kept as text unless it parses as JSON below
If t <> "" Then v = New JValue(in_Json)
' Looks like JSON? Then try to parse it
If t.StartsWith("{") OrElse t.StartsWith("[") Then
    ' Messages such as "[GET odata/Folders] ..." also start with "[": keep them as text when they are not JSON
    Try
        ' Parse the JSON (dates are kept as text)
        v = JsonConvert.DeserializeObject(Of JToken)(t, New JsonSerializerSettings With {.DateParseHandling = DateParseHandling.None})
    Catch ex As JsonException
        ' Not JSON after all: keep the text
        v = New JValue(in_Json)
    End Try
End If
' Store the value under the key
in_Target(in_Key) = v
