'ARG in in_Target JO
'ARG in in_Key S
'ARG in in_Json S
' Stores a raw API result under in_Key: parsed JSON when in_Json is JSON, the text otherwise, null when empty.
Dim v As Newtonsoft.Json.Linq.JToken = Newtonsoft.Json.Linq.JValue.CreateNull()
Dim t As String = If(in_Json, "").Trim()
If t <> "" Then v = New Newtonsoft.Json.Linq.JValue(in_Json)
If t.StartsWith("{") OrElse t.StartsWith("[") Then
    ' Messages such as "[GET odata/Folders] ..." also start with "[": keep them as text when they are not JSON.
    Try
        v = Newtonsoft.Json.JsonConvert.DeserializeObject(Of Newtonsoft.Json.Linq.JToken)(t, New Newtonsoft.Json.JsonSerializerSettings With {.DateParseHandling = Newtonsoft.Json.DateParseHandling.None})
    Catch ex As Newtonsoft.Json.JsonException
        v = New Newtonsoft.Json.Linq.JValue(in_Json)
    End Try
End If
in_Target(in_Key) = v
