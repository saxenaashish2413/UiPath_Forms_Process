'ARG in in_Versions JA
'ARG out out_Sorted JA
' Sorts version strings newest first (numeric comparison per dot-separated part; text parts compared ordinally).
Dim Key As Func(Of String, String) = Function(v) String.Join(".", v.Split("."c).Select(Function(seg) If(seg.All(AddressOf Char.IsDigit) AndAlso seg <> "", seg.PadLeft(10, "0"c), seg)))
Dim list As List(Of String) = If(in_Versions, New Newtonsoft.Json.Linq.JArray()).Values(Of String)().Where(Function(v) Not String.IsNullOrWhiteSpace(v)).Distinct().ToList()
out_Sorted = New Newtonsoft.Json.Linq.JArray(list.OrderByDescending(Function(v) Key(v), StringComparer.Ordinal).ToArray())
