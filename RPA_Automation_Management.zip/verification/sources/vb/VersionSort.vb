'ARG in in_Versions JA
'ARG out out_Sorted JA
' Sorts version strings newest first. Each dot-separated number is padded to 10 digits before comparing, so 1.10.0 sorts above 1.9.0.
' Keep only real version strings, each once
Dim list As List(Of String) = If(in_Versions, New JArray()).Values(Of String)().Where(Function(v) Not String.IsNullOrWhiteSpace(v)).Distinct().ToList()
' Sort newest first: pad every numeric part to 10 digits so the text order equals the numeric order
out_Sorted = New JArray(list.OrderByDescending(Function(v) String.Join(".", v.Split("."c).Select(Function(seg) If(seg.All(AddressOf Char.IsDigit) AndAlso seg <> "", seg.PadLeft(10, "0"c), seg))), StringComparer.Ordinal).ToArray())
