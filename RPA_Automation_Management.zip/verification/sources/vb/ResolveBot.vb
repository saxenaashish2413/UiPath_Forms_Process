'ARG in in_Config JO
'ARG in in_Tool S
'ARG in in_BotId S
'ARG out out_Bot JO
'ARG out out_Error S
'ARG out out_NotMapped B
' Resolves a business Bot ID (or alias) through Config\BotMapping.json. The Bot ID is never used as an Orchestrator key directly: the mapping supplies process, package, folders, queues, assets and access per environment. out_NotMapped = True only when the ID is valid but not in the mapping (the caller may then search Dev for it).
' Nothing resolved yet
out_Bot = Nothing
out_Error = ""
out_NotMapped = False
Dim botId As String = If(in_BotId, "").Trim()
' Check the inputs, then look the Bot ID up in the mapping
If String.IsNullOrWhiteSpace(in_Tool) Then
    out_Error = "Select an Automation Tool first."
ElseIf Not New String() {"UiPath", "Power Automate"}.Contains(in_Tool) Then
    out_Error = "Automation tool '" & in_Tool & "' is not supported. Choose UiPath or Power Automate."
ElseIf botId = "" Then
    out_Error = "Enter a Bot ID."
ElseIf Not System.Text.RegularExpressions.Regex.IsMatch(botId, If(in_Config.Value(Of String)("botIdPattern"), ".+")) Then
    out_Error = "Bot ID '" & botId & "' has an invalid format."
Else
    ' Mapping entry whose botId or one of its aliases equals the Bot ID (ignoring case)
    Dim match As JObject = in_Config("bots").Children(Of JObject)().FirstOrDefault(Function(b) String.Equals(b.Value(Of String)("botId"), botId, StringComparison.OrdinalIgnoreCase) OrElse (TypeOf b("aliases") Is JArray AndAlso b("aliases").Values(Of String)().Any(Function(a) String.Equals(a, botId, StringComparison.OrdinalIgnoreCase))))
    ' Not mapped, registered for the other tool, or found
    If match Is Nothing Then
        out_NotMapped = True
        out_Error = "Bot ID '" & botId & "' was not found in the Bot ID mapping. Check the ID or ask the RPA CoE to register it."
    ElseIf match.Value(Of String)("automationTool") <> in_Tool Then
        out_Error = "Bot ID '" & botId & "' is registered for " & match.Value(Of String)("automationTool") & ", not " & in_Tool & ". Change the Automation Tool or the Bot ID."
    Else
        out_Bot = CType(match.DeepClone(), JObject)
    End If
End If
