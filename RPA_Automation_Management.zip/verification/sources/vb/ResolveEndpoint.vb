'ARG in in_Config JO
'ARG in in_Provider S
'ARG in in_Environment S
'ARG out out_BaseUrl S
'ARG out out_TenantName S
'ARG out out_ExtraHeadersJson S
'ARG out out_TimeoutSeconds I
'ARG out out_RetryCount I
'ARG out out_RetryDelaySeconds I
'ARG out out_TokenKey S
'ARG out out_TokenUrl S
'ARG out out_CredentialAsset S
'ARG out out_CredentialFolder S
'ARG out out_Scope S
' Environment-specific connection settings. Dev, UAT and Prod are fully separate (own URL, own account, own credential asset). UiPath: base {orchestratorUrl}/; token from {tokenUrl} (Identity Server client credentials), or for authMode UsernamePassword {orchestratorUrl}/api/Account/Authenticate when tokenUrl is empty; scope from settings. Power Automate: base {environmentUrl}/api/data/{apiVersion}/; token from Entra ID v2.0; scope {environmentUrl}/.default.
' Only Dev, UAT and Prod are allowed
If Not New String() {"Dev", "UAT", "Prod"}.Contains(in_Environment) Then Throw New ArgumentException("Unknown environment '" & in_Environment & "'")
' HTTP timeout and retry settings (settings http.*)
out_TimeoutSeconds = CInt(If(in_Config.SelectToken("http.timeoutSeconds"), 60))
out_RetryCount = CInt(If(in_Config.SelectToken("http.retryCount"), 3))
out_RetryDelaySeconds = CInt(If(in_Config.SelectToken("http.retryDelaySeconds"), 2))
' Settings for the chosen provider
If in_Provider = "UiPath" Then
    ' UiPath: this environment's Orchestrator settings
    Dim e As JToken = in_Config.SelectToken("uipath.environments." & in_Environment)
    out_BaseUrl = e.Value(Of String)("orchestratorUrl").TrimEnd("/"c) & "/"
    out_TenantName = If(e.Value(Of String)("tenantName"), "")
    out_ExtraHeadersJson = ""
    out_TokenUrl = If(e.Value(Of String)("tokenUrl"), "")
    ' Standalone sign-in with tenant, user name and password: default authenticate address
    If out_TokenUrl.Trim() = "" AndAlso e.Value(Of String)("authMode") = "UsernamePassword" Then out_TokenUrl = out_BaseUrl & "api/Account/Authenticate"
    out_CredentialAsset = e.Value(Of String)("credentialAsset")
    out_CredentialFolder = e.Value(Of String)("credentialFolder")
    out_Scope = e.Value(Of String)("scope")
ElseIf in_Provider = "PowerAutomate" Then
    ' Power Automate: Dataverse Web API of this environment
    Dim pa As JToken = in_Config("powerAutomate")
    Dim envUrl As String = pa.SelectToken("environments." & in_Environment & ".environmentUrl").ToString().TrimEnd("/"c)
    out_BaseUrl = envUrl & "/api/data/" & If(pa.Value(Of String)("apiVersion"), "v9.2") & "/"
    out_TenantName = ""
    out_ExtraHeadersJson = "{""OData-MaxVersion"":""4.0"",""OData-Version"":""4.0""}"
    out_TokenUrl = pa.Value(Of String)("authorityUrl").TrimEnd("/"c) & "/" & pa.Value(Of String)("tenantId") & "/oauth2/v2.0/token"
    out_CredentialAsset = pa.Value(Of String)("credentialAsset")
    out_CredentialFolder = pa.Value(Of String)("credentialFolder")
    out_Scope = envUrl & "/.default"
Else
    Throw New ArgumentException("Unsupported provider '" & in_Provider & "'")
End If
' Key used to cache the token for this provider and environment
out_TokenKey = in_Provider & "|" & in_Environment
