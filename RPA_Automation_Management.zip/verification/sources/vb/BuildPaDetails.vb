'ARG in in_Config JO
'ARG in in_Raw JO
'ARG out out_Details JO
' Power Automate provider: builds the form object from the Dataverse responses collected by PA_Fetch_Bot_Configuration.xaml. A Power Automate "package" is a Dataverse solution (uniquename + version); flows are solution components (type 29). in_Raw keys: bot, processType, deploymentPath, sourceEnv, targetEnv, "<Env>.org" (RetrieveCurrentOrganization), "<Env>.solution" (solutions collection), "<Env>.error", "Dev.flows" (workflow records), artifactVersions (managed solution files already exported to the artifact store).
' The bot entry (from the mapping or found in Dev) and its solution
Dim bot As JObject = CType(in_Raw("bot"), JObject)
Dim uniqueName As String = bot.SelectToken("powerAutomate.solutionUniqueName").ToString()
' Details header
Dim d As New JObject()
d("tool") = "Power Automate"
d("botId") = bot.Value(Of String)("botId")
d("processType") = in_Raw.Value(Of String)("processType")
d("deploymentPath") = in_Raw.Value(Of String)("deploymentPath")
d("sourceEnv") = in_Raw.Value(Of String)("sourceEnv")
d("targetEnv") = in_Raw.Value(Of String)("targetEnv")
d("retrievedAtUtc") = DateTime.UtcNow.ToString("o", System.Globalization.CultureInfo.InvariantCulture)
Dim warnings As New JArray()
' One block per environment: name, solution version, managed or not, status text
Dim envs As New JObject()
For Each env As String In New String() {"Dev", "UAT", "Prod"}
    Dim e As New JObject()
    ' Read error for this environment, if any
    Dim err As String = If(in_Raw.Value(Of String)(env & ".error"), "")
    ' Environment details from RetrieveCurrentOrganization
    Dim org As JToken = If(in_Raw(env & ".org"), JValue.CreateNull()).SelectToken("Detail")
    ' The solution record, when the solution is installed there
    Dim sols As JArray = TryCast(If(in_Raw(env & ".solution"), New JObject()).SelectToken("value"), JArray)
    Dim sol As JObject = If(sols Is Nothing, Nothing, sols.Children(Of JObject)().FirstOrDefault())
    e("environmentUrl") = in_Config.SelectToken("powerAutomate.environments." & env & ".environmentUrl").ToString()
    e("environmentName") = If(org Is Nothing, "", Convert.ToString(org("FriendlyName")))
    e("environmentId") = If(org Is Nothing, "", Convert.ToString(org("EnvironmentId")))
    e("folderPath") = If(org Is Nothing, e.Value(Of String)("environmentUrl"), Convert.ToString(org("FriendlyName")) & " (" & e.Value(Of String)("environmentUrl") & ")")
    e("folderExists") = err = "" AndAlso org IsNot Nothing
    e("releaseExists") = sol IsNot Nothing
    e("solutionId") = If(sol Is Nothing, "", Convert.ToString(sol("solutionid")))
    e("deployedVersion") = If(sol Is Nothing, "", Convert.ToString(sol("version")))
    e("isManaged") = sol IsNot Nothing AndAlso sol.Value(Of Boolean)("ismanaged")
    e("availableVersions") = New JArray(If(sol Is Nothing, New String() {}, New String() {Convert.ToString(sol("version"))}))
    e("error") = err
    e("status") = If(err <> "", "Not available: " & err, If(sol Is Nothing, "Solution not installed", "Installed: " & Convert.ToString(sol("version")) & If(e.Value(Of Boolean)("isManaged"), " (managed)", " (unmanaged)")))
    envs(env) = e
Next
d("environments") = envs
' Dev environment block and the Dev solution
Dim dev As JObject = CType(envs("Dev"), JObject)
Dim devSol As JObject = TryCast(If(in_Raw("Dev.solution"), New JObject()).SelectToken("value[0]"), JObject)
' Package section of the form
Dim p As New JObject()
p("processName") = If(devSol Is Nothing, "", Convert.ToString(devSol("friendlyname")))
p("packageName") = uniqueName
p("currentVersion") = dev.Value(Of String)("deployedVersion")
p("latestDevVersion") = dev.Value(Of String)("deployedVersion")
p("packageAvailability") = If(devSol Is Nothing, "Solution not found in Dev", If(devSol.Value(Of Boolean)("ismanaged"), "Managed in Dev (cannot be exported)", "Unmanaged solution in Dev; exported as managed for deployment"))
p("devFolder") = dev.Value(Of String)("folderPath")
p("uatFolder") = envs("UAT").Value(Of String)("folderPath")
p("prodFolder") = envs("Prod").Value(Of String)("folderPath")
p("devEnvironment") = dev.Value(Of String)("folderPath")
p("description") = If(devSol Is Nothing, "", Convert.ToString(devSol("description")))
p("devStatus") = dev.Value(Of String)("status")
p("uatStatus") = envs("UAT").Value(Of String)("status")
p("prodStatus") = envs("Prod").Value(Of String)("status")
d("process") = p
d("versions") = dev("availableVersions")
' Versions that can be deployed from the source environment
Dim srcEnv As String = d.Value(Of String)("sourceEnv")
Dim artifacts As JArray = If(TryCast(in_Raw("artifactVersions"), JArray), New JArray())
If srcEnv = "Dev" Then
    d("sourceVersions") = dev("availableVersions")
Else
    ' A managed solution cannot be exported from UAT: UAT -> Prod imports the managed file exported from Dev for that version, and only when that version is the one installed in UAT
    d("sourceVersions") = New JArray(envs(srcEnv)("availableVersions").Values(Of String)().Where(Function(v) artifacts.Values(Of String)().Contains(v)).ToArray())
    If envs(srcEnv).Value(Of Boolean)("releaseExists") AndAlso CType(d("sourceVersions"), JArray).Count = 0 Then warnings.Add("The managed solution file for version " & envs(srcEnv).Value(Of String)("deployedVersion") & " is not in the artifact store; run Dev to UAT for that version first.")
End If
' Overall result shown at the top of the form
If dev.Value(Of String)("error") <> "" Then
    d("status") = "Error"
    d("message") = "Details could not be retrieved from the Dev environment: " & dev.Value(Of String)("error")
ElseIf devSol Is Nothing Then
    d("status") = "NotFound"
    d("message") = "Solution '" & uniqueName & "' (Bot ID " & d.Value(Of String)("botId") & ") was not found in the Dev environment."
Else
    d("status") = "Found"
    d("message") = "Bot ID " & d.Value(Of String)("botId") & ": solution " & uniqueName & " version " & Convert.ToString(devSol("version")) & " in " & dev.Value(Of String)("environmentName") & "."
End If
' Cloud flows in the Dev solution (expected = listed in the mapping, or every flow when the mapping lists none)
Dim flows As New JArray()
Dim expected As List(Of String) = If(TryCast(bot.SelectToken("powerAutomate.flows"), JArray), New JArray()).Values(Of String)().ToList()
Dim found As List(Of JObject) = If(TryCast(in_Raw("Dev.flows"), JArray), New JArray()).Children(Of JObject)().ToList()
For Each f As JObject In found
    Dim row As New JObject()
    row("name") = Convert.ToString(f("name"))
    row("flowId") = Convert.ToString(f("workflowid"))
    row("state") = If(Convert.ToString(f("statecode")) = "1", "On", If(Convert.ToString(f("statecode")) = "2", "Suspended", "Off"))
    row("expected") = expected.Count = 0 OrElse expected.Contains(Convert.ToString(f("name")), StringComparer.OrdinalIgnoreCase)
    flows.Add(row)
Next
' Flows named in the mapping but missing from the solution
For Each n As String In expected.Where(Function(x) Not found.Any(Function(fl) String.Equals(Convert.ToString(fl("name")), x, StringComparison.OrdinalIgnoreCase)))
    warnings.Add("Flow '" & n & "' from the Bot ID mapping is not in solution " & uniqueName & " in Dev.")
Next
' UAT or Prod could not be read
For Each env2 As String In New String() {"UAT", "Prod"}
    If envs(env2).Value(Of String)("error") <> "" Then warnings.Add(env2 & " status could not be read: " & envs(env2).Value(Of String)("error"))
Next
If d.Value(Of String)("processType") = "New" Then warnings.Add("Power Automate solutions carry their own connection references and environment variables; set their values in the target environment (deployment settings). UiPath assets, queues and folder access do not apply.")
d("flows") = flows
d("assets") = New JArray()
d("queues") = New JArray()
d("access") = New JArray()
d("warnings") = warnings
out_Details = d
