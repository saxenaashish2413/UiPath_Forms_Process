'ARG in in_Config JO
'ARG in in_Raw JO
'ARG out out_Details JO
' Power Automate provider: builds the form object from Dataverse responses collected by PA_Fetch_Bot_Configuration.xaml.
' A Power Automate "package" is a Dataverse solution (uniquename + version); flows are solution components (type 29).
' in_Raw keys: bot, processType, deploymentPath, sourceEnv, targetEnv, "<Env>.org" (RetrieveCurrentOrganization),
' "<Env>.solution" (solutions collection), "<Env>.error", "Dev.flows" (workflow records), artifactVersions (managed
' solution files already exported to the artifact store).
Dim inv As System.Globalization.CultureInfo = System.Globalization.CultureInfo.InvariantCulture
Dim bot As Newtonsoft.Json.Linq.JObject = CType(in_Raw("bot"), Newtonsoft.Json.Linq.JObject)
Dim uniqueName As String = bot.SelectToken("powerAutomate.solutionUniqueName").ToString()
Dim Str As Func(Of Newtonsoft.Json.Linq.JToken, String, String) = Function(t, k) If(t Is Nothing OrElse t(k) Is Nothing OrElse t(k).Type = Newtonsoft.Json.Linq.JTokenType.Null, "", t(k).ToString())
Dim d As New Newtonsoft.Json.Linq.JObject()
d("tool") = "Power Automate"
d("botId") = bot.Value(Of String)("botId")
d("processType") = in_Raw.Value(Of String)("processType")
d("deploymentPath") = in_Raw.Value(Of String)("deploymentPath")
d("sourceEnv") = in_Raw.Value(Of String)("sourceEnv")
d("targetEnv") = in_Raw.Value(Of String)("targetEnv")
d("retrievedAtUtc") = DateTime.UtcNow.ToString("o", inv)
Dim warnings As New Newtonsoft.Json.Linq.JArray()
Dim envs As New Newtonsoft.Json.Linq.JObject()
For Each env As String In New String() {"Dev", "UAT", "Prod"}
    Dim e As New Newtonsoft.Json.Linq.JObject()
    Dim err As String = If(in_Raw.Value(Of String)(env & ".error"), "")
    Dim org As Newtonsoft.Json.Linq.JToken = If(in_Raw(env & ".org"), Newtonsoft.Json.Linq.JValue.CreateNull()).SelectToken("Detail")
    Dim sols As Newtonsoft.Json.Linq.JArray = TryCast(If(in_Raw(env & ".solution"), New Newtonsoft.Json.Linq.JObject()).SelectToken("value"), Newtonsoft.Json.Linq.JArray)
    Dim sol As Newtonsoft.Json.Linq.JObject = If(sols Is Nothing, Nothing, sols.Children(Of Newtonsoft.Json.Linq.JObject)().FirstOrDefault())
    e("environmentUrl") = in_Config.SelectToken("powerAutomate.environments." & env & ".environmentUrl").ToString()
    e("environmentName") = If(org Is Nothing, "", Str(org, "FriendlyName"))
    e("environmentId") = If(org Is Nothing, "", Str(org, "EnvironmentId"))
    e("folderPath") = If(org Is Nothing, e.Value(Of String)("environmentUrl"), Str(org, "FriendlyName") & " (" & e.Value(Of String)("environmentUrl") & ")")
    e("folderExists") = err = "" AndAlso org IsNot Nothing
    e("releaseExists") = sol IsNot Nothing
    e("solutionId") = Str(sol, "solutionid")
    e("deployedVersion") = Str(sol, "version")
    e("isManaged") = sol IsNot Nothing AndAlso sol.Value(Of Boolean)("ismanaged")
    e("availableVersions") = New Newtonsoft.Json.Linq.JArray(If(sol Is Nothing, New String() {}, New String() {Str(sol, "version")}))
    e("error") = err
    e("status") = If(err <> "", "Not available: " & err, If(sol Is Nothing, "Solution not installed", "Installed: " & Str(sol, "version") & If(e.Value(Of Boolean)("isManaged"), " (managed)", " (unmanaged)")))
    envs(env) = e
Next
d("environments") = envs
Dim dev As Newtonsoft.Json.Linq.JObject = CType(envs("Dev"), Newtonsoft.Json.Linq.JObject)
Dim devSol As Newtonsoft.Json.Linq.JObject = TryCast(If(in_Raw("Dev.solution"), New Newtonsoft.Json.Linq.JObject()).SelectToken("value[0]"), Newtonsoft.Json.Linq.JObject)
Dim p As New Newtonsoft.Json.Linq.JObject()
p("processName") = Str(devSol, "friendlyname")
p("packageName") = uniqueName
p("currentVersion") = dev.Value(Of String)("deployedVersion")
p("latestDevVersion") = dev.Value(Of String)("deployedVersion")
p("packageAvailability") = If(devSol Is Nothing, "Solution not found in Dev", If(devSol.Value(Of Boolean)("ismanaged"), "Managed in Dev (cannot be exported)", "Unmanaged solution in Dev; exported as managed for deployment"))
p("devFolder") = dev.Value(Of String)("folderPath")
p("uatFolder") = envs("UAT").Value(Of String)("folderPath")
p("prodFolder") = envs("Prod").Value(Of String)("folderPath")
p("devEnvironment") = dev.Value(Of String)("folderPath")
p("description") = Str(devSol, "description")
p("devStatus") = dev.Value(Of String)("status")
p("uatStatus") = envs("UAT").Value(Of String)("status")
p("prodStatus") = envs("Prod").Value(Of String)("status")
d("process") = p
d("versions") = dev("availableVersions")
Dim srcEnv As String = d.Value(Of String)("sourceEnv")
Dim artifacts As Newtonsoft.Json.Linq.JArray = If(TryCast(in_Raw("artifactVersions"), Newtonsoft.Json.Linq.JArray), New Newtonsoft.Json.Linq.JArray())
If srcEnv = "Dev" Then
    d("sourceVersions") = dev("availableVersions")
Else
    ' A managed solution cannot be exported from UAT: UAT -> Prod imports the managed file exported from Dev for that version,
    ' and only when that version is the one installed in UAT.
    d("sourceVersions") = New Newtonsoft.Json.Linq.JArray(envs(srcEnv)("availableVersions").Values(Of String)().Where(Function(v) artifacts.Values(Of String)().Contains(v)).ToArray())
    If envs(srcEnv).Value(Of Boolean)("releaseExists") AndAlso CType(d("sourceVersions"), Newtonsoft.Json.Linq.JArray).Count = 0 Then warnings.Add("The managed solution file for version " & envs(srcEnv).Value(Of String)("deployedVersion") & " is not in the artifact store; run Dev to UAT for that version first.")
End If
If dev.Value(Of String)("error") <> "" Then
    d("status") = "Error"
    d("message") = "Details could not be retrieved from the Dev environment: " & dev.Value(Of String)("error")
ElseIf devSol Is Nothing Then
    d("status") = "NotFound"
    d("message") = "Solution '" & uniqueName & "' (Bot ID " & d.Value(Of String)("botId") & ") was not found in the Dev environment."
Else
    d("status") = "Found"
    d("message") = "Bot ID " & d.Value(Of String)("botId") & ": solution " & uniqueName & " version " & Str(devSol, "version") & " in " & dev.Value(Of String)("environmentName") & "."
End If
Dim flows As New Newtonsoft.Json.Linq.JArray()
Dim expected As List(Of String) = If(TryCast(bot.SelectToken("powerAutomate.flows"), Newtonsoft.Json.Linq.JArray), New Newtonsoft.Json.Linq.JArray()).Values(Of String)().ToList()
Dim found As List(Of Newtonsoft.Json.Linq.JObject) = If(TryCast(in_Raw("Dev.flows"), Newtonsoft.Json.Linq.JArray), New Newtonsoft.Json.Linq.JArray()).Children(Of Newtonsoft.Json.Linq.JObject)().ToList()
For Each f As Newtonsoft.Json.Linq.JObject In found
    Dim row As New Newtonsoft.Json.Linq.JObject()
    row("name") = Str(f, "name")
    row("flowId") = Str(f, "workflowid")
    row("state") = If(Str(f, "statecode") = "1", "On", If(Str(f, "statecode") = "2", "Suspended", "Off"))
    row("expected") = expected.Count = 0 OrElse expected.Contains(Str(f, "name"), StringComparer.OrdinalIgnoreCase)
    flows.Add(row)
Next
For Each n As String In expected.Where(Function(x) Not found.Any(Function(f) String.Equals(Str(f, "name"), x, StringComparison.OrdinalIgnoreCase)))
    warnings.Add("Flow '" & n & "' from the Bot ID mapping is not in solution " & uniqueName & " in Dev.")
Next
For Each env As String In New String() {"UAT", "Prod"}
    If envs(env).Value(Of String)("error") <> "" Then warnings.Add(env & " status could not be read: " & envs(env).Value(Of String)("error"))
Next
If d.Value(Of String)("processType") = "New" Then warnings.Add("Power Automate solutions carry their own connection references and environment variables; set their values in the target environment (deployment settings). UiPath assets, queues and folder access do not apply.")
d("flows") = flows
d("assets") = New Newtonsoft.Json.Linq.JArray()
d("queues") = New Newtonsoft.Json.Linq.JArray()
d("access") = New Newtonsoft.Json.Linq.JArray()
d("warnings") = warnings
out_Details = d
