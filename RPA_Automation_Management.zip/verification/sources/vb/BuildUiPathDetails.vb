'ARG in in_Config JO
'ARG in in_Raw JO
'ARG out out_Details JO
' Turns the raw Orchestrator responses collected by Fetch_Bot_Configuration.xaml into the object the form shows.
' in_Raw keys: bot, processType, deploymentPath, sourceEnv, targetEnv, "<Env>.folder", "<Env>.release", "<Env>.versions",
' "<Env>.error", devAssets, targetAssets, devQueues, targetQueues, devUsers, targetUsers.
' Values only come from API responses; when a call failed the field says so (nothing is invented).
' Secret values are never present: assets are read without credential fields, and Credential/Secret assets and
' names matching security.sensitiveAssetNamePatterns are shown with security.maskedValueText.
Dim inv As System.Globalization.CultureInfo = System.Globalization.CultureInfo.InvariantCulture
Dim bot As Newtonsoft.Json.Linq.JObject = CType(in_Raw("bot"), Newtonsoft.Json.Linq.JObject)
Dim ui As Newtonsoft.Json.Linq.JToken = bot("uipath")
Dim processType As String = in_Raw.Value(Of String)("processType")
Dim targetEnv As String = in_Raw.Value(Of String)("targetEnv")
Dim mask As String = in_Config.SelectToken("security.maskedValueText").ToString()
Dim patterns As String() = If(in_Config.SelectToken("security.sensitiveAssetNamePatterns"), New Newtonsoft.Json.Linq.JArray()).Values(Of String)().ToArray()
Dim Arr As Func(Of String, Newtonsoft.Json.Linq.JArray) = Function(k) If(TryCast(in_Raw(k), Newtonsoft.Json.Linq.JArray), New Newtonsoft.Json.Linq.JArray())
Dim Obj As Func(Of String, Newtonsoft.Json.Linq.JObject) = Function(k) TryCast(in_Raw(k), Newtonsoft.Json.Linq.JObject)
Dim Str As Func(Of Newtonsoft.Json.Linq.JToken, String, String) = Function(t, k) If(t Is Nothing OrElse t(k) Is Nothing OrElse t(k).Type = Newtonsoft.Json.Linq.JTokenType.Null, "", t(k).ToString())
Dim VKey As Func(Of String, String) = Function(v) String.Join(".", v.Split("."c).Select(Function(seg) If(seg.All(AddressOf Char.IsDigit) AndAlso seg <> "", seg.PadLeft(10, "0"c), seg)))
Dim d As New Newtonsoft.Json.Linq.JObject()
d("tool") = "UiPath"
d("botId") = bot.Value(Of String)("botId")
d("processType") = processType
d("deploymentPath") = in_Raw.Value(Of String)("deploymentPath")
d("sourceEnv") = in_Raw.Value(Of String)("sourceEnv")
d("targetEnv") = targetEnv
d("retrievedAtUtc") = DateTime.UtcNow.ToString("o", inv)
Dim warnings As New Newtonsoft.Json.Linq.JArray()
Dim envs As New Newtonsoft.Json.Linq.JObject()
For Each env As String In New String() {"Dev", "UAT", "Prod"}
    Dim e As New Newtonsoft.Json.Linq.JObject()
    Dim folder As Newtonsoft.Json.Linq.JObject = Obj(env & ".folder")
    Dim release As Newtonsoft.Json.Linq.JObject = Obj(env & ".release")
    Dim err As String = If(in_Raw.Value(Of String)(env & ".error"), "")
    e("orchestratorUrl") = in_Config.SelectToken("uipath.environments." & env & ".orchestratorUrl").ToString()
    e("folderPath") = ui.SelectToken("folders." & env).ToString()
    e("folderExists") = folder IsNot Nothing
    e("folderId") = If(folder Is Nothing, 0L, folder.Value(Of Long)("Id"))
    e("releaseExists") = release IsNot Nothing
    e("releaseId") = If(release Is Nothing, 0L, release.Value(Of Long)("Id"))
    e("deployedVersion") = Str(release, "ProcessVersion")
    Dim vers As Newtonsoft.Json.Linq.JArray = Arr(env & ".versions")
    e("availableVersions") = New Newtonsoft.Json.Linq.JArray(vers.Children(Of Newtonsoft.Json.Linq.JObject)().Select(Function(v) v.Value(Of String)("Version")).Where(Function(v) Not String.IsNullOrEmpty(v)).Distinct().OrderByDescending(Function(v) VKey(v), StringComparer.Ordinal).ToArray())
    e("error") = err
    Dim status As String
    If err <> "" Then
        status = "Not available: " & err
    ElseIf folder Is Nothing Then
        status = "Folder " & e.Value(Of String)("folderPath") & " not found"
    ElseIf release Is Nothing Then
        status = If(CType(e("availableVersions"), Newtonsoft.Json.Linq.JArray).Count > 0, "Package in feed, process not deployed", "Not deployed")
    Else
        status = "Deployed: " & release.Value(Of String)("ProcessVersion")
    End If
    e("status") = status
    envs(env) = e
Next
d("environments") = envs
Dim dev As Newtonsoft.Json.Linq.JObject = CType(envs("Dev"), Newtonsoft.Json.Linq.JObject)
Dim devRelease As Newtonsoft.Json.Linq.JObject = Obj("Dev.release")
Dim devVersions As Newtonsoft.Json.Linq.JArray = CType(dev("availableVersions"), Newtonsoft.Json.Linq.JArray)
Dim p As New Newtonsoft.Json.Linq.JObject()
p("processName") = If(devRelease Is Nothing, ui.Value(Of String)("processName"), Str(devRelease, "Name"))
p("packageName") = If(devRelease Is Nothing, ui.Value(Of String)("packageId"), Str(devRelease, "ProcessKey"))
p("currentVersion") = dev.Value(Of String)("deployedVersion")
p("latestDevVersion") = If(devVersions.Count > 0, devVersions(0).ToString(), "")
p("packageAvailability") = If(devVersions.Count > 0, devVersions.Count.ToString(inv) & " version(s) in the Dev feed", "No package versions found in the Dev feed")
p("devFolder") = dev.Value(Of String)("folderPath")
p("uatFolder") = envs("UAT").Value(Of String)("folderPath")
p("prodFolder") = envs("Prod").Value(Of String)("folderPath")
p("devEnvironment") = "Dev (" & dev.Value(Of String)("orchestratorUrl") & ")"
p("description") = Str(devRelease, "Description")
p("devStatus") = dev.Value(Of String)("status")
p("uatStatus") = envs("UAT").Value(Of String)("status")
p("prodStatus") = envs("Prod").Value(Of String)("status")
d("process") = p
d("versions") = devVersions
Dim srcVersions As Newtonsoft.Json.Linq.JArray = CType(envs(d.Value(Of String)("sourceEnv"))("availableVersions"), Newtonsoft.Json.Linq.JArray)
d("sourceVersions") = srcVersions
' ---- status
If dev.Value(Of String)("error") <> "" Then
    d("status") = "Error"
    d("message") = "Details could not be retrieved from Dev: " & dev.Value(Of String)("error")
ElseIf Not dev.Value(Of Boolean)("folderExists") Then
    d("status") = "NotFound"
    d("message") = "Bot ID " & d.Value(Of String)("botId") & " is mapped to Dev folder '" & dev.Value(Of String)("folderPath") & "', which does not exist or is not visible to the API account."
ElseIf devRelease Is Nothing Then
    d("status") = "NotFound"
    d("message") = "Process '" & ui.Value(Of String)("processName") & "' was not found in Dev folder '" & dev.Value(Of String)("folderPath") & "'."
ElseIf devVersions.Count = 0 Then
    d("status") = "NotFound"
    d("message") = "Package '" & p.Value(Of String)("packageName") & "' has no versions in the Dev feed."
Else
    d("status") = "Found"
    d("message") = "Bot ID " & d.Value(Of String)("botId") & ": " & p.Value(Of String)("processName") & " (package " & p.Value(Of String)("packageName") & ", Dev version " & p.Value(Of String)("currentVersion") & ")."
End If
For Each env As String In New String() {"UAT", "Prod"}
    If envs(env).Value(Of String)("error") <> "" Then warnings.Add(env & " status could not be read: " & envs(env).Value(Of String)("error"))
Next
' ---- configuration (New only)
Dim assets As New Newtonsoft.Json.Linq.JArray()
Dim queues As New Newtonsoft.Json.Linq.JArray()
Dim access As New Newtonsoft.Json.Linq.JArray()
If processType = "New" AndAlso d.Value(Of String)("status") = "Found" Then
    Dim mapAssets As List(Of Newtonsoft.Json.Linq.JObject) = If(TryCast(ui("assets"), Newtonsoft.Json.Linq.JArray), New Newtonsoft.Json.Linq.JArray()).Children(Of Newtonsoft.Json.Linq.JObject)().ToList()
    Dim tAssets As List(Of Newtonsoft.Json.Linq.JObject) = Arr("targetAssets").Children(Of Newtonsoft.Json.Linq.JObject)().ToList()
    Dim IsSecret As Func(Of String, String, Boolean) = Function(n, t) t = "Credential" OrElse t = "Secret" OrElse patterns.Any(Function(x) n.IndexOf(x, StringComparison.OrdinalIgnoreCase) >= 0)
    Dim ValueOf As Func(Of Newtonsoft.Json.Linq.JObject, String) = Function(a)
        Select Case a.Value(Of String)("ValueType")
            Case "Integer" : Return Str(a, "IntValue")
            Case "Bool" : Return Str(a, "BoolValue").ToLowerInvariant()
            Case "Text" : Return Str(a, "StringValue")
            Case Else : Return ""
        End Select
    End Function
    Dim targetFolderOk As Boolean = envs(targetEnv).Value(Of Boolean)("folderExists")
    Dim targetReadable As Boolean = envs(targetEnv).Value(Of String)("error") = ""
    Dim names As New List(Of String)
    names.AddRange(Arr("devAssets").Children(Of Newtonsoft.Json.Linq.JObject)().Select(Function(a) a.Value(Of String)("Name")))
    names.AddRange(mapAssets.Select(Function(a) a.Value(Of String)("name")).Where(Function(n) Not names.Contains(n, StringComparer.OrdinalIgnoreCase)))
    For Each n As String In names
        Dim src As Newtonsoft.Json.Linq.JObject = Arr("devAssets").Children(Of Newtonsoft.Json.Linq.JObject)().FirstOrDefault(Function(a) String.Equals(a.Value(Of String)("Name"), n, StringComparison.OrdinalIgnoreCase))
        Dim m As Newtonsoft.Json.Linq.JObject = mapAssets.FirstOrDefault(Function(a) String.Equals(a.Value(Of String)("name"), n, StringComparison.OrdinalIgnoreCase))
        Dim tgt As Newtonsoft.Json.Linq.JObject = tAssets.FirstOrDefault(Function(a) String.Equals(a.Value(Of String)("Name"), n, StringComparison.OrdinalIgnoreCase))
        Dim typ As String = If(src IsNot Nothing, Str(src, "ValueType"), If(tgt IsNot Nothing, Str(tgt, "ValueType"), "Unknown"))
        Dim secret As Boolean = IsSecret(n, typ)
        Dim row As New Newtonsoft.Json.Linq.JObject()
        row("name") = n
        row("type") = typ
        row("isSecret") = secret
        row("devValue") = If(src Is Nothing, "(not in Dev folder)", If(secret, mask, ValueOf(src)))
        row("description") = Str(src, "Description")
        row("scope") = If(src Is Nothing, "", Str(src, "ValueScope") & " - " & dev.Value(Of String)("folderPath"))
        row("required") = m IsNot Nothing AndAlso m.Value(Of Boolean?)("required").GetValueOrDefault(True)
        row("hasSecretSource") = m IsNot Nothing AndAlso m.SelectToken("secretSource." & targetEnv) IsNot Nothing
        row("targetExists") = tgt IsNot Nothing
        row("targetValue") = If(tgt Is Nothing, "", If(secret, mask, ValueOf(tgt)))
        row("targetStatus") = If(Not targetReadable, "Unknown (target not readable)", If(Not targetFolderOk, "Target folder missing", If(tgt Is Nothing, "Missing in " & targetEnv, If(Str(tgt, "ValueType") <> typ, "Exists with different type " & Str(tgt, "ValueType"), "Exists in " & targetEnv))))
        row("action") = If(tgt Is Nothing, If(CBool(row("required")), "Create", "Skip"), "Keep")
        row("proposedValue") = If(secret OrElse src Is Nothing, "", ValueOf(src))
        row("savedStatus") = ""
        If src IsNot Nothing AndAlso Str(src, "ValueScope") = "PerRobot" Then warnings.Add("Asset " & n & " has per-robot values in Dev; only the global value can be migrated.")
        assets.Add(row)
    Next
    Dim mapQueues As List(Of Newtonsoft.Json.Linq.JObject) = If(TryCast(ui("queues"), Newtonsoft.Json.Linq.JArray), New Newtonsoft.Json.Linq.JArray()).Children(Of Newtonsoft.Json.Linq.JObject)().ToList()
    Dim tQueues As List(Of Newtonsoft.Json.Linq.JObject) = Arr("targetQueues").Children(Of Newtonsoft.Json.Linq.JObject)().ToList()
    Dim qnames As New List(Of String)
    qnames.AddRange(Arr("devQueues").Children(Of Newtonsoft.Json.Linq.JObject)().Select(Function(q) q.Value(Of String)("Name")))
    qnames.AddRange(mapQueues.Select(Function(q) q.Value(Of String)("name")).Where(Function(n) Not qnames.Contains(n, StringComparer.OrdinalIgnoreCase)))
    For Each n As String In qnames
        Dim src As Newtonsoft.Json.Linq.JObject = Arr("devQueues").Children(Of Newtonsoft.Json.Linq.JObject)().FirstOrDefault(Function(q) String.Equals(q.Value(Of String)("Name"), n, StringComparison.OrdinalIgnoreCase))
        Dim m As Newtonsoft.Json.Linq.JObject = mapQueues.FirstOrDefault(Function(q) String.Equals(q.Value(Of String)("name"), n, StringComparison.OrdinalIgnoreCase))
        Dim tgt As Newtonsoft.Json.Linq.JObject = tQueues.FirstOrDefault(Function(q) String.Equals(q.Value(Of String)("Name"), n, StringComparison.OrdinalIgnoreCase))
        Dim row As New Newtonsoft.Json.Linq.JObject()
        row("name") = n
        row("folder") = dev.Value(Of String)("folderPath")
        row("description") = Str(src, "Description")
        row("maxRetries") = If(src Is Nothing, "0", Str(src, "MaxNumberOfRetries"))
        row("autoRetry") = If(src Is Nothing, "false", Str(src, "AcceptAutomaticallyRetry").ToLowerInvariant())
        row("uniqueReference") = If(src Is Nothing, "false", Str(src, "EnforceUniqueReference").ToLowerInvariant())
        row("required") = m IsNot Nothing AndAlso m.Value(Of Boolean?)("required").GetValueOrDefault(True)
        row("targetExists") = tgt IsNot Nothing
        Dim differs As Boolean = tgt IsNot Nothing AndAlso src IsNot Nothing AndAlso (Str(tgt, "MaxNumberOfRetries") <> Str(src, "MaxNumberOfRetries") OrElse Str(tgt, "EnforceUniqueReference") <> Str(src, "EnforceUniqueReference") OrElse Str(tgt, "AcceptAutomaticallyRetry") <> Str(src, "AcceptAutomaticallyRetry"))
        row("targetStatus") = If(Not targetReadable, "Unknown (target not readable)", If(Not targetFolderOk, "Target folder missing", If(tgt Is Nothing, "Missing in " & targetEnv, If(differs, "Exists in " & targetEnv & " with different settings", "Exists in " & targetEnv))))
        row("action") = If(tgt Is Nothing, If(CBool(row("required")) OrElse src IsNot Nothing, "Create", "Skip"), "Keep")
        row("proposedName") = n
        row("savedStatus") = ""
        If src Is Nothing Then warnings.Add("Queue " & n & " is in the Bot ID mapping but not in the Dev folder; its settings use defaults.")
        queues.Add(row)
    Next
    Dim roleMap As Newtonsoft.Json.Linq.JObject = CType(in_Config("roleMappings"), Newtonsoft.Json.Linq.JObject)
    Dim RolesOf As Func(Of Newtonsoft.Json.Linq.JObject, List(Of String)) = Function(u) If(TryCast(u("Roles"), Newtonsoft.Json.Linq.JArray), New Newtonsoft.Json.Linq.JArray()).Children(Of Newtonsoft.Json.Linq.JObject)().Select(Function(r) r.Value(Of String)("Name")).ToList()
    Dim NameOf2 As Func(Of Newtonsoft.Json.Linq.JObject, String) = Function(u) Str(u("UserEntity"), "UserName")
    Dim tUsers As List(Of Newtonsoft.Json.Linq.JObject) = Arr("targetUsers").Children(Of Newtonsoft.Json.Linq.JObject)().ToList()
    For Each m As Newtonsoft.Json.Linq.JObject In If(TryCast(ui("access"), Newtonsoft.Json.Linq.JArray), New Newtonsoft.Json.Linq.JArray()).Children(Of Newtonsoft.Json.Linq.JObject)()
        Dim n As String = m.Value(Of String)("name")
        Dim level As String = m.Value(Of String)("accessLevel")
        Dim need As List(Of String) = If(TryCast(roleMap(level), Newtonsoft.Json.Linq.JArray), New Newtonsoft.Json.Linq.JArray()).Values(Of String)().ToList()
        Dim devU As Newtonsoft.Json.Linq.JObject = Arr("devUsers").Children(Of Newtonsoft.Json.Linq.JObject)().FirstOrDefault(Function(u) String.Equals(NameOf2(u), n, StringComparison.OrdinalIgnoreCase))
        Dim tU As Newtonsoft.Json.Linq.JObject = tUsers.FirstOrDefault(Function(u) String.Equals(NameOf2(u), n, StringComparison.OrdinalIgnoreCase))
        Dim have As List(Of String) = If(tU Is Nothing, New List(Of String), RolesOf(tU))
        Dim missing As List(Of String) = need.Where(Function(r) Not have.Contains(r, StringComparer.OrdinalIgnoreCase)).ToList()
        Dim row As New Newtonsoft.Json.Linq.JObject()
        row("name") = n
        row("type") = If(m.Value(Of String)("type"), "DirectoryUser")
        row("source") = "Bot ID mapping"
        row("folder") = envs(targetEnv).Value(Of String)("folderPath")
        row("devRoles") = If(devU Is Nothing, "", String.Join(", ", RolesOf(devU)))
        row("accessLevel") = level
        row("requiredRoles") = String.Join(", ", need)
        row("targetRoles") = String.Join(", ", have)
        row("targetStatus") = If(Not targetReadable, "Unknown (target not readable)", If(Not targetFolderOk, "Target folder missing", If(tU Is Nothing, "No access in " & targetEnv, If(missing.Count = 0, "Has required access", "Missing roles: " & String.Join(", ", missing)))))
        row("action") = If(missing.Count = 0 AndAlso tU IsNot Nothing, "No change", "Grant")
        row("proposedChange") = If(missing.Count = 0 AndAlso tU IsNot Nothing, "", "Add " & String.Join(", ", missing) & " on " & envs(targetEnv).Value(Of String)("folderPath"))
        row("savedStatus") = ""
        access.Add(row)
    Next
    For Each u As Newtonsoft.Json.Linq.JObject In Arr("devUsers").Children(Of Newtonsoft.Json.Linq.JObject)()
        Dim n As String = NameOf2(u)
        If access.Children(Of Newtonsoft.Json.Linq.JObject)().Any(Function(r) String.Equals(r.Value(Of String)("name"), n, StringComparison.OrdinalIgnoreCase)) Then Continue For
        Dim tU As Newtonsoft.Json.Linq.JObject = tUsers.FirstOrDefault(Function(x) String.Equals(NameOf2(x), n, StringComparison.OrdinalIgnoreCase))
        Dim row As New Newtonsoft.Json.Linq.JObject()
        row("name") = n
        row("type") = Str(u("UserEntity"), "Type")
        row("source") = "Dev folder (information)"
        row("folder") = envs(targetEnv).Value(Of String)("folderPath")
        row("devRoles") = String.Join(", ", RolesOf(u))
        row("accessLevel") = ""
        row("requiredRoles") = ""
        row("targetRoles") = If(tU Is Nothing, "", String.Join(", ", RolesOf(tU)))
        row("targetStatus") = If(tU Is Nothing, "No access in " & targetEnv, "Has access in " & targetEnv)
        row("action") = "No change"
        row("proposedChange") = ""
        row("savedStatus") = ""
        access.Add(row)
    Next
End If
d("assets") = assets
d("queues") = queues
d("access") = access
d("flows") = New Newtonsoft.Json.Linq.JArray()
d("warnings") = warnings
out_Details = d
