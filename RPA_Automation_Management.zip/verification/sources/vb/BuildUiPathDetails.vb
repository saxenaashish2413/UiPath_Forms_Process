'ARG in in_Config JO
'ARG in in_Raw JO
'ARG out out_Details JO
' Turns the raw Orchestrator responses collected by Fetch_Bot_Configuration.xaml into the object the form shows. in_Raw keys: bot, processType, deploymentPath, sourceEnv, targetEnv, "<Env>.folder", "<Env>.release", "<Env>.versions", "<Env>.error", devAssets, targetAssets, devQueues, targetQueues, devUsers, targetUsers. Values only come from API responses; when a call failed the field says so (nothing is invented). Secret values are never present: assets are read without credential fields, and Credential/Secret assets and names matching security.sensitiveAssetNamePatterns are shown with security.maskedValueText.
' The bot entry (from the mapping or found in Dev) and the request choices
Dim bot As JObject = CType(in_Raw("bot"), JObject)
Dim ui As JToken = bot("uipath")
Dim processType As String = in_Raw.Value(Of String)("processType")
Dim targetEnv As String = in_Raw.Value(Of String)("targetEnv")
' Masking text and the asset name patterns that count as sensitive
Dim mask As String = in_Config.SelectToken("security.maskedValueText").ToString()
Dim patterns As String() = If(in_Config.SelectToken("security.sensitiveAssetNamePatterns"), New JArray()).Values(Of String)().ToArray()
' Details header
Dim d As New JObject()
d("tool") = "UiPath"
d("botId") = bot.Value(Of String)("botId")
d("processType") = processType
d("deploymentPath") = in_Raw.Value(Of String)("deploymentPath")
d("sourceEnv") = in_Raw.Value(Of String)("sourceEnv")
d("targetEnv") = targetEnv
d("retrievedAtUtc") = DateTime.UtcNow.ToString("o", System.Globalization.CultureInfo.InvariantCulture)
Dim warnings As New JArray()
' One block per environment: folder, process (release), package versions in the feed and a status text
Dim envs As New JObject()
For Each env As String In New String() {"Dev", "UAT", "Prod"}
    Dim e As New JObject()
    ' Folder and process records read from this environment (Nothing when not found)
    Dim folder As JObject = TryCast(in_Raw(env & ".folder"), JObject)
    Dim release As JObject = TryCast(in_Raw(env & ".release"), JObject)
    Dim err As String = If(in_Raw.Value(Of String)(env & ".error"), "")
    e("orchestratorUrl") = in_Config.SelectToken("uipath.environments." & env & ".orchestratorUrl").ToString()
    e("folderPath") = ui.SelectToken("folders." & env).ToString()
    e("folderExists") = folder IsNot Nothing
    e("folderId") = If(folder Is Nothing, 0L, folder.Value(Of Long)("Id"))
    e("releaseExists") = release IsNot Nothing
    e("releaseId") = If(release Is Nothing, 0L, release.Value(Of Long)("Id"))
    e("deployedVersion") = If(release Is Nothing, "", Convert.ToString(release("ProcessVersion")))
    ' Package versions in the feed, newest first (numbers padded so 1.10 sorts after 1.9)
    Dim vers As JArray = If(TryCast(in_Raw(env & ".versions"), JArray), New JArray())
    e("availableVersions") = New JArray(vers.Children(Of JObject)().Select(Function(v) v.Value(Of String)("Version")).Where(Function(v) Not String.IsNullOrEmpty(v)).Distinct().OrderByDescending(Function(v) String.Join(".", v.Split("."c).Select(Function(seg) If(System.Text.RegularExpressions.Regex.IsMatch(seg, "^[0-9]+$"), seg.PadLeft(10, "0"c), seg))), StringComparer.Ordinal).ToArray())
    e("error") = err
    ' Status text shown on the form for this environment
    Dim status As String
    If err <> "" Then
        status = "Not available: " & err
    ElseIf folder Is Nothing Then
        status = "Folder " & e.Value(Of String)("folderPath") & " not found"
    ElseIf release Is Nothing Then
        status = If(CType(e("availableVersions"), JArray).Count > 0, "Package in feed, process not deployed", "Not deployed")
    Else
        status = "Deployed: " & release.Value(Of String)("ProcessVersion")
    End If
    e("status") = status
    envs(env) = e
Next
d("environments") = envs
' Dev block, the Dev process and the Dev feed versions
Dim dev As JObject = CType(envs("Dev"), JObject)
Dim devRelease As JObject = TryCast(in_Raw("Dev.release"), JObject)
Dim devReleaseObj As JObject = If(devRelease, New JObject())
Dim devVersions As JArray = CType(dev("availableVersions"), JArray)
' Process and package section of the form
Dim p As New JObject()
p("processName") = If(devRelease Is Nothing, ui.Value(Of String)("processName"), Convert.ToString(devReleaseObj("Name")))
p("packageName") = If(devRelease Is Nothing, ui.Value(Of String)("packageId"), Convert.ToString(devReleaseObj("ProcessKey")))
p("currentVersion") = dev.Value(Of String)("deployedVersion")
p("latestDevVersion") = If(devVersions.Count > 0, devVersions(0).ToString(), "")
p("packageAvailability") = If(devVersions.Count > 0, devVersions.Count.ToString(System.Globalization.CultureInfo.InvariantCulture) & " version(s) in the Dev feed", "No package versions found in the Dev feed")
p("devFolder") = dev.Value(Of String)("folderPath")
p("uatFolder") = envs("UAT").Value(Of String)("folderPath")
p("prodFolder") = envs("Prod").Value(Of String)("folderPath")
p("devEnvironment") = "Dev (" & dev.Value(Of String)("orchestratorUrl") & ")"
p("description") = Convert.ToString(devReleaseObj("Description"))
p("devStatus") = dev.Value(Of String)("status")
p("uatStatus") = envs("UAT").Value(Of String)("status")
p("prodStatus") = envs("Prod").Value(Of String)("status")
d("process") = p
d("versions") = devVersions
' Versions that can be deployed from the source environment of the path
d("sourceVersions") = CType(envs(d.Value(Of String)("sourceEnv"))("availableVersions"), JArray)
' Overall result shown at the top of the form
If dev.Value(Of String)("error") <> "" Then
    d("status") = "Error"
    d("message") = "Details could not be retrieved from Dev: " & dev.Value(Of String)("error")
ElseIf Not dev.Value(Of Boolean)("folderExists") Then
    d("status") = "NotFound"
    d("message") = "Bot ID " & d.Value(Of String)("botId") & " is mapped to Dev folder '" & dev.Value(Of String)("folderPath") & "', which does not exist or is not visible to the API account."
ElseIf devRelease Is Nothing Then
    d("status") = "NotFound"
    d("message") = "Process '" & ui.Value(Of String)("processName") & "' was not found in Dev folder '" & dev.Value(Of String)("folderPath") & "'."
ElseIf devVersions.Count = 0 Then
    d("status") = "NotFound"
    d("message") = "Package '" & p.Value(Of String)("packageName") & "' has no versions in the Dev feed."
Else
    d("status") = "Found"
    d("message") = "Bot ID " & d.Value(Of String)("botId") & ": " & p.Value(Of String)("processName") & " (package " & p.Value(Of String)("packageName") & ", Dev version " & p.Value(Of String)("currentVersion") & ")."
End If
' Warn when UAT or Prod could not be read
For Each env2 As String In New String() {"UAT", "Prod"}
    If envs(env2).Value(Of String)("error") <> "" Then warnings.Add(env2 & " status could not be read: " & envs(env2).Value(Of String)("error"))
Next
' Configuration grid rows (filled only for New requests whose details were found)
Dim assets As New JArray()
Dim queues As New JArray()
Dim access As New JArray()
If processType = "New" AndAlso d.Value(Of String)("status") = "Found" Then
    ' Assets listed in the mapping, and assets read from the target folder
    Dim mapAssets As List(Of JObject) = If(TryCast(ui("assets"), JArray), New JArray()).Children(Of JObject)().ToList()
    Dim tAssets As List(Of JObject) = If(TryCast(in_Raw("targetAssets"), JArray), New JArray()).Children(Of JObject)().ToList()
    Dim devAssets As List(Of JObject) = If(TryCast(in_Raw("devAssets"), JArray), New JArray()).Children(Of JObject)().ToList()
    ' Can the target be trusted for existence checks?
    Dim targetFolderOk As Boolean = envs(targetEnv).Value(Of Boolean)("folderExists")
    Dim targetReadable As Boolean = envs(targetEnv).Value(Of String)("error") = ""
    ' Asset names: everything in the Dev folder, plus mapped assets that are not in Dev
    Dim names As List(Of String) = devAssets.Select(Function(a) a.Value(Of String)("Name")).ToList()
    names = names.Concat(mapAssets.Select(Function(a) a.Value(Of String)("name")).Where(Function(x) Not names.Contains(x, StringComparer.OrdinalIgnoreCase)).Distinct(StringComparer.OrdinalIgnoreCase)).ToList()
    ' One grid row per asset
    For Each assetName As String In names
        ' The asset in Dev, in the mapping and in the target (Nothing when absent)
        Dim src As JObject = devAssets.FirstOrDefault(Function(a) String.Equals(a.Value(Of String)("Name"), assetName, StringComparison.OrdinalIgnoreCase))
        Dim mapEntry As JObject = mapAssets.FirstOrDefault(Function(a) String.Equals(a.Value(Of String)("name"), assetName, StringComparison.OrdinalIgnoreCase))
        Dim tgt As JObject = tAssets.FirstOrDefault(Function(a) String.Equals(a.Value(Of String)("Name"), assetName, StringComparison.OrdinalIgnoreCase))
        Dim srcObj As JObject = If(src, New JObject())
        Dim tgtObj As JObject = If(tgt, New JObject())
        Dim typ As String = If(src IsNot Nothing, Convert.ToString(srcObj("ValueType")), If(tgt IsNot Nothing, Convert.ToString(tgtObj("ValueType")), "Unknown"))
        ' Credential and Secret assets, and names matching the sensitive patterns, are never shown
        Dim secret As Boolean = typ = "Credential" OrElse typ = "Secret" OrElse patterns.Any(Function(x) assetName.IndexOf(x, StringComparison.OrdinalIgnoreCase) >= 0)
        ' Plain values of the Dev and target asset, by value type
        Dim devVal As String = If(srcObj.Value(Of String)("ValueType") = "Integer", Convert.ToString(srcObj("IntValue")), If(srcObj.Value(Of String)("ValueType") = "Bool", Convert.ToString(srcObj("BoolValue")).ToLowerInvariant(), If(srcObj.Value(Of String)("ValueType") = "Text", Convert.ToString(srcObj("StringValue")), "")))
        Dim tgtVal As String = If(tgtObj.Value(Of String)("ValueType") = "Integer", Convert.ToString(tgtObj("IntValue")), If(tgtObj.Value(Of String)("ValueType") = "Bool", Convert.ToString(tgtObj("BoolValue")).ToLowerInvariant(), If(tgtObj.Value(Of String)("ValueType") = "Text", Convert.ToString(tgtObj("StringValue")), "")))
        Dim row As New JObject()
        row("name") = assetName
        row("type") = typ
        row("isSecret") = secret
        row("devValue") = If(src Is Nothing, "(not in Dev folder)", If(secret, mask, devVal))
        row("description") = Convert.ToString(srcObj("Description"))
        row("scope") = If(src Is Nothing, "", Convert.ToString(srcObj("ValueScope")) & " - " & dev.Value(Of String)("folderPath"))
        row("required") = mapEntry IsNot Nothing AndAlso mapEntry.Value(Of Boolean?)("required").GetValueOrDefault(True)
        row("hasSecretSource") = mapEntry IsNot Nothing AndAlso mapEntry.SelectToken("secretSource." & targetEnv) IsNot Nothing
        row("targetExists") = tgt IsNot Nothing
        row("targetValue") = If(tgt Is Nothing, "", If(secret, mask, tgtVal))
        row("targetStatus") = If(Not targetReadable, "Unknown (target not readable)", If(Not targetFolderOk, "Target folder missing", If(tgt Is Nothing, "Missing in " & targetEnv, If(Convert.ToString(tgtObj("ValueType")) <> typ, "Exists with different type " & Convert.ToString(tgtObj("ValueType")), "Exists in " & targetEnv))))
        ' Proposed action: create what is required and missing, keep what exists
        row("action") = If(tgt Is Nothing, If(CBool(row("required")), "Create", "Skip"), "Keep")
        row("proposedValue") = If(secret OrElse src Is Nothing, "", devVal)
        row("savedStatus") = ""
        ' Per-robot values cannot be migrated
        If src IsNot Nothing AndAlso Convert.ToString(srcObj("ValueScope")) = "PerRobot" Then warnings.Add("Asset " & assetName & " has per-robot values in Dev; only the global value can be migrated.")
        assets.Add(row)
    Next
    ' Queues listed in the mapping, read from Dev and read from the target folder
    Dim mapQueues As List(Of JObject) = If(TryCast(ui("queues"), JArray), New JArray()).Children(Of JObject)().ToList()
    Dim tQueues As List(Of JObject) = If(TryCast(in_Raw("targetQueues"), JArray), New JArray()).Children(Of JObject)().ToList()
    Dim devQueues As List(Of JObject) = If(TryCast(in_Raw("devQueues"), JArray), New JArray()).Children(Of JObject)().ToList()
    ' Queue names: everything in the Dev folder, plus mapped queues that are not in Dev
    Dim qnames As List(Of String) = devQueues.Select(Function(q) q.Value(Of String)("Name")).ToList()
    qnames = qnames.Concat(mapQueues.Select(Function(q) q.Value(Of String)("name")).Where(Function(x) Not qnames.Contains(x, StringComparer.OrdinalIgnoreCase)).Distinct(StringComparer.OrdinalIgnoreCase)).ToList()
    ' One grid row per queue
    For Each queueName As String In qnames
        Dim src As JObject = devQueues.FirstOrDefault(Function(q) String.Equals(q.Value(Of String)("Name"), queueName, StringComparison.OrdinalIgnoreCase))
        Dim mapEntry As JObject = mapQueues.FirstOrDefault(Function(q) String.Equals(q.Value(Of String)("name"), queueName, StringComparison.OrdinalIgnoreCase))
        Dim tgt As JObject = tQueues.FirstOrDefault(Function(q) String.Equals(q.Value(Of String)("Name"), queueName, StringComparison.OrdinalIgnoreCase))
        Dim srcObj As JObject = If(src, New JObject())
        Dim tgtObj As JObject = If(tgt, New JObject())
        Dim row As New JObject()
        row("name") = queueName
        row("folder") = dev.Value(Of String)("folderPath")
        row("description") = Convert.ToString(srcObj("Description"))
        row("maxRetries") = If(src Is Nothing, "0", Convert.ToString(srcObj("MaxNumberOfRetries")))
        row("autoRetry") = If(src Is Nothing, "false", Convert.ToString(srcObj("AcceptAutomaticallyRetry")).ToLowerInvariant())
        row("uniqueReference") = If(src Is Nothing, "false", Convert.ToString(srcObj("EnforceUniqueReference")).ToLowerInvariant())
        row("required") = mapEntry IsNot Nothing AndAlso mapEntry.Value(Of Boolean?)("required").GetValueOrDefault(True)
        row("targetExists") = tgt IsNot Nothing
        ' Does the target queue have different retry or unique-reference settings?
        Dim differs As Boolean = tgt IsNot Nothing AndAlso src IsNot Nothing AndAlso (Convert.ToString(tgtObj("MaxNumberOfRetries")) <> Convert.ToString(srcObj("MaxNumberOfRetries")) OrElse Convert.ToString(tgtObj("EnforceUniqueReference")) <> Convert.ToString(srcObj("EnforceUniqueReference")) OrElse Convert.ToString(tgtObj("AcceptAutomaticallyRetry")) <> Convert.ToString(srcObj("AcceptAutomaticallyRetry")))
        row("targetStatus") = If(Not targetReadable, "Unknown (target not readable)", If(Not targetFolderOk, "Target folder missing", If(tgt Is Nothing, "Missing in " & targetEnv, If(differs, "Exists in " & targetEnv & " with different settings", "Exists in " & targetEnv))))
        ' Proposed action: create what is missing, keep what exists
        row("action") = If(tgt Is Nothing, If(CBool(row("required")) OrElse src IsNot Nothing, "Create", "Skip"), "Keep")
        row("proposedName") = queueName
        row("savedStatus") = ""
        If src Is Nothing Then warnings.Add("Queue " & queueName & " is in the Bot ID mapping but not in the Dev folder; its settings use defaults.")
        queues.Add(row)
    Next
    ' Access: roles needed per access level (settings roleMappings) and users read from Dev and the target folder
    Dim roleMap As JObject = CType(in_Config("roleMappings"), JObject)
    Dim tUsers As List(Of JObject) = If(TryCast(in_Raw("targetUsers"), JArray), New JArray()).Children(Of JObject)().ToList()
    Dim devUsers As List(Of JObject) = If(TryCast(in_Raw("devUsers"), JArray), New JArray()).Children(Of JObject)().ToList()
    ' One row per account listed in the mapping, showing which roles are still missing in the target
    For Each accessEntry As JObject In If(TryCast(ui("access"), JArray), New JArray()).Children(Of JObject)()
        Dim accountName As String = accessEntry.Value(Of String)("name")
        Dim level As String = accessEntry.Value(Of String)("accessLevel")
        Dim need As List(Of String) = If(TryCast(roleMap(level), JArray), New JArray()).Values(Of String)().ToList()
        Dim devU As JObject = devUsers.FirstOrDefault(Function(u) String.Equals(Convert.ToString(u.SelectToken("UserEntity.UserName")), accountName, StringComparison.OrdinalIgnoreCase))
        Dim tU As JObject = tUsers.FirstOrDefault(Function(u) String.Equals(Convert.ToString(u.SelectToken("UserEntity.UserName")), accountName, StringComparison.OrdinalIgnoreCase))
        Dim have As List(Of String) = If(tU Is Nothing, New List(Of String), If(TryCast(tU("Roles"), JArray), New JArray()).Children(Of JObject)().Select(Function(r) r.Value(Of String)("Name")).ToList())
        Dim missing As List(Of String) = need.Where(Function(r) Not have.Contains(r, StringComparer.OrdinalIgnoreCase)).ToList()
        Dim row As New JObject()
        row("name") = accountName
        row("type") = If(accessEntry.Value(Of String)("type"), "DirectoryUser")
        row("source") = "Bot ID mapping"
        row("folder") = envs(targetEnv).Value(Of String)("folderPath")
        row("devRoles") = If(devU Is Nothing, "", String.Join(", ", If(TryCast(devU("Roles"), JArray), New JArray()).Children(Of JObject)().Select(Function(r) r.Value(Of String)("Name"))))
        row("accessLevel") = level
        row("requiredRoles") = String.Join(", ", need)
        row("targetRoles") = String.Join(", ", have)
        row("targetStatus") = If(Not targetReadable, "Unknown (target not readable)", If(Not targetFolderOk, "Target folder missing", If(tU Is Nothing, "No access in " & targetEnv, If(missing.Count = 0, "Has required access", "Missing roles: " & String.Join(", ", missing)))))
        row("action") = If(missing.Count = 0 AndAlso tU IsNot Nothing, "No change", "Grant")
        row("proposedChange") = If(missing.Count = 0 AndAlso tU IsNot Nothing, "", "Add " & String.Join(", ", missing) & " on " & envs(targetEnv).Value(Of String)("folderPath"))
        row("savedStatus") = ""
        access.Add(row)
    Next
    ' Accounts with access in the Dev folder that are not in the mapping are listed for information only
    For Each devUser As JObject In devUsers
        Dim accountName As String = Convert.ToString(devUser.SelectToken("UserEntity.UserName"))
        ' Skip accounts already listed from the mapping
        If Not access.Children(Of JObject)().Any(Function(r) String.Equals(r.Value(Of String)("name"), accountName, StringComparison.OrdinalIgnoreCase)) Then
            Dim tU As JObject = tUsers.FirstOrDefault(Function(x) String.Equals(Convert.ToString(x.SelectToken("UserEntity.UserName")), accountName, StringComparison.OrdinalIgnoreCase))
            Dim row As New JObject()
            row("name") = accountName
            row("type") = Convert.ToString(devUser.SelectToken("UserEntity.Type"))
            row("source") = "Dev folder (information)"
            row("folder") = envs(targetEnv).Value(Of String)("folderPath")
            row("devRoles") = String.Join(", ", If(TryCast(devUser("Roles"), JArray), New JArray()).Children(Of JObject)().Select(Function(r) r.Value(Of String)("Name")))
            row("accessLevel") = ""
            row("requiredRoles") = ""
            row("targetRoles") = If(tU Is Nothing, "", String.Join(", ", If(TryCast(tU("Roles"), JArray), New JArray()).Children(Of JObject)().Select(Function(r) r.Value(Of String)("Name"))))
            row("targetStatus") = If(tU Is Nothing, "No access in " & targetEnv, "Has access in " & targetEnv)
            row("action") = "No change"
            row("proposedChange") = ""
            row("savedStatus") = ""
            access.Add(row)
        End If
    Next
End If
' Put the grid rows and warnings into the result
d("assets") = assets
d("queues") = queues
d("access") = access
d("flows") = New JArray()
d("warnings") = warnings
out_Details = d
