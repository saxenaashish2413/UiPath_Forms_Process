'ARG in in_Config JO
'ARG in in_Session DSO
'ARG in in_Operation S
'ARG in in_Status S
'ARG in in_Message S
'ARG in in_Data JO
'ARG out out_Line S
' Appends one JSON line to <audit.folder>\audit-yyyyMMdd.jsonl and to the run's step list (Session "steps"). Fields: timestampUtc, requestReference, botId, user, machine, operation, status, message, data. Anything that looks like a secret is masked before it is written; secret values are never passed here.
' Regular expression that hides bearer tokens
Dim maskBearer As String = "(?i)(bearer\s+)[A-Za-z0-9\-\._~\+/]+=*"
' Regular expression that hides password/secret/token values
Dim maskSecret As String = "(?i)(""?(password|secret|client_secret|access_token|token|credentialpassword)""?\s*[:=]\s*)""?[^"",\s}]+""?"
' One audit line: when, which request, who, where, what happened
Dim line As New JObject()
line("timestampUtc") = DateTime.UtcNow.ToString("o", System.Globalization.CultureInfo.InvariantCulture)
line("requestReference") = If(in_Session.ContainsKey("requestReference") AndAlso in_Session("requestReference") IsNot Nothing, in_Session("requestReference").ToString(), "")
line("botId") = If(in_Session.ContainsKey("botId") AndAlso in_Session("botId") IsNot Nothing, in_Session("botId").ToString(), "")
line("user") = If(in_Session.ContainsKey("user") AndAlso in_Session("user") IsNot Nothing, in_Session("user").ToString(), "")
line("machine") = Environment.MachineName
line("operation") = in_Operation
line("status") = in_Status
' Message with anything secret-looking masked
line("message") = System.Text.RegularExpressions.Regex.Replace(System.Text.RegularExpressions.Regex.Replace(If(in_Message, ""), maskBearer, "$1***"), maskSecret, "$1***")
' Optional data, masked the same way
If in_Data IsNot Nothing Then line("data") = JToken.Parse(System.Text.RegularExpressions.Regex.Replace(System.Text.RegularExpressions.Regex.Replace(in_Data.ToString(Newtonsoft.Json.Formatting.None), maskBearer, "$1***"), maskSecret, "$1***"))
' The line as compact JSON
out_Line = line.ToString(Newtonsoft.Json.Formatting.None)
' Audit folder from settings (relative paths are under the project folder)
Dim folder As String = in_Config.SelectToken("audit.folder").ToString()
If Not System.IO.Path.IsPathRooted(folder) Then folder = System.IO.Path.Combine(Environment.CurrentDirectory, folder)
' Make sure the folder exists
System.IO.Directory.CreateDirectory(folder As String)
' Append the line to today's audit file
System.IO.File.AppendAllText(System.IO.Path.Combine(folder, "audit-" & DateTime.UtcNow.ToString("yyyyMMdd", System.Globalization.CultureInfo.InvariantCulture) & ".jsonl") As String, out_Line & Environment.NewLine As String)
' Also keep it in this run's step list (stored with the deployment result)
If Not in_Session.ContainsKey("steps") Then in_Session("steps") = New JArray()
CType(in_Session("steps"), JArray).Add(line)
