'ARG in in_Config JO
'ARG in in_Session DSO
'ARG in in_Operation S
'ARG in in_Status S
'ARG in in_Message S
'ARG in in_Data JO
'ARG out out_Line S
' Appends one JSON line to <audit.folder>\audit-yyyyMMdd.jsonl and to the run's step list (Session "steps").
' Fields: timestampUtc, requestReference, botId, user, machine, operation, status, message, data.
' Anything that looks like a secret is masked before it is written; secret values are never passed here.
Dim inv As System.Globalization.CultureInfo = System.Globalization.CultureInfo.InvariantCulture
Dim S As Func(Of String, String) = Function(k) If(in_Session.ContainsKey(k) AndAlso in_Session(k) IsNot Nothing, in_Session(k).ToString(), "")
Dim Mask As Func(Of String, String) = Function(t)
    Dim x As String = System.Text.RegularExpressions.Regex.Replace(If(t, ""), "(?i)(bearer\s+)[A-Za-z0-9\-\._~\+/]+=*", "$1***")
    Return System.Text.RegularExpressions.Regex.Replace(x, "(?i)(""?(password|secret|client_secret|access_token|token|credentialpassword)""?\s*[:=]\s*)""?[^"",\s}]+""?", "$1***")
End Function
Dim line As New Newtonsoft.Json.Linq.JObject()
line("timestampUtc") = DateTime.UtcNow.ToString("o", inv)
line("requestReference") = S("requestReference")
line("botId") = S("botId")
line("user") = S("user")
line("machine") = Environment.MachineName
line("operation") = in_Operation
line("status") = in_Status
line("message") = Mask(in_Message)
If in_Data IsNot Nothing Then line("data") = Newtonsoft.Json.Linq.JToken.Parse(Mask(in_Data.ToString(Newtonsoft.Json.Formatting.None)))
out_Line = line.ToString(Newtonsoft.Json.Formatting.None)
Dim folder As String = in_Config.SelectToken("audit.folder").ToString()
If Not System.IO.Path.IsPathRooted(folder) Then folder = System.IO.Path.Combine(Environment.CurrentDirectory, folder)
System.IO.Directory.CreateDirectory(folder)
System.IO.File.AppendAllText(System.IO.Path.Combine(folder, "audit-" & DateTime.UtcNow.ToString("yyyyMMdd", inv) & ".jsonl"), out_Line & Environment.NewLine)
If Not in_Session.ContainsKey("steps") Then in_Session("steps") = New Newtonsoft.Json.Linq.JArray()
CType(in_Session("steps"), Newtonsoft.Json.Linq.JArray).Add(line)
