'ARG in in_Queue JO
'ARG in in_TargetQueueJson S
'ARG out out_Method S
'ARG out out_Url S
'ARG out out_Body S
'ARG out out_Change S
' Idempotent queue operation for one approved row (settings copied from the Dev queue):
'  Create + missing -> POST odata/QueueDefinitions ; Create + exists (earlier run) -> NoChange
'  Update + exists  -> PUT odata/QueueDefinitions(<Id>) only when a setting differs ; Keep/Skip -> NoChange
out_Method = ""
out_Url = ""
out_Body = ""
out_Change = "NoChange"
Dim act As String = in_Queue.Value(Of String)("action")
If act <> "Create" AndAlso act <> "Update" Then Return
Dim tgt As Newtonsoft.Json.Linq.JObject = If(String.IsNullOrWhiteSpace(in_TargetQueueJson), Nothing, Newtonsoft.Json.Linq.JObject.Parse(in_TargetQueueJson))
If act = "Create" AndAlso tgt IsNot Nothing Then Return
If act = "Update" AndAlso tgt Is Nothing Then Throw New InvalidOperationException("Queue " & in_Queue.Value(Of String)("name") & " no longer exists in the target; validate the request again.")
Dim body As New Newtonsoft.Json.Linq.JObject()
If tgt IsNot Nothing Then body("Id") = tgt("Id")
body("Name") = in_Queue.Value(Of String)("proposedName")
body("Description") = If(in_Queue.Value(Of String)("description"), "")
body("MaxNumberOfRetries") = Integer.Parse(If(in_Queue.Value(Of String)("maxRetries"), "0"), System.Globalization.CultureInfo.InvariantCulture)
body("AcceptAutomaticallyRetry") = Boolean.Parse(If(in_Queue.Value(Of String)("autoRetry"), "false"))
body("EnforceUniqueReference") = Boolean.Parse(If(in_Queue.Value(Of String)("uniqueReference"), "false"))
If tgt IsNot Nothing AndAlso tgt.Value(Of Integer)("MaxNumberOfRetries") = body.Value(Of Integer)("MaxNumberOfRetries") AndAlso tgt.Value(Of Boolean)("AcceptAutomaticallyRetry") = body.Value(Of Boolean)("AcceptAutomaticallyRetry") AndAlso tgt.Value(Of Boolean)("EnforceUniqueReference") = body.Value(Of Boolean)("EnforceUniqueReference") AndAlso tgt.Value(Of String)("Description") = body.Value(Of String)("Description") Then Return
out_Body = body.ToString(Newtonsoft.Json.Formatting.None)
If tgt Is Nothing Then
    out_Method = "POST" : out_Url = "odata/QueueDefinitions" : out_Change = "Created"
Else
    out_Method = "PUT" : out_Url = "odata/QueueDefinitions(" & tgt.Value(Of Long)("Id").ToString(System.Globalization.CultureInfo.InvariantCulture) & ")" : out_Change = "Updated"
End If
