'ARG in in_Queue JO
'ARG in in_TargetQueueJson S
'ARG out out_Method S
'ARG out out_Url S
'ARG out out_Body S
'ARG out out_Change S
' Decides the idempotent operation for one approved queue row (settings copied from the Dev queue): Create + missing -> POST odata/QueueDefinitions; Create + already there (earlier run) -> NoChange; Update + exists -> PUT odata/QueueDefinitions(<Id>) only when a setting differs; Keep/Skip -> NoChange. An empty out_Method means: nothing to send.
' Default: nothing to send
out_Method = ""
out_Url = ""
out_Body = ""
out_Change = "NoChange"
' Action chosen in the form: Create, Update, Keep or Skip
Dim act As String = in_Queue.Value(Of String)("action")
' The queue as it is in the target now (empty when it does not exist)
Dim tgt As JObject = If(String.IsNullOrWhiteSpace(in_TargetQueueJson), Nothing, JObject.Parse(in_TargetQueueJson))
' Update needs the queue to exist
If act = "Update" AndAlso tgt Is Nothing Then Throw New InvalidOperationException("Queue " & in_Queue.Value(Of String)("name") & " no longer exists in the target; validate the request again.")
' Only Create of a missing queue, or Update of an existing one, can change anything
If (act = "Create" AndAlso tgt Is Nothing) OrElse (act = "Update" AndAlso tgt IsNot Nothing) Then
    ' Build the queue definition from the approved row
    Dim body As New JObject()
    ' PUT needs the target's Id
    If tgt IsNot Nothing Then body("Id") = tgt("Id")
    body("Name") = in_Queue.Value(Of String)("proposedName")
    body("Description") = If(in_Queue.Value(Of String)("description"), "")
    body("MaxNumberOfRetries") = Integer.Parse(If(in_Queue.Value(Of String)("maxRetries"), "0"), System.Globalization.CultureInfo.InvariantCulture)
    body("AcceptAutomaticallyRetry") = Boolean.Parse(If(in_Queue.Value(Of String)("autoRetry"), "false"))
    body("EnforceUniqueReference") = Boolean.Parse(If(in_Queue.Value(Of String)("uniqueReference"), "false"))
    ' Does the existing queue already have exactly these settings?
    Dim same As Boolean = tgt IsNot Nothing AndAlso tgt.Value(Of Integer)("MaxNumberOfRetries") = body.Value(Of Integer)("MaxNumberOfRetries") AndAlso tgt.Value(Of Boolean)("AcceptAutomaticallyRetry") = body.Value(Of Boolean)("AcceptAutomaticallyRetry") AndAlso tgt.Value(Of Boolean)("EnforceUniqueReference") = body.Value(Of Boolean)("EnforceUniqueReference") AndAlso tgt.Value(Of String)("Description") = body.Value(Of String)("Description")
    ' Send only when something differs
    If Not same Then
        out_Body = body.ToString(Newtonsoft.Json.Formatting.None)
        ' Missing: create it (POST); existing: update it (PUT)
        If tgt Is Nothing Then
            out_Method = "POST"
            out_Url = "odata/QueueDefinitions"
            out_Change = "Created"
        Else
            out_Method = "PUT"
            out_Url = "odata/QueueDefinitions(" & tgt.Value(Of Long)("Id").ToString(System.Globalization.CultureInfo.InvariantCulture) & ")"
            out_Change = "Updated"
        End If
    End If
End If
