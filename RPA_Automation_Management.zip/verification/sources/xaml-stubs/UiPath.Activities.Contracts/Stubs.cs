// Test-only stand-ins for UiPath.Activities.Contracts (shipped with Studio/Robot, not on nuget.org): only what the XAML loader needs.
using System;
namespace UiPath.Activities.Contracts {
  [AttributeUsage(AttributeTargets.All, AllowMultiple = true)] public class XamlMigrationAttribute : Attribute { public XamlMigrationAttribute(Type t) { } }
  [AttributeUsage(AttributeTargets.All, AllowMultiple = true)] public class RefactoringsAttribute : Attribute { public RefactoringsAttribute(Type t) { } }
  public abstract class XamlMigration { }
  public abstract class Refactorings { }
}
namespace UiPath.Activities.Contracts {
  public interface IWorkflowRuntime { }
  public interface IWorkflowExecutor { }
  public interface IRobotSettings { }
  public interface IOrchestratorSettings { }
  public interface ICrossWorkflowProperties { }
  public interface IWorkflowDesignerContract { }
}
namespace UiPath.Activities.Contracts.Telemetry { public interface ITelemetryProxy { } }
namespace UiPath.Activities.Contracts.Persistence { public interface IPersistenceBookmarks { } }
