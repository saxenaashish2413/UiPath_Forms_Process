using System;
namespace UiPath.CodedWorkflows {
  [AttributeUsage(AttributeTargets.All, AllowMultiple = true)] public class CodedWorkflowsServiceRegistryAttribute : Attribute { public CodedWorkflowsServiceRegistryAttribute(Type t) { } }
}
