"""Form\\Automation_Form_Controller.xaml and the entry points Main.xaml, ExecuteDeployment.xaml, ApproveRequest.xaml."""
from xamlgen import Workflow, Arg, Var, Seq, Assign, Log, If, Try, ForEach, Invoke, Code, Throw, MessageBox, Rethrow
from formacts import ShowFormAsync, GetFields, SetFields, CloseForm, Break, Switch, TriggerScope
from wf_framework import CFG, q, ctx, audit

READ_FIELDS = ["AutomationTool", "ProcessType", "BotId", "DeploymentPath", "RequestedVersion", "EnhancementDescription", "ChangeReference",
               "BugDescription", "IncidentReference", "ProposedProcessName", "ProposedTargetFolder", "AdditionalConfig",
               "AssetsProposedJson", "QueuesProposedJson", "AccessProposedJson"]
FV = {f: "f" + f for f in READ_FIELDS}   # form field -> variable

D = 'Convert.ToString(joDetails.SelectToken("{0}"))'


def details_fields():
    src = 'joDetails.Value(Of String)("sourceEnv")'
    return {
        "LookupKey": 'fAutomationTool & "|" & fProcessType & "|" & fBotId.Trim().ToUpperInvariant() & "|" & fDeploymentPath',
        "LookupStatus": 'joDetails.Value(Of String)("status")',
        "LookupMessage": 'joDetails.Value(Of String)("message")',
        "ProcessName": D.format("process.processName"), "PackageName": D.format("process.packageName"),
        "CurrentVersion": D.format("process.currentVersion"), "LatestDevVersion": D.format("process.latestDevVersion"),
        "PackageAvailability": D.format("process.packageAvailability"), "DevFolder": D.format("process.devFolder"),
        "UatFolder": D.format("process.uatFolder"), "ProdFolder": D.format("process.prodFolder"),
        "DevEnvironment": D.format("process.devEnvironment"), "ProcessDescription": D.format("process.description"),
        "DevStatus": D.format("process.devStatus"), "UatStatus": D.format("process.uatStatus"), "ProdStatus": D.format("process.prodStatus"),
        "VersionsJson": 'joDetails("sourceVersions").ToString(Newtonsoft.Json.Formatting.None)',
        "RequestedVersion": f'If({src} = "Dev", If(joDetails("sourceVersions").Count() > 0, joDetails("sourceVersions")(0).ToString(), ""), If(joDetails("sourceVersions").Values(Of String)().Contains(joDetails.SelectToken("environments." & {src} & ".deployedVersion").ToString()), joDetails.SelectToken("environments." & {src} & ".deployedVersion").ToString(), ""))',
        "AssetsJson": 'joDetails("assets").ToString(Newtonsoft.Json.Formatting.None)',
        "QueuesJson": 'joDetails("queues").ToString(Newtonsoft.Json.Formatting.None)',
        "AccessJson": 'joDetails("access").ToString(Newtonsoft.Json.Formatting.None)',
        "FlowsJson": 'joDetails("flows").ToString(Newtonsoft.Json.Formatting.None)',
        "WarningsText": 'String.Join(Environment.NewLine, joDetails("warnings").Values(Of String)())',
        "ProposedProcessName": D.format("process.processName"),
        "ProposedTargetFolder": 'Convert.ToString(joDetails.SelectToken("environments." & joDetails.Value(Of String)("targetEnv") & ".folderPath"))',
        "EditMode": '"No"', "EditMessage": '""', "ValidationStatus": '""', "SummaryHtml": '""', "SubmitStatus": '""', "SubmitMessage": '""', "RequestReference": '""',
    }


CLEAR = {k: '""' for k in details_fields()}
CLEAR.update({"VersionsJson": '"[]"', "AssetsJson": '"[]"', "QueuesJson": '"[]"', "AccessJson": '"[]"', "FlowsJson": '"[]"', "EditMode": '"No"'})


def fetch_seq(label):
    return Seq(label, [
        GetFields("Read selection", {k: FV[k] for k in ["AutomationTool", "ProcessType", "BotId", "DeploymentPath"]}),
        If('fDeploymentPath = ""', Seq("Default deployment path", [
            Assign("fDeploymentPath", 'in_Config("deploymentPaths")(0).Value(Of String)("name")', "S"),
            SetFields("Show default path", {"DeploymentPath": "fDeploymentPath"})])),
        SetFields("Show searching", {"LookupStatus": '"Searching"', "LookupMessage": '"Retrieving details for " & fBotId & " from " & fAutomationTool & "..."', "LookupKey": '""'}),
        Invoke("Requests/Fetch_Provider_Details.xaml", ctx(in_Tool="fAutomationTool", in_BotId="fBotId", in_ProcessType="fProcessType", in_DeploymentPath="fDeploymentPath",
                                                          out_Found="boolFound", out_Bot="joBot", out_Details="joDetails", out_Message="strMessage"), name="Fetch details"),
        If("joDetails IsNot Nothing",
           SetFields("Show details", details_fields()),
           Seq("Show look-up error", [
               SetFields("Clear details", CLEAR),
               SetFields("Show error", {"LookupStatus": '"NotFound"', "LookupMessage": "strMessage"})])),
    ])


def form_payload():
    return "New JObject(" + ", ".join(f'New JProperty("{k}", {v})' for k, v in FV.items()) + ")"


def build():
    validate = [
        GetFields("Read all fields", FV),
        Assign("joForm", form_payload(), "JO", "Form values"),
        Code("BuildRequest", {"in_Config": "in_Config", "in_Form": "joForm", "in_Details": "joDetails", "in_RequestedBy": "in_RequestedBy", "out_Request": "joRequest"}, "Build request"),
        Invoke("Requests/Validate_Deployment_Request.xaml", ctx(in_Request="joRequest", in_Details="joDetails", in_Mode='"Form"', in_IsEditor="boolEditor",
                                                                 out_IsValid="boolValid", out_Errors="jaErrors", out_Warnings="jaWarnings", out_Notes="jaNotes"), name="Validate request"),
        Code("Summary", {"in_Request": "joRequest", "in_Errors": "jaErrors", "in_Warnings": "jaWarnings", "in_Notes": "jaNotes", "out_Html": "strSummary"}, "Review summary"),
        SetFields("Show validation", {"ValidationStatus": 'If(boolValid, "Valid", "Invalid")', "SummaryHtml": "strSummary"}),
    ]
    handler = Try("Handle form event", Switch("Which form event?", "args.TriggerName", {
        "Fetch requested": fetch_seq("Fetch details"),
        "Deployment path changed": If('joDetails IsNot Nothing', fetch_seq("Re-fetch for the new path"), SetFields("Reset validation", {"ValidationStatus": '""', "SummaryHtml": '""'})),
        "Automation tool changed": Seq("Tool changed: clear details", [Assign("joDetails", "Nothing", "JO"), SetFields("Clear details", CLEAR)]),
        "Process type changed": Seq("Type changed: clear details", [Assign("joDetails", "Nothing", "JO"), SetFields("Clear details", CLEAR)]),
        "Edit requested": Seq("Edit configuration", [
            GetFields("Read edit mode", {"EditMode": "strEditMode"}),
            If("Not boolEditor",
               SetFields("Not authorized", {"EditMessage": '"You are not authorized to change the configuration (configuration editors only). You can still review and submit the retrieved configuration."'}),
               If('joDetails Is Nothing OrElse joDetails.Value(Of String)("tool") <> "UiPath" OrElse joDetails.Value(Of String)("processType") <> "New"',
                  SetFields("Not applicable", {"EditMessage": '"Configuration can be edited for New UiPath requests after Fetch Details."'}),
                  SetFields("Toggle edit mode", {"EditMode": 'If(strEditMode = "Yes", "No", "Yes")', "EditMessage": 'If(strEditMode = "Yes", "", "Edit mode: change the Proposed columns, then Validate.")', "ValidationStatus": '""', "SummaryHtml": '""'})))]),
        "Validate requested": Seq("Validate", validate),
        "Submit requested": Seq("Submit", validate + [
            If("Not boolValid",
               SetFields("Fix errors first", {"SubmitStatus": '""', "SubmitMessage": '"Fix the validation errors before submitting."'}),
               Seq("Submit and maybe deploy", [
                   Invoke("Requests/Submit_Request.xaml", ctx(in_Request="joRequest", out_Duplicate="boolDuplicate", out_RequestId="strRequestId"), name="Submit request"),
                   If("boolDuplicate",
                      SetFields("Duplicate", {"SubmitStatus": '"Duplicate"', "SubmitMessage": '"This request was already submitted (" & joRequest.Value(Of String)("reference") & "). Nothing new was created."'}),
                      Seq("Submitted", [
                          Assign("out_Outcome", '"Submitted"', "S"),
                          Assign("out_RequestReference", 'joRequest.Value(Of String)("reference")', "S"),
                          Assign("joPath", 'in_Config("deploymentPaths").Children(Of JObject)().First(Function(p) p.Value(Of String)("name") = joRequest.Value(Of String)("deploymentPath"))', "JO"),
                          If('joPath.Value(Of Boolean)("autoExecuteAfterSubmit") AndAlso Not joPath.Value(Of Boolean)("requiresApproval") AndAlso joRequest.Value(Of String)("targetEnvironment") <> "Prod"',
                             Seq("Deploy now", [
                                 SetFields("Show deploying", {"SubmitStatus": '"Deploying"', "RequestReference": "out_RequestReference", "SubmitMessage": '"Submitted as " & out_RequestReference & ". Deploying to " & joRequest.Value(Of String)("targetEnvironment") & "..."'}),
                                 Invoke("Requests/Execute_Request.xaml", ctx(in_RequestReference="out_RequestReference", out_Status="strStatus", out_Message="strMessage", out_Result="joResult"), name="Execute request"),
                                 Assign("out_Outcome", 'If(strStatus = "Succeeded" OrElse strStatus = "AlreadyDeployed", "Deployed", "DeploymentFailed")', "S"),
                                 GetFields("Read grids", {"AssetsJson": "strAssets", "QueuesJson": "strQueues", "AccessJson": "strAccess"}),
                                 Code("MergeSaved", {"in_RowsJson": "strAssets", "in_Result": "joResult", "in_Kind": '"Asset"', "in_Request": "joRequest", "out_RowsJson": "strAssets"}, "Saved assets"),
                                 Code("MergeSaved", {"in_RowsJson": "strQueues", "in_Result": "joResult", "in_Kind": '"Queue"', "in_Request": "joRequest", "out_RowsJson": "strQueues"}, "Saved queues"),
                                 Code("MergeSaved", {"in_RowsJson": "strAccess", "in_Result": "joResult", "in_Kind": '"Access"', "in_Request": "joRequest", "out_RowsJson": "strAccess"}, "Saved access"),
                                 SetFields("Show deployment result", {"SubmitStatus": "strStatus", "SubmitMessage": '"Request " & out_RequestReference & ": " & strMessage', "AssetsJson": "strAssets", "QueuesJson": "strQueues", "AccessJson": "strAccess"})]),
                             SetFields("Show awaiting approval", {"SubmitStatus": '"Submitted"', "RequestReference": "out_RequestReference",
                                                                  "SubmitMessage": '"Submitted as " & out_RequestReference & ". Nothing was deployed. " & String.Join(" ", jaNotes.Values(Of String)()) & " After approval, ExecuteDeployment.xaml runs the deployment with this reference."'}))]))]))]),
        "Cancel requested": Seq("Cancel", [CloseForm(), Break()]),
        "Form window closed": Break(),
    }), [("EX", "exEvent", Seq("Event failed", [
        Log("Error", '"Form event " & args.TriggerName & " failed: " & exEvent.ToString()'),
        Try("Try show error", SetFields("Show error", {"LookupStatus": '"Error"', "LookupMessage": '"Something went wrong (" & exEvent.Message & "). The details are in the robot log."'}),
            [("EX", "exShow", Log("Error", '"Could not show the error in the form: " & exShow.Message'))])]))])

    Workflow("Form/Automation_Form_Controller.xaml",
             "Shows Form\\AutomationManagement.uiform (Show Form with 'Continue workflow execution' = On) and reacts to its "
             "buttons and selection changes with a Trigger Scope: Fetch Details, Edit Configuration, Validate, Submit Request, Cancel, "
             "and Automation Tool / Process Type / Deployment Path changes. Business logic lives in Requests\\ and Providers\\; "
             "this workflow only moves values between the form and them.",
             CFG + [Arg("in", "in_RequestedBy", "S", "Requester (DOMAIN\\user)."),
                    Arg("out", "out_Outcome", "S", "Cancelled | Submitted | Deployed | DeploymentFailed"),
                    Arg("out", "out_RequestReference", "S", "Reference of the submitted request.")],
             Seq("Automation form controller", [
                 Assign("out_Outcome", '"Cancelled"', "S"), Assign("out_RequestReference", '""', "S"), Assign("joDetails", "Nothing", "JO"),
                 Code("CheckAuthorization", {"in_User": "in_RequestedBy", "in_Allowed": 'TryCast(in_Config.SelectToken("authorization.configurationEditors"), JArray)', "out_Allowed": "boolEditor"}, "Configuration editor?"),
                 ShowFormAsync("Show Automation Management form", '"Automation Management"',
                               {"RequesterName": "in_RequestedBy", "CanEdit": 'If(boolEditor, "Yes", "No")',
                                "AccessLevelOptions": 'New JArray(CType(in_Config("roleMappings"), JObject).Properties().Select(Function(p) p.Name)).ToString(Newtonsoft.Json.Formatting.None)',
                                "DeploymentPathOptions": 'New JArray(in_Config("deploymentPaths").Children(Of JObject)().Select(Function(p) p.Value(Of String)("name"))).ToString(Newtonsoft.Json.Formatting.None)'},
                               doc="Form: Form\\AutomationManagement.uiform. Continue workflow execution = On; the Trigger Scope below handles the form."),
                 TriggerScope("Listen to form events", [
                     ("Fetch requested", "click.btnFetch"), ("Edit requested", "click.btnEdit"), ("Validate requested", "click.btnValidate"),
                     ("Submit requested", "click.btnSubmit"), ("Cancel requested", "click.btnCancel"),
                     ("Automation tool changed", "changed.AutomationTool"), ("Process type changed", "changed.ProcessType"),
                     ("Deployment path changed", "changed.DeploymentPath"), ("Form window closed", "window.closed")],
                     Seq("Handle event", [handler]),
                     doc="Sequential: one event at a time. Break ends the scope after Cancel or closing the window."),
             ], vars=[Var(v, "S") for v in FV.values()] + [Var(n, "S") for n in ["strMessage", "strEditMode", "strSummary", "strRequestId", "strStatus", "strAssets", "strQueues", "strAccess"]]
                + [Var("joDetails", "JO"), Var("joBot", "JO"), Var("joForm", "JO"), Var("joRequest", "JO"), Var("joPath", "JO"), Var("joResult", "JO"),
                   Var("jaErrors", "JA"), Var("jaWarnings", "JA"), Var("jaNotes", "JA"), Var("boolFound", "B"), Var("boolEditor", "B"), Var("boolValid", "B"), Var("boolDuplicate", "B")]))

    paths = [Arg("in", "in_SettingsPath", "S", "Settings file; empty = Config\\Settings.json."), Arg("in", "in_BotMappingPath", "S", "Bot ID mapping; empty = Config\\BotMapping.json.")]
    load = [
        Assign("strSettings", 'If(String.IsNullOrWhiteSpace(in_SettingsPath), "Config\\Settings.json", in_SettingsPath)', "S"),
        Assign("strMapping", 'If(String.IsNullOrWhiteSpace(in_BotMappingPath), "Config\\BotMapping.json", in_BotMappingPath)', "S"),
        Invoke("Framework/Load_Configuration.xaml", {"in_SettingsPath": "strSettings", "in_BotMappingPath": "strMapping", "out_Config": "joConfig", "out_ErrorMessage": "strConfigError"}, name="Load configuration"),
        Assign("strUser", 'Environment.UserDomainName & "\\" & Environment.UserName', "S", "Current user"),
        Assign("dicSession", 'New Dictionary(Of String, Object) From {{"user", strUser}}', "DSO", "Run context"),
    ]
    lvars = [Var("strSettings", "S"), Var("strMapping", "S"), Var("joConfig", "JO"), Var("strConfigError", "S"), Var("strUser", "S"), Var("dicSession", "DSO")]
    sess = {"in_Config": "joConfig", "in_Session": "dicSession"}

    Workflow("Main.xaml",
             "Requester entry point (attended): loads the configuration and opens the Automation Management form. Submitting "
             "creates an auditable request; only Dev to UAT (when settings allow) is deployed straight away; Prod always waits "
             "for approval and ExecuteDeployment.xaml.",
             paths + [Arg("out", "out_Outcome", "S", "Cancelled | Submitted | Deployed | DeploymentFailed | ConfigurationError"),
                      Arg("out", "out_RequestReference", "S", "Reference of the submitted request, if any.")],
             Seq("Main", load + [
                 Assign("out_Outcome", '"Cancelled"', "S"), Assign("out_RequestReference", '""', "S"),
                 If('strConfigError <> ""',
                    Seq("Configuration error", [Assign("out_Outcome", '"ConfigurationError"', "S"), MessageBox('"Automation Management"', "strConfigError", "Tell the user")]),
                    Try("Run form", Invoke("Form/Automation_Form_Controller.xaml", dict(sess, in_RequestedBy="strUser", out_Outcome="out_Outcome", out_RequestReference="out_RequestReference"), name="Automation form"),
                        [("EX", "exMain", Seq("Unexpected error", [
                            Log("Fatal", '"Automation Management stopped: " & exMain.ToString()'),
                            MessageBox('"Automation Management"', '"Automation Management stopped unexpectedly: " & exMain.Message & Environment.NewLine & "The details are in the robot log."', "Tell the user"),
                            Rethrow()]))])),
                 Log("Info", '"Automation Management finished: " & out_Outcome & If(out_RequestReference <> "", " (" & out_RequestReference & ")", "")'),
             ], vars=lvars))

    Workflow("ExecuteDeployment.xaml",
             "Deployment entry point (unattended or operator): executes one submitted request by reference after re-validating it, "
             "including the approval and previous-stage checks for Prod. The job faults when the request is rejected or fails, so "
             "Orchestrator shows it; the outcome is also in the results queue and the audit file.",
             paths + [Arg("in", "in_RequestReference", "S", "Request reference (AM|...)."),
                      Arg("out", "out_Status", "S", "Succeeded | AlreadyDeployed | Rejected | Failed"), Arg("out", "out_Message", "S", "Outcome.")],
             Seq("Execute deployment", load + [
                 If('strConfigError <> ""', Throw("New BusinessRuleException(strConfigError)", "Configuration error")),
                 Invoke("Requests/Execute_Request.xaml", dict(sess, in_RequestReference="in_RequestReference", out_Status="out_Status", out_Message="out_Message", out_Result="joResult"), name="Execute request"),
                 Log("Info", '"Request " & in_RequestReference & ": " & out_Status & " - " & out_Message'),
                 If('out_Status = "Rejected"', Throw("New BusinessRuleException(out_Message)", "Rejected")),
                 If('out_Status = "Failed"', Throw("New Exception(out_Message)", "Failed")),
             ], vars=lvars + [Var("joResult", "JO")]))

    Workflow("ApproveRequest.xaml",
             "Approver entry point (attended): records Approved or Rejected for a submitted request in the approvals queue "
             "(reference APR|<request reference>). Only approvers listed for the target environment may decide, never the requester "
             "(segregation of duties), and a request is decided once. Approving does not deploy.",
             paths + [Arg("in", "in_RequestReference", "S", "Request reference (AM|...)."), Arg("in", "in_Decision", "S", "Approved | Rejected"),
                      Arg("in", "in_Comment", "S", "Reason / CAB reference."), Arg("out", "out_Message", "S", "Outcome.")],
             Seq("Approve request", load + [
                 If('strConfigError <> ""', Throw("New BusinessRuleException(strConfigError)", "Configuration error")),
                 Assign('dicSession("requestReference")', "in_RequestReference", "O"),
                 Invoke("Requests/Find_Queue_Item.xaml", dict(sess, in_QueueName='joConfig.SelectToken("governance.requestsQueue").ToString()', in_Reference="in_RequestReference", out_Found="boolFound", out_ItemJson="strItem"), name="Find request"),
                 If("Not boolFound", Throw('New BusinessRuleException("Request " & in_RequestReference & " was not found.")', "Unknown request")),
                 Code("QueueItem", {"in_Mode": '"parse"', "in_QueueName": '""', "in_Reference": '""', "in_Content": "Nothing", "in_ItemJson": "strItem", "out_Body": "strIgnore", "out_Content": "joItem"}, "Read request"),
                 Assign("joRequest", 'CType(joItem("Request"), JObject)', "JO"),
                 Assign('dicSession("botId")', 'joRequest.Value(Of String)("botId")', "O"),
                 Assign("strTarget", 'joRequest.Value(Of String)("targetEnvironment")', "S"),
                 Code("CheckAuthorization", {"in_User": "strUser", "in_Allowed": 'TryCast(joConfig.SelectToken("authorization.approvers." & strTarget), JArray)', "out_Allowed": "boolApprover"}, "Is approver?"),
                 If("Not boolApprover", Throw('New BusinessRuleException(strUser & " is not an approver for " & strTarget & ".")', "Not an approver")),
                 If('CBool(joConfig.SelectToken("authorization.segregationOfDuties")) AndAlso String.Equals(strUser, joRequest.Value(Of String)("requestedBy"), StringComparison.OrdinalIgnoreCase)',
                    Throw('New BusinessRuleException("Segregation of duties: the requester cannot approve their own request.")', "Own request")),
                 If('in_Decision <> "Approved" AndAlso in_Decision <> "Rejected"', Throw('New BusinessRuleException("Decision must be Approved or Rejected.")', "Bad decision")),
                 If('String.IsNullOrWhiteSpace(in_Comment)', Throw('New BusinessRuleException("A comment (reason or CAB reference) is required.")', "No comment")),
                 Assign("joContent", 'New JObject(New JProperty("RequestReference", in_RequestReference), New JProperty("Decision", in_Decision), New JProperty("Approver", strUser), New JProperty("Comment", in_Comment), New JProperty("ApprovedVersion", joRequest.SelectToken("package.requestedVersion").ToString()), New JProperty("TargetEnvironment", strTarget), New JProperty("ApprovedAtUtc", DateTime.UtcNow.ToString("o")))', "JO"),
                 Invoke("Requests/Add_Queue_Item.xaml", dict(sess, in_QueueName='joConfig.SelectToken("governance.approvalsQueue").ToString()', in_Reference='Left("APR|" & in_RequestReference, 128)', in_Content="joContent", out_Duplicate="boolDuplicate", out_ItemJson="strItem"), name="Record decision"),
                 Assign("out_Message", 'If(boolDuplicate, "This request was already decided; the existing decision stands.", in_Decision & " by " & strUser & " for version " & joRequest.SelectToken("package.requestedVersion").ToString() & " to " & strTarget & ".")', "S"),
                 Invoke("Framework/Write_Audit_Log.xaml", dict(sess, in_Operation='"Approval " & in_RequestReference', in_Status='If(boolDuplicate, "NoChange", in_Decision)', in_Message="out_Message", in_Data="Nothing"), name="Audit decision"),
                 Log("Info", "out_Message"),
             ], vars=lvars + [Var("boolFound", "B"), Var("strItem", "S"), Var("strIgnore", "S"), Var("joItem", "JO"), Var("joRequest", "JO"), Var("strTarget", "S"),
                              Var("boolApprover", "B"), Var("joContent", "JO"), Var("boolDuplicate", "B")]))
