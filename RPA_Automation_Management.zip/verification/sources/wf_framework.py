"""Framework\\*.xaml: configuration, tokens, the single HTTP entry point, paging, error handling and audit."""
from xamlgen import Workflow, Arg, Var, Seq, Assign, Log, If, Try, ForEach, DoWhile, Invoke, Code, Throw, GetCredential, Rethrow

CFG = [Arg("in", "in_Config", "JO", "Settings + bot mapping from Framework\\Load_Configuration.xaml."),
       Arg("in", "in_Session", "DSO", "Run context shared by all workflows: token cache, user, request reference, step list. Never persisted.")]


def q(s):
    """Python text -> VB string literal."""
    return '"' + s.replace('"', '""') + '"'


def odq(expr):
    """VB expression -> same text with OData single quotes doubled."""
    return f'{expr}.Replace("\'", "\'\'")'


def ctx(**kw):
    d = {"in_Config": "in_Config", "in_Session": "in_Session"}
    d.update(kw)
    return d


def api(method, url, name, env="in_Environment", provider='"UiPath"', folder="0L", body='""', accept='""', upload='""', download='""',
        status="intStatus", resp="strBody"):
    """Invoke Framework\\Send_Api_Request.xaml (needs variables intStatus/strBody or the names given)."""
    return Invoke("Framework/Send_Api_Request.xaml", ctx(
        in_Provider=provider, in_Environment=env, in_Method=q(method), in_Url=url, in_FolderId=folder, in_Body=body,
        in_ApiName=q(name), in_AcceptStatuses=accept, in_UploadFilePath=upload, in_DownloadFilePath=download,
        out_StatusCode=status, out_ResponseBody=resp), name=name)


def collection(url, name, out, env="in_Environment", provider='"UiPath"', folder="0L", mode='"skip"', not_found="False"):
    return Invoke("Framework/Get_OData_Collection.xaml", ctx(
        in_Provider=provider, in_Environment=env, in_Url=url, in_FolderId=folder, in_ApiName=q(name), in_PageMode=mode,
        in_AcceptNotFound=not_found, out_Items=out), name=name)


def audit(op, status, message, data="Nothing"):
    return Invoke("Framework/Write_Audit_Log.xaml", ctx(in_Operation=op, in_Status=status, in_Message=message, in_Data=data),
                  name="Audit: " + (op.strip('"') if op.startswith('"') else "operation"))


def build():
    Workflow("Framework/Load_Configuration.xaml",
             "Reads Config\\Settings.json and Config\\BotMapping.json, merges them and checks the structure. "
             "Returns a message instead of throwing so the caller can tell the user; no credentials are read here.",
             [Arg("in", "in_SettingsPath", "S", "Settings file (absolute or relative to the project folder)."),
              Arg("in", "in_BotMappingPath", "S", "Bot ID mapping file."),
              Arg("out", "out_Config", "JO", "Merged configuration; Nothing when out_ErrorMessage is set."),
              Arg("out", "out_ErrorMessage", "S", "Empty when usable.")],
             Seq("Load configuration", [
                 Code("ConfigLoad", {"in_SettingsPath": "in_SettingsPath", "in_BotMappingPath": "in_BotMappingPath", "out_Config": "out_Config", "out_Error": "strProblems"},
                      "Read, merge and check configuration"),
                 If('strProblems <> ""',
                    Seq("Configuration not usable", [
                        Log("Error", '"Configuration problem: " & strProblems'),
                        Assign("out_ErrorMessage", '"The Automation Management configuration is not valid: " & strProblems', "S")]),
                    Seq("Configuration loaded", [
                        Assign("out_ErrorMessage", '""', "S"),
                        Log("Info", '"Configuration loaded: " & CType(out_Config("bots"), JArray).Count.ToString() & " bot mapping(s), " & CType(out_Config("deploymentPaths"), JArray).Count.ToString() & " deployment path(s)"')]))
             ], vars=[Var("strProblems", "S")]))

    Workflow("Framework/Get_Access_Token.xaml",
             "Returns a bearer token for one provider and environment. Client credentials grant: UiPath Identity Server of the "
             "standalone Orchestrator ({orchestrator}/identity/connect/token) or Microsoft Entra ID (Dataverse). The client ID and "
             "secret come from an Orchestrator Credential asset (Username = client ID, Password = client secret); the token is "
             "cached in in_Session only and never logged.",
             CFG + [Arg("in", "in_Provider", "S", "UiPath | PowerAutomate"),
                    Arg("in", "in_Environment", "S", "Dev | UAT | Prod"),
                    Arg("out", "out_AccessToken", "SEC", "Bearer token.")],
             Seq("Get access token", [
                 Code("ResolveEndpoint", {"in_Config": "in_Config", "in_Provider": "in_Provider", "in_Environment": "in_Environment",
                                          "out_BaseUrl": "strBaseUrl", "out_TenantName": "strTenant", "out_ExtraHeadersJson": "strHeaders",
                                          "out_TimeoutSeconds": "intTimeout", "out_RetryCount": "intRetries", "out_RetryDelaySeconds": "intDelay",
                                          "out_TokenKey": "strTokenKey", "out_TokenUrl": "strTokenUrl", "out_CredentialAsset": "strAsset",
                                          "out_CredentialFolder": "strAssetFolder", "out_Scope": "strScope"}, "Resolve environment settings"),
                 Code("TokenCache", {"in_Mode": '"get"', "in_Session": "in_Session", "in_Key": "strTokenKey", "io_Token": "out_AccessToken",
                                     "in_ExpiresAtUtc": "DateTime.MinValue", "out_Found": "boolCached"}, "Token cache lookup"),
                 If("Not boolCached", Seq("Request a new token", [
                     GetCredential("strAsset", "strAssetFolder", "strClientId", "secClientSecret", "Get API client credential"),
                     Code("TokenRequest", {"in_TokenUrl": "strTokenUrl", "in_ClientId": "strClientId", "in_ClientSecret": "secClientSecret",
                                           "in_Scope": "strScope", "in_TimeoutSeconds": "intTimeout", "in_RetryCount": "intRetries",
                                           "in_RetryDelaySeconds": "intDelay", "out_AccessToken": "out_AccessToken", "out_ExpiresAtUtc": "dtExpires"},
                          "Client credentials token request"),
                     Code("TokenCache", {"in_Mode": '"put"', "in_Session": "in_Session", "in_Key": "strTokenKey", "io_Token": "out_AccessToken",
                                         "in_ExpiresAtUtc": "dtExpires", "out_Found": "boolCached"}, "Cache token"),
                     Log("Info", '"Access token acquired for " & strTokenKey & " (valid until " & dtExpires.ToString("u") & ")"'),
                 ]))
             ], vars=[Var(n, "S") for n in ["strBaseUrl", "strTenant", "strHeaders", "strTokenKey", "strTokenUrl", "strAsset", "strAssetFolder", "strScope", "strClientId"]]
                + [Var(n, "I") for n in ["intTimeout", "intRetries", "intDelay"]] + [Var("boolCached", "B"), Var("secClientSecret", "SEC"), Var("dtExpires", "DTM")]))

    Workflow("Framework/Handle_API_Exception.xaml",
             "Classifies a failed HTTP response and throws the matching exception: 401/403 -> UnauthorizedAccessException "
             "(never retried), 400/404/409 -> BusinessRuleException, everything else -> Exception. The message carries method, "
             "path, status, error code and correlation ID, with anything that looks like a credential masked.",
             [Arg("in", "in_StatusCode", "I", "HTTP status."), Arg("in", "in_ResponseBody", "S", "Response body."),
              Arg("in", "in_Method", "S", "HTTP method."), Arg("in", "in_Url", "S", "Request URL (query string is dropped from the message)."),
              Arg("in", "in_ApiName", "S", "Operation name for the log."), Arg("in", "in_CorrelationId", "S", "Server correlation ID.")],
             Seq("Handle API exception", [
                 Code("ClassifyApiError", {"in_StatusCode": "in_StatusCode", "in_ResponseBody": "in_ResponseBody", "in_Method": "in_Method", "in_Url": "in_Url",
                                           "in_ApiName": "in_ApiName", "in_CorrelationId": "in_CorrelationId", "out_Category": "strCategory",
                                           "out_ErrorCode": "strCode", "out_ErrorMessage": "strMessage", "out_IsTransient": "boolTransient", "out_Summary": "strSummary"},
                      "Classify API error"),
                 Log("Error", "strSummary"),
                 If('strCategory = "Authentication" OrElse strCategory = "Authorization"',
                    Throw('New UnauthorizedAccessException(strSummary & If(strCategory = "Authorization", " - the API account lacks a role or scope for this operation.", " - check the client credential asset and the allowed scopes."))', "Throw authentication/authorization error"),
                    If('strCategory = "Validation" OrElse strCategory = "NotFound" OrElse strCategory = "Conflict"',
                       Throw("New BusinessRuleException(strSummary)", "Throw business error"),
                       Throw("New Exception(strSummary)", "Throw system error")))
             ], vars=[Var(n, "S") for n in ["strCategory", "strCode", "strMessage", "strSummary"]] + [Var("boolTransient", "B")]))

    Workflow("Framework/Send_Api_Request.xaml",
             "Single entry point for every Orchestrator and Dataverse call. Resolves the environment URL, adds the bearer token, "
             "the folder header (X-UIPATH-OrganizationUnitId) and the tenant header, retries only transient failures "
             "(429/5xx/timeouts, exponential back-off, Retry-After), re-authenticates once on 401, logs method/path/status/duration "
             "(never bodies or tokens) and hands non-accepted error statuses to Handle_API_Exception.xaml.",
             CFG + [Arg("in", "in_Provider", "S", "UiPath | PowerAutomate"), Arg("in", "in_Environment", "S", "Dev | UAT | Prod"),
                    Arg("in", "in_Method", "S", "GET, POST, PUT, PATCH or DELETE."),
                    Arg("in", "in_Url", "S", "Path relative to the environment base URL (e.g. odata/Assets?...) or an absolute URL (paging links)."),
                    Arg("in", "in_FolderId", "L", "Orchestrator folder ID for folder-scoped calls; 0 = none."),
                    Arg("in", "in_Body", "S", "JSON body; empty for none. Never logged."),
                    Arg("in", "in_ApiName", "S", "Operation name for logs and errors."),
                    Arg("in", "in_AcceptStatuses", "S", "Comma-separated non-2xx statuses the caller handles itself, e.g. \"404,409\"."),
                    Arg("in", "in_UploadFilePath", "S", "File sent as multipart field 'file' (package upload); empty for none."),
                    Arg("in", "in_DownloadFilePath", "S", "Save a 2xx response body to this file (package download); empty for none."),
                    Arg("out", "out_StatusCode", "I", "HTTP status."), Arg("out", "out_ResponseBody", "S", "Response body.")],
             Seq("Send API request", [
                 Code("ResolveEndpoint", {"in_Config": "in_Config", "in_Provider": "in_Provider", "in_Environment": "in_Environment",
                                          "out_BaseUrl": "strBaseUrl", "out_TenantName": "strTenant", "out_ExtraHeadersJson": "strHeaders",
                                          "out_TimeoutSeconds": "intTimeout", "out_RetryCount": "intRetries", "out_RetryDelaySeconds": "intDelay",
                                          "out_TokenKey": "strTokenKey", "out_TokenUrl": "strTokenUrl", "out_CredentialAsset": "strAsset",
                                          "out_CredentialFolder": "strAssetFolder", "out_Scope": "strScope"}, "Resolve environment settings"),
                 Assign("strFullUrl", 'If(in_Url.StartsWith("https://", StringComparison.OrdinalIgnoreCase) OrElse in_Url.StartsWith("http://", StringComparison.OrdinalIgnoreCase), in_Url, strBaseUrl & in_Url)', "S", "Full URL"),
                 Invoke("Framework/Get_Access_Token.xaml", ctx(in_Provider="in_Provider", in_Environment="in_Environment", out_AccessToken="secToken"), name="Get access token"),
                 Code("HttpSend", {"in_Method": "in_Method", "in_Url": "strFullUrl", "in_Body": "in_Body", "in_AccessToken": "secToken", "in_FolderId": "in_FolderId",
                                   "in_TenantName": "strTenant", "in_ExtraHeadersJson": "strHeaders", "in_TimeoutSeconds": "intTimeout", "in_RetryCount": "intRetries",
                                   "in_RetryDelaySeconds": "intDelay", "in_UploadFilePath": "in_UploadFilePath", "in_DownloadFilePath": "in_DownloadFilePath",
                                   "out_StatusCode": "out_StatusCode", "out_ResponseBody": "out_ResponseBody", "out_CorrelationId": "strCorrelation",
                                   "out_Attempts": "intAttempts", "out_DurationMs": "lngDuration"}, "HTTP request"),
                 If("out_StatusCode = 401", Seq("Token rejected: re-authenticate once", [
                     Log("Warn", '"HTTP 401 from " & in_ApiName & "; requesting a new token and retrying once"'),
                     Code("TokenCache", {"in_Mode": '"drop"', "in_Session": "in_Session", "in_Key": "strTokenKey", "io_Token": "secToken",
                                         "in_ExpiresAtUtc": "DateTime.MinValue", "out_Found": "boolFound"}, "Forget rejected token"),
                     Invoke("Framework/Get_Access_Token.xaml", ctx(in_Provider="in_Provider", in_Environment="in_Environment", out_AccessToken="secToken"), name="Get new access token"),
                     Code("HttpSend", {"in_Method": "in_Method", "in_Url": "strFullUrl", "in_Body": "in_Body", "in_AccessToken": "secToken", "in_FolderId": "in_FolderId",
                                       "in_TenantName": "strTenant", "in_ExtraHeadersJson": "strHeaders", "in_TimeoutSeconds": "intTimeout", "in_RetryCount": "intRetries",
                                       "in_RetryDelaySeconds": "intDelay", "in_UploadFilePath": "in_UploadFilePath", "in_DownloadFilePath": "in_DownloadFilePath",
                                       "out_StatusCode": "out_StatusCode", "out_ResponseBody": "out_ResponseBody", "out_CorrelationId": "strCorrelation",
                                       "out_Attempts": "intAttempts", "out_DurationMs": "lngDuration"}, "HTTP request (retry after 401)")])),
                 Log("Trace", '"[" & in_ApiName & "] " & in_Environment & " " & in_Method.ToUpperInvariant() & " " & strFullUrl.Split("?"c)(0) & " -> " & out_StatusCode.ToString() & " (" & lngDuration.ToString() & " ms, " & intAttempts.ToString() & " attempt(s)" & If(strCorrelation <> "", ", correlation " & strCorrelation, "") & ")"'),
                 If('(out_StatusCode < 200 OrElse out_StatusCode > 299) AndAlso Not in_AcceptStatuses.Split(","c).Select(Function(s) s.Trim()).Contains(out_StatusCode.ToString())',
                    Invoke("Framework/Handle_API_Exception.xaml", {"in_StatusCode": "out_StatusCode", "in_ResponseBody": "out_ResponseBody", "in_Method": "in_Method",
                                                                   "in_Url": "strFullUrl", "in_ApiName": "in_ApiName", "in_CorrelationId": "strCorrelation"}, name="Handle API exception"))
             ], vars=[Var(n, "S") for n in ["strBaseUrl", "strTenant", "strHeaders", "strTokenKey", "strTokenUrl", "strAsset", "strAssetFolder", "strScope", "strFullUrl", "strCorrelation"]]
                + [Var(n, "I") for n in ["intTimeout", "intRetries", "intDelay", "intAttempts"]] + [Var("lngDuration", "L"), Var("secToken", "SEC"), Var("boolFound", "B")]))

    Workflow("Framework/Get_OData_Collection.xaml",
             "Reads every page of an OData collection. Orchestrator: $top/$skip with settings.http.pageSize until a short page. "
             "Dataverse: follows @odata.nextLink. Stops at settings.http.maxPages with a warning.",
             CFG + [Arg("in", "in_Provider", "S", "UiPath | PowerAutomate"), Arg("in", "in_Environment", "S", "Dev | UAT | Prod"),
                    Arg("in", "in_Url", "S", "Relative collection URL, may already contain $filter/$select (no $top/$skip)."),
                    Arg("in", "in_FolderId", "L", "Folder header; 0 = none."), Arg("in", "in_ApiName", "S", "Operation name."),
                    Arg("in", "in_PageMode", "S", "skip (Orchestrator) | nextLink (Dataverse)"),
                    Arg("in", "in_AcceptNotFound", "B", "True: HTTP 404 returns an empty list instead of failing."),
                    Arg("out", "out_Items", "JA", "All items.")],
             Seq("Get OData collection", [
                 Assign("out_Items", "New JArray()", "JA"),
                 Assign("intPageSize", 'CInt(in_Config.SelectToken("http.pageSize"))', "I"),
                 Assign("intMaxPages", 'CInt(in_Config.SelectToken("http.maxPages"))', "I"),
                 Assign("intSkip", "0", "I"), Assign("intPages", "0", "I"), Assign("strNext", '""', "S"),
                 DoWhile('intPages < intMaxPages AndAlso ((in_PageMode = "skip" AndAlso intPageCount = intPageSize) OrElse (in_PageMode = "nextLink" AndAlso strNext <> ""))',
                         Seq("Read one page", [
                             Assign("strPageUrl", 'If(in_PageMode = "nextLink", If(strNext <> "", strNext, in_Url), in_Url & If(in_Url.Contains("?"), "&", "?") & "$top=" & intPageSize.ToString() & "&$skip=" & intSkip.ToString())', "S", "Page URL"),
                             Invoke("Framework/Send_Api_Request.xaml", ctx(in_Provider="in_Provider", in_Environment="in_Environment", in_Method='"GET"', in_Url="strPageUrl",
                                                                         in_FolderId="in_FolderId", in_Body='""', in_ApiName="in_ApiName",
                                                                         in_AcceptStatuses='If(in_AcceptNotFound, "404", "")', in_UploadFilePath='""', in_DownloadFilePath='""',
                                                                         out_StatusCode="intStatus", out_ResponseBody="strBody"), name="GET page"),
                             If("intStatus = 404", Seq("Not found: empty", [Assign("intPageCount", "0", "I"), Assign("strNext", '""', "S")]),
                                Code("ParsePage", {"in_ResponseBody": "strBody", "io_Items": "out_Items", "out_NextUrl": "strNext", "out_PageCount": "intPageCount"}, "Append page")),
                             Assign("intSkip", "intSkip + intPageCount", "I"),
                             Assign("intPages", "intPages + 1", "I")])),
                 If('intPages >= intMaxPages AndAlso (intPageCount = intPageSize OrElse strNext <> "")',
                    Log("Warn", '"[" & in_ApiName & "] stopped after " & intMaxPages.ToString() & " pages; results may be incomplete (raise http.maxPages)"'))
             ], vars=[Var("intPageSize", "I"), Var("intMaxPages", "I"), Var("intSkip", "I"), Var("intPages", "I"), Var("intPageCount", "I"), Var("intStatus", "I"),
                      Var("strNext", "S"), Var("strPageUrl", "S"), Var("strBody", "S")]))

    Workflow("Framework/Write_Audit_Log.xaml",
             "Writes one audit record (JSON line in settings.audit.folder, robot log line and the run's step list). "
             "Request reference, Bot ID and user come from in_Session. Never pass secret values.",
             CFG + [Arg("in", "in_Operation", "S", "What was done, e.g. 'UAT asset INV_ApiBaseUrl'."),
                    Arg("in", "in_Status", "S", "Started | Succeeded | NoChange | Failed | Rejected | Submitted | Approved ..."),
                    Arg("in", "in_Message", "S", "Safe, human-readable detail."),
                    Arg("in", "in_Data", "JO", "Optional structured detail (no secrets); Nothing for none.")],
             Seq("Write audit log", [
                 Code("AuditLine", {"in_Config": "in_Config", "in_Session": "in_Session", "in_Operation": "in_Operation", "in_Status": "in_Status",
                                    "in_Message": "in_Message", "in_Data": "in_Data", "out_Line": "strLine"}, "Append audit line"),
                 If('in_Status = "Failed" OrElse in_Status = "Rejected"', Log("Warn", '"[audit] " & in_Operation & ": " & in_Status & " - " & in_Message'),
                    Log("Info", '"[audit] " & in_Operation & ": " & in_Status & " - " & in_Message'))
             ], vars=[Var("strLine", "S")]))
