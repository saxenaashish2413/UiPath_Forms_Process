"""Providers\\PowerAutomate\\*.xaml: Dataverse Web API (solutions are the deployable unit; flows are components)."""
from xamlgen import Workflow, Arg, Var, Seq, Assign, Log, If, Try, ForEach, DoWhile, Delay, Invoke, Code, Throw
from wf_framework import CFG, q, odq, ctx, api, collection, audit

PA = '"PowerAutomate"'
ENV = Arg("in", "in_Environment", "S", "Dev | UAT | Prod")
APIV = [Var("intStatus", "I"), Var("strBody", "S")]


def build():
    Workflow("Providers/PowerAutomate/PA_Get_Solution_Details.xaml",
             "Reads environment details and one solution. GET RetrieveCurrentOrganization(AccessType=@p)?@p=Microsoft.Dynamics.CRM."
             "EndpointAccessType'Default' (environment name and ID) and GET solutions?$filter=uniquename eq '<name>'&$select=solutionid,"
             "uniquename,friendlyname,version,ismanaged,description,modifiedon.",
             CFG + [ENV, Arg("in", "in_SolutionUniqueName", "S", "Solution unique name."),
                    Arg("out", "out_OrgJson", "S", "RetrieveCurrentOrganization response."), Arg("out", "out_SolutionJson", "S", "solutions collection response.")],
             Seq("Get solution details", [
                 api("GET", '"RetrieveCurrentOrganization(AccessType=@p)?@p=Microsoft.Dynamics.CRM.EndpointAccessType\'Default\'"', "GET RetrieveCurrentOrganization", provider=PA),
                 Assign("out_OrgJson", "strBody", "S"),
                 api("GET", '"solutions?$filter=" & Uri.EscapeDataString("uniquename eq \'" & ' + odq("in_SolutionUniqueName") + ' & "\'") & "&$select=solutionid,uniquename,friendlyname,version,ismanaged,description,modifiedon"',
                     "GET solutions by unique name", provider=PA),
                 Assign("out_SolutionJson", "strBody", "S"),
             ], vars=APIV))

    Workflow("Providers/PowerAutomate/PA_Get_Flows.xaml",
             "Cloud flows in a solution: GET solutioncomponents?$filter=_solutionid_value eq <id> and componenttype eq 29&$select=objectid "
             "(component type 29 = Workflow), then GET workflows?$filter=category eq 5 and (workflowid eq ... or ...)&$select=workflowid,name,statecode,statuscode.",
             CFG + [ENV, Arg("in", "in_SolutionId", "S", "solutionid (GUID)."), Arg("out", "out_FlowsJson", "S", "JSON array of workflow records.")],
             Seq("Get flows", [
                 collection('"solutioncomponents?$filter=" & Uri.EscapeDataString("_solutionid_value eq " & in_SolutionId & " and componenttype eq 29") & "&$select=objectid"',
                            "GET solutioncomponents (workflows)", "jaComponents", provider=PA, mode='"nextLink"'),
                 Assign("jaFlows", "New JArray()", "JA"),
                 If("jaComponents.Count > 0", Seq("Read flows", [
                     Assign("strIds", 'String.Join(" or ", jaComponents.Children(Of JObject)().Select(Function(c) "workflowid eq " & c.Value(Of String)("objectid")))', "S"),
                     collection('"workflows?$filter=" & Uri.EscapeDataString("category eq 5 and (" & strIds & ")") & "&$select=workflowid,name,statecode,statuscode"',
                                "GET workflows (cloud flows)", "jaFlows", provider=PA, mode='"nextLink"')])),
                 Assign("out_FlowsJson", "jaFlows.ToString(Newtonsoft.Json.Formatting.None)", "S"),
             ], vars=[Var("jaComponents", "JA"), Var("jaFlows", "JA"), Var("strIds", "S")]))

    Workflow("Providers/PowerAutomate/PA_Fetch_Bot_Configuration.xaml",
             "Power Automate provider: reads the mapped solution in Dev, UAT and Prod (version, managed state, environment name), "
             "the cloud flows of the Dev solution, and which versions already have a managed export in the artifact store. Nothing "
             "is shown that the API did not return.",
             CFG + [Arg("in", "in_Bot", "JO", "Bot ID mapping entry."), Arg("in", "in_ProcessType", "S", "New | Enhancement | Bug Fix"),
                    Arg("in", "in_DeploymentPath", "S", "Deployment path name."), Arg("out", "out_Details", "JO", "Details for the form.")],
             Seq("Fetch Power Automate bot configuration", [
                 Assign("joPath", 'in_Config("deploymentPaths").Children(Of JObject)().First(Function(p) p.Value(Of String)("name") = in_DeploymentPath)', "JO", "Deployment path"),
                 Assign("strSolution", 'in_Bot.SelectToken("powerAutomate.solutionUniqueName").ToString()', "S"),
                 Assign("joRaw", "New JObject()", "JO"),
                 Code("JsonPut", {"in_Target": "joRaw", "in_Key": '"bot"', "in_Json": "in_Bot.ToString()"}, "Keep mapping"),
                 Code("JsonPut", {"in_Target": "joRaw", "in_Key": '"processType"', "in_Json": "in_ProcessType"}, "Keep process type"),
                 Code("JsonPut", {"in_Target": "joRaw", "in_Key": '"deploymentPath"', "in_Json": "in_DeploymentPath"}, "Keep path"),
                 Code("JsonPut", {"in_Target": "joRaw", "in_Key": '"sourceEnv"', "in_Json": 'joPath.Value(Of String)("source")'}, "Keep source"),
                 Code("JsonPut", {"in_Target": "joRaw", "in_Key": '"targetEnv"', "in_Json": 'joPath.Value(Of String)("target")'}, "Keep target"),
                 ForEach("strEnv", "S", 'New String() {"Dev", "UAT", "Prod"}', Try("Try read environment", Seq("Read environment", [
                     Invoke("Providers/PowerAutomate/PA_Get_Solution_Details.xaml", ctx(in_Environment="strEnv", in_SolutionUniqueName="strSolution", out_OrgJson="strOrg", out_SolutionJson="strSol"), name="Get solution details"),
                     Code("JsonPut", {"in_Target": "joRaw", "in_Key": 'strEnv & ".org"', "in_Json": "strOrg"}, "Keep environment"),
                     Code("JsonPut", {"in_Target": "joRaw", "in_Key": 'strEnv & ".solution"', "in_Json": "strSol"}, "Keep solution"),
                     If('strEnv = "Dev" AndAlso JObject.Parse(strSol)("value").Count() > 0', Seq("Dev flows", [
                         Invoke("Providers/PowerAutomate/PA_Get_Flows.xaml", ctx(in_Environment="strEnv", in_SolutionId='JObject.Parse(strSol).SelectToken("value[0].solutionid").ToString()', out_FlowsJson="strFlows"), name="Get flows"),
                         Code("JsonPut", {"in_Target": "joRaw", "in_Key": '"Dev.flows"', "in_Json": "strFlows"}, "Keep flows")]))]),
                     [("EX", "exEnv", Seq("Environment not readable", [
                         Log("Warn", '"Could not read Power Platform " & strEnv & " for Bot ID " & in_Bot.Value(Of String)("botId") & ": " & exEnv.Message'),
                         Code("JsonPut", {"in_Target": "joRaw", "in_Key": 'strEnv & ".error"', "in_Json": "exEnv.Message"}, "Keep error")]))]), name="For each environment"),
                 Code("SolutionArtifact", {"in_Mode": '"list"', "in_Store": 'in_Config.SelectToken("powerAutomate.solutionArtifactStore").ToString()', "in_Solution": "strSolution",
                                           "in_Version": '""', "in_Base64": '""', "out_Base64": "strIgnore", "out_Sha256": "strIgnore", "out_Versions": "jaArtifacts"}, "Exported versions in artifact store"),
                 Code("JsonPut", {"in_Target": "joRaw", "in_Key": '"artifactVersions"', "in_Json": "jaArtifacts.ToString()"}, "Keep artifact versions"),
                 Code("BuildPaDetails", {"in_Config": "in_Config", "in_Raw": "joRaw", "out_Details": "out_Details"}, "Build details"),
                 Log("Info", '"Power Automate details for " & in_Bot.Value(Of String)("botId") & ": " & out_Details.Value(Of String)("status") & " - " & out_Details.Value(Of String)("message")'),
             ], vars=[Var("joPath", "JO"), Var("joRaw", "JO"), Var("strSolution", "S"), Var("strOrg", "S"), Var("strSol", "S"), Var("strFlows", "S"), Var("strIgnore", "S"), Var("jaArtifacts", "JA")]))

    Workflow("Providers/PowerAutomate/PA_Deploy_Solution.xaml",
             "Deploys a solution version. Dev -> UAT: checks the Dev version, POST ExportSolution {SolutionName, Managed: true}, "
             "stores the managed file with its SHA-256 in the artifact store. UAT -> Prod: loads that stored file (hash checked) "
             "and requires the same version to be installed in UAT. Then POST ImportSolutionAsync {CustomizationFile, "
             "OverwriteUnmanagedCustomizations: false, PublishWorkflows: true, ImportJobId, ComponentParameters: []}, polls "
             "asyncoperations(<id>) until statecode 3 (statuscode 30 = succeeded) and reads the target solution version back. "
             "Skipped when the target already has the version (idempotent). Approval for Prod is checked by the caller.",
             CFG + [Arg("in", "in_Request", "JO", "Validated request."), Arg("out", "out_Result", "JO", "Result with 'objects'.")],
             Seq("Deploy solution", [
                 Assign("out_Result", "New JObject()", "JO"),
                 Assign("strSource", 'in_Request.Value(Of String)("sourceEnvironment")', "S"),
                 Assign("strTarget", 'in_Request.Value(Of String)("targetEnvironment")', "S"),
                 Assign("strVersion", 'in_Request.SelectToken("package.requestedVersion").ToString()', "S"),
                 Assign("strSolution", 'in_Request.SelectToken("package.packageName").ToString()', "S"),
                 Assign("strStore", 'in_Config.SelectToken("powerAutomate.solutionArtifactStore").ToString()', "S"),
                 Invoke("Providers/PowerAutomate/PA_Get_Solution_Details.xaml", ctx(in_Environment="strTarget", in_SolutionUniqueName="strSolution", out_OrgJson="strOrg", out_SolutionJson="strSol"), name="Target solution"),
                 Assign("strInstalled", 'Convert.ToString(JObject.Parse(strSol).SelectToken("value[0].version"))', "S"),
                 If("strInstalled = strVersion",
                    Seq("Already installed", [
                        Code("StepResult", {"in_Result": "out_Result", "in_Kind": '"Solution"', "in_Name": 'strSolution & " " & strVersion', "in_Change": '"NoChange"', "in_Message": '"Already installed in " & strTarget'}, "Record"),
                        audit('strTarget & " solution " & strSolution', '"NoChange"', '"Version " & strVersion & " already installed"')]),
                    Seq("Export and import", [
                        If('strSource = "Dev"',
                           Seq("Export managed solution from Dev", [
                               Invoke("Providers/PowerAutomate/PA_Get_Solution_Details.xaml", ctx(in_Environment='"Dev"', in_SolutionUniqueName="strSolution", out_OrgJson="strOrg", out_SolutionJson="strSol"), name="Dev solution"),
                               If('Convert.ToString(JObject.Parse(strSol).SelectToken("value[0].version")) <> strVersion',
                                  Throw('New BusinessRuleException("Source package unavailable: solution " & strSolution & " in Dev is not at version " & strVersion & ".")', "Version changed in Dev")),
                               api("POST", '"ExportSolution"', "POST ExportSolution (managed)", env='"Dev"', provider=PA,
                                   body='New JObject(New JProperty("SolutionName", strSolution), New JProperty("Managed", True)).ToString(Newtonsoft.Json.Formatting.None)'),
                               Code("SolutionArtifact", {"in_Mode": '"save"', "in_Store": "strStore", "in_Solution": "strSolution", "in_Version": "strVersion",
                                                         "in_Base64": 'JObject.Parse(strBody).Value(Of String)("ExportSolutionFile")', "out_Base64": "strIgnore", "out_Sha256": "strSha", "out_Versions": "jaIgnore"}, "Store managed file"),
                               Assign("strBody", '""', "S", "Release export payload"),
                               audit('"Dev solution export " & strSolution & " " & strVersion', '"Succeeded"', '"Managed file stored (SHA-256 " & strSha & ")"')]),
                           Seq("Use the managed file exported for UAT", [
                               Invoke("Providers/PowerAutomate/PA_Get_Solution_Details.xaml", ctx(in_Environment="strSource", in_SolutionUniqueName="strSolution", out_OrgJson="strOrg", out_SolutionJson="strSol"), name="Source solution"),
                               If('Convert.ToString(JObject.Parse(strSol).SelectToken("value[0].version")) <> strVersion',
                                  Throw('New BusinessRuleException("Version " & strVersion & " is not the version installed in " & strSource & ".")', "Not the tested version"))])),
                        Code("SolutionArtifact", {"in_Mode": '"load"', "in_Store": "strStore", "in_Solution": "strSolution", "in_Version": "strVersion",
                                                  "in_Base64": '""', "out_Base64": "strFile", "out_Sha256": "strSha", "out_Versions": "jaIgnore"}, "Load managed file (hash checked)"),
                        Assign("strJobId", "Guid.NewGuid().ToString()", "S"),
                        api("POST", '"ImportSolutionAsync"', "POST ImportSolutionAsync", env="strTarget", provider=PA,
                            body='New JObject(New JProperty("OverwriteUnmanagedCustomizations", False), New JProperty("PublishWorkflows", True), New JProperty("CustomizationFile", strFile), New JProperty("ImportJobId", strJobId), New JProperty("ComponentParameters", New JArray())).ToString(Newtonsoft.Json.Formatting.None)'),
                        Assign("strFile", '""', "S", "Release file content"),
                        Assign("strAsync", 'JObject.Parse(strBody).Value(Of String)("AsyncOperationId")', "S"),
                        Assign("dtDeadline", 'DateTime.UtcNow.AddMinutes(CDbl(in_Config.SelectToken("powerAutomate.asyncTimeoutMinutes")))', "DTM"),
                        Assign("intState", "0", "I"),
                        DoWhile('intState <> 3 AndAlso DateTime.UtcNow < dtDeadline', Seq("Poll import", [
                            Delay('CDbl(in_Config.SelectToken("powerAutomate.asyncPollSeconds"))', "Wait before polling"),
                            api("GET", '"asyncoperations(" & strAsync & ")?$select=statecode,statuscode,message,friendlymessage"', "GET asyncoperations(id)", env="strTarget", provider=PA),
                            Assign("intState", 'JObject.Parse(strBody).Value(Of Integer)("statecode")', "I"),
                            Assign("intAsyncStatus", 'JObject.Parse(strBody).Value(Of Integer)("statuscode")', "I"),
                            Assign("strAsyncMessage", 'If(JObject.Parse(strBody).Value(Of String)("friendlymessage"), If(JObject.Parse(strBody).Value(Of String)("message"), ""))', "S")])),
                        If("intState <> 3", Throw('New TimeoutException("Solution import into " & strTarget & " did not finish within " & in_Config.SelectToken("powerAutomate.asyncTimeoutMinutes").ToString() & " minutes (async operation " & strAsync & ").")', "Import timed out")),
                        If("intAsyncStatus <> 30", Throw('New Exception("Solution import into " & strTarget & " failed (statuscode " & intAsyncStatus.ToString() & "): " & strAsyncMessage)', "Import failed")),
                        Invoke("Providers/PowerAutomate/PA_Get_Solution_Details.xaml", ctx(in_Environment="strTarget", in_SolutionUniqueName="strSolution", out_OrgJson="strOrg", out_SolutionJson="strSol"), name="Target solution (verify)"),
                        Assign("strInstalled", 'Convert.ToString(JObject.Parse(strSol).SelectToken("value[0].version"))', "S"),
                        If("strInstalled <> strVersion", Throw('New Exception("Deployment verification failed: " & strTarget & " has solution version " & If(strInstalled = "", "none", strInstalled) & " instead of " & strVersion & ". A managed solution cannot be downgraded automatically; fix forward or uninstall.")', "Verification failed")),
                        Code("StepResult", {"in_Result": "out_Result", "in_Kind": '"Solution"', "in_Name": 'strSolution & " " & strVersion', "in_Change": '"Updated"', "in_Message": '"Imported into " & strTarget & " (managed, SHA-256 " & strSha & ")"'}, "Record"),
                        Code("JsonPut", {"in_Target": "out_Result", "in_Key": '"packageSha256"', "in_Json": "strSha"}, "Keep SHA-256"),
                        audit('strTarget & " solution " & strSolution', '"Succeeded"', '"Version " & strVersion & " imported and verified"')])),
                 Code("JsonPut", {"in_Target": "out_Result", "in_Key": '"deployedVersion"', "in_Json": "strVersion"}, "Keep deployed version"),
             ], vars=APIV + [Var(n, "S") for n in ["strSource", "strTarget", "strVersion", "strSolution", "strStore", "strOrg", "strSol", "strInstalled", "strIgnore", "strSha", "strFile", "strJobId", "strAsync", "strAsyncMessage"]]
                + [Var("jaIgnore", "JA"), Var("dtDeadline", "DTM"), Var("intState", "I"), Var("intAsyncStatus", "I")]))
