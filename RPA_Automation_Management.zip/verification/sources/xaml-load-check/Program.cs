using System;
using System.Activities;
using System.Activities.XamlIntegration;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.Loader;

class Program
{
    static readonly HashSet<string> Missing = new(), Stubbed = new();
    static string Stubs = "";
    static int Main(string[] a)
    {
        string dlls = a[0], proj = a[1]; Stubs = Environment.GetEnvironmentVariable("STUBS") ?? "";
        AssemblyLoadContext.Default.Resolving += (ctx, name) =>
        {
            var p = Path.Combine(dlls, name.Name + ".dll");
            if (File.Exists(p)) return ctx.LoadFromAssemblyPath(p);
            var st = Path.Combine(Stubs, name.Name + ".dll");
            if (File.Exists(st)) { Stubbed.Add(name.Name); return ctx.LoadFromAssemblyPath(st); }
            Missing.Add(name.Name); return null;
        };
        foreach (var d in Directory.GetFiles(dlls, "*.dll")) AssemblyLoadContext.Default.LoadFromAssemblyPath(d);
        if (a.Length > 2)
        {
            foreach (var tn in a[2].Split(','))
            {
                var parts = tn.Split('@');
                try { var ty = Assembly.Load(parts[1]).GetType(parts[0], true); Console.WriteLine("type " + ty.FullName + " base " + ty.BaseType); foreach (var c in ty.GetConstructors()) ; Activator.CreateInstance(ty); Console.WriteLine("  created"); }
                catch (Exception ex) { Console.WriteLine("type " + tn + " -> " + ex.ToString().Split('\n')[0]); }
            }
            foreach (var asm in AppDomain.CurrentDomain.GetAssemblies().Where(x => x.GetName().Name.StartsWith("UiPath")))
                try { foreach (var at in asm.GetCustomAttributesData().Where(c => c.AttributeType.Name == "XmlnsDefinitionAttribute")) Console.WriteLine(asm.GetName().Name + ": " + string.Join(" -> ", at.ConstructorArguments.Select(c => c.Value))); }
                catch (Exception ex) { Console.WriteLine(asm.GetName().Name + " attrs: " + ex.Message); }
            return 0;
        }
        int bad = 0;
        var uiform = Environment.GetEnvironmentVariable("UIFORM");
        if (!string.IsNullOrEmpty(uiform))
        {
            // FormSerializer is internal to UiPath.Studio.Forms.Runtime; call it the way the Show Form runtime does.
            var rt = Assembly.Load("UiPath.Studio.Forms.Runtime");
            var ser = rt.GetType("UiPath.Studio.Forms.Runtime.FormSerializer", true);
            var schema = ser.GetMethod("Deserialize", BindingFlags.Public | BindingFlags.Static).Invoke(null, new object[] { File.ReadAllText(uiform) });
            var md = schema.GetType().GetProperty("Metadata").GetValue(schema);
            var dp = schema.GetType().GetProperty("DesignProperties").GetValue(schema);
            var data = (Newtonsoft.Json.Linq.JToken)schema.GetType().GetProperty("Data").GetValue(schema);
            string P(object x, string n) => x?.GetType().GetProperty(n)?.GetValue(x)?.ToString();
            var comps = data.SelectTokens("$..components[*]").Count();
            Console.WriteLine($"OK   {Path.GetFileName(uiform)} via {rt.GetName().Name} {rt.GetName().Version}: Id={P(md, "Id")} Kind={P(md, "Kind")} Title={P(dp, "Title")} Width={P(dp, "Width")} Height={P(dp, "Height")} components={comps}");
        }
        foreach (var f in Directory.GetFiles(proj, "*.xaml", SearchOption.AllDirectories).OrderBy(x => x))
        {
            var rel = Path.GetRelativePath(proj, f);
            try
            {
                var act = ActivityXamlServices.Load(f);
                var counts = new SortedDictionary<string, int>();
                Walk(act, counts, new HashSet<object>(ReferenceEqualityComparer.Instance));
                var errs = new List<string>();
                if (Environment.GetEnvironmentVariable("VALIDATE") == "1")
                {
                    // Compiles every VB expression (Roslyn, as the robot does) and checks variable scoping and argument types.
                    var res = System.Activities.Validation.ActivityValidationServices.Validate(act, new System.Activities.Validation.ValidationSettings { SkipValidatingRootConfiguration = false });
                    foreach (var e in res.Errors) errs.Add("       ERROR " + (e.Source?.DisplayName ?? "") + ": " + e.Message);
                    foreach (var w in res.Warnings) errs.Add("       warn  " + (w.Source?.DisplayName ?? "") + ": " + w.Message);
                }
                if (errs.Any(e => e.StartsWith("       ERROR"))) bad++;
                Console.WriteLine((errs.Any(e => e.StartsWith("       ERROR")) ? "FAIL " : "OK   ") + rel + (Environment.GetEnvironmentVariable("VALIDATE") == "1" ? "  (expressions compiled and validated)" : ""));
                foreach (var e in errs) Console.WriteLine(e);
                foreach (var kv in counts) Console.WriteLine($"       {kv.Value,3} x {kv.Key}");
                foreach (var dl in details) Console.WriteLine(dl);
                details.Clear();
            }
            catch (Exception ex)
            {
                bad++;
                Console.WriteLine($"FAIL {rel}: {ex.GetType().Name}: {ex.Message}"); for (var ie = ex.InnerException; ie != null; ie = ie.InnerException) Console.WriteLine("     inner " + ie.GetType().Name + ": " + ie.Message);
            }
        }
        if (Stubbed.Count > 0) Console.WriteLine("Empty test stubs used for Studio-internal assemblies not published on nuget.org: " + string.Join(", ", Stubbed.OrderBy(x => x)));
        if (Missing.Count > 0) Console.WriteLine("Unresolved references (not needed to load these types): " + string.Join(", ", Missing.OrderBy(x => x)));
        Console.WriteLine(bad == 0 ? "All workflows loaded" : $"{bad} workflow(s) failed");
        return bad;
    }

    // Walk the object graph produced by the XAML reader and count every activity type (keeps generic args for readability).
    static List<string> details = new();
    static void Walk(object o, IDictionary<string, int> counts, HashSet<object> seen)
    {
        if (o == null || o is string || o.GetType().IsPrimitive || !seen.Add(o)) return;
        var t = o.GetType();
        if (o is DynamicActivity da) { Walk(da.Implementation?.Invoke(), counts, seen); return; }
        if (o is Delegate) return;
        if (o is Activity && !t.Namespace.StartsWith("Microsoft.VisualBasic.Activities"))
        {
            var n = Name(t) + " [" + t.Assembly.GetName().Name + " " + t.Assembly.GetName().Version + "]";
            counts[n] = counts.TryGetValue(n, out var c) ? c + 1 : 1;
            if (t.Namespace == "UiPath.Forms.Activities" || t.Name == "TriggerScope")
            {
                var props = new List<string>();
                foreach (var p in t.GetProperties(BindingFlags.Public | BindingFlags.Instance).OrderBy(p => p.Name))
                {
                    object v; try { v = p.GetValue(o); } catch { continue; }
                    if (v == null) continue;
                    if (p.PropertyType == typeof(string) || p.PropertyType.IsEnum || p.PropertyType == typeof(bool)) { if (!(v is bool b && !b) && p.Name != "Id" && !p.Name.StartsWith("Display")) props.Add($"{p.Name}={v}"); }
                    else if (v is IDictionary d && d.Count > 0) props.Add($"{p.Name}[{string.Join(",", d.Keys.Cast<object>())}]");
                    else if (v is ActivityDelegate aa) props.Add($"{p.Name}=ActivityAction<{string.Join(",", aa.GetType().GetGenericArguments().Select(Name))}>({string.Join(",", aa.GetType().GetProperties().Where(x => x.PropertyType.Name.StartsWith("DelegateInArgument")).Select(x => (x.GetValue(aa) as DelegateArgument)?.Name))})");
                    else if (v is InArgument ia && ia.Expression != null) props.Add($"{p.Name}={ia.Expression.GetType().Name.Split('`')[0]}");
                    else if (p.Name == "Triggers" && v is IList tl) props.Add($"Triggers={tl.Count}");
                }
                details.Add("       " + Name(t).Replace("UiPath.Forms.Activities.", "").Replace("UiPath.Core.Activities.", "") + ": " + string.Join("; ", props));
            }
        }
        if (o is IEnumerable e && !(o is string)) { foreach (var x in e) Walk(x, counts, seen); }
        if (t.Namespace != null && (t.Namespace.StartsWith("System.Activities") || t.Namespace.StartsWith("UiPath")))
            foreach (var p in t.GetProperties(BindingFlags.Public | BindingFlags.Instance))
            {
                if (p.GetIndexParameters().Length > 0 || p.PropertyType.IsPrimitive || p.PropertyType == typeof(string)) continue;
                object v; try { v = p.GetValue(o); } catch { continue; }
                if (v is System.Collections.Generic.KeyValuePair<string, Argument>) continue;
                Walk(v, counts, seen);
            }
    }
    static string Name(Type t) => t.IsGenericType ? t.Name.Split('`')[0] + "<" + string.Join(",", t.GetGenericArguments().Select(Name)) + ">" : t.FullName;
}
