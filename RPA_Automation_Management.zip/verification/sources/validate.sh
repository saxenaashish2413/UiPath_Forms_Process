#!/bin/bash
# Loads every XAML with the real UiPath activity DLLs and compiles every expression (VALIDATE=1).
S=$(cd "$(dirname "$0")/.." && pwd)
cd $S/build/xaml-load-check && VALIDATE=1 STUBS=$S/stubdlls UIFORM=$UIFORM dotnet run -- $S/dlls $S/build/out/proj > $S/xaml-validate.raw 2>&1; echo exit $?
grep -E "^FAIL|ERROR|warn|All work|failed|rror" $S/xaml-validate.raw | cut -c1-400 | head -${1:-60}
