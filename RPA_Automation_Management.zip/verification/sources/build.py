"""Renders every workflow to XAML (UiPath project) and to one VB.NET module (test twin).
Usage: python3 build.py <project dir> <Workflows.vb>"""
import pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent))
import xamlgen as G
import wf_framework, wf_uipath, wf_pa, wf_requests, wf_entry
for m in (wf_framework, wf_uipath, wf_pa, wf_requests, wf_entry):
    m.build()
out = pathlib.Path(sys.argv[1])
for w in G.REGISTRY.values():
    p = out / w.path.replace("\\", "/")
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(G.render_xaml(w), encoding="utf-8")
skip = ("System.Activities", "System.Activities.Expressions", "System.Activities.Statements", "Microsoft.VisualBasic.Activities",
        "UiPath.Core.Activities", "UiPath.Forms.Activities", "UiPath.Web.Activities.Http")
vb = ["Option Strict On", "Option Explicit On", "Option Infer On"] + [f"Imports {n}" for n in G.NAMESPACES if n not in skip]
vb += ["Public Module Workflows"] + [G.render_vb(w) for w in G.REGISTRY.values()] + [G.render_code_subs(), "End Module"]
pathlib.Path(sys.argv[2]).write_text("\n".join(vb), encoding="utf-8")
print(len(G.REGISTRY), "workflows,", len(G.CODE_USES), "code bodies")
