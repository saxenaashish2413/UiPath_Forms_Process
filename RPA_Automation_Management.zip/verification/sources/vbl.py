"""Turns the logic files in vb/<Name>.vb into ordinary UiPath workflows (Logic\\<Name>.xaml) made only of standard
activities: Assign, If, For Each, Try Catch, Throw and Invoke Method. No Invoke Code is generated.

The files use a small, statement-per-line subset of VB.NET:
  'ARG in|out|io <name> <type code>     workflow arguments (type codes as in xamlgen.T)
  ' text                                annotation (and display name) for the next step; the one comment line
                                        right after the ARG lines is the workflow's own annotation
  Dim x As T = expr / Dim x As New T(...) / Dim x As T
  target = expr   target += expr   target &= expr
  If cond Then ... ElseIf cond Then ... Else ... End If      (also single-line  If cond Then <statement>)
  For Each x As T In expr ... Next
  Try ... Catch ex As T ... End Try
  Throw expr
  obj.Add(expr)                         Invoke Method Add (parameter type from obj's declared type)
  Target.Method(expr As T, ...)         Invoke Method with explicit parameter types (System.IO.File/Directory are static)
Not allowed (they have no activity equivalent): Return, Continue For, Exit For, Select Case, multi-line lambdas and
lambdas stored in variables (a stored lambda would read workflow variables after its activity has finished).
"""
import re
import xamlgen as G

STATIC = {"System.IO.File": "sio:File", "System.IO.Directory": "sio:Directory"}

SIMPLE = {
    "String": "x:String", "Integer": "x:Int32", "Long": "x:Int64", "Boolean": "x:Boolean", "Double": "x:Double",
    "Decimal": "x:Decimal", "Object": "x:Object", "Char": "x:Char", "Byte": "x:Byte",
    "DateTime": "s:DateTime", "Date": "s:DateTime", "TimeSpan": "s:TimeSpan", "Guid": "s:Guid",
    "Exception": "s:Exception", "ArgumentException": "s:ArgumentException", "SystemException": "s:SystemException",
    "InvalidOperationException": "s:InvalidOperationException", "FileNotFoundException": "sio:FileNotFoundException",
    "JObject": "njl:JObject", "JArray": "njl:JArray", "JToken": "njl:JToken", "JProperty": "njl:JProperty", "JValue": "njl:JValue",
    "JsonException": "nj:JsonException", "JsonReaderException": "nj:JsonReaderException",
    "List": "scg:List", "Dictionary": "scg:Dictionary", "KeyValuePair": "scg:KeyValuePair", "IEnumerable": "scg:IEnumerable",
    "HashSet": "scg:HashSet", "Func": "s:Func", "SecureString": "ss:SecureString", "CultureInfo": "sg:CultureInfo",
}


def strip_ns(name):
    for p in ("Newtonsoft.Json.Linq.", "Newtonsoft.Json.", "System.Collections.Generic.", "System.Globalization.", "System.Security.", "System."):
        if name.startswith(p):
            return name[len(p):]
    return name


def split_top(s, sep=","):
    """Split at top-level separators (outside parentheses, braces and strings)."""
    out, depth, cur, i, instr = [], 0, "", 0, False
    while i < len(s):
        c = s[i]
        if c == '"':
            instr = not instr
        elif not instr:
            if c in "({":
                depth += 1
            elif c in ")}":
                depth -= 1
            elif depth == 0 and s.startswith(sep, i):
                out.append(cur)
                cur, i = "", i + len(sep)
                continue
        cur += c
        i += 1
    out.append(cur)
    return [x.strip() for x in out]


def depth_of(s):
    d, instr = 0, False
    for c in s:
        if c == '"':
            instr = not instr
        elif not instr:
            d += c in "({"
            d -= c in ")}"
    return d


def parse_type(s, ctor=False):
    """'List(Of String)(args)' -> ('List(Of String)', '(args)'); handles arrays 'String()'."""
    m = re.match(r"[\w.]+", s)
    t, rest = m.group(0), s[m.end():]
    if rest.startswith("(Of "):
        d, i = 0, 0
        for i, c in enumerate(rest):
            d += c == "("
            d -= c == ")"
            if d == 0:
                break
        t, rest = t + rest[:i + 1], rest[i + 1:]
    if not ctor and rest.startswith("()") and not rest[2:].strip().startswith("{") and (rest[2:].strip() == "" or rest[2:].lstrip().startswith("=")):
        t, rest = t + "()", rest[2:]
    return t, rest.strip()


def xaml_type(vb):
    vb = vb.strip()
    if vb.endswith("()"):
        base = xaml_type(vb[:-2])
        # XAML intrinsic types (x:String ...) cannot be used as array element types; use the CLR name
        return ("s:" + base[2:] if base.startswith("x:") else base) + "[]"
    m = re.match(r"^([\w.]+)\(Of (.*)\)$", vb)
    if m:
        base = SIMPLE[strip_ns(m.group(1))]
        return f"{base}({', '.join(xaml_type(x) for x in split_top(m.group(2)))})"
    return SIMPLE[strip_ns(vb)]


def tcode(vb):
    """Registers a VB type in xamlgen.T and returns its key."""
    for k, (_, v) in G.T.items():
        if v == vb:
            return k
    G.T[vb] = (xaml_type(vb), vb)
    return vb


def element_type(vb):
    vb = strip_ns(vb)
    if vb in ("JObject", "JArray", "JToken"):
        return "JToken"
    m = re.match(r"^(List|HashSet|IEnumerable)\(Of (.*)\)$", vb)
    if m:
        return m.group(2)
    m = re.match(r"^Dictionary\(Of (.*)\)$", vb)
    if m:
        return split_top(m.group(1))[1]
    if vb.endswith("()"):
        return vb[:-2]
    raise ValueError("element type of " + vb)


class InvokeMethod(G.Act):
    """System.Activities InvokeMethod (Studio: Invoke Method)."""

    def __init__(self, target, method, params, name, static=False, ttype=None):
        self.target, self.method, self.params, self.name, self.static, self.ttype = target, method, params, name, static, ttype

    def xaml(self, ind):
        p = " " * ind
        if self.static:
            out = [f'{p}<InvokeMethod DisplayName={G.a(self.name)} MethodName="{self.method}" TargetType="{STATIC[self.target]}">']
        else:
            out = [f'{p}<InvokeMethod DisplayName={G.a(self.name)} MethodName="{self.method}">',
                   f"{p}  <InvokeMethod.TargetObject>",
                   f'{p}    <InArgument x:TypeArguments="{G.T[self.ttype][0]}">{G.escape(G.X(self.target))}</InArgument>',
                   f"{p}  </InvokeMethod.TargetObject>"]
        for expr, t in self.params:
            out.append(f'{p}  <InArgument x:TypeArguments="{G.T[t][0]}">{G.escape(G.X(expr))}</InArgument>')
        out.append(f"{p}</InvokeMethod>")
        return "\n".join(out)

    def vb(self, ind, ctx):
        tgt = self.target if self.static else f"CType({self.target}, {G.T[self.ttype][1]})"
        return " " * ind + f"{tgt}.{self.method}(" + ", ".join(f"CType({e}, {G.T[t][1]})" for e, t in self.params) + ")"

    def auto_note(self):
        return f"Invoke Method: calls {self.method} on {self.target}."


def short(s, n=60):
    s = re.sub(r"\s+", " ", s).strip()
    return s if len(s) <= n else s[:n - 3].rstrip() + "..."


class Translator:
    def __init__(self, name):
        self.name = name
        text = (G.VB_DIR / f"{name}.vb").read_text()
        lines = text.splitlines()
        self.args = []
        while lines and lines[0].startswith("'ARG "):
            _, d, n, t = lines.pop(0).split()
            self.args.append(G.Arg(d, n, t))
        # the single comment line after the ARG lines describes the whole workflow; later comments belong to steps
        self.doc = lines.pop(0)[1:].strip() if lines and lines[0].startswith("'") else ""
        self.types = {x.name: G.T[x.type][1] for x in self.args}
        self.items = self.logical(lines)
        self.pos = 0
        self.var_types = {}

    # ---- lexing
    def logical(self, lines):
        out, buf = [], ""
        for raw in lines:
            s = raw.strip()
            if not buf and not s:
                continue
            if not buf and s.startswith("'"):
                out.append(("c", s[1:].strip()))
                continue
            buf = f"{buf} {s}" if buf else s
            if depth_of(buf) > 0 or re.search(r"(&|,|\(|\{|\bOrElse|\bAndAlso|\+|=| _)$", buf):
                continue
            out.append(("s", buf.rstrip(" _")))
            buf = ""
        assert not buf, f"{self.name}: unterminated statement {buf[:80]}"
        return out

    # ---- parsing
    def block(self, stop):
        acts, note = [], []
        while self.pos < len(self.items):
            kind, s = self.items[self.pos]
            if kind == "c":
                note.append(s)
                self.pos += 1
                continue
            if any(re.match(p, s) for p in stop):
                return acts, s
            self.pos += 1
            acts.extend(self.stmt(s, " ".join(note)))
            note = []
        return acts, None

    def seq(self, acts, name, vars_=()):
        return G.Seq(name, acts, vars=vars_)

    def var(self, n, vb):
        k = tcode(vb)
        if n in self.var_types and self.var_types[n] != k:
            raise ValueError(f"{self.name}: variable {n} declared with two types")
        assert n not in self.types or self.var_types.get(n) == k, f"{self.name}: {n} clashes with an argument"
        self.var_types[n] = k
        self.types[n] = vb
        return G.Var(n, k)

    def lhs_type(self, lhs):
        if lhs in self.types:
            return self.types[lhs]
        m = re.match(r"^(\w+)\((.*)\)$", lhs)
        if m and m.group(1) in self.types:
            return element_type(self.types[m.group(1)])
        raise ValueError(f"{self.name}: cannot tell the type of {lhs}")

    def name_note(self, act, note, default_name, default_note=None):
        first = re.split(r"(?<=[.:;])\s", note, 1)[0] if note else ""
        act.name = short(first.rstrip(".:;"), 70) if first else default_name
        act.note = note or default_note
        return act

    def stmt(self, s, note):
        m = re.match(r"^Dim (\w+) As New (.+)$", s)
        if m:
            t, rest = parse_type(m.group(2), ctor=True)
            v = self.var(m.group(1), t)
            a = G.Assign(m.group(1), f"New {t}{rest if rest else ''}", tcode(t))
            a.decl = [v]
            return [self.name_note(a, note, f"Create {m.group(1)}", f"Creates a new, empty {strip_ns(t)} in {m.group(1)}.")]
        m = re.match(r"^Dim (\w+) As (.+)$", s)
        if m:
            t, rest = parse_type(m.group(2))
            v = self.var(m.group(1), t)
            if not rest:
                holder = G.Seq("decl", [])
                holder.decl = [v]
                return [holder]
            assert rest.startswith("="), s
            self.check_expr(rest[1:])
            a = G.Assign(m.group(1), rest[1:].strip(), tcode(t))
            a.decl = [v]
            return [self.name_note(a, note, f"Set {m.group(1)}", f"Sets {m.group(1)} to: {short(rest[1:], 150)}")]
        m = re.match(r"^If (.+) Then$", s)
        if m:
            return [self.if_block(m.group(1), note)]
        m = re.match(r"^If (.+?) Then (.+)$", s)
        if m and depth_of(m.group(1)) == 0 and m.group(1).count('"') % 2 == 0:
            self.check_expr(m.group(1))
            then = self.stmt(m.group(2), "")
            act = G.If(m.group(1), self.wrap(then, "Then"))
            return [self.name_note(act, note, "If " + short(m.group(1), 50), "Runs the step under Then only when the condition is true.")]
        m = re.match(r"^For Each (\w+) As (.+?) In (.+)$", s)
        if m:
            t = m.group(2)
            self.types[m.group(1)] = t
            body, end = self.block([r"^Next$"])
            assert end == "Next", s
            self.pos += 1
            vals = m.group(3)
            self.check_expr(vals)
            if "Function(" in vals and not re.search(r"\.(ToList|ToArray)\(\)$", vals):
                vals += ".ToList()"     # evaluate the filter now, while its variables are still in scope
            act = G.ForEach(m.group(1), tcode(t), vals, self.wrap(body, "Body"))
            return [self.name_note(act, note, f"For each {m.group(1)}", f"Repeats the steps inside once for every {m.group(1)}.")]
        if s == "Try":
            body, end = self.block([r"^Catch "])
            catches = []
            while end and end.startswith("Catch "):
                mc = re.match(r"^Catch (\w+) As (.+)$", end)
                self.pos += 1
                self.types[mc.group(1)] = mc.group(2)
                cb, end = self.block([r"^Catch ", r"^End Try$"])
                catches.append((tcode(mc.group(2)), mc.group(1), self.wrap(cb, "Handle " + strip_ns(mc.group(2)))))
            assert end == "End Try", s
            self.pos += 1
            act = G.Try("Try", self.wrap(body, "Try"), catches)
            return [self.name_note(act, note, "Try", "Runs the steps in Try; if the listed error happens, the Catch steps run instead of stopping the robot.")]
        m = re.match(r"^Throw (.+)$", s)
        if m:
            act = G.Throw(m.group(1))
            return [self.name_note(act, note, "Throw error", "Stops this workflow with the error shown, for the caller to handle.")]
        for op in ("+=", "&=", "-="):
            parts = split_top(s, " " + op + " ")
            if len(parts) == 2:
                lhs, rhs = parts
                act = G.Assign(lhs, f"{lhs} {op[0]} ({rhs})", tcode(self.lhs_type(lhs)))
                return [self.name_note(act, note, f"Update {short(lhs, 40)}", f"Updates {lhs}.")]
        parts = split_top(s, " = ")
        if len(parts) >= 2 and re.match(r"^[\w.]+(\(.*\))?$", parts[0]):
            lhs, rhs = parts[0], " = ".join(parts[1:])
            self.check_expr(rhs)
            act = G.Assign(lhs, rhs, tcode(self.lhs_type(lhs)))
            return [self.name_note(act, note, f"Set {short(lhs, 50)}", f"Sets {lhs} to: {short(rhs, 150)}")]
        m = None
        if s.endswith(")"):
            d, instr = 0, False
            for i, c in enumerate(s):
                if c == '"':
                    instr = not instr
                elif not instr and c == "(":
                    if d == 0:
                        head = s[:i]
                        mm = re.match(r"^(.+)\.(\w+)$", head)
                        if mm and not head.startswith("CType") and depth_of(s[i:]) == 0:
                            m = (mm.group(1), mm.group(2), s[i + 1:-1])
                        elif head.startswith("CType"):
                            continue
                        break
                    d += 1
                elif not instr and c == ")":
                    d -= 1
            if m is None and s.startswith("CType("):
                mm = re.match(r"^(CType\(.+?, [\w.()]+?\))\.(\w+)\((.*)\)$", s)
                m = mm and (mm.group(1), mm.group(2), mm.group(3))
        if m:
            target, method, argstr = m
            args = [x for x in split_top(argstr) if x]
            params = []
            for x in args:
                pp = split_top(x, " As ")
                if len(pp) == 2:
                    params.append((pp[0], tcode(pp[1])))
                else:
                    assert method in ("Add", "Remove") and len(args) == 1, f"{self.name}: give the parameter type: {s}"
                    tt = self.types.get(target)
                    mm = re.match(r"^CType\(.+, (.+)\)$", target)
                    tt = tt or (mm and mm.group(1))
                    params.append((x, tcode("String" if method == "Remove" else element_type(tt))))
            if target in STATIC:
                act = InvokeMethod(target, method, params, "", static=True)
            else:
                tt = self.types.get(target)
                mm = re.match(r"^CType\(.+, (.+)\)$", target)
                tt = tt or (mm and mm.group(1))
                assert tt, f"{self.name}: type of {target} unknown"
                act = InvokeMethod(target, method, params, "", ttype=tcode(tt))
            return [self.name_note(act, note, f"{method} ({short(target, 40)})", act.auto_note())]
        raise ValueError(f"{self.name}: unsupported statement: {s}")

    def check_expr(self, e):
        assert not re.search(r"\bFunction\([^)]*\)\s*$", e), f"{self.name}: multi-line lambda: {e[:80]}"

    def if_block(self, cond, note):
        self.check_expr(cond)
        then, end = self.block([r"^ElseIf ", r"^Else$", r"^End If$"])
        els = None
        if end and end.startswith("ElseIf "):
            self.items[self.pos] = ("s", "If " + end[len("ElseIf "):])   # an ElseIf is an If inside Else
            m = re.match(r"^If (.+) Then$", self.items[self.pos][1])
            self.pos += 1
            inner = self.if_block(m.group(1), "")
            inner.name = "Else if " + short(m.group(1), 45)
            inner.note = inner.note or "Checked only when the previous condition was false."
            els = self.wrap([inner], "Else")
            act = G.If(cond, self.wrap(then, "Then"), els)
            return self.name_note(act, note, "If " + short(cond, 50), "Runs Then when the condition is true, otherwise Else.")
        if end == "Else":
            self.pos += 1
            eb, end = self.block([r"^End If$"])
            els = self.wrap(eb, "Else")
        assert end == "End If", f"{self.name}: If without End If: {cond[:60]}"
        self.pos += 1
        act = G.If(cond, self.wrap(then, "Then"), els)
        return self.name_note(act, note, "If " + short(cond, 50), "Runs Then when the condition is true" + (", otherwise Else." if els else "."))

    def wrap(self, acts, name):
        """Sequence holding acts, declaring the variables they introduce (Dim) in this scope."""
        decl, keep = [], []
        for x in acts:
            decl += getattr(x, "decl", [])
            if not (isinstance(x, G.Seq) and x.name == "decl"):
                keep.append(x)
        return G.Seq(name, keep, vars=decl)

    def build(self):
        acts, end = self.block([])
        assert end is None
        body = self.wrap(acts, re.sub(r"(?<=[a-z])(?=[A-Z])", " ", self.name))
        return G.Workflow(f"Logic/{self.name}.xaml", self.doc, self.args, body)


def workflow_for(name):
    path = f"Logic\\{name}.xaml"
    if path not in G.REGISTRY:
        Translator(name).build()
    return G.REGISTRY[path]
