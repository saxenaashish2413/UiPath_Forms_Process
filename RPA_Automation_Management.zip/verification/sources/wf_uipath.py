"""Providers\\UiPath\\*.xaml: Orchestrator 2025.10 (standalone) reads, provisioning and package deployment."""
from xamlgen import Workflow, Arg, Var, Seq, Assign, Log, If, Try, ForEach, Invoke, Code, Throw, GetCredential, Rethrow
from wf_framework import CFG, q, odq, ctx, api, collection, audit

ENV = Arg("in", "in_Environment", "S", "Dev | UAT | Prod")
FOLDER = Arg("in", "in_FolderId", "L", "Orchestrator folder ID (sent as X-UIPATH-OrganizationUnitId).")
APIV = [Var("intStatus", "I"), Var("strBody", "S")]


def flt(expr):
    """$filter value -> URL-encoded VB expression."""
    return f'Uri.EscapeDataString({expr})'


def build():
    Workflow("Providers/UiPath/Get_Folder.xaml",
             "Finds a folder by its full path. GET odata/Folders?$filter=FullyQualifiedName eq '<path>'. "
             "out_FolderId = 0 when the folder does not exist or the API account cannot see it.",
             CFG + [ENV, Arg("in", "in_FolderPath", "S", "Full folder path, e.g. Finance/Invoice."),
                    Arg("out", "out_FolderId", "L", "Folder ID or 0."), Arg("out", "out_FolderJson", "S", "Folder record (JSON) or empty.")],
             Seq("Get folder", [
                 Code("ParsePage", {"in_ResponseBody": '""', "io_Items": "jaItems", "out_NextUrl": "strNext", "out_PageCount": "intCount"}, "Empty list"),
                 api("GET", '"odata/Folders?$filter=" & ' + flt('"FullyQualifiedName eq \'" & ' + odq("in_FolderPath") + ' & "\'"') + ' & "&$select=Id,DisplayName,FullyQualifiedName"',
                     "GET odata/Folders by path"),
                 Code("ParsePage", {"in_ResponseBody": "strBody", "io_Items": "jaItems", "out_NextUrl": "strNext", "out_PageCount": "intCount"}, "Read folders"),
                 Assign("out_FolderJson", 'If(jaItems.Count > 0, jaItems(0).ToString(Newtonsoft.Json.Formatting.None), "")', "S"),
                 Assign("out_FolderId", 'If(jaItems.Count > 0, jaItems(0).Value(Of Long)("Id"), 0L)', "L"),
             ], vars=APIV + [Var("jaItems", "JA"), Var("strNext", "S"), Var("intCount", "I")]))

    Workflow("Providers/UiPath/Get_Process_Details.xaml",
             "Reads a process (release) in a folder by name. GET odata/Releases?$filter=Name eq '<name>' with the folder header.",
             CFG + [ENV, FOLDER, Arg("in", "in_ProcessName", "S", "Process (release) name."),
                    Arg("out", "out_ReleaseJson", "S", "Release record (Id, Key, Name, ProcessKey, ProcessVersion, Description) or empty.")],
             Seq("Get process details", [
                 Code("ParsePage", {"in_ResponseBody": '""', "io_Items": "jaItems", "out_NextUrl": "strNext", "out_PageCount": "intCount"}, "Empty list"),
                 api("GET", '"odata/Releases?$filter=" & ' + flt('"Name eq \'" & ' + odq("in_ProcessName") + ' & "\'"') + ' & "&$select=Id,Key,Name,ProcessKey,ProcessVersion,Description,IsLatestVersion"',
                     "GET odata/Releases by name", folder="in_FolderId"),
                 Code("ParsePage", {"in_ResponseBody": "strBody", "io_Items": "jaItems", "out_NextUrl": "strNext", "out_PageCount": "intCount"}, "Read releases"),
                 Assign("out_ReleaseJson", 'If(jaItems.Count > 0, jaItems(0).ToString(Newtonsoft.Json.Formatting.None), "")', "S"),
             ], vars=APIV + [Var("jaItems", "JA"), Var("strNext", "S"), Var("intCount", "I")]))

    Workflow("Providers/UiPath/Get_Package_Details.xaml",
             "Lists the versions of a package in the environment's feed. "
             "GET odata/Processes/UiPath.Server.Configuration.OData.GetProcessVersions(processId='<packageId>') "
             "(plus ?feedId=<guid> when settings uipath.environments.<env>.feedId is set for a folder feed). A package that "
             "is not in the feed returns an empty list.",
             CFG + [ENV, Arg("in", "in_PackageId", "S", "Package ID (NuGet ID)."),
                    Arg("out", "out_VersionsJson", "S", "JSON array of {Key, Version, Published, IsLatestVersion}.")],
             Seq("Get package details", [
                 Assign("strFeed", 'Convert.ToString(in_Config.SelectToken("uipath.environments." & in_Environment & ".feedId"))', "S", "Folder feed ID (optional)"),
                 collection('"odata/Processes/UiPath.Server.Configuration.OData.GetProcessVersions(processId=\'" & Uri.EscapeDataString(' + odq("in_PackageId") + ') & "\')?$select=Key,Version,Published,IsLatestVersion" & If(strFeed <> "", "&feedId=" & Uri.EscapeDataString(strFeed), "")',
                            "GET Processes/GetProcessVersions", "jaItems", not_found="True"),
                 Assign("out_VersionsJson", "jaItems.ToString(Newtonsoft.Json.Formatting.None)", "S"),
             ], vars=[Var("jaItems", "JA"), Var("strFeed", "S")]))

    Workflow("Providers/UiPath/Get_Asset_Details.xaml",
             "Lists the assets of a folder WITHOUT credential fields: GET odata/Assets?$select=Id,Name,ValueType,ValueScope,"
             "StringValue,IntValue,BoolValue,Description (folder header, paged). Credential usernames/passwords are never requested.",
             CFG + [ENV, FOLDER, Arg("out", "out_AssetsJson", "S", "JSON array of assets.")],
             Seq("Get asset details", [
                 collection('"odata/Assets?$select=Id,Name,ValueType,ValueScope,StringValue,IntValue,BoolValue,Description&$orderby=Name"', "GET odata/Assets", "jaItems", folder="in_FolderId"),
                 Assign("out_AssetsJson", "jaItems.ToString(Newtonsoft.Json.Formatting.None)", "S"),
             ], vars=[Var("jaItems", "JA")]))

    Workflow("Providers/UiPath/Get_Queue_Details.xaml",
             "Lists the queues of a folder: GET odata/QueueDefinitions?$select=Id,Name,Description,MaxNumberOfRetries,"
             "AcceptAutomaticallyRetry,EnforceUniqueReference (folder header, paged).",
             CFG + [ENV, FOLDER, Arg("out", "out_QueuesJson", "S", "JSON array of queue definitions.")],
             Seq("Get queue details", [
                 collection('"odata/QueueDefinitions?$select=Id,Name,Description,MaxNumberOfRetries,AcceptAutomaticallyRetry,EnforceUniqueReference&$orderby=Name"', "GET odata/QueueDefinitions", "jaItems", folder="in_FolderId"),
                 Assign("out_QueuesJson", "jaItems.ToString(Newtonsoft.Json.Formatting.None)", "S"),
             ], vars=[Var("jaItems", "JA")]))

    Workflow("Providers/UiPath/Get_User_Access.xaml",
             "Users, groups and robot accounts with roles on a folder: "
             "GET odata/Folders/UiPath.Server.Configuration.OData.GetUsersForFolder(key=<folderId>,includeInherited=<bool>)?$expand=UserEntity,Roles (paged).",
             CFG + [ENV, FOLDER, Arg("in", "in_IncludeInherited", "B", "True to include access inherited from parent folders (display); False for direct assignments (merging)."),
                    Arg("out", "out_UsersJson", "S", "JSON array of {UserEntity, Roles}.")],
             Seq("Get user access", [
                 collection('"odata/Folders/UiPath.Server.Configuration.OData.GetUsersForFolder(key=" & in_FolderId.ToString() & ",includeInherited=" & in_IncludeInherited.ToString().ToLowerInvariant() & ")?$expand=UserEntity,Roles"',
                            "GET Folders/GetUsersForFolder", "jaItems"),
                 Assign("out_UsersJson", "jaItems.ToString(Newtonsoft.Json.Formatting.None)", "S"),
             ], vars=[Var("jaItems", "JA")]))

    # ---------------------------------------------------------------- fetch
    def env_block():
        return ForEach("strEnv", "S", 'New String() {"Dev", "UAT", "Prod"}', Seq("Read environment", [
            Try("Try read environment", Seq("Folder, process and package", [
                Assign("strFolderPath", 'in_Bot.SelectToken("uipath.folders." & strEnv).ToString()', "S"),
                Invoke("Providers/UiPath/Get_Folder.xaml", ctx(in_Environment="strEnv", in_FolderPath="strFolderPath", out_FolderId="lngFolderId", out_FolderJson="strJson"), name="Get folder"),
                Code("JsonPut", {"in_Target": "joRaw", "in_Key": 'strEnv & ".folder"', "in_Json": "strJson"}, "Keep folder"),
                If("lngFolderId > 0", Seq("Read process", [
                    Invoke("Providers/UiPath/Get_Process_Details.xaml", ctx(in_Environment="strEnv", in_FolderId="lngFolderId", in_ProcessName='in_Bot.SelectToken("uipath.processName").ToString()', out_ReleaseJson="strJson"), name="Get process details"),
                    Code("JsonPut", {"in_Target": "joRaw", "in_Key": 'strEnv & ".release"', "in_Json": "strJson"}, "Keep release")])),
                Invoke("Providers/UiPath/Get_Package_Details.xaml", ctx(in_Environment="strEnv", in_PackageId='in_Bot.SelectToken("uipath.packageId").ToString()', out_VersionsJson="strJson"), name="Get package details"),
                Code("JsonPut", {"in_Target": "joRaw", "in_Key": 'strEnv & ".versions"', "in_Json": "strJson"}, "Keep versions"),
            ]), [("EX", "exEnv", Seq("Environment not readable", [
                Log("Warn", '"Could not read " & strEnv & " for Bot ID " & in_Bot.Value(Of String)("botId") & ": " & exEnv.Message'),
                Code("JsonPut", {"in_Target": "joRaw", "in_Key": 'strEnv & ".error"', "in_Json": "exEnv.Message"}, "Keep error")]))])]),
            name="For each environment")

    folder_id = 'If(joRaw(%s) IsNot Nothing AndAlso joRaw(%s).Type = JTokenType.Object, joRaw(%s).Value(Of Long)("Id"), 0L)'
    Workflow("Providers/UiPath/Fetch_Bot_Configuration.xaml",
             "UiPath provider: resolves the mapped folders in Dev, UAT and Prod, reads the process, package versions and "
             "deployment status in each, and for New requests the Dev assets, queues and folder access plus their state in the "
             "target environment of the selected path. UAT/Prod read failures are reported per environment; a Dev failure makes "
             "the result an error. Only what the API account may read is returned.",
             CFG + [Arg("in", "in_Bot", "JO", "Bot ID mapping entry."), Arg("in", "in_ProcessType", "S", "New | Enhancement | Bug Fix"),
                    Arg("in", "in_DeploymentPath", "S", "Deployment path name from settings."),
                    Arg("out", "out_Details", "JO", "Details for the form (see BuildUiPathDetails).")],
             Seq("Fetch UiPath bot configuration", [
                 Assign("joPath", 'in_Config("deploymentPaths").Children(Of JObject)().First(Function(p) p.Value(Of String)("name") = in_DeploymentPath)', "JO", "Deployment path"),
                 Assign("joRaw", "New JObject()", "JO"),
                 Code("JsonPut", {"in_Target": "joRaw", "in_Key": '"bot"', "in_Json": "in_Bot.ToString()"}, "Keep mapping"),
                 Code("JsonPut", {"in_Target": "joRaw", "in_Key": '"processType"', "in_Json": "in_ProcessType"}, "Keep process type"),
                 Code("JsonPut", {"in_Target": "joRaw", "in_Key": '"deploymentPath"', "in_Json": "in_DeploymentPath"}, "Keep path"),
                 Code("JsonPut", {"in_Target": "joRaw", "in_Key": '"sourceEnv"', "in_Json": 'joPath.Value(Of String)("source")'}, "Keep source"),
                 Code("JsonPut", {"in_Target": "joRaw", "in_Key": '"targetEnv"', "in_Json": 'joPath.Value(Of String)("target")'}, "Keep target"),
                 env_block(),
                 If('in_ProcessType = "New"', Seq("Configuration (New only)", [
                     Assign("strTarget", 'joPath.Value(Of String)("target")', "S"),
                     Assign("lngDevFolder", folder_id % (('"Dev.folder"',) * 3), "L"),
                     Assign("lngTargetFolder", folder_id % (('strTarget & ".folder"',) * 3), "L"),
                     If("lngDevFolder > 0", Try("Try read Dev configuration", Seq("Dev assets, queues, access", [
                         Invoke("Providers/UiPath/Get_Asset_Details.xaml", ctx(in_Environment='"Dev"', in_FolderId="lngDevFolder", out_AssetsJson="strJson"), name="Dev assets"),
                         Code("JsonPut", {"in_Target": "joRaw", "in_Key": '"devAssets"', "in_Json": "strJson"}, "Keep Dev assets"),
                         Invoke("Providers/UiPath/Get_Queue_Details.xaml", ctx(in_Environment='"Dev"', in_FolderId="lngDevFolder", out_QueuesJson="strJson"), name="Dev queues"),
                         Code("JsonPut", {"in_Target": "joRaw", "in_Key": '"devQueues"', "in_Json": "strJson"}, "Keep Dev queues"),
                         Invoke("Providers/UiPath/Get_User_Access.xaml", ctx(in_Environment='"Dev"', in_FolderId="lngDevFolder", in_IncludeInherited="True", out_UsersJson="strJson"), name="Dev folder access"),
                         Code("JsonPut", {"in_Target": "joRaw", "in_Key": '"devUsers"', "in_Json": "strJson"}, "Keep Dev access")]),
                         [("EX", "exDev", Seq("Dev configuration not readable", [
                             Log("Warn", '"Could not read Dev configuration: " & exDev.Message'),
                             Code("JsonPut", {"in_Target": "joRaw", "in_Key": '"Dev.error"', "in_Json": '"configuration could not be read: " & exDev.Message'}, "Keep error")]))])),
                     If("lngTargetFolder > 0", Try("Try read target configuration", Seq("Target assets, queues, access", [
                         Invoke("Providers/UiPath/Get_Asset_Details.xaml", ctx(in_Environment="strTarget", in_FolderId="lngTargetFolder", out_AssetsJson="strJson"), name="Target assets"),
                         Code("JsonPut", {"in_Target": "joRaw", "in_Key": '"targetAssets"', "in_Json": "strJson"}, "Keep target assets"),
                         Invoke("Providers/UiPath/Get_Queue_Details.xaml", ctx(in_Environment="strTarget", in_FolderId="lngTargetFolder", out_QueuesJson="strJson"), name="Target queues"),
                         Code("JsonPut", {"in_Target": "joRaw", "in_Key": '"targetQueues"', "in_Json": "strJson"}, "Keep target queues"),
                         Invoke("Providers/UiPath/Get_User_Access.xaml", ctx(in_Environment="strTarget", in_FolderId="lngTargetFolder", in_IncludeInherited="True", out_UsersJson="strJson"), name="Target folder access"),
                         Code("JsonPut", {"in_Target": "joRaw", "in_Key": '"targetUsers"', "in_Json": "strJson"}, "Keep target access")]),
                         [("EX", "exTarget", Seq("Target configuration not readable", [
                             Log("Warn", '"Could not read " & strTarget & " configuration: " & exTarget.Message'),
                             Code("JsonPut", {"in_Target": "joRaw", "in_Key": 'strTarget & ".error"', "in_Json": '"configuration could not be read: " & exTarget.Message'}, "Keep error")]))]))])),
                 Code("BuildUiPathDetails", {"in_Config": "in_Config", "in_Raw": "joRaw", "out_Details": "out_Details"}, "Build details"),
                 Log("Info", '"UiPath details for " & in_Bot.Value(Of String)("botId") & ": " & out_Details.Value(Of String)("status") & " - " & out_Details.Value(Of String)("message")'),
             ], vars=[Var("joPath", "JO"), Var("joRaw", "JO"), Var("strFolderPath", "S"), Var("lngFolderId", "L"), Var("strJson", "S"), Var("strTarget", "S"),
                      Var("lngDevFolder", "L"), Var("lngTargetFolder", "L")]))

    # ---------------------------------------------------------------- provisioning
    Workflow("Providers/UiPath/Update_Asset_Configuration.xaml",
             "Applies one approved asset row in the target folder, idempotently: reads the current asset, then creates it, "
             "updates it (only when the value differs) or leaves it, and reads it back. Credential values are read with Get "
             "Credential from the approved secret source named in the Bot ID mapping (assets.secretSource.<env>) and sent "
             "straight to Orchestrator; they never reach the form, the request, logs or the audit.",
             CFG + [ENV, FOLDER, Arg("in", "in_Bot", "JO", "Bot ID mapping entry (secret sources)."),
                    Arg("in", "in_Asset", "JO", "Approved asset row from the request (name, type, action, proposedValue, isSecret...)."),
                    Arg("out", "out_Change", "S", "Created | Updated | NoChange"), Arg("out", "out_Message", "S", "Safe detail.")],
             Seq("Update asset configuration", [
                 Assign("strName", 'in_Asset.Value(Of String)("name")', "S"),
                 Assign("strLookup", '"odata/Assets?$filter=" & ' + flt('"Name eq \'" & ' + odq("strName") + ' & "\'"') + ' & "&$select=Id,Name,ValueType,ValueScope,StringValue,IntValue,BoolValue,Description"', "S", "Lookup URL"),
                 api("GET", "strLookup", "GET odata/Assets by name", folder="in_FolderId"),
                 Assign("jaItems", "New JArray()", "JA"),
                 Code("ParsePage", {"in_ResponseBody": "strBody", "io_Items": "jaItems", "out_NextUrl": "strNext", "out_PageCount": "intCount"}, "Read asset"),
                 Assign("strTargetJson", 'If(jaItems.Count > 0, jaItems(0).ToString(Newtonsoft.Json.Formatting.None), "")', "S"),
                 Assign("strCredUser", '""', "S"),
                 Assign("secCredPassword", "Nothing", "SEC"),
                 If('in_Asset.Value(Of String)("type") = "Credential" AndAlso ((in_Asset.Value(Of String)("action") = "Create" AndAlso strTargetJson = "") OrElse in_Asset.Value(Of String)("action") = "Update")',
                    Seq("Read value from approved secret source", [
                        Assign("joSource", 'TryCast(If(TryCast(in_Bot.SelectToken("uipath.assets"), JArray), New JArray()).Children(Of JObject)().Where(Function(a) String.Equals(a.Value(Of String)("name"), strName, StringComparison.OrdinalIgnoreCase)).Select(Function(a) a.SelectToken("secretSource." & in_Environment)).FirstOrDefault(), JObject)', "JO", "Secret source"),
                        If("joSource Is Nothing", Throw('New BusinessRuleException("No approved secret source is configured for credential asset " & strName & " in " & in_Environment & ".")', "No secret source")),
                        GetCredential('joSource.Value(Of String)("assetName")', 'joSource.Value(Of String)("folderPath")', "strCredUser", "secCredPassword", "Get credential from secret source")])),
                 Code("AssetBody", {"in_Asset": "in_Asset", "in_TargetAssetJson": "strTargetJson", "in_CredentialUser": "strCredUser", "in_CredentialPassword": "secCredPassword",
                                    "out_Method": "strMethod", "out_Url": "strUrl", "out_Body": "strRequestBody", "out_Change": "out_Change"}, "Plan asset change"),
                 If('strMethod <> ""', Seq("Apply asset change", [
                     Invoke("Framework/Send_Api_Request.xaml", ctx(in_Provider='"UiPath"', in_Environment="in_Environment", in_Method="strMethod", in_Url="strUrl", in_FolderId="in_FolderId",
                                                                 in_Body="strRequestBody", in_ApiName='"Asset " & strMethod & " " & strName', in_AcceptStatuses='"409"', in_UploadFilePath='""',
                                                                 in_DownloadFilePath='""', out_StatusCode="intStatus", out_ResponseBody="strBody"), name="Create or update asset"),
                     Assign("strRequestBody", '""', "S", "Forget the body (may contain a credential)"),
                     If("intStatus = 409", Assign("out_Change", '"NoChange"', "S", "Created concurrently: keep existing")),
                     api("GET", "strLookup", "GET odata/Assets (verify)", folder="in_FolderId"),
                     Assign("jaItems", "New JArray()", "JA"),
                     Code("ParsePage", {"in_ResponseBody": "strBody", "io_Items": "jaItems", "out_NextUrl": "strNext", "out_PageCount": "intCount"}, "Read asset back"),
                     If("jaItems.Count = 0", Throw('New Exception("Asset " & strName & " is not present in " & in_Environment & " after " & strMethod & ".")', "Verification failed")),
                     If('Not in_Asset.Value(Of Boolean)("isSecret") AndAlso in_Asset.Value(Of String)("type") = "Text" AndAlso jaItems(0).Value(Of String)("StringValue") <> in_Asset.Value(Of String)("proposedValue")',
                        Throw('New Exception("Asset " & strName & " does not have the approved value in " & in_Environment & " after " & strMethod & ".")', "Value verification failed")),
                 ])),
                 Assign("out_Message", 'If(out_Change = "NoChange", If(strTargetJson = "", "Not requested", "Already present; left unchanged"), out_Change & " and verified" & If(in_Asset.Value(Of Boolean)("isSecret"), " (value from approved secret source)", ""))', "S"),
                 audit('in_Environment & " asset " & strName', 'If(out_Change = "NoChange", "NoChange", "Succeeded")', "out_Message"),
             ], vars=APIV + [Var(n, "S") for n in ["strName", "strLookup", "strNext", "strTargetJson", "strCredUser", "strMethod", "strUrl", "strRequestBody"]]
                + [Var("intCount", "I"), Var("jaItems", "JA"), Var("secCredPassword", "SEC"), Var("joSource", "JO")]))

    Workflow("Providers/UiPath/Validate_Queue_Configuration.xaml",
             "Checks one approved queue row against the target folder and, when in_ApplyChanges, creates it or updates its "
             "settings idempotently (GET odata/QueueDefinitions?$filter=Name eq ..., then POST or PUT odata/QueueDefinitions), "
             "then reads it back. An existing queue is never recreated.",
             CFG + [ENV, FOLDER, Arg("in", "in_Queue", "JO", "Approved queue row (name, proposedName, action, settings)."),
                    Arg("in", "in_ApplyChanges", "B", "False = check only."),
                    Arg("out", "out_Change", "S", "Created | Updated | NoChange | WouldCreate | WouldUpdate"), Arg("out", "out_Message", "S", "Safe detail.")],
             Seq("Validate queue configuration", [
                 Assign("strName", 'in_Queue.Value(Of String)("proposedName")', "S"),
                 Assign("strLookup", '"odata/QueueDefinitions?$filter=" & ' + flt('"Name eq \'" & ' + odq("strName") + ' & "\'"') + ' & "&$select=Id,Name,Description,MaxNumberOfRetries,AcceptAutomaticallyRetry,EnforceUniqueReference"', "S", "Lookup URL"),
                 api("GET", "strLookup", "GET odata/QueueDefinitions by name", folder="in_FolderId"),
                 Assign("jaItems", "New JArray()", "JA"),
                 Code("ParsePage", {"in_ResponseBody": "strBody", "io_Items": "jaItems", "out_NextUrl": "strNext", "out_PageCount": "intCount"}, "Read queue"),
                 Assign("strTargetJson", 'If(jaItems.Count > 0, jaItems(0).ToString(Newtonsoft.Json.Formatting.None), "")', "S"),
                 Code("QueueBody", {"in_Queue": "in_Queue", "in_TargetQueueJson": "strTargetJson", "out_Method": "strMethod", "out_Url": "strUrl", "out_Body": "strRequestBody", "out_Change": "out_Change"}, "Plan queue change"),
                 If('strMethod <> "" AndAlso Not in_ApplyChanges', Assign("out_Change", '"Would" & If(strMethod = "POST", "Create", "Update")', "S", "Check only")),
                 If('strMethod <> "" AndAlso in_ApplyChanges', Seq("Apply queue change", [
                     Invoke("Framework/Send_Api_Request.xaml", ctx(in_Provider='"UiPath"', in_Environment="in_Environment", in_Method="strMethod", in_Url="strUrl", in_FolderId="in_FolderId",
                                                                 in_Body="strRequestBody", in_ApiName='"Queue " & strMethod & " " & strName', in_AcceptStatuses='"409"', in_UploadFilePath='""',
                                                                 in_DownloadFilePath='""', out_StatusCode="intStatus", out_ResponseBody="strBody"), name="Create or update queue"),
                     If("intStatus = 409", Assign("out_Change", '"NoChange"', "S", "Created concurrently: keep existing")),
                     api("GET", "strLookup", "GET odata/QueueDefinitions (verify)", folder="in_FolderId"),
                     Assign("jaItems", "New JArray()", "JA"),
                     Code("ParsePage", {"in_ResponseBody": "strBody", "io_Items": "jaItems", "out_NextUrl": "strNext", "out_PageCount": "intCount"}, "Read queue back"),
                     If("jaItems.Count = 0", Throw('New Exception("Queue " & strName & " is not present in " & in_Environment & " after " & strMethod & ".")', "Verification failed"))])),
                 Assign("out_Message", 'If(out_Change = "NoChange", If(strTargetJson = "", "Not requested", "Already present; left unchanged"), If(out_Change.StartsWith("Would"), out_Change.Replace("Would", "Will be ").ToLowerInvariant(), out_Change & " and verified"))', "S"),
                 If("in_ApplyChanges", audit('in_Environment & " queue " & strName', 'If(out_Change = "NoChange", "NoChange", "Succeeded")', "out_Message")),
             ], vars=APIV + [Var(n, "S") for n in ["strName", "strLookup", "strNext", "strTargetJson", "strMethod", "strUrl", "strRequestBody"]] + [Var("intCount", "I"), Var("jaItems", "JA")]))

    Workflow("Providers/UiPath/Validate_User_Access.xaml",
             "Checks and (when in_ApplyChanges) grants folder access for approved rows. Accounts must already exist "
             "(GET odata/Users?$filter=UserName eq ...); roles are resolved by name (GET odata/Roles). Because AssignUsers sets an "
             "account's complete role list on the folder, current direct roles are merged in so nothing is removed; then "
             "GetUsersForFolder is read again to verify. Unknown accounts or roles are reported, never created.",
             CFG + [ENV, FOLDER, Arg("in", "in_Rows", "JA", "Approved access rows (name, type, accessLevel, action)."),
                    Arg("in", "in_ApplyChanges", "B", "False = check only."),
                    Arg("out", "out_Results", "JA", "Per account: {name, status: Granted|NoChange|Verified|Failed, message}.")],
             Seq("Validate user access", [
                 Assign("out_Results", "New JArray()", "JA"),
                 Assign("jaGrant", 'New JArray(in_Rows.Children(Of JObject)().Where(Function(r) r.Value(Of String)("action") = "Grant"))', "JA", "Rows to grant"),
                 If("jaGrant.Count > 0", Seq("Resolve and grant", [
                     Assign("jaAccounts", "New JArray()", "JA"),
                     ForEach("joRow", "JO", "jaGrant.Children(Of JObject)().ToList()", Seq("Find account", [
                         api("GET", '"odata/Users?$filter=" & ' + flt('"UserName eq \'" & ' + odq('joRow.Value(Of String)("name")') + ' & "\'"') + ' & "&$select=Id,UserName,Name,Type"', "GET odata/Users by name"),
                         Code("ParsePage", {"in_ResponseBody": "strBody", "io_Items": "jaAccounts", "out_NextUrl": "strNext", "out_PageCount": "intCount"}, "Keep account")]), name="For each account"),
                     collection('"odata/Roles?$select=Id,Name,Type"', "GET odata/Roles", "jaRoles"),
                     Invoke("Providers/UiPath/Get_User_Access.xaml", ctx(in_Environment="in_Environment", in_FolderId="in_FolderId", in_IncludeInherited="False", out_UsersJson="strJson"), name="Current direct access"),
                     Code("AccessPlan", {"in_Mode": '"plan"', "in_Config": "in_Config", "in_Rows": "jaGrant", "in_Accounts": "jaAccounts", "in_Roles": "jaRoles",
                                         "in_FolderUsers": "JArray.Parse(strJson)", "in_FolderId": "in_FolderId", "out_Bodies": "jaBodies", "out_Results": "out_Results"}, "Plan role assignments"),
                     If("in_ApplyChanges AndAlso jaBodies.Count > 0", Seq("Assign and verify", [
                         ForEach("strAssign", "S", "jaBodies.Values(Of String)().ToList()",
                                 api("POST", '"odata/Folders/UiPath.Server.Configuration.OData.AssignUsers"', "POST Folders/AssignUsers", body="strAssign"), name="For each assignment"),
                         Invoke("Providers/UiPath/Get_User_Access.xaml", ctx(in_Environment="in_Environment", in_FolderId="in_FolderId", in_IncludeInherited="False", out_UsersJson="strJson"), name="Read access back"),
                         Code("AccessPlan", {"in_Mode": '"verify"', "in_Config": "in_Config", "in_Rows": "jaGrant", "in_Accounts": "jaAccounts", "in_Roles": "jaRoles",
                                             "in_FolderUsers": "JArray.Parse(strJson)", "in_FolderId": "in_FolderId", "out_Bodies": "jaVerifyBodies", "out_Results": "jaVerify"}, "Verify role assignments"),
                         ForEach("joRes", "JO", "out_Results.Children(Of JObject)().ToList()",
                                 If('joRes.Value(Of String)("status") = "Granted" AndAlso jaVerify.Children(Of JObject)().Any(Function(v) v.Value(Of String)("name") = joRes.Value(Of String)("name") AndAlso v.Value(Of String)("status") <> "Verified")',
                                    Assign('joRes("status")', '"Failed"', "JT", "Mark not verified")), name="Merge verification")])),
                     If("in_ApplyChanges", ForEach("joAudit", "JO", "out_Results.Children(Of JObject)().ToList()",
                         audit('in_Environment & " access " & joAudit.Value(Of String)("name")', 'If(joAudit.Value(Of String)("status") = "Failed", "Failed", If(joAudit.Value(Of String)("status") = "NoChange", "NoChange", "Succeeded"))', 'joAudit.Value(Of String)("message")'), name="Audit each account"))
                 ]))
             ], vars=APIV + [Var("jaGrant", "JA"), Var("jaAccounts", "JA"), Var("jaRoles", "JA"), Var("jaBodies", "JA"), Var("jaVerifyBodies", "JA"), Var("jaVerify", "JA"),
                             Var("strNext", "S"), Var("intCount", "I"), Var("strJson", "S")]))

    Workflow("Providers/UiPath/Deploy_Package.xaml",
             "Moves one package version to the target and points the process at it. 1) target feed already has the version -> "
             "skip transfer; otherwise the version must exist in the source feed, is downloaded (GET Processes/DownloadPackage"
             "(key='<id>:<version>')), its SHA-256 recorded, and uploaded (POST Processes/UploadPackage, multipart 'file'; 409 = "
             "already there) and the target feed is re-checked. 2) process in the target folder: same version -> no change; other "
             "version -> POST Releases(<id>)/UiPath.Server.Configuration.OData.UpdateToSpecificPackageVersion; missing -> created "
             "(POST odata/Releases) only for New requests. 3) the process is read back; a wrong version restores the previous one "
             "and fails. Assets, queues and access are NOT touched here.",
             CFG + [Arg("in", "in_Request", "JO", "Validated request."), Arg("in", "in_TargetFolderId", "L", "Target folder ID."),
                    Arg("in", "in_Result", "JO", "Result object; steps are added to its 'objects' list and keys package*/release*.")],
             Seq("Deploy package", [
                 Assign("strSource", 'in_Request.Value(Of String)("sourceEnvironment")', "S"),
                 Assign("strTarget", 'in_Request.Value(Of String)("targetEnvironment")', "S"),
                 Assign("strVersion", 'in_Request.SelectToken("package.requestedVersion").ToString()', "S"),
                 Assign("strPackage", 'in_Request.SelectToken("package.packageName").ToString()', "S"),
                 Assign("strProcess", 'If(String.IsNullOrEmpty(Convert.ToString(in_Request.SelectToken("configuration.processName"))), Convert.ToString(in_Request.SelectToken("package.processName")), Convert.ToString(in_Request.SelectToken("configuration.processName")))', "S"),
                 Invoke("Providers/UiPath/Get_Package_Details.xaml", ctx(in_Environment="strTarget", in_PackageId="strPackage", out_VersionsJson="strJson"), name="Target feed versions"),
                 If('JArray.Parse(strJson).Children(Of JObject)().Any(Function(v) v.Value(Of String)("Version") = strVersion)',
                    Seq("Already in target feed", [
                        Code("StepResult", {"in_Result": "in_Result", "in_Kind": '"Package"', "in_Name": 'strPackage & " " & strVersion', "in_Change": '"NoChange"', "in_Message": '"Already in the " & strTarget & " feed"'}, "Record"),
                        audit('strTarget & " package " & strPackage & " " & strVersion', '"NoChange"', '"Already in the target feed"')]),
                    Seq("Transfer package", [
                        Invoke("Providers/UiPath/Get_Package_Details.xaml", ctx(in_Environment="strSource", in_PackageId="strPackage", out_VersionsJson="strJson"), name="Source feed versions"),
                        If('Not JArray.Parse(strJson).Children(Of JObject)().Any(Function(v) v.Value(Of String)("Version") = strVersion)',
                           Throw('New BusinessRuleException("Source package unavailable: " & strPackage & " " & strVersion & " is not in the " & strSource & " feed.")', "Source package unavailable")),
                        Assign("strFile", 'Path.Combine(Path.GetTempPath(), "am_" & Guid.NewGuid().ToString("N") & ".nupkg")', "S", "Temp file"),
                        Try("Download and upload", Seq("Download and upload", [
                            api("GET", '"odata/Processes/UiPath.Server.Configuration.OData.DownloadPackage(key=\'" & Uri.EscapeDataString(' + odq('strPackage & ":" & strVersion') + ') & "\')"',
                                "GET Processes/DownloadPackage", env="strSource", download="strFile"),
                            Code("FileHash", {"in_Path": "strFile", "in_Delete": "False", "out_Sha256": "strSha"}, "SHA-256 of package"),
                            api("POST", '"odata/Processes/UiPath.Server.Configuration.OData.UploadPackage"', "POST Processes/UploadPackage", env="strTarget", upload="strFile", accept='"409"'),
                        ]), [], final=Seq("Delete temp file", [Code("FileHash", {"in_Path": "strFile", "in_Delete": "True", "out_Sha256": "strIgnore"}, "Delete temp package")])),
                        Invoke("Providers/UiPath/Get_Package_Details.xaml", ctx(in_Environment="strTarget", in_PackageId="strPackage", out_VersionsJson="strJson"), name="Target feed versions (verify)"),
                        If('Not JArray.Parse(strJson).Children(Of JObject)().Any(Function(v) v.Value(Of String)("Version") = strVersion)',
                           Throw('New Exception("Package " & strPackage & " " & strVersion & " is not in the " & strTarget & " feed after upload.")', "Upload not visible")),
                        Code("JsonPut", {"in_Target": "in_Result", "in_Key": '"packageSha256"', "in_Json": "strSha"}, "Keep SHA-256"),
                        Code("StepResult", {"in_Result": "in_Result", "in_Kind": '"Package"', "in_Name": 'strPackage & " " & strVersion', "in_Change": '"Created"', "in_Message": '"Uploaded to the " & strTarget & " feed (SHA-256 " & strSha & ")"'}, "Record"),
                        audit('strTarget & " package " & strPackage & " " & strVersion', '"Succeeded"', '"Transferred from " & strSource & " (SHA-256 " & strSha & ")"')])),
                 Invoke("Providers/UiPath/Get_Process_Details.xaml", ctx(in_Environment="strTarget", in_FolderId="in_TargetFolderId", in_ProcessName="strProcess", out_ReleaseJson="strJson"), name="Target process"),
                 Assign("strPrevious", '""', "S"),
                 If('strJson = ""',
                    If('in_Request.Value(Of String)("processType") = "New"',
                       Seq("Create process", [
                           api("POST", '"odata/Releases"', "POST odata/Releases", env="strTarget", folder="in_TargetFolderId",
                               body='New JObject(New JProperty("Name", strProcess), New JProperty("ProcessKey", strPackage), New JProperty("ProcessVersion", strVersion), New JProperty("Description", Convert.ToString(in_Request.SelectToken("package.processName")))).ToString(Newtonsoft.Json.Formatting.None)'),
                           Assign("lngRelease", 'JObject.Parse(strBody).Value(Of Long)("Id")', "L"),
                           Code("StepResult", {"in_Result": "in_Result", "in_Kind": '"Process"', "in_Name": "strProcess", "in_Change": '"Created"', "in_Message": '"Created with version " & strVersion'}, "Record")]),
                       Throw('New BusinessRuleException("Process " & strProcess & " does not exist in " & strTarget & "; Enhancement and Bug Fix only update an existing process.")', "Process missing")),
                    Seq("Update process version", [
                        Assign("lngRelease", 'JObject.Parse(strJson).Value(Of Long)("Id")', "L"),
                        Assign("strPrevious", 'JObject.Parse(strJson).Value(Of String)("ProcessVersion")', "S"),
                        If("strPrevious = strVersion",
                           Code("StepResult", {"in_Result": "in_Result", "in_Kind": '"Process"', "in_Name": "strProcess", "in_Change": '"NoChange"', "in_Message": '"Already on version " & strVersion'}, "Record"),
                           Seq("Update to requested version", [
                               api("POST", '"odata/Releases(" & lngRelease.ToString() & ")/UiPath.Server.Configuration.OData.UpdateToSpecificPackageVersion"', "POST Releases/UpdateToSpecificPackageVersion",
                                   env="strTarget", folder="in_TargetFolderId", body='New JObject(New JProperty("packageVersion", strVersion)).ToString(Newtonsoft.Json.Formatting.None)'),
                               Code("StepResult", {"in_Result": "in_Result", "in_Kind": '"Process"', "in_Name": "strProcess", "in_Change": '"Updated"', "in_Message": 'strPrevious & " -> " & strVersion'}, "Record")]))])),
                 api("GET", '"odata/Releases(" & lngRelease.ToString() & ")?$select=Id,Name,ProcessKey,ProcessVersion"', "GET Releases(Id) (verify)", env="strTarget", folder="in_TargetFolderId"),
                 Assign("strDeployed", 'JObject.Parse(strBody).Value(Of String)("ProcessVersion")', "S"),
                 If("strDeployed <> strVersion", Seq("Wrong version: roll back", [
                     If('strPrevious <> "" AndAlso strPrevious <> strVersion',
                        api("POST", '"odata/Releases(" & lngRelease.ToString() & ")/UiPath.Server.Configuration.OData.UpdateToSpecificPackageVersion"', "Rollback to previous version",
                            env="strTarget", folder="in_TargetFolderId", body='New JObject(New JProperty("packageVersion", strPrevious)).ToString(Newtonsoft.Json.Formatting.None)')),
                     audit('strTarget & " process " & strProcess', '"Failed"', '"Version check failed: " & strDeployed & " instead of " & strVersion & If(strPrevious <> "", "; restored " & strPrevious, "")'),
                     Throw('New Exception("Deployment verification failed: " & strProcess & " runs " & strDeployed & " instead of " & strVersion & " in " & strTarget & If(strPrevious <> "", "; previous version " & strPrevious & " restored.", "."))', "Verification failed")])),
                 Code("JsonPut", {"in_Target": "in_Result", "in_Key": '"deployedVersion"', "in_Json": "strDeployed"}, "Keep deployed version"),
                 Code("JsonPut", {"in_Target": "in_Result", "in_Key": '"previousVersion"', "in_Json": "strPrevious"}, "Keep previous version"),
                 audit('strTarget & " process " & strProcess', '"Succeeded"', '"Runs version " & strDeployed & If(strPrevious <> "" AndAlso strPrevious <> strDeployed, " (was " & strPrevious & ")", "")'),
             ], vars=APIV + [Var(n, "S") for n in ["strSource", "strTarget", "strVersion", "strPackage", "strProcess", "strJson", "strFile", "strSha", "strIgnore", "strPrevious", "strDeployed"]]
                + [Var("lngRelease", "L")]))

    Workflow("Providers/UiPath/Execute_UiPath_Deployment.xaml",
             "Runs an approved UiPath request against its target: package + process (Deploy_Package.xaml) for every type; for New "
             "requests also the approved assets, queues and folder access, each checked first and changed only as approved. "
             "Each object is recorded; if any object fails the run fails after the rest were attempted, and a re-run resumes "
             "safely because every step is idempotent.",
             CFG + [Arg("in", "in_Bot", "JO", "Bot ID mapping entry."), Arg("in", "in_Request", "JO", "Validated request."),
                    Arg("in", "in_Details", "JO", "Fresh details (target folder ID)."), Arg("out", "out_Result", "JO", "Result with 'objects'.")],
             Seq("Execute UiPath deployment", [
                 Assign("out_Result", "New JObject()", "JO"),
                 Assign("strTarget", 'in_Request.Value(Of String)("targetEnvironment")', "S"),
                 Assign("lngFolder", 'in_Details.SelectToken("environments." & strTarget & ".folderId").ToObject(Of Long)()', "L"),
                 If("lngFolder <= 0", Throw('New BusinessRuleException("Target folder for " & strTarget & " is not available.")', "No target folder")),
                 Invoke("Providers/UiPath/Deploy_Package.xaml", ctx(in_Request="in_Request", in_TargetFolderId="lngFolder", in_Result="out_Result"), name="Deploy package"),
                 Assign("intFailed", "0", "I"),
                 If('in_Request.Value(Of String)("processType") = "New" AndAlso in_Request("configuration") IsNot Nothing', Seq("Provision configuration (New)", [
                     ForEach("joAsset", "JO", 'in_Request.SelectToken("configuration.assets").Children(Of JObject)().Where(Function(a) a.Value(Of String)("action") = "Create" OrElse a.Value(Of String)("action") = "Update").ToList()',
                             Try("Try asset", Seq("Asset", [
                                 Invoke("Providers/UiPath/Update_Asset_Configuration.xaml", ctx(in_Environment="strTarget", in_FolderId="lngFolder", in_Bot="in_Bot", in_Asset="joAsset", out_Change="strChange", out_Message="strMessage"), name="Update asset"),
                                 Code("StepResult", {"in_Result": "out_Result", "in_Kind": '"Asset"', "in_Name": 'joAsset.Value(Of String)("name")', "in_Change": "strChange", "in_Message": "strMessage"}, "Record")]),
                                 [("EX", "exAsset", Seq("Asset failed", [
                                     Assign("intFailed", "intFailed + 1", "I"),
                                     Code("StepResult", {"in_Result": "out_Result", "in_Kind": '"Asset"', "in_Name": 'joAsset.Value(Of String)("name")', "in_Change": '"Failed"', "in_Message": "exAsset.Message"}, "Record"),
                                     audit('strTarget & " asset " & joAsset.Value(Of String)("name")', '"Failed"', "exAsset.Message")]))]), name="For each approved asset"),
                     ForEach("joQueue", "JO", 'in_Request.SelectToken("configuration.queues").Children(Of JObject)().Where(Function(x) x.Value(Of String)("action") = "Create" OrElse x.Value(Of String)("action") = "Update").ToList()',
                             Try("Try queue", Seq("Queue", [
                                 Invoke("Providers/UiPath/Validate_Queue_Configuration.xaml", ctx(in_Environment="strTarget", in_FolderId="lngFolder", in_Queue="joQueue", in_ApplyChanges="True", out_Change="strChange", out_Message="strMessage"), name="Create or update queue"),
                                 Code("StepResult", {"in_Result": "out_Result", "in_Kind": '"Queue"', "in_Name": 'joQueue.Value(Of String)("proposedName")', "in_Change": "strChange", "in_Message": "strMessage"}, "Record")]),
                                 [("EX", "exQueue", Seq("Queue failed", [
                                     Assign("intFailed", "intFailed + 1", "I"),
                                     Code("StepResult", {"in_Result": "out_Result", "in_Kind": '"Queue"', "in_Name": 'joQueue.Value(Of String)("proposedName")', "in_Change": '"Failed"', "in_Message": "exQueue.Message"}, "Record"),
                                     audit('strTarget & " queue " & joQueue.Value(Of String)("proposedName")', '"Failed"', "exQueue.Message")]))]), name="For each approved queue"),
                     Try("Try access", Seq("Access", [
                         Invoke("Providers/UiPath/Validate_User_Access.xaml", ctx(in_Environment="strTarget", in_FolderId="lngFolder", in_Rows='CType(in_Request.SelectToken("configuration.access"), JArray)', in_ApplyChanges="True", out_Results="jaAccess"), name="Grant folder access"),
                         ForEach("joAcc", "JO", "jaAccess.Children(Of JObject)().ToList()", Seq("Record account", [
                             If('joAcc.Value(Of String)("status") = "Failed"', Assign("intFailed", "intFailed + 1", "I")),
                             Code("StepResult", {"in_Result": "out_Result", "in_Kind": '"Access"', "in_Name": 'joAcc.Value(Of String)("name")', "in_Change": 'joAcc.Value(Of String)("status")', "in_Message": 'joAcc.Value(Of String)("message")'}, "Record")]), name="For each account result")]),
                         [("EX", "exAccess", Seq("Access failed", [
                             Assign("intFailed", "intFailed + 1", "I"),
                             Code("StepResult", {"in_Result": "out_Result", "in_Kind": '"Access"', "in_Name": '"folder access"', "in_Change": '"Failed"', "in_Message": "exAccess.Message"}, "Record"),
                             audit('strTarget & " folder access"', '"Failed"', "exAccess.Message")]))])])),
                 If("intFailed > 0", Throw('New Exception(intFailed.ToString() & " configuration item(s) failed in " & strTarget & ": " & String.Join("; ", out_Result("objects").Children(Of JObject)().Where(Function(o) o.Value(Of String)("change") = "Failed").Select(Function(o) o.Value(Of String)("kind") & " " & o.Value(Of String)("name") & ": " & o.Value(Of String)("message"))) & ". The package step completed; re-run the request to resume.")', "Partial provisioning failure")),
             ], vars=[Var("strTarget", "S"), Var("lngFolder", "L"), Var("intFailed", "I"), Var("strChange", "S"), Var("strMessage", "S"), Var("jaAccess", "JA")]))

    for wfname, path_src, path_tgt, extra_doc in [
        ("Deploy_Dev_To_UAT", "Dev", "UAT", "Option A: no approval unless the Dev to UAT path in settings requires one."),
        ("Deploy_UAT_To_Prod", "UAT", "Prod", "Option B: refuses to run unless Requests\\Check_Approval.xaml confirms the approval and the successful UAT deployment of this exact version (checked again here, not only at submission).")]:
        body = [
            If(f'in_Request.Value(Of String)("sourceEnvironment") <> "{path_src}" OrElse in_Request.Value(Of String)("targetEnvironment") <> "{path_tgt}" OrElse in_Request.Value(Of String)("automationTool") <> "UiPath"',
               Throw(f'New BusinessRuleException("{wfname} received a request for " & in_Request.Value(Of String)("automationTool") & " " & in_Request.Value(Of String)("deploymentPath") & ".")', "Wrong path")),
        ]
        if path_tgt == "Prod":
            body += [
                Invoke("Requests/Check_Approval.xaml", ctx(in_Request="in_Request", out_Satisfied="boolApproved", out_Messages="jaMessages"), name="Check approval and UAT evidence"),
                If("Not boolApproved", Throw('New BusinessRuleException("Production deployment blocked: " & String.Join(" ", jaMessages.Values(Of String)()))', "Blocked: approval missing")),
            ]
        body += [Invoke("Providers/UiPath/Execute_UiPath_Deployment.xaml", ctx(in_Bot="in_Bot", in_Request="in_Request", in_Details="in_Details", out_Result="out_Result"), name="Execute deployment")]
        Workflow(f"Providers/UiPath/{wfname}.xaml",
                 f"{path_src} -> {path_tgt} for UiPath. {extra_doc} Then Execute_UiPath_Deployment.xaml (package for every type; assets, queues and access only for New).",
                 CFG + [Arg("in", "in_Bot", "JO", "Bot ID mapping entry."), Arg("in", "in_Request", "JO", "Validated request."),
                        Arg("in", "in_Details", "JO", "Fresh details."), Arg("out", "out_Result", "JO", "Result.")],
                 Seq(wfname.replace("_", " "), body), )
        if path_tgt == "Prod":
            from xamlgen import REGISTRY
            REGISTRY[f"Providers\\UiPath\\{wfname}.xaml"].body.vars = [Var("boolApproved", "B"), Var("jaMessages", "JA")]
