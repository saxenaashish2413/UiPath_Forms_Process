"""Tiny workflow model that renders to UiPath XAML and to an equivalent VB.NET module.

The VB twin uses the very same expressions and Invoke Code bodies, so compiling it with Option Strict On
checks every expression, and running it against mock APIs tests the control flow end to end.
"""
import pathlib, re, uuid
from xml.sax.saxutils import escape, quoteattr

VB_DIR = pathlib.Path(__file__).parent / "vb"

# short type -> (xaml type, vb type)
T = {
    "S": ("x:String", "String"), "I": ("x:Int32", "Integer"), "L": ("x:Int64", "Long"), "B": ("x:Boolean", "Boolean"),
    "O": ("x:Object", "Object"), "DT": ("sd:DataTable", "DataTable"), "DTM": ("s:DateTime", "DateTime"),
    "DSO": ("scg:Dictionary(x:String, x:Object)", "Dictionary(Of String, Object)"),
    "DSS": ("scg:Dictionary(x:String, x:String)", "Dictionary(Of String, String)"),
    "LS": ("scg:List(x:String)", "List(Of String)"), "LL": ("scg:List(x:Int64)", "List(Of Long)"),
    "SEC": ("ss:SecureString", "System.Security.SecureString"), "EX": ("s:Exception", "Exception"),
    "BRE": ("ui:BusinessRuleException", "BusinessRuleException"),
    "HRS": ("uwahm:HttpResponseSummary", "UiPath.Web.Activities.Http.Models.HttpResponseSummary"),
    "TCE": ("st:TaskCanceledException", "System.Threading.Tasks.TaskCanceledException"),
    "HRE": ("snh:HttpRequestException", "System.Net.Http.HttpRequestException"),
    "JT": ("njl:JToken", "JToken"), "JA": ("njl:JArray", "JArray"), "JO": ("njl:JObject", "JObject"),
    "JRE": ("nj:JsonReaderException", "Newtonsoft.Json.JsonReaderException"),
}

NAMESPACES = ["Microsoft.VisualBasic", "Microsoft.VisualBasic.Activities", "Newtonsoft.Json", "Newtonsoft.Json.Linq", "System",
              "System.Activities", "System.Activities.Expressions", "System.Activities.Statements", "System.Collections",
              "System.Collections.Generic", "System.Collections.ObjectModel", "System.Data", "System.Globalization", "System.IO",
              "System.Linq", "System.Net", "System.Net.Http", "System.Net.Mail", "System.Security", "System.Text",
              "System.Text.RegularExpressions", "UiPath.Core", "UiPath.Core.Activities", "UiPath.Forms.Activities", "UiPath.Platform.Triggers",
              "UiPath.Web.Activities.Http", "UiPath.Web.Activities.Http.Models"]
REFERENCES = ["Microsoft.VisualBasic", "mscorlib", "Newtonsoft.Json", "System", "System.Activities", "System.Collections",
              "System.ComponentModel", "System.Core", "System.Data", "System.Data.Common", "System.Data.DataSetExtensions",
              "System.Linq", "System.Memory", "System.Net.Http", "System.Net.Mail", "System.Net.Primitives", "System.ObjectModel",
              "System.Private.CoreLib", "System.Private.Uri", "System.Runtime", "System.Security.Cryptography",
              "System.Text.RegularExpressions", "System.Xml", "System.Xml.Linq", "UiPath.Excel", "UiPath.Excel.Activities",
              "UiPath.System.Activities", "UiPath.Workflow", "UiPath.Forms.Activities", "UiPath.Platform",
              "UiPath.Web.Activities"]

XMLNS = ('xmlns="http://schemas.microsoft.com/netfx/2009/xaml/activities" '
         'xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006" '
         'xmlns:nj="clr-namespace:Newtonsoft.Json;assembly=Newtonsoft.Json" '
         'xmlns:njl="clr-namespace:Newtonsoft.Json.Linq;assembly=Newtonsoft.Json" '
         'xmlns:s="clr-namespace:System;assembly=System.Private.CoreLib" '
         'xmlns:sap="http://schemas.microsoft.com/netfx/2009/xaml/activities/presentation" '
         'xmlns:sap2010="http://schemas.microsoft.com/netfx/2010/xaml/activities/presentation" '
         'xmlns:scg="clr-namespace:System.Collections.Generic;assembly=System.Private.CoreLib" '
         'xmlns:sco="clr-namespace:System.Collections.ObjectModel;assembly=System.Private.CoreLib" '
         'xmlns:sd="clr-namespace:System.Data;assembly=System.Data.Common" '
         'xmlns:ss="clr-namespace:System.Security;assembly=System.Private.CoreLib" '
         'xmlns:ui="http://schemas.uipath.com/workflow/activities" '
         'xmlns:uf="clr-namespace:UiPath.Forms.Activities;assembly=UiPath.Forms.Activities" '
         'xmlns:upt="clr-namespace:UiPath.Platform.Triggers;assembly=UiPath.Platform" '
         'xmlns:sio="clr-namespace:System.IO;assembly=System.Private.CoreLib" '
         'xmlns:snh="clr-namespace:System.Net.Http;assembly=System.Net.Http" '
         'xmlns:st="clr-namespace:System.Threading.Tasks;assembly=System.Private.CoreLib" '
         'xmlns:uwah="clr-namespace:UiPath.Web.Activities.Http;assembly=UiPath.Web.Activities" '
         'xmlns:uwahm="clr-namespace:UiPath.Web.Activities.Http.Models;assembly=UiPath.Web.Activities" '
         'xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"')

REGISTRY = {}   # workflow path -> Workflow


def X(e):
    """Expression -> XAML expression text (bracketed)."""
    # Workflow expressions are compiled to expression trees: VB null-propagation (?.) is rejected there (BC37240).
    assert "?." not in re.sub(r'"[^"]*"', '""', e), "null-propagating operator in workflow expression: " + e
    return "[" + e + "]"


def a(v):
    # A XAML attribute value starting with "{" is parsed as a markup extension; "{}" escapes it.
    return quoteattr("{}" + v if v.startswith("{") else v)


class Arg:
    def __init__(self, direction, name, typ, doc=""):
        assert direction in ("in", "out", "io")
        self.direction, self.name, self.type, self.doc = direction, name, typ, doc


class Var:
    def __init__(self, name, typ, default=None):
        self.name, self.type, self.default = name, typ, default


class Workflow:
    def __init__(self, path, doc, args, body):
        self.path = path.replace("/", "\\")
        self.cls = re.sub(r"\W", "_", pathlib.PurePosixPath(path.replace("\\", "/")).stem)
        self.vbname = "W_" + re.sub(r"\W", "_", path.replace(".xaml", ""))
        self.doc, self.args, self.body = doc, args, body
        REGISTRY[self.path] = self

    def argmap(self):
        return {x.name: x for x in self.args}


# ---------------------------------------------------------------- activities
def _inject_note(act, text):
    """Adds the step's annotation (Studio: right-click > Annotations) to the first element of its XAML."""
    note = act.annotation()
    if not note:
        return text
    first, nl, rest = text.partition("\n")
    if "Annotation.AnnotationText" in first:
        return text
    first = re.sub(r"^(\s*<[\w:.]+)", lambda m: m.group(1) + " sap2010:Annotation.AnnotationText=" + a(note), first, count=1)
    return first + nl + rest


class Act:
    vars = ()
    note = None

    def __init_subclass__(cls, **kw):
        super().__init_subclass__(**kw)
        if "xaml" in cls.__dict__:
            orig = cls.__dict__["xaml"]

            def xaml(self, ind, *args, _orig=orig, **kws):
                return _inject_note(self, _orig(self, ind, *args, **kws))
            cls.xaml = xaml

    def annotation(self):
        return self.note or self.auto_note()

    def auto_note(self):
        return None

    def walk(self):
        yield self


class Seq(Act):
    def __init__(self, name, items, vars=(), doc=""):
        self.name, self.items, self.vars, self.doc = name, [i for i in items if i is not None], list(vars), doc

    def walk(self):
        yield self
        for i in self.items:
            yield from i.walk()

    def xaml(self, ind):
        p = " " * ind
        out = [f'{p}<Sequence DisplayName={a(self.name)}' + (f' sap2010:Annotation.AnnotationText={a(self.doc)}' if self.doc else "") + ">"]
        if self.vars:
            out.append(f"{p}  <Sequence.Variables>")
            for v in self.vars:
                d = f" Default={a(X(v.default))}" if v.default is not None else ""
                out.append(f'{p}    <Variable x:TypeArguments="{T[v.type][0]}"{d} Name="{v.name}" />')
            out.append(f"{p}  </Sequence.Variables>")
        for i in self.items:
            out.append(i.xaml(ind + 2))
        out.append(f"{p}</Sequence>")
        return "\n".join(out)

    def annotation(self):
        generic = {"Then": "Steps that run when the If condition above is true.",
                   "Else": "Steps that run when the If condition above is false.",
                   "Body": "Steps repeated for each item of the loop above.",
                   "Try": "Steps protected by the Try Catch: an error here goes to the Catch steps."}
        return None if self.doc else (self.note or generic.get(self.name) or f"Group of steps: {self.name}.")

    def vb(self, ind, ctx):
        out = [" " * ind + f"' -- {self.name}"]
        for v in self.vars:
            if v.default is not None:
                out.append(" " * ind + f"{v.name} = {v.default}")
        for i in self.items:
            out.append(i.vb(ind, ctx))
        return "\n".join(out)


class Assign(Act):
    def __init__(self, to, value, typ=None, name=None):
        self.to, self.value, self.typ, self.name = to, value, typ, name

    def xaml(self, ind, wf=None):
        p = " " * ind
        t = T[self.typ][0]
        return (f'{p}<Assign DisplayName={a(self.name or ("Assign " + self.to))}>\n'
                f'{p}  <Assign.To>\n{p}    <OutArgument x:TypeArguments="{t}">{escape(X(self.to))}</OutArgument>\n{p}  </Assign.To>\n'
                f'{p}  <Assign.Value>\n{p}    <InArgument x:TypeArguments="{t}">{escape(X(self.value))}</InArgument>\n{p}  </Assign.Value>\n'
                f'{p}</Assign>')

    def vb(self, ind, ctx):
        return " " * ind + f"{self.to} = {self.value}"

    def auto_note(self):
        return (f"{self.name}: " if self.name else "") + f"stores the result in {self.to}."


class Log(Act):
    def __init__(self, level, message, name=None):
        assert level in ("Trace", "Info", "Warn", "Error", "Fatal")
        self.level, self.message, self.name = level, message, name

    def xaml(self, ind):
        return " " * ind + f'<ui:LogMessage DisplayName={a(self.name or ("Log " + self.level))} Level="{self.level}" Message={a(X(self.message))} />'

    def vb(self, ind, ctx):
        return " " * ind + f'TestHost.Log("{self.level}", CStr({self.message}))'

    def auto_note(self):
        return f"Writes a {self.level} message to the robot log (visible in Orchestrator > Logs). No secrets are written."


class If(Act):
    def __init__(self, cond, then, els=None, name=None):
        self.cond, self.then, self.els, self.name = cond, then, els, name

    def walk(self):
        yield self
        yield from self.then.walk()
        if self.els:
            yield from self.els.walk()

    def xaml(self, ind):
        p = " " * ind
        out = [f'{p}<If Condition={a(X(self.cond))} DisplayName={a(self.name or "If")}>', f"{p}  <If.Then>", self.then.xaml(ind + 4), f"{p}  </If.Then>"]
        if self.els:
            out += [f"{p}  <If.Else>", self.els.xaml(ind + 4), f"{p}  </If.Else>"]
        out.append(f"{p}</If>")
        return "\n".join(out)

    def vb(self, ind, ctx):
        p = " " * ind
        out = [f"{p}If {self.cond} Then", self.then.vb(ind + 4, ctx)]
        if self.els:
            out += [f"{p}Else", self.els.vb(ind + 4, ctx)]
        out.append(f"{p}End If")
        return "\n".join(out)

    def auto_note(self):
        return (f"Decision: {self.name}. " if self.name else "") + "Runs Then when the condition is true" + (", otherwise Else." if self.els else "; otherwise nothing happens.")


class Throw(Act):
    def __init__(self, exc, name=None):
        self.exc, self.name = exc, name

    def xaml(self, ind):
        return " " * ind + f'<Throw DisplayName={a(self.name or "Throw")} Exception={a(X(self.exc))} />'

    def vb(self, ind, ctx):
        return " " * ind + f"Throw {self.exc}"

    def auto_note(self):
        return f"Stops here with an error ({self.name or 'Throw'}). The caller's Try Catch decides what the user sees."


class Rethrow(Act):
    def xaml(self, ind):
        return " " * ind + '<Rethrow DisplayName="Rethrow" />'

    def vb(self, ind, ctx):
        return " " * ind + "Throw"

    def auto_note(self):
        return "Passes the caught error on to the calling workflow unchanged."


class Try(Act):
    def __init__(self, name, body, catches, final=None):
        self.name, self.body, self.catches, self.final = name, body, catches, final   # catches: [(type, varname, Seq)]

    def walk(self):
        yield self
        yield from self.body.walk()
        for _, _, s in self.catches:
            yield from s.walk()
        if self.final:
            yield from self.final.walk()

    def xaml(self, ind):
        p = " " * ind
        out = [f"{p}<TryCatch DisplayName={a(self.name)}>", f"{p}  <TryCatch.Try>", self.body.xaml(ind + 4), f"{p}  </TryCatch.Try>"]
        if self.catches:
            out.append(f"{p}  <TryCatch.Catches>")
            for t, v, s in self.catches:
                xt = T[t][0]
                out += [f'{p}    <Catch x:TypeArguments="{xt}">', f'{p}      <ActivityAction x:TypeArguments="{xt}">',
                        f"{p}        <ActivityAction.Argument>", f'{p}          <DelegateInArgument x:TypeArguments="{xt}" Name="{v}" />',
                        f"{p}        </ActivityAction.Argument>", s.xaml(ind + 8), f"{p}      </ActivityAction>", f"{p}    </Catch>"]
            out.append(f"{p}  </TryCatch.Catches>")
        if self.final:
            out += [f"{p}  <TryCatch.Finally>", self.final.xaml(ind + 4), f"{p}  </TryCatch.Finally>"]
        out.append(f"{p}</TryCatch>")
        return "\n".join(out)

    def vb(self, ind, ctx):
        p = " " * ind
        out = [f"{p}Try", self.body.vb(ind + 4, ctx)]
        for t, v, s in self.catches:
            out += [f"{p}Catch {v} As {T[t][1]}", s.vb(ind + 4, ctx)]
        if self.final:
            out += [f"{p}Finally", self.final.vb(ind + 4, ctx)]
        out.append(f"{p}End Try")
        return "\n".join(out)

    def auto_note(self):
        kinds = ", ".join(T[t][1].split(".")[-1] for t, _, _ in self.catches)
        return f"{self.name}: runs the steps in Try. If a {kinds} happens, the Catch steps run instead of stopping the robot." + (" Finally always runs." if self.final else "")


class ForEach(Act):
    def __init__(self, item, typ, values, body, name=None):
        self.item, self.typ, self.values, self.body, self.name = item, typ, values, body, name

    def walk(self):
        yield self
        yield from self.body.walk()

    def xaml(self, ind):
        p = " " * ind
        xt = T[self.typ][0]
        return "\n".join([
            f'{p}<ui:ForEach x:TypeArguments="{xt}" CurrentIndex="{{x:Null}}" DisplayName={a(self.name or "For Each")} Values={a(X(self.values))}>',
            f"{p}  <ui:ForEach.Body>", f'{p}    <ActivityAction x:TypeArguments="{xt}">', f"{p}      <ActivityAction.Argument>",
            f'{p}        <DelegateInArgument x:TypeArguments="{xt}" Name="{self.item}" />', f"{p}      </ActivityAction.Argument>",
            self.body.xaml(ind + 6), f"{p}    </ActivityAction>", f"{p}  </ui:ForEach.Body>", f"{p}</ui:ForEach>"])

    def vb(self, ind, ctx):
        p = " " * ind
        return f"{p}For Each {self.item} As {T[self.typ][1]} In {self.values}\n{self.body.vb(ind + 4, ctx)}\n{p}Next"

    def auto_note(self):
        return (f"{self.name}: " if self.name else "") + f"repeats the steps inside once for each item; the current item is {self.item}."


class DoWhile(Act):
    def __init__(self, cond, body, name=None):
        self.cond, self.body, self.name = cond, body, name

    def walk(self):
        yield self
        yield from self.body.walk()

    def xaml(self, ind):
        p = " " * ind
        return f'{p}<DoWhile Condition={a(X(self.cond))} DisplayName={a(self.name or "Do While")}>\n{self.body.xaml(ind + 2)}\n{p}</DoWhile>'

    def vb(self, ind, ctx):
        p = " " * ind
        return f"{p}Do\n{self.body.vb(ind + 4, ctx)}\n{p}Loop While {self.cond}"

    def auto_note(self):
        return (f"{self.name}: " if self.name else "") + "runs the steps inside, then repeats them while the condition is true."


class Delay(Act):
    def __init__(self, seconds_expr, name=None):
        self.s, self.name = seconds_expr, name

    def xaml(self, ind):
        return " " * ind + f'<Delay DisplayName={a(self.name or "Delay")} Duration={a(X("TimeSpan.FromSeconds(" + self.s + ")"))} />'

    def vb(self, ind, ctx):
        return " " * ind + f"TestHost.Delay(TimeSpan.FromSeconds({self.s}))"

    def auto_note(self):
        return f"Waits {self.s} second(s) before the next step."


class Invoke(Act):
    def __init__(self, path, args, name=None):
        self.path, self.args, self.name = path.replace("/", "\\"), args, name

    def target(self):
        if self.path not in REGISTRY:
            raise KeyError("Unknown workflow " + self.path)
        return REGISTRY[self.path]

    def xaml(self, ind):
        p = " " * ind
        tgt = self.target()
        am = tgt.argmap()
        out = [f'{p}<ui:InvokeWorkflowFile ArgumentsVariable="{{x:Null}}" ContinueOnError="{{x:Null}}" DisplayName={a(self.name or ("Invoke " + tgt.cls))} UnSafe="False" WorkflowFileName={a(self.path)}>',
               f"{p}  <ui:InvokeWorkflowFile.Arguments>"]
        for k, v in self.args.items():
            if k not in am:
                raise KeyError(f"{self.path} has no argument {k}")
            d = {"in": "InArgument", "out": "OutArgument", "io": "InOutArgument"}[am[k].direction]
            out.append(f'{p}    <{d} x:TypeArguments="{T[am[k].type][0]}" x:Key="{k}">{escape(X(v))}</{d}>')
        out += [f"{p}  </ui:InvokeWorkflowFile.Arguments>", f"{p}</ui:InvokeWorkflowFile>"]
        return "\n".join(out)

    def vb(self, ind, ctx):
        tgt = self.target()
        return " " * ind + f"{tgt.vbname}(" + ", ".join(f"{k}:=({v})" if k.startswith("in_") else f"{k}:={v}" for k, v in self.args.items()) + ")"  # in-args are copies in UiPath; parentheses make VB pass a copy too

    def auto_note(self):
        tgt = self.target()
        first = re.split(r"(?<=\.)\s", tgt.doc, 1)[0] if tgt.doc else ""
        return f"Runs {self.path}. {first}".strip()


CODE_USES = {}


class Code(Act):
    """Runs the logic in vb/<name>.vb, translated by vbl.py into Logic\\<name>.xaml (standard activities only).
    args: {argument name: expression}."""

    def __init__(self, name, args, display):
        import vbl
        wf = vbl.workflow_for(name)
        dn = {x.name for x in wf.args}
        assert set(args) == dn, f"{name}: args {sorted(set(args) ^ dn)} mismatch"
        CODE_USES[name] = CODE_USES.get(name, 0) + 1
        self.inv = Invoke(wf.path, args, display)
        self.name = display

    def xaml(self, ind):
        return self.inv.xaml(ind)

    def annotation(self):
        return self.note or self.inv.auto_note()

    def vb(self, ind, ctx):
        return self.inv.vb(ind, ctx)


class GetCredential(Act):
    def __init__(self, asset, folder, user, pwd, name):
        self.asset, self.folder, self.user, self.pwd, self.name = asset, folder, user, pwd, name

    def xaml(self, ind):
        return " " * ind + (f'<ui:GetRobotCredential TimeoutMS="{{x:Null}}" AssetName={a(X(self.asset))} DisplayName={a(self.name)} '
                            f'FolderPath={a(X(self.folder))} Password={a(X(self.pwd))} Username={a(X(self.user))} />')

    def vb(self, ind, ctx):
        return " " * ind + f"TestHost.GetCredential({self.asset}, {self.folder}, {self.user}, {self.pwd})"

    def auto_note(self):
        return "Get Credential: reads the Orchestrator Credential asset named here. The password stays a SecureString and is never logged or shown."


class ReadRange(Act):
    def __init__(self, path, sheet, dt, name=None):
        self.path, self.sheet, self.dt, self.name = path, sheet, dt, name

    def xaml(self, ind):
        return " " * ind + (f'<ui:ReadRange Range="{{x:Null}}" AddHeaders="True" DataTable={a(X(self.dt))} DisplayName={a(self.name or ("Read " + self.sheet + " sheet"))} '
                            f'SheetName={a(self.sheet)} WorkbookPath={a(X(self.path))} />')

    def vb(self, ind, ctx):
        return " " * ind + f'{self.dt} = TestHost.ReadRange({self.path}, "{self.sheet}")'

    def auto_note(self):
        return "Read Range: reads the sheet into a DataTable."

class AddLogFields(Act):
    def __init__(self, fields, name="Add log fields"):
        self.fields, self.name = fields, name

    def xaml(self, ind):
        p = " " * ind
        out = [f"{p}<ui:AddLogFields DisplayName={a(self.name)}>", f"{p}  <ui:AddLogFields.Fields>"]
        for k, v in self.fields.items():
            out.append(f'{p}    <InArgument x:TypeArguments="x:String" x:Key="{k}">{escape(X(v))}</InArgument>')
        out += [f"{p}  </ui:AddLogFields.Fields>", f"{p}</ui:AddLogFields>"]
        return "\n".join(out)

    def vb(self, ind, ctx):
        return "\n".join(" " * ind + f'TestHost.AddLogField("{k}", CStr({v}))' for k, v in self.fields.items())

    def auto_note(self):
        return "Add Log Fields: adds these values to every following log message, so the logs can be filtered by request."

class MessageBox(Act):
    def __init__(self, caption, text, name="Message Box"):
        self.caption, self.text, self.name = caption, text, name

    def xaml(self, ind):
        return " " * ind + (f'<ui:MessageBox AutoCloseAfter="{{x:Null}}" Buttons="{{x:Null}}" ChosenButton="{{x:Null}}" Caption={a(X(self.caption))} '
                            f'DisplayName={a(self.name)} Text={a(X(self.text))} TopMost="True" />')

    def vb(self, ind, ctx):
        return " " * ind + f"TestHost.MessageBox({self.caption}, {self.text})"

    def auto_note(self):
        return "Message Box: shows this message to the person running the robot."

class HttpRequest(Act):
    """UiPath.WebAPI.Activities 'HTTP Request' (UiPath.Web.Activities.Http.NetHttpRequest, package 2.4.0).
    Property names and defaults are taken from the package itself. Non-2xx statuses do not throw: the status is in Result.
    ContinueOnError = True turns connection errors into HTTP 503 (retried like any 503). RetryCount is the total number of
    attempts (the retry handler loops RetryCount times). Method and RequestBodyType are design-time enums, so each
    method/body combination is its own activity."""
    BODY = ("None", "Text", "FormUrlEncoded", "MultipartFormData")

    def __init__(self, name, method, url, result, headers=None, token=None, body_type="None", text=None, form=None, parts=None,
                 timeout_ms="10000", attempts="1", delay_ms="0", save_folder=None, save_name=None):
        assert method in ("GET", "POST", "PUT", "PATCH", "DELETE") and body_type in self.BODY
        self.name, self.method, self.url, self.result, self.headers, self.token = name, method, url, result, headers, token
        self.body_type, self.text, self.form, self.parts = body_type, text, form, parts
        self.timeout_ms, self.attempts, self.delay_ms, self.save_folder, self.save_name = timeout_ms, attempts, delay_ms, save_folder, save_name

    def props(self):
        pr = [("Method", self.method, False), ("RequestUrl", self.url, True)]
        if self.headers:
            pr.append(("Headers", self.headers, True))
        pr.append(("AuthenticationType", "OAuthToken" if self.token else "None", False))
        if self.token:
            pr.append(("OAuthToken", self.token, True))
        pr.append(("RequestBodyType", self.body_type, False))
        if self.body_type == "Text":
            pr += [("TextPayload", self.text, True), ("TextPayloadContentType", '"application/json"', True), ("TextPayloadEncoding", '"UTF-8"', True)]
        if self.body_type == "FormUrlEncoded":
            pr.append(("FormData", self.form, True))
        if self.body_type == "MultipartFormData":
            pr.append(("FormDataParts", self.parts, True))
        pr += [("TimeoutInMiliseconds", self.timeout_ms, True), ("ContinueOnError", "True", True),
               ("RetryPolicyType", "ExponentialBackoff", False), ("RetryCount", self.attempts, True), ("InitialDelay", self.delay_ms, True),
               ("Multiplier", "2.0", True), ("UseJitter", "False", True), ("PreferRetryAfterValue", "True", True), ("MaxRetryAfterDelay", "120000", True),
               ("FollowRedirects", "True", True), ("EnableCookies", "False", True), ("DisableSslVerification", "False", True),
               ("SaveRawRequestResponse", "False", True)]
        if self.save_folder:
            pr += [("SaveResponseAsFile", "True", True), ("OutputFileTargetFolder", self.save_folder, True), ("OutputFileName", self.save_name, True),
                   ("FileOverwrite", "Replace", False)]
        else:
            pr.append(("SaveResponseAsFile", "False", True))
        pr.append(("Result", self.result, True))
        return pr

    def xaml(self, ind):
        attrs = " ".join(f"{k}={a(X(v) if expr else v)}" for k, v, expr in self.props())
        return " " * ind + f"<uwah:NetHttpRequest DisplayName={a(self.name)} {attrs} />"

    def vb(self, ind, ctx):
        d = {k: v for k, v, _ in self.props()}
        args = [q(self.method), d["RequestUrl"], d.get("Headers", "Nothing"), d.get("OAuthToken", "Nothing"), q(self.body_type),
                d.get("TextPayload", "Nothing"), d.get("FormData", "Nothing"), d.get("FormDataParts", "Nothing"), d["TimeoutInMiliseconds"],
                d["RetryCount"], d["InitialDelay"], d.get("OutputFileTargetFolder", "Nothing"), d.get("OutputFileName", "Nothing")]
        return " " * ind + f"{self.result} = TestHost.NetHttpRequest(" + ", ".join(f"({x})" for x in args) + ")"

    def auto_note(self):
        return (f"HTTP Request ({self.method}): calls the REST API at the URL shown. Retries 408, 429 and 5xx with exponential back-off; "
                f"the status code and response body come back in {self.result} and are checked by the next steps.")

class DeleteFile(Act):
    """System.Activities InvokeMethod: System.IO.File.Delete(path)."""

    def __init__(self, path, name):
        self.path, self.name = path, name

    def xaml(self, ind):
        p = " " * ind
        return (f'{p}<InvokeMethod DisplayName={a(self.name)} MethodName="Delete" TargetType="sio:File">\n'
                f'{p}  <InArgument x:TypeArguments="x:String">{escape(X(self.path))}</InArgument>\n{p}</InvokeMethod>')

    def vb(self, ind, ctx):
        return " " * ind + f"System.IO.File.Delete({self.path})"

    def auto_note(self):
        return "Invoke Method File.Delete: removes the temporary file."


def q(s):
    return '"' + s.replace('"', '""') + '"'


# ---------------------------------------------------------------- rendering
def all_vars(wf):
    seen = {}
    for act in wf.body.walk():
        for v in getattr(act, "vars", ()):
            if v.name in seen and seen[v.name] != v.type:
                raise ValueError(f"{wf.path}: variable {v.name} declared twice with different types")
            seen[v.name] = v.type
    return seen


def render_xaml(wf):
    members = []
    for x in wf.args:
        d = {"in": "InArgument", "out": "OutArgument", "io": "InOutArgument"}[x.direction]
        members.append(f'    <x:Property sap2010:Annotation.AnnotationText={a(x.doc)} Name="{x.name}" Type="{d}({T[x.type][0]})" />')
    ns = "\n".join(f"      <x:String>{n}</x:String>" for n in NAMESPACES)
    refs = "\n".join(f"      <AssemblyReference>{r}</AssemblyReference>" for r in REFERENCES)
    body = wf.body
    body.doc = body.doc or wf.doc
    return f'''<?xml version="1.0" encoding="utf-8"?>
<Activity mc:Ignorable="sap sap2010" x:Class="{wf.cls}" {XMLNS}>
  <x:Members>
{chr(10).join(members)}
  </x:Members>
  <VisualBasic.Settings>
    <x:Null />
  </VisualBasic.Settings>
  <TextExpression.NamespacesForImplementation>
    <sco:Collection x:TypeArguments="x:String">
{ns}
    </sco:Collection>
  </TextExpression.NamespacesForImplementation>
  <TextExpression.ReferencesForImplementation>
    <sco:Collection x:TypeArguments="AssemblyReference">
{refs}
    </sco:Collection>
  </TextExpression.ReferencesForImplementation>
{body.xaml(2)}
</Activity>
'''


def render_vb(wf):
    params = ", ".join(f"Optional {'ByVal' if x.direction == 'in' else 'ByRef'} {x.name} As {T[x.type][1]} = Nothing" for x in wf.args)
    vs = all_vars(wf)
    argn = {x.name for x in wf.args}
    out = [f"    ' {wf.path}", f"    Public Sub {wf.vbname}({params})", f'        TestHost.Enter("{wf.path}")']
    for n, t in vs.items():
        if n in argn:
            raise ValueError(f"{wf.path}: variable {n} shadows an argument")
        out.append(f"        Dim {n} As {T[t][1]} = Nothing")
    out.append(wf.body.vb(8, wf))
    out.append(f'        TestHost.Leave("{wf.path}")')
    out.append("    End Sub")
    return "\n".join(out)


def render_code_subs():
    return ""
    out = []
    for name in sorted(CODE_USES):
        decl, body = load_code(name)
        params = ", ".join(f"{'ByVal' if d == 'in' else 'ByRef'} {n} As {T[t][1]}" for d, n, t in decl)  # UiPath compiles In as ByVal, Out/InOut as ByRef
        out.append(f"    Public Sub IC_{name}({params})\n" + "\n".join("        " + l for l in body.splitlines()) + "\n    End Sub")
    return "\n".join(out)
