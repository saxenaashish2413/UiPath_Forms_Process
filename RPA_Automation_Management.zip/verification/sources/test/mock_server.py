"""MOCK of three standalone Orchestrators (Dev/UAT/Prod, with Identity Server token endpoints), Microsoft Entra ID token
endpoint and three Dataverse environments, for OFFLINE tests of the generated workflows (VB twin). It implements only the
calls the workflows make, with the request/response shapes from the Orchestrator 2025.10 and Dataverse Web API docs.
It is NOT a substitute for testing against real environments.

  /orch/<Env>/identity/connect/token            client_credentials (form-urlencoded)
  /orch/<Env>/odata/...                          Folders, Releases, Processes (GetProcessVersions, DownloadPackage, UploadPackage),
                                                 Assets, QueueDefinitions, QueueItems, Queues/UiPathODataSvc.AddQueueItem,
                                                 Folders/GetUsersForFolder, Folders/AssignUsers, Users, Roles
  /entra/<tenant>/oauth2/v2.0/token              client_credentials, scope <envUrl>/.default
  /dv/<Env>/api/data/v9.2/...                    RetrieveCurrentOrganization, solutions, solutioncomponents, workflows,
                                                 ExportSolution, ImportSolutionAsync, asyncoperations(id)
  /__control  POST {"op": "reset" | "fault" | "set", ...}     /__state GET     /__log GET (request log, secrets redacted)
Usage: python3 mock_server.py <port>"""
import base64, copy, json, re, sys, threading, urllib.parse, uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

LOCK = threading.RLock()
APPS = {"Dev": ("am-dev", "dev-secret-123"), "UAT": ("am-uat", "uat-secret-456"), "Prod": ("am-prod", "prod-secret-789")}
PA_APP = ("pa-app", "pa-secret-000")
ROLES = [{"Id": 1, "Name": "Automation User", "Type": "Mixed"}, {"Id": 2, "Name": "Allow to be Automation User", "Type": "Mixed"},
         {"Id": 3, "Name": "Automation Developer", "Type": "Mixed"}, {"Id": 4, "Name": "Folder Administrator", "Type": "Mixed"},
         {"Id": 5, "Name": "Robot Operator", "Type": "Folder"}]


def pkg(pid, ver):
    return ("NUPKG|" + pid + "|" + ver + "|" + "x" * 64).encode()


def initial():
    def orch(env, deployed, feed, assets, queues, users, folder_users, extra_folders=()):
        folders = [{"Id": 10, "DisplayName": "Invoice", "FullyQualifiedName": "Finance/Invoice"},
                   {"Id": 20, "DisplayName": "AutomationManagement", "FullyQualifiedName": "Shared/AutomationManagement"},
                   {"Id": 30, "DisplayName": "SecretStaging", "FullyQualifiedName": "Shared/SecretStaging"}] + list(extra_folders)
        rel = [] if deployed is None else [{"Id": 501, "Key": str(uuid.uuid5(uuid.NAMESPACE_URL, env)), "Name": "InvoiceProcessing", "ProcessKey": "InvoiceProcessing",
                                            "ProcessVersion": deployed, "Description": "Reads invoices and posts them.", "IsLatestVersion": False, "_folder": 10}]
        return {"folders": folders, "releases": rel, "feed": {"InvoiceProcessing": {v: pkg("InvoiceProcessing", v) for v in feed}},
                "assets": {10: assets}, "queues": {10: queues, 20: [
                    {"Id": 901, "Name": "AM_Requests", "Description": "", "MaxNumberOfRetries": 0, "AcceptAutomaticallyRetry": False, "EnforceUniqueReference": True},
                    {"Id": 902, "Name": "AM_Approvals", "Description": "", "MaxNumberOfRetries": 0, "AcceptAutomaticallyRetry": False, "EnforceUniqueReference": True},
                    {"Id": 903, "Name": "AM_DeploymentResults", "Description": "", "MaxNumberOfRetries": 0, "AcceptAutomaticallyRetry": False, "EnforceUniqueReference": True}]},
                "users": users, "folderUsers": folder_users, "queueItems": [], "nextId": 1000, "stuckRelease": False}
    users = [{"Id": 71, "UserName": "CORP\\Finance-RPA-Operators", "Name": "Finance-RPA-Operators", "Type": "DirectoryGroup"},
             {"Id": 72, "UserName": "CORP\\dev.lead", "Name": "dev.lead", "Type": "DirectoryUser"}]
    dev_assets = [{"Id": 301, "Name": "INV_ApiBaseUrl", "ValueType": "Text", "ValueScope": "Global", "StringValue": "https://dev-api.example.local", "Description": "API base URL"},
                  {"Id": 302, "Name": "INV_MaxInvoices", "ValueType": "Integer", "ValueScope": "Global", "IntValue": 50, "Description": ""},
                  {"Id": 303, "Name": "INV_ServiceAccount", "ValueType": "Credential", "ValueScope": "Global", "Description": "Service account",
                   "CredentialUsername": "svc_dev", "CredentialPassword": "DEV-ONLY-PASSWORD"}]
    dev_queues = [{"Id": 401, "Name": "INV_Invoices", "Description": "Invoices to process", "MaxNumberOfRetries": 1, "AcceptAutomaticallyRetry": True, "EnforceUniqueReference": True}]
    dev_fu = {10: {71: [5], 72: [3]}}
    st = {"orch": {
        "Dev": orch("Dev", "1.4.0", ["1.3.2", "1.4.0", "1.10.0"], dev_assets, dev_queues, users, dev_fu),
        "UAT": orch("UAT", None, [], [{"Id": 312, "Name": "INV_MaxInvoices", "ValueType": "Integer", "ValueScope": "Global", "IntValue": 25, "Description": ""}], [],
                    copy.deepcopy(users), {10: {72: [{"Id": 1, "Origin": "Inherited"}]}}),
        "Prod": orch("Prod", "1.3.2", ["1.3.2"], [], [], copy.deepcopy(users), {10: {}})},
        "dv": {env: {"org": {"FriendlyName": f"Contoso {env}", "EnvironmentId": str(uuid.uuid5(uuid.NAMESPACE_URL, "dv" + env))},
                     "solutions": [], "components": [], "workflows": [], "async": {}} for env in ("Dev", "UAT", "Prod")},
        "faults": [], "log": [], "tokens": {}}
    sid = str(uuid.uuid5(uuid.NAMESPACE_URL, "sol"))
    st["dv"]["Dev"]["solutions"] = [{"solutionid": sid, "uniquename": "PurchaseApprovals", "friendlyname": "Purchase Approvals", "version": "1.0.0.3",
                                     "ismanaged": False, "description": "Purchase approval flows", "modifiedon": "2026-10-01T10:00:00Z"}]
    wid = str(uuid.uuid5(uuid.NAMESPACE_URL, "flow1"))
    st["dv"]["Dev"]["components"] = [{"_solutionid_value": sid, "componenttype": 29, "objectid": wid}]
    st["dv"]["Dev"]["workflows"] = [{"workflowid": wid, "name": "Purchase approval", "category": 5, "statecode": 1, "statuscode": 2}]
    return st


STATE = initial()


def redact(s):
    s = re.sub(r"(client_secret=)[^&]*", r"\1***", s)
    s = re.sub(r'("CredentialPassword"\s*:\s*")[^"]*', r"\1***", s)
    return s


class H(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *a):
        pass

    def send(self, status, body=None, ctype="application/json", headers=None):
        data = b"" if body is None else (body if isinstance(body, bytes) else json.dumps(body, default=lambda o: o.decode("latin-1") if isinstance(o, bytes) else str(o)).encode())
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("X-UIPATH-Correlation-Id", str(uuid.uuid4()))
        for k, v in (headers or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(data)

    def err(self, status, msg, code=0):
        self.send(status, {"message": msg, "errorCode": code, "traceId": "mock-" + uuid.uuid4().hex[:8]})

    def do_GET(self):
        self.handle_any("GET")

    def do_POST(self):
        self.handle_any("POST")

    def do_PUT(self):
        self.handle_any("PUT")

    def handle_any(self, method):
        n = int(self.headers.get("Content-Length") or 0)
        raw = self.rfile.read(n) if n else b""
        u = urllib.parse.urlsplit(self.path)
        path = urllib.parse.unquote(u.path)
        qs = {k: v[0] for k, v in urllib.parse.parse_qs(u.query, keep_blank_values=True).items()}
        with LOCK:
            if path == "/__control":
                return self.control(json.loads(raw or b"{}"))
            if path == "/__state":
                return self.send(200, {k: v for k, v in STATE.items() if k != "log"}, )
            if path == "/__log":
                return self.send(200, STATE["log"])
            entry = {"method": method, "path": path, "query": u.query, "folder": self.headers.get("X-UIPATH-OrganizationUnitId"),
                     "tenant": self.headers.get("X-UIPATH-TenantName"), "auth": (self.headers.get("Authorization") or "")[:7],
                     "body": redact(raw.decode("utf-8", "replace"))[:4000] if not raw.startswith(b"--") else "(multipart)"}
            STATE["log"].append(entry)
            for f in STATE["faults"]:
                if f["times"] > 0 and f.get("method", method) == method and f["contains"] in path + "?" + urllib.parse.unquote(u.query):
                    f["times"] -= 1
                    entry["fault"] = f["status"]
                    return self.send(f["status"], f.get("body", {"message": "Injected fault " + str(f["status"])}), headers=f.get("headers"))
            m = re.match(r"^/orch/(Dev|UAT|Prod)(/.*)$", path)
            if m:
                return self.orch(m.group(1), m.group(2), method, qs, raw)
            m = re.match(r"^/entra/([^/]+)/oauth2/v2.0/token$", path)
            if m:
                return self.entra(raw)
            m = re.match(r"^/dv/(Dev|UAT|Prod)/api/data/v9.2/(.*)$", path)
            if m:
                return self.dv(m.group(1), m.group(2), method, qs, raw)
            self.err(404, "No route " + path)

    def control(self, c):
        global STATE
        if c["op"] == "reset":
            STATE = initial()
        elif c["op"] == "fault":
            STATE["faults"].append({"contains": c["contains"], "status": c["status"], "times": c.get("times", 1), "method": c.get("method", None) or None,
                                    "body": c.get("body"), "headers": c.get("headers")})
            if STATE["faults"][-1]["method"] is None:
                STATE["faults"][-1].pop("method")
        elif c["op"] == "set":   # {"path": ["orch","UAT","stuckRelease"], "value": ...}
            t = STATE
            for k in c["path"][:-1]:
                t = t[int(k) if isinstance(t, list) else k]
            t[c["path"][-1]] = c["value"]
        elif c["op"] == "queueitem":   # simulate another person's record (e.g. an approval made by a different approver)
            o = STATE["orch"][c["env"]]
            q = next(q for q in o["queues"][20] if q["Name"] == c["queue"])
            o["nextId"] += 1
            o["queueItems"].append({"Id": o["nextId"], "QueueDefinitionId": q["Id"], "Status": "New", "Reference": c["reference"], "Priority": "Normal",
                                    "SpecificContent": c["content"], "CreationTime": "2026-10-11T12:30:00Z", "_folder": 20})
        elif c["op"] == "clearlog":
            STATE["log"] = []
        self.send(200, {"ok": True})

    # ------------------------------------------------------------------ tokens
    def form(self, raw):
        return {k: v[0] for k, v in urllib.parse.parse_qs(raw.decode()).items()}

    def issue(self, key, scope):
        tok = "mock-" + uuid.uuid4().hex
        STATE["tokens"][tok] = {"key": key, "scope": scope}
        self.send(200, {"access_token": tok, "token_type": "Bearer", "expires_in": 3600, "scope": scope})

    def entra(self, raw):
        f = self.form(raw)
        if f.get("grant_type") != "client_credentials" or (f.get("client_id"), f.get("client_secret")) != PA_APP:
            return self.send(401, {"error": "invalid_client", "error_description": "AADSTS7000215: Invalid client secret provided."})
        m = re.match(r"^http://[^/]+/dv/(Dev|UAT|Prod)/\.default$", f.get("scope", ""))
        if not m:
            return self.send(400, {"error": "invalid_scope", "error_description": "AADSTS70011: invalid scope"})
        self.issue("dv:" + m.group(1), f["scope"])

    def authorized(self, key):
        h = self.headers.get("Authorization") or ""
        t = STATE["tokens"].get(h[7:]) if h.startswith("Bearer ") else None
        if t is None or t["key"] != key:
            self.send(401, {"message": "You are not authenticated!", "errorCode": 0})
            return False
        return True

    # ------------------------------------------------------------------ Orchestrator
    def orch(self, env, p, method, qs, raw):
        o = STATE["orch"][env]
        if p == "/identity/connect/token":
            f = self.form(raw)
            if f.get("grant_type") != "client_credentials" or (f.get("client_id"), f.get("client_secret")) != APPS[env]:
                return self.send(400, {"error": "invalid_client"})
            return self.issue("orch:" + env, f.get("scope", ""))
        if not self.authorized("orch:" + env):
            return
        if self.headers.get("X-UIPATH-TenantName") != "Default":
            return self.err(400, "Tenant header missing")
        folder = self.headers.get("X-UIPATH-OrganizationUnitId")
        fid = int(folder) if folder else None
        flt = qs.get("$filter", "")
        top, skip = int(qs.get("$top", "1000")), int(qs.get("$skip", "0"))

        def page(items):
            return self.send(200, {"@odata.context": "mock", "@odata.count": len(items), "value": items[skip:skip + top]})

        def eq(field):
            m = re.search(field + r" eq '((?:[^']|'')*)'", flt)
            return None if not m else m.group(1).replace("''", "'")

        def need_folder():
            if fid is None or not any(f["Id"] == fid for f in o["folders"]):
                self.err(400, "A folder is required for this action.", 1101)
                return False
            return True

        def nid():
            o["nextId"] += 1
            return o["nextId"]

        clean = lambda x: {k: v for k, v in x.items() if not k.startswith("_") and k not in ("CredentialPassword", "CredentialUsername")}
        if p == "/odata/Folders" and method == "GET":
            v = eq("FullyQualifiedName")
            return page([f for f in o["folders"] if v is None or f["FullyQualifiedName"] == v])
        m = re.match(r"^/odata/Folders/UiPath.Server.Configuration.OData.GetUsersForFolder\(key=(\d+),includeInherited=(true|false)\)$", p)
        if m:
            k, inh = int(m.group(1)), m.group(2) == "true"
            out = []
            for uid, roles in o["folderUsers"].get(k, {}).items():
                user = next(u for u in o["users"] if u["Id"] == uid)
                rs = []
                for r in roles:
                    rid, origin = (r["Id"], r["Origin"]) if isinstance(r, dict) else (r, "Assigned")
                    if origin == "Inherited" and not inh:
                        continue
                    rs.append({"Id": rid, "Name": next(x["Name"] for x in ROLES if x["Id"] == rid), "Origin": origin})
                if rs:
                    out.append({"UserEntity": {"Id": user["Id"], "UserName": user["UserName"], "Name": user["Name"], "Type": user["Type"]}, "Roles": rs})
            return page(out)
        if p == "/odata/Folders/UiPath.Server.Configuration.OData.AssignUsers" and method == "POST":
            b = json.loads(raw)["assignments"]
            for uid in b["UserIds"]:
                for rf in b["RolesPerFolder"]:
                    cur = o["folderUsers"].setdefault(rf["FolderId"], {}).get(uid, [])
                    inherited = [r for r in cur if isinstance(r, dict) and r["Origin"] == "Inherited"]
                    o["folderUsers"][rf["FolderId"]][uid] = inherited + list(rf["RoleIds"])   # replaces the assigned roles
            return self.send(204)
        if p == "/odata/Users" and method == "GET":
            v = eq("UserName")
            return page([u for u in o["users"] if v is None or u["UserName"].lower() == v.lower()])
        if p == "/odata/Roles":
            return page(ROLES)
        if p == "/odata/Releases" and method == "GET":
            if not need_folder():
                return
            v = eq("Name")
            return page([clean(r) for r in o["releases"] if r["_folder"] == fid and (v is None or r["Name"] == v)])
        if p == "/odata/Releases" and method == "POST":
            if not need_folder():
                return
            b = json.loads(raw)
            if any(r["Name"] == b["Name"] and r["_folder"] == fid for r in o["releases"]):
                return self.err(409, "A process with this name already exists.", 1002)
            if b["ProcessVersion"] not in o["feed"].get(b["ProcessKey"], {}):
                return self.err(400, "Package not found.", 1005)
            r = {"Id": nid(), "Key": str(uuid.uuid4()), "Name": b["Name"], "ProcessKey": b["ProcessKey"], "ProcessVersion": b["ProcessVersion"],
                 "Description": b.get("Description", ""), "IsLatestVersion": False, "_folder": fid}
            o["releases"].append(r)
            return self.send(201, clean(r))
        m = re.match(r"^/odata/Releases\((\d+)\)(/UiPath.Server.Configuration.OData.UpdateToSpecificPackageVersion)?$", p)
        if m:
            if not need_folder():
                return
            r = next((r for r in o["releases"] if r["Id"] == int(m.group(1)) and r["_folder"] == fid), None)
            if r is None:
                return self.err(404, "Process not found.")
            if m.group(2):
                ver = json.loads(raw)["packageVersion"]
                if ver not in o["feed"].get(r["ProcessKey"], {}):
                    return self.err(400, "Package version not found.")
                if not o["stuckRelease"] or ver != o["stuckRelease"]:
                    r["ProcessVersion"] = ver
                return self.send(200, {})
            return self.send(200, clean(r))
        m = re.match(r"^/odata/Processes/UiPath.Server.Configuration.OData.GetProcessVersions\(processId='([^']*)'\)$", p)
        if m:
            vers = o["feed"].get(m.group(1))
            if not vers:
                return self.err(404, "Package not found.", 1005)
            return page([{"Key": m.group(1) + ":" + v, "Version": v, "Published": "2026-10-01T10:00:00Z", "IsLatestVersion": False} for v in vers])
        m = re.match(r"^/odata/Processes/UiPath.Server.Configuration.OData.DownloadPackage\(key='([^':]*):([^']*)'\)$", p)
        if m:
            b = o["feed"].get(m.group(1), {}).get(m.group(2))
            return self.send(200, b, "application/octet-stream", headers={"Content-Disposition": 'attachment; filename="%s.%s.nupkg"' % (m.group(1), m.group(2))}) if b else self.err(404, "Package not found.")
        if p == "/odata/Processes/UiPath.Server.Configuration.OData.UploadPackage" and method == "POST":
            mm = re.search(rb"NUPKG\|([^|]+)\|([^|]+)\|", raw)
            if not mm or not re.search(rb'name="?file"?', raw):
                return self.err(400, "No package file.")
            pid, ver = mm.group(1).decode(), mm.group(2).decode()
            if ver in o["feed"].setdefault(pid, {}):
                return self.err(409, "Package already exists.", 1004)
            o["feed"][pid][ver] = pkg(pid, ver)
            return self.send(200, {"value": [{"Key": pid + ":" + ver, "Status": "OK"}]})
        if p == "/odata/Assets" and method == "GET":
            if not need_folder():
                return
            v = eq("Name")
            return page([clean(a) for a in o["assets"].setdefault(fid, []) if v is None or a["Name"].lower() == v.lower()])
        if p == "/odata/Assets" and method == "POST":
            if not need_folder():
                return
            b = json.loads(raw)
            lst = o["assets"].setdefault(fid, [])
            if any(a["Name"].lower() == b["Name"].lower() for a in lst):
                return self.err(409, "An asset with this name already exists.", 1002)
            b["Id"] = nid()
            lst.append(b)
            return self.send(201, clean(b))
        m = re.match(r"^/odata/Assets\((\d+)\)$", p)
        if m and method == "PUT":
            if not need_folder():
                return
            a = next((a for a in o["assets"].setdefault(fid, []) if a["Id"] == int(m.group(1))), None)
            if a is None:
                return self.err(404, "Asset not found.")
            a.update(json.loads(raw))
            return self.send(200, {})
        if p == "/odata/QueueDefinitions" and method == "GET":
            if not need_folder():
                return
            v = eq("Name")
            return page([q for q in o["queues"].setdefault(fid, []) if v is None or q["Name"] == v])
        if p == "/odata/QueueDefinitions" and method == "POST":
            if not need_folder():
                return
            b = json.loads(raw)
            lst = o["queues"].setdefault(fid, [])
            if any(q["Name"] == b["Name"] for q in lst):
                return self.err(409, "Queue already exists.", 1002)
            b["Id"] = nid()
            lst.append(b)
            return self.send(201, b)
        m = re.match(r"^/odata/QueueDefinitions\((\d+)\)$", p)
        if m and method == "PUT":
            if not need_folder():
                return
            q = next((q for q in o["queues"].setdefault(fid, []) if q["Id"] == int(m.group(1))), None)
            if q is None:
                return self.err(404, "Queue not found.")
            q.update(json.loads(raw))
            return self.send(200, {})
        if p == "/odata/QueueItems" and method == "GET":
            if not need_folder():
                return
            mq = re.search(r"QueueDefinitionId eq (\d+)", flt)
            ref = eq("Reference")
            items = [i for i in o["queueItems"] if i["_folder"] == fid and (not mq or i["QueueDefinitionId"] == int(mq.group(1))) and (ref is None or i["Reference"] == ref)]
            items.sort(key=lambda i: -i["Id"])
            return page([clean(i) for i in items])
        if p == "/odata/Queues/UiPathODataSvc.AddQueueItem" and method == "POST":
            if not need_folder():
                return
            d = json.loads(raw)["itemData"]
            q = next((q for q in o["queues"].get(fid, []) if q["Name"] == d["Name"]), None)
            if q is None:
                return self.err(404, "Queue does not exist.", 1002)
            if q["EnforceUniqueReference"] and any(i["QueueDefinitionId"] == q["Id"] and i["Reference"] == d["Reference"] and i["Status"] != "Deleted" for i in o["queueItems"]):
                return self.err(409, "Error creating Transaction. Duplicate Reference.", 1016)
            if any(not isinstance(v, str) for v in d["SpecificContent"].values()):
                return self.err(400, "SpecificContent values must be strings in this mock.")
            it = {"Id": nid(), "QueueDefinitionId": q["Id"], "Status": "New", "Reference": d["Reference"], "Priority": d.get("Priority"),
                  "SpecificContent": d["SpecificContent"], "CreationTime": "2026-10-11T12:00:%02dZ" % (o["nextId"] % 60), "_folder": fid}
            o["queueItems"].append(it)
            return self.send(201, clean(it))
        self.err(404, f"Mock Orchestrator has no route {method} {p}")

    # ------------------------------------------------------------------ Dataverse
    def dv(self, env, p, method, qs, raw):
        if not self.authorized("dv:" + env):
            return
        if self.headers.get("OData-Version") != "4.0":
            return self.send(400, {"error": {"code": "0x0", "message": "OData-Version header missing"}})
        d = STATE["dv"][env]
        flt = qs.get("$filter", "")
        if p.startswith("RetrieveCurrentOrganization(AccessType=@p)"):
            if qs.get("@p") != "Microsoft.Dynamics.CRM.EndpointAccessType'Default'":
                return self.send(400, {"error": {"code": "0x80060888", "message": "bad @p"}})
            return self.send(200, {"Detail": dict(d["org"], OrganizationVersion="9.2.26100.000")})
        if p == "solutions":
            m = re.search(r"uniquename eq '([^']*)'", flt)
            return self.send(200, {"value": [s for s in d["solutions"] if not m or s["uniquename"] == m.group(1)]})
        if p == "solutioncomponents":
            m = re.search(r"_solutionid_value eq ([0-9a-f-]+) and componenttype eq 29", flt)
            items = [{"objectid": c["objectid"]} for c in d["components"] if m and c["_solutionid_value"] == m.group(1) and c["componenttype"] == 29]
            return self.send(200, {"value": items})
        if p == "workflows":
            ids = re.findall(r"workflowid eq ([0-9a-f-]+)", flt)
            return self.send(200, {"value": [{k: w[k] for k in ("workflowid", "name", "statecode", "statuscode")} for w in d["workflows"] if w["workflowid"] in ids and "category eq 5" in flt]})
        if p == "ExportSolution" and method == "POST":
            b = json.loads(raw)
            s = next((s for s in d["solutions"] if s["uniquename"] == b["SolutionName"]), None)
            if s is None:
                return self.send(404, {"error": {"code": "0x8004f800", "message": "Solution not found"}})
            if not b.get("Managed"):
                return self.send(400, {"error": {"code": "x", "message": "mock expects managed export"}})
            content = f"PK|managed|{s['uniquename']}|{s['version']}|{s['friendlyname']}".encode()
            return self.send(200, {"ExportSolutionFile": base64.b64encode(content).decode()})
        if p == "ImportSolutionAsync" and method == "POST":
            b = json.loads(raw)
            for k in ("OverwriteUnmanagedCustomizations", "PublishWorkflows", "CustomizationFile", "ImportJobId", "ComponentParameters"):
                if k not in b:
                    return self.send(400, {"error": {"code": "x", "message": "missing " + k}})
            parts = base64.b64decode(b["CustomizationFile"]).decode().split("|")
            aid = str(uuid.uuid4())
            d["async"][aid] = {"polls": 0, "fail": d.get("failImport", False), "solution": parts[2], "version": parts[3], "name": parts[4]}
            return self.send(200, {"AsyncOperationId": aid, "ImportJobKey": b["ImportJobId"]})
        m = re.match(r"^asyncoperations\(([0-9a-f-]+)\)$", p)
        if m:
            a = d["async"].get(m.group(1))
            if a is None:
                return self.send(404, {"error": {"code": "x", "message": "no async op"}})
            a["polls"] += 1
            if a["polls"] < 2:
                return self.send(200, {"statecode": 1, "statuscode": 20, "message": None, "friendlymessage": None})
            if a["fail"]:
                return self.send(200, {"statecode": 3, "statuscode": 31, "message": "Import failed: missing dependency", "friendlymessage": "A required component is missing."})
            if not a.get("done"):
                a["done"] = True
                s = next((s for s in d["solutions"] if s["uniquename"] == a["solution"]), None)
                if s is None:
                    d["solutions"].append({"solutionid": str(uuid.uuid4()), "uniquename": a["solution"], "friendlyname": a["name"], "version": a["version"],
                                           "ismanaged": True, "description": "", "modifiedon": "2026-10-11T12:00:00Z"})
                else:
                    s["version"] = a["version"]
            return self.send(200, {"statecode": 3, "statuscode": 30, "message": None, "friendlymessage": None})
        self.send(404, {"error": {"code": "0x80060888", "message": f"Mock Dataverse has no route {method} {p}"}})


if __name__ == "__main__":
    srv = ThreadingHTTPServer(("127.0.0.1", int(sys.argv[1])), H)
    print("mock listening on", sys.argv[1], flush=True)
    srv.serve_forever()
