Option Strict On
Imports System.Collections.Generic
Imports Newtonsoft.Json.Linq

Namespace UiPath.Platform.Triggers
    ' Same shape as UiPath.Platform.Triggers.TriggerArgs (UiPath.Platform 25.10): TriggerName = DisplayName of the Form Trigger.
    Public Class TriggerArgs
        Public Property TriggerName As String
    End Class
End Namespace

Namespace UiPath.Core
    ' Stand-in for UiPath.Core.Activities.BusinessRuleException (UiPath.System.Activities).
    Public Class BusinessRuleException
        Inherits Exception
        Public Sub New(message As String)
            MyBase.New(message)
        End Sub
        Public Sub New(message As String, inner As Exception)
            MyBase.New(message, inner)
        End Sub
    End Class
End Namespace

' Stand-ins for the UiPath activities used by the generated VB twin of the workflows (MOCKED: no robot, no Orchestrator).
' The form is simulated as a dictionary of field values; a test script lists what the user changes before each form event.
Public Module TestHost
    Public Class FormStep
        Public Trigger As String
        Public UserInput As New Dictionary(Of String, String)
    End Class

    Public Logs As New List(Of String)
    Public Dialogs As New List(Of String)
    Public Calls As New List(Of String)
    Public FormData As New Dictionary(Of String, String)
    Public FormShown As Boolean, FormClosed As Boolean, RanOutOfEvents As Boolean
    Public SetLog As New List(Of KeyValuePair(Of String, Dictionary(Of String, Object)))
    Public Script As New Queue(Of FormStep)
    Public Triggers As New List(Of String)
    ' Orchestrator Credential assets as the robot would see them: "folder|asset" -> (user, password)
    Public Credentials As New Dictionary(Of String, Tuple(Of String, String))
    Public CredentialReads As New List(Of String)
    Public Delays As New List(Of TimeSpan)
    Public Quiet As Boolean = True
    Public OnEvent As Action(Of String)

    Public Sub Reset(steps As IEnumerable(Of FormStep))
        Logs.Clear() : Dialogs.Clear() : Calls.Clear() : FormData.Clear() : SetLog.Clear() : Triggers.Clear()
        CredentialReads.Clear() : Delays.Clear()
        FormShown = False : FormClosed = False : RanOutOfEvents = False
        Script = New Queue(Of FormStep)(steps)
    End Sub

    Public Sub Log(level As String, message As String)
        Logs.Add(level.PadRight(5) & " " & message)
        If Not Quiet Then Console.WriteLine("      " & level.PadRight(5) & " " & message)
    End Sub
    Public Sub Enter(path As String)
        Calls.Add(path)
    End Sub
    Public Sub Leave(path As String)
    End Sub
    Public Sub MessageBox(caption As String, text As String)
        Dialogs.Add(text)
    End Sub
    ' Delay: recorded, not waited (polling loops in tests run instantly).
    Public Sub Delay(d As TimeSpan)
        Delays.Add(d)
    End Sub
    ' Get Credential (UiPath.System.Activities): asset not found -> exception, like the real activity.
    Public Sub GetCredential(asset As String, folder As String, ByRef user As String, ByRef pwd As System.Security.SecureString)
        Dim c As Tuple(Of String, String) = Nothing
        If Not Credentials.TryGetValue(folder & "|" & asset, c) Then Throw New InvalidOperationException("Could not find the asset '" & asset & "'.")
        CredentialReads.Add(folder & "|" & asset)
        user = c.Item1
        pwd = New System.Net.NetworkCredential("", c.Item2).SecurePassword
    End Sub

    ' Show Form (IsAsync = True): initial values go into the form, the workflow continues.
    Public Sub ShowForm(title As String, inputs As Dictionary(Of String, Object))
        If FormShown Then Throw New InvalidOperationException("form shown twice")
        FormShown = True
        For Each kv In inputs
            FormData(kv.Key) = CStr(kv.Value)
        Next
    End Sub
    Public Function GetField(key As String) As String
        If FormClosed Then Throw New InvalidOperationException("Get Form Fields after the form was closed")
        Dim v As String = Nothing
        Return If(FormData.TryGetValue(key, v), v, "")
    End Function
    ' Set Form Fields: values that are Nothing are skipped by the real activity, so the workflows must never pass Nothing.
    Public Sub SetFields(name As String, values As Dictionary(Of String, Object))
        If FormClosed Then Throw New InvalidOperationException("Set Form Fields after the form was closed")
        For Each kv In values
            If kv.Value Is Nothing Then Throw New InvalidOperationException("Set Form Fields got Nothing for " & kv.Key)
            FormData(kv.Key) = CStr(kv.Value)
        Next
        SetLog.Add(New KeyValuePair(Of String, Dictionary(Of String, Object))(name, values))
    End Sub
    Public Sub CloseForm()
        FormClosed = True
    End Sub
    Public Sub RegisterTriggers(ParamArray names As String())
        Triggers.AddRange(names)
    End Sub
    Public Function NextTrigger(ByRef args As UiPath.Platform.Triggers.TriggerArgs) As Boolean
        If Script.Count = 0 Then
            RanOutOfEvents = True
            Return False
        End If
        Dim s As FormStep = Script.Dequeue()
        If Not Triggers.Contains(s.Trigger) Then Throw New InvalidOperationException("No Form Trigger named " & s.Trigger)
        For Each kv In s.UserInput
            FormData(kv.Key) = kv.Value
        Next
        If OnEvent IsNot Nothing Then OnEvent(s.Trigger)
        args = New UiPath.Platform.Triggers.TriggerArgs With {.TriggerName = s.Trigger}
        Return True
    End Function
End Module
