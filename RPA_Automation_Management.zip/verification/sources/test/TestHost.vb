Option Strict On
Imports System.Collections.Generic
Imports Newtonsoft.Json.Linq


' Stand-ins for the UiPath.WebAPI.Activities 2.4.0 model types used in workflow expressions (same names and members as the
' package; the XAML itself is validated against the real UiPath.Web.Activities.dll).
Namespace UiPath.Web.Activities.Http.Models
    Public Class HttpResponseSummary
        Public Property StatusCode As System.Net.HttpStatusCode
        Public Property TextContent As String
        Public Property BinaryContent As Byte()
        Public Property Headers As IEnumerable(Of KeyValuePair(Of String, String))
        Public Property ContentHeaders As IEnumerable(Of KeyValuePair(Of String, String))
    End Class
    Public MustInherit Class FormDataPart
        Public Property PartName As String
        Public Property ContentType As String
    End Class
    Public Class FileFormDataPart
        Inherits FormDataPart
        Public ReadOnly Property FilePath As String
        Public ReadOnly Property FileName As String
        Public Sub New(filePath As String, partName As String, contentType As String)
            Me.FilePath = filePath : Me.FileName = System.IO.Path.GetFileName(filePath) : Me.PartName = partName : Me.ContentType = contentType
        End Sub
    End Class
End Namespace

Namespace UiPath.Platform.Triggers
    ' Same shape as UiPath.Platform.Triggers.TriggerArgs (UiPath.Platform 25.10): TriggerName = DisplayName of the Form Trigger.
    Public Class TriggerArgs
        Public Property TriggerName As String
    End Class
End Namespace

Namespace UiPath.Core
    ' Stand-in for UiPath.Core.Activities.BusinessRuleException (UiPath.System.Activities).
    Public Class BusinessRuleException
        Inherits Exception
        Public Sub New(message As String)
            MyBase.New(message)
        End Sub
        Public Sub New(message As String, inner As Exception)
            MyBase.New(message, inner)
        End Sub
    End Class
End Namespace

' Stand-ins for the UiPath activities used by the generated VB twin of the workflows (MOCKED: no robot, no Orchestrator).
' The form is simulated as a dictionary of field values; a test script lists what the user changes before each form event.
Public Module TestHost
    Public Class FormStep
        Public Trigger As String
        Public UserInput As New Dictionary(Of String, String)
    End Class

    Public Logs As New List(Of String)
    Public Dialogs As New List(Of String)
    Public Calls As New List(Of String)
    Public FormData As New Dictionary(Of String, String)
    Public FormShown As Boolean, FormClosed As Boolean, RanOutOfEvents As Boolean
    Public SetLog As New List(Of KeyValuePair(Of String, Dictionary(Of String, Object)))
    Public Script As New Queue(Of FormStep)
    Public Triggers As New List(Of String)
    ' Orchestrator Credential assets as the robot would see them: "folder|asset" -> (user, password)
    Public Credentials As New Dictionary(Of String, Tuple(Of String, String))
    Public CredentialReads As New List(Of String)
    Public Delays As New List(Of TimeSpan)
    Public Quiet As Boolean = True
    Public OnEvent As Action(Of String)

    Public Sub Reset(steps As IEnumerable(Of FormStep))
        Logs.Clear() : Dialogs.Clear() : Calls.Clear() : FormData.Clear() : SetLog.Clear() : Triggers.Clear()
        CredentialReads.Clear() : Delays.Clear()
        FormShown = False : FormClosed = False : RanOutOfEvents = False
        Script = New Queue(Of FormStep)(steps)
    End Sub

    Public Sub Log(level As String, message As String)
        Logs.Add(level.PadRight(5) & " " & message)
        If Not Quiet Then Console.WriteLine("      " & level.PadRight(5) & " " & message)
    End Sub
    Public Sub Enter(path As String)
        Calls.Add(path)
    End Sub
    Public Sub Leave(path As String)
    End Sub
    Public Sub MessageBox(caption As String, text As String)
        Dialogs.Add(text)
    End Sub
    ' Delay: recorded, not waited (polling loops in tests run instantly).

    ' Emulates UiPath.Web.Activities.Http.NetHttpRequest 2.4.0 as decompiled from the package: handler chain
    ' OAuth token -> exponential back-off retry (RetryCount = total attempts; 408/429/500/502/503/504; Retry-After preferred)
    ' -> ContinueOnError (connection errors become HTTP 503 with the error text); HttpClient.Timeout covers the whole call;
    ' non-2xx statuses are returned, not thrown; text/json bodies -> TextContent, file responses or SaveResponseAsFile -> file
    ' in OutputFileTargetFolder, other bodies -> BinaryContent.
    Public HttpCalls As Integer
    Private ReadOnly RetryCodes As Integer() = {408, 429, 500, 502, 503, 504}
    Public Function NetHttpRequest(method As String, url As String, headers As Dictionary(Of String, String), token As String, bodyType As String,
                                   text As String, form As Dictionary(Of String, String), parts As IEnumerable(Of UiPath.Web.Activities.Http.Models.FormDataPart),
                                   timeoutMs As Integer?, attempts As Integer, delayMs As Integer, saveFolder As String, saveName As String) As UiPath.Web.Activities.Http.Models.HttpResponseSummary
        If String.IsNullOrWhiteSpace(url) Then Throw New ArgumentOutOfRangeException("Request URL")
        If token IsNot Nothing AndAlso String.IsNullOrWhiteSpace(token) Then Throw New ArgumentException("OAuth token is required")
        If attempts < 0 OrElse delayMs < 0 Then Throw New ArgumentOutOfRangeException("Retry")
        Dim handler As New System.Net.Http.SocketsHttpHandler() With {.UseCookies = False, .AllowAutoRedirect = True, .MaxAutomaticRedirections = 3}
        Using client As New System.Net.Http.HttpClient(handler) With {.Timeout = TimeSpan.FromMilliseconds(If(timeoutMs, 10000))}
            Dim delay As Integer = delayMs
            Dim response As System.Net.Http.HttpResponseMessage = Nothing
            For i As Integer = 0 To attempts - 1
                Dim req As New System.Net.Http.HttpRequestMessage(New System.Net.Http.HttpMethod(method), url)
                If token IsNot Nothing Then req.Headers.Authorization = New System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token)
                Select Case bodyType
                    Case "Text"
                        If String.IsNullOrEmpty(text) Then Throw New ArgumentException("Text payload cannot be null for Text body type.")
                        req.Content = New System.Net.Http.StringContent(text, System.Text.Encoding.UTF8, "application/json")
                    Case "FormUrlEncoded"
                        If form Is Nothing Then Throw New ArgumentException("Form data cannot be null for form-urlencoded body type.")
                        req.Content = New System.Net.Http.FormUrlEncodedContent(form)
                    Case "MultipartFormData"
                        Dim mp As New System.Net.Http.MultipartFormDataContent()
                        For Each p As UiPath.Web.Activities.Http.Models.FormDataPart In parts
                            Dim f = DirectCast(p, UiPath.Web.Activities.Http.Models.FileFormDataPart)
                            Dim sc As New System.Net.Http.ByteArrayContent(System.IO.File.ReadAllBytes(f.FilePath))
                            sc.Headers.ContentType = New System.Net.Http.Headers.MediaTypeHeaderValue(f.ContentType)
                            mp.Add(sc, f.PartName, f.FileName)
                        Next
                        req.Content = mp
                End Select
                If headers IsNot Nothing Then
                    For Each h In headers
                        req.Headers.TryAddWithoutValidation(h.Key, h.Value)
                    Next
                End If
                HttpCalls += 1
                Try
                    response = client.SendAsync(req, System.Net.Http.HttpCompletionOption.ResponseHeadersRead).GetAwaiter().GetResult()
                Catch ex As System.Net.Http.HttpRequestException
                    response = New System.Net.Http.HttpResponseMessage(System.Net.HttpStatusCode.ServiceUnavailable) With {.Content = New System.Net.Http.StringContent(ex.Message)}
                End Try
                If Not RetryCodes.Contains(CInt(response.StatusCode)) OrElse i = attempts - 1 Then Exit For
                Dim wait As Integer = delay
                If response.Headers.RetryAfter IsNot Nothing AndAlso response.Headers.RetryAfter.Delta.HasValue Then wait = CInt(Math.Min(120000, response.Headers.RetryAfter.Delta.Value.TotalMilliseconds))
                Delays.Add(TimeSpan.FromMilliseconds(wait))
                If Not Quiet Then Console.WriteLine("HTTP Request retry: " & method & " " & url & " -> " & CInt(response.StatusCode).ToString())
                delay = CInt(delay * 2.0)
            Next
            Dim r As New UiPath.Web.Activities.Http.Models.HttpResponseSummary With {.StatusCode = response.StatusCode, .TextContent = "", .BinaryContent = Array.Empty(Of Byte)(),
                .Headers = response.Headers.Select(Function(h) New KeyValuePair(Of String, String)(h.Key, String.Join(", ", h.Value))).ToList(),
                .ContentHeaders = response.Content.Headers.Select(Function(h) New KeyValuePair(Of String, String)(h.Key, String.Join(", ", h.Value))).ToList()}
            Dim bytes As Byte() = response.Content.ReadAsByteArrayAsync().GetAwaiter().GetResult()
            If bytes.Length = 0 Then Return r
            Dim ct As String = If(response.Content.Headers.ContentType?.MediaType, "").ToLowerInvariant()
            Dim isText As Boolean = ct.StartsWith("text/") OrElse ct = "application/json" OrElse ct = "application/xml" OrElse (ct.StartsWith("application/") AndAlso (ct.EndsWith("+json") OrElse ct.EndsWith("+xml")))
            Dim isFile As Boolean = Not isText AndAlso response.Content.Headers.ContentDisposition IsNot Nothing
            If saveFolder IsNot Nothing OrElse isFile Then
                Dim folder As String = If(saveFolder IsNot Nothing AndAlso System.IO.Directory.Exists(saveFolder), saveFolder, Environment.CurrentDirectory)
                Dim name As String = If(Not String.IsNullOrWhiteSpace(saveName), System.IO.Path.GetFileName(saveName), If(response.Content.Headers.ContentDisposition?.FileName?.Trim(""""c), "downloaded_file_" & Guid.NewGuid().ToString()))
                System.IO.File.WriteAllBytes(System.IO.Path.Combine(folder, name), bytes)
            ElseIf isText Then
                r.TextContent = System.Text.Encoding.UTF8.GetString(bytes)
            Else
                r.BinaryContent = bytes
            End If
            Return r
        End Using
    End Function

    Public Sub Delay(d As TimeSpan)
        Delays.Add(d)
    End Sub
    ' Get Credential (UiPath.System.Activities): asset not found -> exception, like the real activity.
    Public Sub GetCredential(asset As String, folder As String, ByRef user As String, ByRef pwd As System.Security.SecureString)
        Dim c As Tuple(Of String, String) = Nothing
        If Not Credentials.TryGetValue(folder & "|" & asset, c) Then Throw New InvalidOperationException("Could not find the asset '" & asset & "'.")
        CredentialReads.Add(folder & "|" & asset)
        user = c.Item1
        pwd = New System.Net.NetworkCredential("", c.Item2).SecurePassword
    End Sub

    ' Show Form (IsAsync = True): initial values go into the form, the workflow continues.
    Public Sub ShowForm(title As String, inputs As Dictionary(Of String, Object))
        If FormShown Then Throw New InvalidOperationException("form shown twice")
        FormShown = True
        For Each kv In inputs
            FormData(kv.Key) = CStr(kv.Value)
        Next
    End Sub
    Public Function GetField(key As String) As String
        If FormClosed Then Throw New InvalidOperationException("Get Form Fields after the form was closed")
        Dim v As String = Nothing
        Return If(FormData.TryGetValue(key, v), v, "")
    End Function
    ' Set Form Fields: values that are Nothing are skipped by the real activity, so the workflows must never pass Nothing.
    Public Sub SetFields(name As String, values As Dictionary(Of String, Object))
        If FormClosed Then Throw New InvalidOperationException("Set Form Fields after the form was closed")
        For Each kv In values
            If kv.Value Is Nothing Then Throw New InvalidOperationException("Set Form Fields got Nothing for " & kv.Key)
            FormData(kv.Key) = CStr(kv.Value)
        Next
        SetLog.Add(New KeyValuePair(Of String, Dictionary(Of String, Object))(name, values))
    End Sub
    Public Sub CloseForm()
        FormClosed = True
    End Sub
    Public Sub RegisterTriggers(ParamArray names As String())
        Triggers.AddRange(names)
    End Sub
    Public Function NextTrigger(ByRef args As UiPath.Platform.Triggers.TriggerArgs) As Boolean
        If Script.Count = 0 Then
            RanOutOfEvents = True
            Return False
        End If
        Dim s As FormStep = Script.Dequeue()
        If Not Triggers.Contains(s.Trigger) Then Throw New InvalidOperationException("No Form Trigger named " & s.Trigger)
        For Each kv In s.UserInput
            FormData(kv.Key) = kv.Value
        Next
        If OnEvent IsNot Nothing Then OnEvent(s.Trigger)
        args = New UiPath.Platform.Triggers.TriggerArgs With {.TriggerName = s.Trigger}
        Return True
    End Function
End Module
