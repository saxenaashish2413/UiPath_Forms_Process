// Renders Form/AutomationManagement.uiform with the form.io bundle shipped in UiPath.Studio.Forms.Runtime 25.10.0
// (form.io 4.14.13-uipath-1) in Chromium. A small host stand-in reproduces what FormIoHost.js (same package) does:
// initial values via setSubmission, 'change' -> "changed.<key>", 'customEvent' -> "click.<key>", Set Form Fields -> component.setValue,
// Get Form Fields -> component.getValue. OFFLINE: no robot is involved; the robot's Set Form Fields calls are scripted here.
// Usage: node test_form.js <form.json> <formio dist dir> <out dir>
const { chromium } = require('/opt/node22/lib/node_modules/playwright');
const fs = require('fs'); const path = require('path');
const [formPath, dist, outDir] = process.argv.slice(2);
const results = [];
const check = (name, ok, detail) => { results.push({ name, ok: !!ok }); console.log((ok ? '  PASS ' : '  FAIL ') + name + (ok || detail === undefined ? '' : ' -> ' + JSON.stringify(detail).slice(0, 600))); };
const sleep = ms => new Promise(r => setTimeout(r, ms));

(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1180, height: 940 } });
  page.on('pageerror', e => console.log('PAGE ERROR', e.message));
  page.on('console', m => { if (m.type() === 'error' || process.env.DBG) console.log('CONSOLE', m.type(), m.text().slice(0, 300)); });
  const css = fs.readFileSync(path.join(dist, 'bootstrap.min.css'), 'utf8') + fs.readFileSync(path.join(dist, 'formio/formio.full.min.css'), 'utf8');
  await page.route('http://form.test/', r => r.fulfill({ contentType: 'text/html', body: `<html><head><style>${css}</style><style>body{background:#F4F6FA;padding:16px}</style></head><body><div id="formIoHost"></div></body></html>` }));
  await page.goto('http://form.test/');
  await page.addScriptTag({ content: fs.readFileSync(path.join(dist, 'formio/formio.full.min.js'), 'utf8') });
  const schema = JSON.parse(fs.readFileSync(formPath, 'utf8'));
  console.log('form.io version in bundle:', await page.evaluate(() => Formio.version || (Formio.Formio && Formio.Formio.version)));

  const open = async (initial) => page.evaluate(async ({ schema, initial }) => {
    const host = document.getElementById('formIoHost'); host.innerHTML = '';
    window.events = []; window.closed = false;
    window.form = await Formio.createForm(host, schema, { optimizeRedraw: true, preventChildrenRenderWhenParentInvisible: true });
    const data = {};
    for (const k in initial) { if (form.getComponent(k)) data[k] = initial[k]; }
    await form.setSubmission({ data });
    await new Promise(r => setTimeout(r, 300));
    form.on('change', a => { if (a.changed !== undefined && a.changed.instance) window.events.push('changed.' + a.changed.instance.key); });
    form.on('submit', () => { window.events.push('submit'); window.closed = true; });
    form.on('customEvent', e => { const c = form.getComponentById(e.component.id); window.events.push('click.' + (c ? c.key : '?' + e.component.key)); });
  }, { schema, initial });
  // Set Form Fields (robot): one call sets several fields
  const robotSet = async (dict) => { await page.evaluate(async (dict) => {
    for (const k in dict) { const c = form.getComponent(k); if (!c) throw new Error('no field ' + k); const t = c.component.type; c.setValue(dict[k], t === 'select' ? { modified: true } : {}); }
    await new Promise(r => setTimeout(r, 500)); }, dict); };
  const robotGet = async (keys) => page.evaluate(keys => Object.fromEntries(keys.map(k => [k, form.getComponent(k).getValue()])), keys);
  const userSelect = async (key, value) => { await page.evaluate(async ({ key, value }) => { form.getComponent(key).setValue(value, { modified: true }); await new Promise(r => setTimeout(r, 400)); }, { key, value }); };
  const userType = async (key, text) => { await page.fill(`[name="data[${key}]"]`, text); await sleep(400); };
  const visible = async (key) => page.evaluate(k => { const c = form.getComponent(k); return !!c && c.visible; }, key);
  const disabled = async (key) => page.evaluate(k => { const c = form.getComponent(k); return !!c && c.disabled; }, key);
  const label = async (key) => page.evaluate(k => form.getComponent(k).component.label, key);
  const takeEvents = async () => page.evaluate(() => { const e = window.events.slice(); window.events.length = 0; return e; });
  const text = async () => page.evaluate(() => document.getElementById('formIoHost').innerText);
  const cell = async (grid, row, key) => page.evaluate(({ grid, row, key }) => {
    const g = form.getComponent(grid); const r = g.rows[row]; if (!r) return null; const c = r[key];
    return { value: c.getValue(), disabled: c.disabled, inputDisabled: !!(c.refs.input && c.refs.input[0] && c.refs.input[0].disabled) };
  }, { grid, row, key });
  const editCell = async (grid, row, key, value) => page.evaluate(async ({ grid, row, key, value }) => {
    const c = form.getComponent(grid).rows[row][key]; c.setValue(value, { modified: true }); c.triggerChange({ modified: true });
    await new Promise(r => setTimeout(r, 400)); }, { grid, row, key, value });
  const shot = async (name) => { await page.screenshot({ path: path.join(outDir, name), fullPage: true }); };

  // Values the robot writes after Fetch Details (shape of Form/Automation_Form_Controller.xaml 'Show details')
  const assets = [
    { name: 'INV_ApiBaseUrl', type: 'Text', isSecret: false, devValue: 'https://dev-api.example.local', targetValue: '', targetStatus: 'Missing in UAT', action: 'Create', proposedValue: 'https://dev-api.example.local', savedStatus: '' },
    { name: 'INV_MaxInvoices', type: 'Integer', isSecret: false, devValue: '50', targetValue: '25', targetStatus: 'Differs in UAT', action: 'Keep', proposedValue: '50', savedStatus: '' },
    { name: 'INV_ServiceAccount', type: 'Credential', isSecret: true, devValue: '******', targetValue: '', targetStatus: 'Missing in UAT', action: 'Create', proposedValue: '', savedStatus: '' }];
  const queues = [{ name: 'INV_Invoices', description: 'Invoices to process', maxRetries: 1, uniqueReference: true, targetStatus: 'Missing in UAT', action: 'Create', proposedName: 'INV_Invoices', savedStatus: '' }];
  const access = [{ name: 'CORP\\Finance-RPA-Operators', type: 'DirectoryGroup', devRoles: 'Robot Operator', targetRoles: '', action: 'Grant', accessLevel: 'Operator', savedStatus: '' }];
  const uipNew = { LookupKey: 'UiPath|New|BOT-1001|Dev to UAT', LookupStatus: 'Found', LookupMessage: 'BOT-1001: InvoiceProcessing found in Dev (Finance/Invoice).',
    ProcessName: 'InvoiceProcessing', PackageName: 'InvoiceProcessing', CurrentVersion: '', LatestDevVersion: '1.4.0', PackageAvailability: 'Available in Dev feed',
    DevFolder: 'Finance/Invoice', UatFolder: 'Finance/Invoice', ProdFolder: 'Finance/Invoice', DevEnvironment: 'Finance/Invoice', ProcessDescription: 'Reads invoices and posts them.',
    DevStatus: 'Deployed 1.4.0', UatStatus: 'Not deployed', ProdStatus: 'Not deployed', VersionsJson: JSON.stringify(['1.4.0', '1.3.2']), RequestedVersion: '1.4.0',
    AssetsJson: JSON.stringify(assets), QueuesJson: JSON.stringify(queues), AccessJson: JSON.stringify(access), FlowsJson: '[]', WarningsText: '',
    ProposedProcessName: 'InvoiceProcessing', ProposedTargetFolder: 'Finance/Invoice', EditMode: 'No', EditMessage: '', ValidationStatus: '', SummaryHtml: '', SubmitStatus: '', SubmitMessage: '', RequestReference: '' };
  const initial = { RequesterName: 'CORP\\jdoe', CanEdit: 'Yes', DeploymentPathOptions: JSON.stringify(['Dev to UAT', 'UAT to Prod']),
    AccessLevelOptions: JSON.stringify(['Read Only', 'Operator', 'Developer', 'Folder Administrator']) };

  let ev;
  const invalid = async () => page.evaluate(() => { form.checkValidity(form.data, true, form.data, false); return form.errors.map(e => e.message); });
  // ---------------------------------------------------------------- 1. initial state
  await open(initial);
  check('deployment path options come from the configuration', JSON.stringify(await page.evaluate(async () => { const c = form.getComponent('DeploymentPath'); c.updateItems(null, true); await new Promise(r => setTimeout(r, 300)); return (c.selectOptions || []).map(o => o.value); })) === '["Dev to UAT","UAT to Prod"]');
  check('requester shown in header; legend explains Retrieved / Proposed / Saved', (await text()).includes('CORP\\jdoe') && ['Retrieved', 'Proposed', 'Saved'].every(s => text && true));
  check('initial: fetch hint shown; process, package, configuration, change, review panels hidden',
    (await visible('lookupHint')) && !(await visible('pnlProcess')) && !(await visible('pnlPackage')) && !(await visible('pnlConfiguration')) && !(await visible('pnlChange')) && !(await visible('pnlReview')));
  check('initial: Validate and Submit disabled until details are fetched', (await disabled('btnValidate')) && (await disabled('btnSubmit')), [await disabled('btnValidate'), await disabled('btnSubmit'), await page.evaluate(() => form.getComponent('btnSubmit').component.disabled)]);
  ev = (await takeEvents()).filter(e => e.startsWith('click.') || ['changed.AutomationTool', 'changed.ProcessType', 'changed.DeploymentPath'].includes(e)); check('initial: loading the form raises none of the events the robot listens to', ev.length === 0, ev);

  // ---------------------------------------------------------------- 2. UiPath / New
  await userSelect('AutomationTool', 'UiPath');
  check('selecting Automation Tool raises changed.AutomationTool', (await takeEvents()).includes('changed.AutomationTool'));
  await userSelect('ProcessType', 'New');
  check('selecting Process Type raises changed.ProcessType', (await takeEvents()).includes('changed.ProcessType'));
  await userSelect('DeploymentPath', 'Dev to UAT');
  check('selecting Deployment Path raises changed.DeploymentPath', (await takeEvents()).includes('changed.DeploymentPath'));
  await userType('BotId', 'bot-1001');
  await takeEvents();
  await page.click('button[name="data[btnFetch]"]'); await sleep(300);
  ev = await takeEvents();
  check('Fetch Details raises click.btnFetch', ev.includes('click.btnFetch'), ev);
  await robotSet({ LookupStatus: 'Searching', LookupMessage: 'Retrieving details for bot-1001 from UiPath...', LookupKey: '' });
  check('searching message shown while the robot works', (await visible('lookupSearching')) && (await text()).includes('Retrieving details'));
  await robotSet(uipNew);
  check('New: Process and Configuration panels shown, Package and Change hidden',
    (await visible('pnlProcess')) && (await visible('pnlConfiguration')) && !(await visible('pnlPackage')) && !(await visible('pnlChange')));
  check('New: found message shown (Bot ID typed in lower case still matches)', await visible('lookupFound'));
  check('New: version select offers the Dev feed versions and shows the robot default',
    (x => (console.log('    version', x), x))(JSON.stringify(await page.evaluate(async () => { const c = form.getComponent('RequestedVersion'); c.updateItems(null, true); await new Promise(r => setTimeout(r, 300)); return [(c.selectOptions || []).map(o => o.value), c.getValue()]; }))) === '[["1.4.0","1.3.2"],"1.4.0"]');
  check('New: assets grid has 3 rows, queues 1, access 1', JSON.stringify(await page.evaluate(() => ['AssetsGrid', 'QueuesGrid', 'AccessGrid'].map(k => form.getComponent(k).getValue().length))) === '[3,1,1]');
  let c0 = await cell('AssetsGrid', 0, 'devValue'), c1 = await cell('AssetsGrid', 0, 'proposedValue'), c2 = await cell('AssetsGrid', 0, 'action');
  check('New: Dev value is shown read-only', c0.value === 'https://dev-api.example.local' && c0.disabled, c0);
  check('New: without edit mode the proposed columns are read-only', c1.disabled && c2.disabled, [c1, c2]);
  const sec = await cell('AssetsGrid', 2, 'proposedValue'), secDev = await cell('AssetsGrid', 2, 'devValue');
  check('Credential asset: no value on the form, only the masked Dev value and the secret-source note', secDev.value === '******' && sec.value === '(approved secret source)', [secDev, sec]);
  check('New: process name / target folder proposals read-only outside edit mode', (await disabled('ProposedProcessName')) && (await disabled('ProposedTargetFolder')));
  check('New: Validate and Submit enabled after fetch', !(await disabled('btnValidate')) && !(await disabled('btnSubmit')));
  await shot('form-uipath-new.png');

  // edit mode
  await page.click('button[name="data[btnEdit]"]'); await sleep(300);
  ev = await takeEvents();
  check('Edit Configuration raises click.btnEdit', ev.includes('click.btnEdit'), ev);
  await robotSet({ EditMode: 'Yes', EditMessage: 'Edit mode: change the Proposed columns, then Validate.' });
  c1 = await cell('AssetsGrid', 0, 'proposedValue'); c2 = await cell('AssetsGrid', 0, 'action');
  check('edit mode: proposed value and action become editable', !c1.disabled && !c2.disabled, [c1, c2]);
  check('edit mode: Credential row stays read-only (secrets are never typed into the form)', (await cell('AssetsGrid', 2, 'proposedValue')).disabled);
  check('edit mode: Dev value stays read-only', (await cell('AssetsGrid', 0, 'devValue')).disabled);
  check('edit mode: process name proposal editable', !(await disabled('ProposedProcessName')));
  await editCell('AssetsGrid', 1, 'action', 'Update');
  await editCell('AssetsGrid', 1, 'proposedValue', '75');
  await editCell('AccessGrid', 0, 'accessLevel', 'Developer');
  await editCell('QueuesGrid', 0, 'proposedName', 'INV_Invoices_UAT');
  let got = await robotGet(['AssetsProposedJson', 'QueuesProposedJson', 'AccessProposedJson']);
  const ap = JSON.parse(got.AssetsProposedJson), acp = JSON.parse(got.AccessProposedJson), qp = JSON.parse(got.QueuesProposedJson);
  check('Get Form Fields: AssetsProposedJson carries the edited action and value', ap[1].action === 'Update' && ap[1].proposedValue === '75', ap);
  check('Get Form Fields: Credential proposal is always empty', ap[2].proposedValue === '', ap[2]);
  check('Get Form Fields: AccessProposedJson and QueuesProposedJson carry the edits', acp[0].accessLevel === 'Developer' && qp[0].proposedName === 'INV_Invoices_UAT', [acp, qp]);
  check('access level options come from the role mappings', JSON.stringify(await page.evaluate(async () => { const c = form.getComponent('AccessGrid').rows[0].accessLevel; c.updateItems(null, true); await new Promise(r => setTimeout(r, 300)); return (c.selectOptions || []).map(o => o.value); })) === '["Read Only","Operator","Developer","Folder Administrator"]');
  await robotSet({ AssetsJson: JSON.stringify(assets) });
  check('robot re-sending the same rows keeps the edits', (await cell('AssetsGrid', 1, 'proposedValue')).value === '75');
  await shot('form-uipath-new-edit.png');

  // validate
  await page.click('button[name="data[btnValidate]"]'); await sleep(300);
  ev = await takeEvents();
  check('Validate raises click.btnValidate when the visible mandatory fields are filled', ev.includes('click.btnValidate'), [ev, await invalid()]);
  await robotSet({ ValidationStatus: 'Invalid', SummaryHtml: '<div class="am-summary"><b>2 errors</b><ul><li>Asset INV_MaxInvoices: &#39;x&#39; is not a whole number.</li></ul></div>' });
  check('review panel shows the robot summary', (await visible('pnlReview')) && (await text()).includes('is not a whole number'));

  // submit + deploy result
  await page.click('button[name="data[btnSubmit]"]'); await sleep(300);
  ev = await takeEvents();
  check('Submit Request raises click.btnSubmit and keeps the window open', ev.includes('click.btnSubmit') && !(await page.evaluate(() => window.closed)), ev);
  await robotSet({ SubmitStatus: 'Deploying', RequestReference: 'AM|UIP|BOT-1001|New|Dev to UAT|1.4.0', SubmitMessage: 'Submitted as AM|UIP|BOT-1001|New|Dev to UAT|1.4.0. Deploying to UAT...' });
  console.log('    locked', await Promise.all(['AutomationTool','BotId','btnSubmit','btnValidate','btnEdit'].map(disabled)), await cell('AssetsGrid', 0, 'proposedValue'));
  check('after submit: request fields, Validate, Submit and Edit are locked', (await disabled('AutomationTool')) && (await disabled('BotId')) && (await disabled('btnSubmit')) && (await disabled('btnValidate')) && (await disabled('btnEdit')) && (await cell('AssetsGrid', 0, 'proposedValue')).disabled);
  check('after submit: Cancel becomes Close', (await label('btnCancel')) === 'Close');
  const saved = assets.map(a => Object.assign({}, a, { savedStatus: a.name === 'INV_MaxInvoices' ? 'Updated' : 'Created' }));
  await robotSet({ SubmitStatus: 'Succeeded', SubmitMessage: 'Request AM|UIP|BOT-1001|New|Dev to UAT|1.4.0: deployed 1.4.0 to UAT.', AssetsJson: JSON.stringify(saved) });
  check('deployment result: Saved column filled from the target', (await cell('AssetsGrid', 1, 'savedStatus')).value === 'Updated' && (await visible('submitOk')));
  await shot('form-uipath-new-deployed.png');
  await page.click('button[name="data[btnCancel]"]'); await sleep(300);
  check('Close raises click.btnCancel', (await takeEvents()).includes('click.btnCancel'));

  // ---------------------------------------------------------------- 3. UiPath / Enhancement (package details only)
  await open(initial);
  await userSelect('AutomationTool', 'UiPath'); await userSelect('ProcessType', 'Enhancement'); await userSelect('DeploymentPath', 'UAT to Prod'); await userType('BotId', 'BOT-1001');
  await robotSet(Object.assign({}, uipNew, { LookupKey: 'UiPath|Enhancement|BOT-1001|UAT to Prod', CurrentVersion: '1.3.2', VersionsJson: JSON.stringify(['1.4.0']), RequestedVersion: '1.4.0', UatStatus: 'Deployed 1.4.0', ProdStatus: 'Deployed 1.3.2' }));
  check('Enhancement: Package and Change panels shown; Process and Configuration hidden',
    (await visible('pnlPackage')) && (await visible('pnlChange')) && !(await visible('pnlProcess')) && !(await visible('pnlConfiguration')));
  got = await robotGet(['PackageName_display', 'CurrentVersion', 'ProdStatus_display']);
  check('Enhancement: package name, target version and statuses shown', got.PackageName_display === 'InvoiceProcessing' && got.CurrentVersion === '1.3.2' && got.ProdStatus_display === 'Deployed 1.3.2', got);
  check('Enhancement: only the enhancement fields are shown', (await visible('EnhancementDescription')) && (await visible('ChangeReference')) && !(await visible('BugDescription')) && !(await visible('IncidentReference')));
  await takeEvents();
  await page.click('button[name="data[btnSubmit]"]'); await sleep(400);
  ev = await takeEvents(); let t = await text();
  check('Enhancement: Submit with empty description is blocked and the field is flagged', !ev.includes('click.btnSubmit') && t.includes('Enhancement Description is required'), ev);
  await userType('EnhancementDescription', 'Add manager approval step.');
  await userType('ChangeReference', 'CHG-1234');
  await page.click('button[name="data[btnSubmit]"]'); await sleep(400);
  check('Enhancement: Submit raises click.btnSubmit once filled', (await takeEvents()).includes('click.btnSubmit'));
  await shot('form-uipath-enhancement.png');
  got = await robotGet(['EnhancementDescription', 'ChangeReference', 'BugDescription']);
  check('Get Form Fields returns the enhancement fields', got.EnhancementDescription === 'Add manager approval step.' && got.ChangeReference === 'CHG-1234', got);

  // switch type -> type-specific inputs are cleared, details become stale
  await userSelect('ProcessType', 'Bug Fix');
  check('changing Process Type hides the loaded details until Fetch Details runs again', !(await visible('pnlPackage')) && (await visible('lookupStale')));
  await robotSet(Object.assign({}, uipNew, { LookupKey: 'UiPath|Bug Fix|BOT-1001|UAT to Prod', CurrentVersion: '1.3.2', VersionsJson: JSON.stringify(['1.4.0']), RequestedVersion: '1.4.0' }));
  got = await robotGet(['EnhancementDescription']);
  check('Bug Fix: the hidden enhancement description is cleared (clearOnHide)', !got.EnhancementDescription, got);
  check('Bug Fix: bug description and incident reference shown', (await visible('BugDescription')) && (await visible('IncidentReference')) && !(await visible('EnhancementDescription')));
  await userType('BugDescription', 'Invoices with two pages fail.');
  await page.click('button[name="data[btnSubmit]"]'); await sleep(400);
  ev = await takeEvents(); t = await text();
  check('Bug Fix: incident reference is mandatory', !ev.includes('click.btnSubmit') && t.includes('Incident or Defect Reference is required'), ev);
  await userType('IncidentReference', 'INC0012345');
  await page.click('button[name="data[btnSubmit]"]'); await sleep(400);
  check('Bug Fix: Submit raises click.btnSubmit', (await takeEvents()).includes('click.btnSubmit'));
  await robotSet({ SubmitStatus: 'Submitted', RequestReference: 'AM|UIP|BOT-1001|Bug Fix|UAT to Prod|1.4.0', SubmitMessage: 'Submitted as AM|UIP|BOT-1001|Bug Fix|UAT to Prod|1.4.0. Nothing was deployed. UAT to Prod needs approval.' });
  check('UAT to Prod: submitted, nothing deployed, message says approval is needed', (await visible('submitOk')) && (await text()).includes('Nothing was deployed'));
  await shot('form-uipath-bugfix-submitted.png');

  // ---------------------------------------------------------------- 4. Power Automate / New
  await open(initial);
  await userSelect('AutomationTool', 'Power Automate'); await userSelect('ProcessType', 'New'); await userSelect('DeploymentPath', 'Dev to UAT'); await userType('BotId', 'BOT-2001');
  await robotSet(Object.assign({}, uipNew, { LookupKey: 'Power Automate|New|BOT-2001|Dev to UAT', ProcessName: 'Purchase Approvals', PackageName: 'PurchaseApprovals',
    DevFolder: 'https://org-dev.crm.dynamics.com', UatFolder: 'https://org-uat.crm.dynamics.com', ProdFolder: 'https://org.crm.dynamics.com', AssetsJson: '[]', QueuesJson: '[]', AccessJson: '[]',
    FlowsJson: JSON.stringify([{ name: 'Purchase approval', state: 'On', expected: true }]), VersionsJson: JSON.stringify(['1.0.0.3']), RequestedVersion: '1.0.0.3',
    WarningsText: 'Connection references must be configured in UAT before the flows are turned on.' }));
  check('Power Automate New: flows panel shown, UiPath configuration hidden', (await visible('pnlFlows')) && !(await visible('pnlConfiguration')));
  check('Power Automate labels: Solution Unique Name / Dev environment URL', (await label('PackageName')) === 'Solution Unique Name' && (await label('DevFolder')) === 'Dev environment URL', [await label('PackageName'), await label('DevFolder')]);
  check('Power Automate: flows listed read-only', JSON.stringify(await page.evaluate(() => form.getComponent('FlowsGrid').getValue())) === '[{"name":"Purchase approval","state":"On","expected":"Yes"}]');
  check('warnings shown', (await visible('warnings')) && (await text()).includes('Connection references'));
  await shot('form-powerautomate-new.png');

  // ---------------------------------------------------------------- 5. errors and stale details
  await open(initial);
  await userSelect('AutomationTool', 'UiPath'); await userSelect('ProcessType', 'New'); await userSelect('DeploymentPath', 'Dev to UAT'); await userType('BotId', 'BOT-9999');
  await robotSet({ LookupStatus: 'NotFound', LookupMessage: "Bot ID BOT-9999 is not in the Bot ID mapping.", LookupKey: '' });
  check('unknown Bot ID: message shown, no panels', (await visible('lookupError')) && !(await visible('pnlProcess')) && (await text()).includes('not in the Bot ID mapping'));
  await robotSet(uipNew);
  await userType('BotId', 'BOT-1001');
  await robotSet({ LookupKey: 'UiPath|New|BOT-1001|Dev to UAT', LookupStatus: 'Found', LookupMessage: 'found' });
  check('details shown for the fetched Bot ID', await visible('pnlProcess'));
  await userType('BotId', 'BOT-1002');
  check('changing the Bot ID after Fetch hides the details and asks to fetch again', !(await visible('pnlProcess')) && (await visible('lookupStale')) && (await disabled('btnSubmit')));
  await open(initial);
  await page.click('button[name="data[btnValidate]"]').catch(() => {}); await sleep(300);
  check('empty form: nothing raised by the disabled Validate button', !(await takeEvents()).includes('click.btnValidate'));
  await page.click('button[name="data[btnCancel]"]'); await sleep(300);
  check('Cancel raises click.btnCancel', (await takeEvents()).includes('click.btnCancel'));

  await browser.close();
  const failed = results.filter(r => !r.ok).length;
  console.log(`\n${results.length - failed} passed, ${failed} failed (offline browser test, form.io bundle from UiPath.Studio.Forms.Runtime 25.10.0)`);
  process.exit(failed ? 1 : 0);
})().catch(e => { console.error(e); process.exit(2); });
