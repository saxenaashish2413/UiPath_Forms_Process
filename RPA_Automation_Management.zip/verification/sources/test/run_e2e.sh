#!/bin/bash
# Usage: run_e2e.sh <work dir>   Starts the mock APIs, runs the workflow suite, stops the mock.
set -u
HERE=$(cd "$(dirname "$0")" && pwd)
PORT=${PORT:-8765}
python3 "$HERE/mock_server.py" $PORT > "$1.mock.log" 2>&1 &
MOCK=$!
trap 'kill $MOCK 2>/dev/null' EXIT
sleep 1
cd "$HERE" && dotnet build -nologo -v q 2>&1 | grep -E " error " | sort -u
dotnet run --no-build -- http://127.0.0.1:$PORT "$HERE/../config" "$1"
