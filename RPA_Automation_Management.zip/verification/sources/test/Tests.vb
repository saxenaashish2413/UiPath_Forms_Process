Option Strict On
Imports System.Collections.Generic
Imports System.IO
Imports System.Linq
Imports Newtonsoft.Json.Linq

' OFFLINE / MOCKED end-to-end tests of the generated workflows (VB twin, same expressions and Invoke Code bodies as the XAML).
' The robot activities are simulated by TestHost; Orchestrator, Identity, Entra ID and Dataverse are simulated by mock_server.py.
' Nothing here proves behaviour against a real Orchestrator 2025.10 or Power Platform environment.
' Usage: Harness <mock base url> <config template dir> <work dir>
Public Module Tests
    Private Passed As Integer, Failed As Integer
    Private Report As New List(Of String)
    Private Base As String, TemplateDir As String, Work As String
    Private ReadOnly Http As New System.Net.Http.HttpClient()
    Private ReadOnly [ME] As String = Environment.UserDomainName & "\" & Environment.UserName
    Private ReadOnly Secrets As String() = {"dev-secret-123", "uat-secret-456", "prod-secret-789", "pa-secret-000", "STAGE-UAT-PASSWORD", "STAGE-PROD-PASSWORD", "DEV-ONLY-PASSWORD"}
    Private AllText As New List(Of String)   ' everything the workflows showed, logged or audited, scanned for secrets at the end
    Private CfgN As Integer

    ' ------------------------------------------------------------------ helpers
    Sub Check(name As String, ok As Boolean, Optional detail As String = "")
        If ok Then Passed += 1 Else Failed += 1
        Report.Add(If(ok, "PASS ", "FAIL ") & name & If(ok OrElse detail = "", "", "  -> " & Left(detail, 900)))
        Console.WriteLine(Report.Last())
    End Sub

    Function Mock(json As String) As String
        Dim r = Http.PostAsync(Base & "/__control", New System.Net.Http.StringContent(json, System.Text.Encoding.UTF8, "application/json")).GetAwaiter().GetResult()
        Return r.Content.ReadAsStringAsync().GetAwaiter().GetResult()
    End Function
    Function MockState() As JObject
        Return JObject.Parse(Http.GetStringAsync(Base & "/__state").GetAwaiter().GetResult())
    End Function
    Function MockLog() As JArray
        Return JArray.Parse(Http.GetStringAsync(Base & "/__log").GetAwaiter().GetResult())
    End Function
    Sub ResetMock()
        Mock("{""op"":""reset""}")
        If Directory.Exists(Path.Combine(Work, "Artifacts")) Then Directory.Delete(Path.Combine(Work, "Artifacts"), True)
    End Sub
    Function Calls(method As String, contains As String, Optional log As JArray = Nothing) As Integer
        Return If(log, MockLog()).Children(Of JObject)().Count(Function(e) e.Value(Of String)("method") = method AndAlso (e.Value(Of String)("path") & "?" & Uri.UnescapeDataString(e.Value(Of String)("query"))).Contains(contains))
    End Function

    ' Settings/BotMapping from the shipped templates, pointed at the mock; tweak lets a test change policy.
    Function Config(Optional tweak As Action(Of JObject, JObject) = Nothing) As Tuple(Of String, String)
        Dim s = JObject.Parse(File.ReadAllText(Path.Combine(TemplateDir, "Settings.json")))
        Dim m = JObject.Parse(File.ReadAllText(Path.Combine(TemplateDir, "BotMapping.json")))
        For Each env In {"Dev", "UAT", "Prod"}
            Dim e = CType(s.SelectToken("uipath.environments." & env), JObject)
            e("orchestratorUrl") = Base & "/orch/" & env
            e("tokenUrl") = Base & "/orch/" & env & "/identity/connect/token"
            s.SelectToken("powerAutomate.environments." & env)("environmentUrl") = Base & "/dv/" & env
        Next
        s("powerAutomate")("authorityUrl") = Base & "/entra"
        s("powerAutomate")("tenantId") = "tid"
        s("powerAutomate")("asyncPollSeconds") = 0
        s("powerAutomate")("solutionArtifactStore") = Path.Combine(Work, "Artifacts")
        s("http")("retryDelaySeconds") = 0
        s("http")("timeoutSeconds") = 10
        s("audit")("folder") = Path.Combine(Work, "Audit")
        s("authorization")("configurationEditors") = New JArray([ME])
        s("authorization")("approvers") = JObject.Parse("{""UAT"":[""CORP\\uat.lead""],""Prod"":[""CORP\\change.approver""]}")
        Dim mj = m.ToString().Replace("<DOMAIN>\\", "CORP\\")
        m = JObject.Parse(mj)
        If tweak IsNot Nothing Then tweak(s, m)
        CfgN += 1
        Dim d = Path.Combine(Work, "cfg" & CfgN.ToString())
        Directory.CreateDirectory(d)
        File.WriteAllText(Path.Combine(d, "Settings.json"), s.ToString())
        File.WriteAllText(Path.Combine(d, "BotMapping.json"), m.ToString())
        Return Tuple.Create(Path.Combine(d, "Settings.json"), Path.Combine(d, "BotMapping.json"))
    End Function

    Function S(trigger As String, ParamArray kv As String()) As FormStep
        Dim st As New FormStep With {.Trigger = trigger}
        For i = 0 To kv.Length - 1 Step 2
            st.UserInput(kv(i)) = kv(i + 1)
        Next
        Return st
    End Function
    ' Select tool, type and path, type the Bot ID, Fetch Details.
    Function Pick(tool As String, ptype As String, path As String, bot As String) As List(Of FormStep)
        Return New List(Of FormStep) From {
            S("Automation tool changed", "AutomationTool", tool), S("Process type changed", "ProcessType", ptype),
            S("Deployment path changed", "DeploymentPath", path), S("Fetch requested", "BotId", bot)}
    End Function

    Function RunForm(steps As IEnumerable(Of FormStep), cfg As Tuple(Of String, String)) As Tuple(Of String, String)
        TestHost.Reset(steps)
        Dim outcome As String = Nothing, reference As String = Nothing
        W_Main(in_SettingsPath:=cfg.Item1, in_BotMappingPath:=cfg.Item2, out_Outcome:=outcome, out_RequestReference:=reference)
        Collect()
        Return Tuple.Create(outcome, reference)
    End Function
    Sub Collect()
        AllText.AddRange(TestHost.Logs)
        AllText.AddRange(TestHost.Dialogs)
        AllText.AddRange(TestHost.SetLog.SelectMany(Function(e) e.Value.Select(Function(kv) kv.Key & "=" & CStr(kv.Value))))
    End Sub
    Function Field(key As String) As String
        Dim v As String = Nothing
        Return If(TestHost.FormData.TryGetValue(key, v), v, "")
    End Function
    ' Every Set Form Fields value of one key, in order
    Function Sets(key As String) As List(Of String)
        Return TestHost.SetLog.Where(Function(e) e.Value.ContainsKey(key)).Select(Function(e) CStr(e.Value(key))).ToList()
    End Function
    Function Execute(ref As String, cfg As Tuple(Of String, String)) As Tuple(Of String, String, String)
        TestHost.Reset(New FormStep() {})
        Dim st As String = Nothing, msg As String = Nothing, thrown As String = ""
        Try
            W_ExecuteDeployment(in_SettingsPath:=cfg.Item1, in_BotMappingPath:=cfg.Item2, in_RequestReference:=ref, out_Status:=st, out_Message:=msg)
        Catch ex As Exception
            thrown = ex.GetType().Name & ": " & ex.Message
        End Try
        Collect()
        AllText.Add(If(msg, "") & thrown)
        Return Tuple.Create(If(st, ""), If(msg, ""), thrown)
    End Function
    Function Approve(ref As String, decision As String, comment As String, cfg As Tuple(Of String, String)) As String
        TestHost.Reset(New FormStep() {})
        Dim msg As String = Nothing
        Try
            W_ApproveRequest(in_SettingsPath:=cfg.Item1, in_BotMappingPath:=cfg.Item2, in_RequestReference:=ref, in_Decision:=decision, in_Comment:=comment, out_Message:=msg)
        Catch ex As Exception
            msg = "THROWN " & ex.GetType().Name & ": " & ex.Message
        End Try
        Collect()
        Return msg
    End Function
    Function QueueItems(queueName As String) As List(Of JObject)
        Dim st = MockState()
        Dim q = st.SelectToken("orch.Dev.queues.20").Children(Of JObject)().First(Function(x) x.Value(Of String)("Name") = queueName)
        Return st.SelectToken("orch.Dev.queueItems").Children(Of JObject)().Where(Function(i) i.Value(Of Long)("QueueDefinitionId") = q.Value(Of Long)("Id")).ToList()
    End Function
    Function Rows(json As String) As List(Of JObject)
        Return If(json = "", New List(Of JObject), JArray.Parse(json).Children(Of JObject)().ToList())
    End Function
    Function Row(json As String, name As String) As JObject
        Return Rows(json).FirstOrDefault(Function(r) r.Value(Of String)("name") = name)
    End Function

    ' ------------------------------------------------------------------ tests
    Sub Main(args As String())
        Base = args(0).TrimEnd("/"c) : TemplateDir = args(1) : Work = args(2)
        Directory.CreateDirectory(Work)
        Environment.CurrentDirectory = Work
        TestHost.Credentials("Shared/AutomationManagement|AM_Orchestrator_Dev_App") = Tuple.Create("am-dev", "dev-secret-123")
        TestHost.Credentials("Shared/AutomationManagement|AM_Orchestrator_UAT_App") = Tuple.Create("am-uat", "uat-secret-456")
        TestHost.Credentials("Shared/AutomationManagement|AM_Orchestrator_Prod_App") = Tuple.Create("am-prod", "prod-secret-789")
        TestHost.Credentials("Shared/AutomationManagement|AM_PowerPlatform_App") = Tuple.Create("pa-app", "pa-secret-000")
        TestHost.Credentials("Shared/SecretStaging|STAGE_INV_ServiceAccount_UAT") = Tuple.Create("svc_uat", "STAGE-UAT-PASSWORD")
        TestHost.Credentials("Shared/SecretStaging|STAGE_INV_ServiceAccount_Prod") = Tuple.Create("svc_prod", "STAGE-PROD-PASSWORD")
        Console.WriteLine("Running as " & [ME] & " (configuration editor in the test settings)")

        Dim tests As New List(Of KeyValuePair(Of String, Action)) From {
            New KeyValuePair(Of String, Action)("Configuration", AddressOf T_Configuration),
            New KeyValuePair(Of String, Action)("Bot ID resolution", AddressOf T_BotIds),
            New KeyValuePair(Of String, Action)("UiPath New Dev to UAT", AddressOf T_UiPathNew),
            New KeyValuePair(Of String, Action)("UiPath Enhancement UAT to Prod", AddressOf T_UiPathEnhancementProd),
            New KeyValuePair(Of String, Action)("UiPath Bug Fix", AddressOf T_UiPathBugFix),
            New KeyValuePair(Of String, Action)("Validation rules", AddressOf T_ValidationRules),
            New KeyValuePair(Of String, Action)("Partial failure and resume", AddressOf T_PartialFailure),
            New KeyValuePair(Of String, Action)("Rollback", AddressOf T_Rollback),
            New KeyValuePair(Of String, Action)("API errors", AddressOf T_ApiErrors),
            New KeyValuePair(Of String, Action)("Power Automate", AddressOf T_PowerAutomate)}
        Dim only = Environment.GetEnvironmentVariable("AM_ONLY")
        For Each t In tests
            If Not String.IsNullOrEmpty(only) AndAlso Not t.Key.Contains(only) Then Continue For
            Console.WriteLine("== " & t.Key)
            Try
                t.Value.Invoke()
            Catch ex As Exception
                Check(t.Key & ": test aborted", False, ex.ToString())
            End Try
        Next
        T_Secrets()
        Console.WriteLine()
        Console.WriteLine(Passed.ToString() & " passed, " & Failed.ToString() & " failed (OFFLINE: VB twin + mock APIs)")
        File.WriteAllLines(Path.Combine(Work, "workflow-tests.log"), Report.Concat({"", Passed.ToString() & " passed, " & Failed.ToString() & " failed (OFFLINE: VB twin + mock APIs)"}))
        Environment.Exit(If(Failed = 0, 0, 1))
    End Sub

    Sub T_Configuration()
        TestHost.Reset(New FormStep() {})
        Dim o As String = Nothing, r As String = Nothing
        W_Main(in_SettingsPath:=Path.Combine(Work, "missing.json"), in_BotMappingPath:=Path.Combine(Work, "missing2.json"), out_Outcome:=o, out_RequestReference:=r)
        Check("CFG-01 missing configuration files: outcome ConfigurationError, user told, form not shown", o = "ConfigurationError" AndAlso TestHost.Dialogs.Any(Function(d) d.Contains("file not found")) AndAlso Not TestHost.FormShown, o & " " & String.Join("|", TestHost.Dialogs))
        Dim bad = Config(Sub(s, m) s("deploymentPaths")(1)("requiresApproval") = False)
        TestHost.Reset(New FormStep() {})
        W_Main(in_SettingsPath:=bad.Item1, in_BotMappingPath:=bad.Item2, out_Outcome:=o, out_RequestReference:=r)
        Check("CFG-02 a path into Prod without approval is rejected as configuration", o = "ConfigurationError" AndAlso TestHost.Dialogs.Any(Function(d) d.Contains("targets Prod and must")), String.Join("|", TestHost.Dialogs))
        Dim dup = Config(Sub(s, m) CType(m("bots")(1)("aliases"), JArray).Add("BOT-1001"))
        TestHost.Reset(New FormStep() {})
        W_Main(in_SettingsPath:=dup.Item1, in_BotMappingPath:=dup.Item2, out_Outcome:=o, out_RequestReference:=r)
        Check("CFG-03 a Bot ID used twice in the mapping is rejected", o = "ConfigurationError" AndAlso TestHost.Dialogs.Any(Function(d) d.Contains("used twice")), String.Join("|", TestHost.Dialogs))
        Collect()
    End Sub

    Sub T_BotIds()
        ResetMock()
        Dim cfg = Config()
        Dim steps = Pick("UiPath", "New", "Dev to UAT", "BOT-9999")
        steps.Add(S("Fetch requested", "BotId", "INV-BOT"))
        steps.Add(S("Fetch requested", "BotId", "BOT-2001"))
        steps.Add(S("Cancel requested"))
        Dim res = RunForm(steps, cfg)
        Dim msgs = Sets("LookupMessage").Where(Function(x) x <> "" AndAlso Not x.StartsWith("Retrieving")).ToList()
        Check("BOT-01 unknown Bot ID: not found, nothing invented", msgs.Count >= 1 AndAlso msgs(0).Contains("BOT-9999") AndAlso Sets("LookupStatus").Contains("NotFound"), String.Join(" | ", msgs))
        Check("BOT-02 alias INV-BOT resolves to BOT-1001 (mapping, not an Orchestrator key)", msgs.Count >= 2 AndAlso msgs(1).Contains("BOT-1001"), String.Join(" | ", msgs))
        Check("BOT-03 Power Automate Bot ID with tool UiPath: tool mismatch explained", msgs.Count >= 3 AndAlso msgs(2).Contains("Power Automate"), String.Join(" | ", msgs))
        Check("BOT-04 Cancel closes the form; outcome Cancelled", res.Item1 = "Cancelled" AndAlso TestHost.FormClosed)
    End Sub

    Sub T_UiPathNew()
        ResetMock()
        Dim cfg = Config()
        Dim steps = Pick("UiPath", "New", "Dev to UAT", "bot-1001")
        ' configuration editor turns edit mode on and changes INV_MaxInvoices from Keep to Update 75 (the form sends its grid as JSON)
        steps.Add(S("Edit requested"))
        steps.Add(S("Validate requested", "AssetsProposedJson", "[{""name"":""INV_ApiBaseUrl"",""action"":""Create"",""proposedValue"":""https://dev-api.example.local""},{""name"":""INV_MaxInvoices"",""action"":""Update"",""proposedValue"":""75""},{""name"":""INV_ServiceAccount"",""action"":""Create"",""proposedValue"":""""}]"))
        steps.Add(S("Submit requested"))
        steps.Add(S("Form window closed"))
        TestHost.OnEvent = Sub(t)
                               If t = "Validate requested" Then
                                   ' what the user saw after Fetch Details
                                   snapshot = New Dictionary(Of String, String)(TestHost.FormData)
                               End If
                           End Sub
        Dim res = RunForm(steps, cfg)
        TestHost.OnEvent = Nothing
        Dim f = snapshot
        Check("NEW-01 fetch: process, package and versions come from Dev (latest 1.10.0 first, numeric sort)", f("ProcessName") = "InvoiceProcessing" AndAlso f("LatestDevVersion") = "1.10.0" AndAlso f("VersionsJson") = "[""1.10.0"",""1.4.0"",""1.3.2""]" AndAlso f("RequestedVersion") = "1.10.0", f("VersionsJson") & " " & f("RequestedVersion"))
        Check("NEW-02 fetch: environment status per environment", f("DevStatus") = "Deployed: 1.4.0" AndAlso f("UatStatus") = "Package in feed, process not deployed" = False AndAlso f("UatStatus") = "Not deployed" AndAlso f("ProdStatus") = "Deployed: 1.3.2", f("DevStatus") & " / " & f("UatStatus") & " / " & f("ProdStatus"))
        Dim a1 = Row(f("AssetsJson"), "INV_ApiBaseUrl"), a2 = Row(f("AssetsJson"), "INV_MaxInvoices"), a3 = Row(f("AssetsJson"), "INV_ServiceAccount")
        Check("NEW-03 assets: Dev value retrieved, UAT state compared, default action per row", a1.Value(Of String)("devValue") = "https://dev-api.example.local" AndAlso a1.Value(Of String)("action") = "Create" AndAlso a2.Value(Of String)("targetValue") = "25" AndAlso a2.Value(Of String)("action") = "Keep", f("AssetsJson"))
        Check("NEW-04 credential asset: masked, no value proposed, secret source known", a3.Value(Of Boolean)("isSecret") AndAlso a3.Value(Of String)("devValue") = "Configured in Orchestrator (hidden)" AndAlso a3.Value(Of String)("proposedValue") = "" AndAlso a3.Value(Of Boolean)("hasSecretSource") AndAlso Not f("AssetsJson").Contains("svc_dev"), a3.ToString())
        Check("NEW-05 queues: Dev settings retrieved, missing in UAT -> Create", Row(f("QueuesJson"), "INV_Invoices").Value(Of String)("action") = "Create" AndAlso Row(f("QueuesJson"), "INV_Invoices").Value(Of String)("maxRetries") = "1", f("QueuesJson"))
        Dim acc = Row(f("AccessJson"), "CORP\Finance-RPA-Operators")
        Check("NEW-06 access: mapped group needs Operator roles in UAT -> Grant; Dev-only accounts listed for information", acc IsNot Nothing AndAlso acc.Value(Of String)("action") = "Grant" AndAlso acc.Value(Of String)("devRoles") = "Robot Operator" AndAlso Row(f("AccessJson"), "CORP\dev.lead").Value(Of String)("action") = "No change", f("AccessJson"))
        Check("NEW-07 Edit Configuration turns edit mode on for an editor", Sets("EditMode").Contains("Yes"))
        Check("NEW-08 Validate: valid", Sets("ValidationStatus").Contains("Valid"), String.Join("|", Sets("SummaryHtml")))
        Check("NEW-09 Submit: request recorded, Dev to UAT deployed straight away (settings allow it)", res.Item1 = "Deployed" AndAlso res.Item2 = "AM|UIP|BOT-1001|New|Dev to UAT|1.10.0" AndAlso Field("SubmitStatus") = "Succeeded", res.Item1 & " " & res.Item2 & " " & Field("SubmitMessage"))
        Dim st = MockState()
        Dim uat = st.SelectToken("orch.UAT")
        Check("NEW-10 package 1.10.0 copied to the UAT feed (same bytes as Dev)", uat.SelectToken("feed.InvoiceProcessing")("1.10.0") IsNot Nothing)
        Dim rel = uat("releases").Children(Of JObject)().FirstOrDefault(Function(x) x.Value(Of String)("Name") = "InvoiceProcessing")
        Check("NEW-11 process created in UAT folder on 1.10.0", rel IsNot Nothing AndAlso rel.Value(Of String)("ProcessVersion") = "1.10.0" AndAlso rel.Value(Of Long)("_folder") = 10)
        Dim ua = uat.SelectToken("assets.10").Children(Of JObject)().ToDictionary(Function(x) x.Value(Of String)("Name"), Function(x) x)
        Check("NEW-12 assets in UAT: text created, integer updated to the proposed 75", ua("INV_ApiBaseUrl").Value(Of String)("StringValue") = "https://dev-api.example.local" AndAlso ua("INV_MaxInvoices").Value(Of Integer)("IntValue") = 75, uat.SelectToken("assets.10").ToString())
        Check("NEW-13 credential created from the UAT staging secret, never from Dev or the form", ua("INV_ServiceAccount").Value(Of String)("CredentialUsername") = "svc_uat" AndAlso ua("INV_ServiceAccount").Value(Of String)("CredentialPassword") = "STAGE-UAT-PASSWORD")
        Check("NEW-14 queue created in UAT with Dev settings", uat.SelectToken("queues.10").Children(Of JObject)().Any(Function(q) q.Value(Of String)("Name") = "INV_Invoices" AndAlso q.Value(Of Integer)("MaxNumberOfRetries") = 1 AndAlso q.Value(Of Boolean)("EnforceUniqueReference")))
        Check("NEW-15 access granted: group gets Automation User + Allow to be Automation User; inherited role untouched", uat.SelectToken("folderUsers.10.71").ToString(Newtonsoft.Json.Formatting.None) = "[1,2]" AndAlso uat.SelectToken("folderUsers.10.72").ToString(Newtonsoft.Json.Formatting.None).Contains("Inherited"), uat.SelectToken("folderUsers").ToString(Newtonsoft.Json.Formatting.None))
        Check("NEW-16 Prod untouched", Calls("POST", "/orch/Prod/odata") = 0 AndAlso Calls("PUT", "/orch/Prod/odata") = 0)
        Check("NEW-17 request, and result evidence RES|...|OK recorded in the governance queues", QueueItems("AM_Requests").Any(Function(i) i.Value(Of String)("Reference") = res.Item2) AndAlso QueueItems("AM_DeploymentResults").Any(Function(i) i.Value(Of String)("Reference") = "RES|UIP|BOT-1001|Dev to UAT|1.10.0|OK"))
        Dim saved = Rows(Field("AssetsJson"))
        Check("NEW-18 form shows what was saved per object (Saved column)", saved.Any(Function(x) x.Value(Of String)("name") = "INV_MaxInvoices" AndAlso x.Value(Of String)("savedStatus").StartsWith("Updated") AndAlso x.Value(Of String)("proposedValue") = "75") AndAlso saved.Any(Function(x) x.Value(Of String)("name") = "INV_ServiceAccount" AndAlso x.Value(Of String)("savedStatus").StartsWith("Created")), Field("AssetsJson"))
        Dim auditFiles = Directory.GetFiles(Path.Combine(Work, "Audit"), "audit-*.jsonl")
        Dim auditText = String.Join(vbLf, auditFiles.Select(Function(x) File.ReadAllText(x)))
        AllText.Add(auditText)
        Check("NEW-19 audit trail: request, package, process, each asset, queue and access step recorded", {"Request AM|UIP|BOT-1001", "UAT package InvoiceProcessing 1.10.0", "UAT process InvoiceProcessing", "UAT asset INV_ServiceAccount", "UAT queue INV_Invoices", "UAT access CORP\\Finance-RPA-Operators"}.All(Function(x) auditText.Contains(x)), auditText.Substring(0, Math.Min(1500, auditText.Length)))
        Dim item = QueueItems("AM_Requests").First()
        AllText.Add(item.ToString())
        Check("NEW-20 the stored request holds Dev values, proposals and who asked, but no secret", item.SelectToken("SpecificContent.RequestJson").ToString().Contains("""proposedValue"":""75""") AndAlso item.SelectToken("SpecificContent.RequestedBy").ToString() = [ME])

        ' idempotency: execute the same request again, submit it again
        Dim log0 = MockLog().Count
        Dim again = Execute(res.Item2, cfg)
        Dim newCalls = MockLog().Skip(log0).OfType(Of JObject)().ToList()
        Check("IDEM-01 executing the same request again: AlreadyDeployed, no change calls", again.Item1 = "AlreadyDeployed" AndAlso Not newCalls.Any(Function(e) e.Value(Of String)("method") <> "GET" AndAlso Not e.Value(Of String)("path").EndsWith("/token") AndAlso Not e.Value(Of String)("path").Contains("AddQueueItem")), again.Item1 & " " & again.Item2)
        steps = Pick("UiPath", "New", "Dev to UAT", "BOT-1001")
        steps.Add(S("Submit requested"))
        steps.Add(S("Form window closed"))
        RunForm(steps, cfg)
        Check("IDEM-02 submitting the same request twice is refused as a duplicate", Sets("SummaryHtml").Any(Function(x) x.Contains("Duplicate submission")) AndAlso QueueItems("AM_Requests").Count = 1, String.Join("|", Sets("SummaryHtml")).Substring(0, 300))
        Check("IDEM-03 after deployment the same objects show as existing (Keep / No change)", Rows(Sets("AssetsJson").First(Function(x) x <> "[]")).All(Function(x) x.Value(Of String)("action") = "Keep") AndAlso Rows(Sets("AccessJson").First(Function(x) x <> "[]")).All(Function(x) x.Value(Of String)("action") = "No change"), Sets("AccessJson").First(Function(x) x <> "[]"))
    End Sub
    Private snapshot As Dictionary(Of String, String)

    ' Needs the UAT state left by T_UiPathNew (1.10.0 in UAT, RES|...|OK recorded).
    Sub T_UiPathEnhancementProd()
        Dim cfg = Config()
        Dim steps = Pick("UiPath", "Enhancement", "UAT to Prod", "BOT-1001")
        steps.Add(S("Submit requested", "EnhancementDescription", "Add manager approval step.", "ChangeReference", "CHG-1234"))
        steps.Add(S("Form window closed"))
        TestHost.OnEvent = Sub(t) If t = "Submit requested" Then snapshot = New Dictionary(Of String, String)(TestHost.FormData)
        Dim log0 = MockLog().Count
        Dim res = RunForm(steps, cfg)
        TestHost.OnEvent = Nothing
        Check("ENH-01 Enhancement shows package details only (no assets/queues/access)", snapshot("AssetsJson") = "[]" AndAlso snapshot("QueuesJson") = "[]" AndAlso snapshot("AccessJson") = "[]", String.Join(",", snapshot.Where(Function(kv) kv.Key.EndsWith("Json") AndAlso kv.Key.Length < 12).Select(Function(kv) kv.Key & "=" & kv.Value.Length)))
        Check("ENH-02 UAT to Prod offers the version tested in UAT (1.10.0)", snapshot("RequestedVersion") = "1.10.0" AndAlso snapshot("VersionsJson") = "[""1.10.0""]", snapshot("VersionsJson"))
        Check("ENH-03 submitted for approval; nothing deployed to Prod", res.Item1 = "Submitted" AndAlso Field("SubmitStatus") = "Submitted" AndAlso Field("SubmitMessage").Contains("Nothing was deployed") AndAlso MockLog().Skip(log0).OfType(Of JObject)().All(Function(e) Not e.Value(Of String)("path").StartsWith("/orch/Prod/odata") OrElse e.Value(Of String)("method") = "GET"), Field("SubmitMessage"))
        Dim req = JObject.Parse(QueueItems("AM_Requests").First(Function(i) i.Value(Of String)("Reference") = res.Item2).SelectToken("SpecificContent.RequestJson").ToString())
        Check("ENH-04 request keeps only Enhancement fields (no configuration, no bug fields)", req("configuration") Is Nothing AndAlso req("bugFix") Is Nothing AndAlso req.SelectToken("enhancement.changeReference").ToString() = "CHG-1234")
        Dim ex1 = Execute(res.Item2, cfg)
        Check("ENH-05 executing without approval: rejected, job faults (BusinessRuleException), Prod untouched", ex1.Item3.StartsWith("BusinessRuleException") AndAlso ex1.Item2.Contains("Approval by CORP\change.approver is required") AndAlso Calls("POST", "/orch/Prod/odata") = 0, ex1.Item3)
        Check("ENH-06 rejection recorded in the results queue", QueueItems("AM_DeploymentResults").Any(Function(i) i.Value(Of String)("Reference").StartsWith("RES|UIP|BOT-1001|UAT to Prod|1.10.0|REJECTED|")))
        Dim selfApprove = Approve(res.Item2, "Approved", "CAB-77", Config(Sub(s, m) s("authorization")("approvers")("Prod") = New JArray([ME])))
        Check("ENH-07 the requester cannot approve their own request (segregation of duties)", selfApprove.Contains("Segregation of duties"), selfApprove)
        Dim notApprover = Approve(res.Item2, "Approved", "CAB-77", cfg)
        Check("ENH-08 a user who is not a Prod approver cannot approve", notApprover.Contains("is not an approver for Prod"), notApprover)
        ' approval recorded by another person (CORP\change.approver) as ApproveRequest.xaml would store it
        Mock("{""op"":""queueitem"",""env"":""Dev"",""queue"":""AM_Approvals"",""reference"":" & New JValue(Left("APR|" & res.Item2, 128)).ToString(Newtonsoft.Json.Formatting.None) & ",""content"":{""RequestReference"":" & New JValue(res.Item2).ToString(Newtonsoft.Json.Formatting.None) & ",""Decision"":""Approved"",""Approver"":""CORP\\change.approver"",""Comment"":""CAB-77"",""ApprovedVersion"":""1.10.0"",""TargetEnvironment"":""Prod"",""ApprovedAtUtc"":""2026-10-11T12:30:00Z""}}")
        Dim ex2 = Execute(res.Item2, cfg)
        Dim prod = MockState().SelectToken("orch.Prod")
        Check("ENH-09 approved: Prod process updated 1.3.2 -> 1.10.0 and verified", ex2.Item1 = "Succeeded" AndAlso prod("releases")(0).Value(Of String)("ProcessVersion") = "1.10.0" AndAlso prod.SelectToken("feed.InvoiceProcessing")("1.10.0") IsNot Nothing, ex2.Item1 & " " & ex2.Item2 & ex2.Item3)
        Check("ENH-10 Enhancement changed no Prod assets, queues or access", prod.SelectToken("assets.10").Count() = 0 AndAlso prod.SelectToken("queues.10").Count() = 0 AndAlso Calls("POST", "/orch/Prod/odata/Folders/UiPath.Server.Configuration.OData.AssignUsers") = 0)
        Check("ENH-11 Prod package came from the UAT feed (downloaded from UAT, not Dev)", Calls("GET", "/orch/UAT/odata/Processes/UiPath.Server.Configuration.OData.DownloadPackage(key='InvoiceProcessing:1.10.0')") >= 1)
        Dim approvedOther = Approve(res.Item2, "Rejected", "late", Config(Sub(s, m)
                                                                       s("authorization")("approvers")("Prod") = New JArray([ME])
                                                                       s("authorization")("segregationOfDuties") = False
                                                                   End Sub))
        Check("ENH-12 a request is decided once (second decision does not override)", approvedOther.Contains("already decided"), approvedOther)
    End Sub

    Sub T_UiPathBugFix()
        ResetMock()
        Dim cfg = Config()
        Dim steps = Pick("UiPath", "Bug Fix", "Dev to UAT", "BOT-1001")
        steps.Add(S("Validate requested", "BugDescription", "Two-page invoices fail.", "RequestedVersion", "1.4.0"))
        steps.Add(S("Form window closed"))
        RunForm(steps, cfg)
        Dim summary = String.Join("|", Sets("SummaryHtml"))
        Check("BUG-01 Bug Fix needs the incident reference", summary.Contains("Incident or Defect Reference is required"), summary)
        Check("BUG-02 Bug Fix into UAT where the process does not exist yet: told to submit New", summary.Contains("does not exist in UAT yet"), summary)
        ' UAT already runs 1.3.2 -> Bug Fix to 1.4.0
        Mock("{""op"":""set"",""path"":[""orch"",""UAT"",""releases""],""value"":[{""Id"":601,""Key"":""k"",""Name"":""InvoiceProcessing"",""ProcessKey"":""InvoiceProcessing"",""ProcessVersion"":""1.3.2"",""Description"":"""",""IsLatestVersion"":false,""_folder"":10}]}")
        Mock("{""op"":""set"",""path"":[""orch"",""UAT"",""feed"",""InvoiceProcessing""],""value"":{""1.3.2"":""NUPKG|InvoiceProcessing|1.3.2|""}}")
        steps = Pick("UiPath", "Bug Fix", "Dev to UAT", "BOT-1001")
        steps.Add(S("Submit requested", "BugDescription", "Two-page invoices fail.", "IncidentReference", "INC0012345", "RequestedVersion", "1.4.0"))
        steps.Add(S("Form window closed"))
        Dim res = RunForm(steps, cfg)
        Dim uat = MockState().SelectToken("orch.UAT")
        Check("BUG-03 Bug Fix Dev to UAT: process updated 1.3.2 -> 1.4.0, nothing else changed", res.Item1 = "Deployed" AndAlso uat("releases")(0).Value(Of String)("ProcessVersion") = "1.4.0" AndAlso uat.SelectToken("assets.10").Count() = 1 AndAlso Calls("POST", "/orch/UAT/odata/Assets") = 0, res.Item1 & " " & Field("SubmitMessage"))
        Check("BUG-04 Bug Fix used UpdateToSpecificPackageVersion (Swagger endpoint, mocked)", Calls("POST", "/orch/UAT/odata/Releases(601)/UiPath.Server.Configuration.OData.UpdateToSpecificPackageVersion") = 1)
        ' downgrade
        steps = Pick("UiPath", "Enhancement", "Dev to UAT", "BOT-1001")
        steps.Add(S("Validate requested", "EnhancementDescription", "x", "RequestedVersion", "1.3.2"))
        steps.Add(S("Form window closed"))
        RunForm(steps, cfg)
        summary = String.Join("|", Sets("SummaryHtml"))
        Check("BUG-05 downgrade refused (1.3.2 older than UAT 1.4.0)", summary.Contains("Downgrades are not allowed"), summary)
    End Sub

    Sub T_ValidationRules()
        ResetMock()
        Dim cfg = Config()
        Dim steps = Pick("UiPath", "New", "Dev to UAT", "BOT-1001")
        steps.Add(S("Validate requested", "AccessProposedJson", "[{""name"":""CORP\\Finance-RPA-Operators"",""action"":""Grant"",""accessLevel"":""Folder Administrator""}]",
                    "AssetsProposedJson", "[{""name"":""INV_MaxInvoices"",""action"":""Create"",""proposedValue"":""seventy""}]",
                    "QueuesProposedJson", "[{""name"":""INV_Invoices"",""action"":""Keep"",""proposedName"":""INV_Invoices""}]"))
        steps.Add(S("Form window closed"))
        RunForm(steps, cfg)
        Dim summary = String.Join("|", Sets("SummaryHtml"))
        Check("VAL-01 unauthorized access change (Folder Administrator not allowed in UAT)", summary.Contains("Unauthorized access change"), summary)
        Check("VAL-02 Create for an asset that exists in UAT is refused (would duplicate)", summary.Contains("INV_MaxInvoices already exists in UAT"), summary)
        Check("VAL-03 required queue missing in UAT cannot be skipped", summary.Contains("Queue INV_Invoices is required"), summary)
        Check("VAL-04 invalid request is not submitted", Sets("ValidationStatus").Contains("Invalid") AndAlso QueueItems("AM_Requests").Count = 0)
        ' non-editor
        Dim cfgNE = Config(Sub(s, m) s("authorization")("configurationEditors") = New JArray("CORP\someone.else"))
        steps = Pick("UiPath", "New", "Dev to UAT", "BOT-1001")
        steps.Add(S("Edit requested"))
        steps.Add(S("Validate requested", "AssetsProposedJson", "[{""name"":""INV_MaxInvoices"",""action"":""Update"",""proposedValue"":""99""}]"))
        steps.Add(S("Form window closed"))
        RunForm(steps, cfgNE)
        summary = String.Join("|", Sets("SummaryHtml"))
        Check("VAL-05 non-editor: edit mode refused and changed values rejected", Sets("EditMessage").Any(Function(x) x.Contains("not authorized")) AndAlso Not Sets("EditMode").Contains("Yes") AndAlso summary.Contains("not authorized to change the configuration"), summary)
        ' credential without secret source
        Dim cfgNS = Config(Sub(s, m) CType(m.SelectToken("bots[0].uipath.assets[2]"), JObject).Remove("secretSource"))
        steps = Pick("UiPath", "New", "Dev to UAT", "BOT-1001")
        steps.Add(S("Validate requested"))
        steps.Add(S("Form window closed"))
        RunForm(steps, cfgNS)
        summary = String.Join("|", Sets("SummaryHtml"))
        Check("VAL-06 credential asset without approved secret source cannot be created", summary.Contains("no approved secret source is configured for UAT"), summary)
        ' stale details: Bot ID changed after fetch
        steps = Pick("UiPath", "Enhancement", "Dev to UAT", "BOT-1001")
        steps.Add(S("Process type changed", "ProcessType", "New"))
        steps.Add(S("Validate requested"))
        steps.Add(S("Form window closed"))
        RunForm(steps, cfg)
        summary = String.Join("|", Sets("SummaryHtml"))
        Check("VAL-07 details must be fetched again after the selection changed", summary.Contains("Fetch the details"), summary)
        ' UAT to Prod for a version that is not in UAT
        steps = Pick("UiPath", "Enhancement", "UAT to Prod", "BOT-1001")
        steps.Add(S("Validate requested", "EnhancementDescription", "x", "RequestedVersion", "1.4.0"))
        steps.Add(S("Form window closed"))
        RunForm(steps, cfg)
        summary = String.Join("|", Sets("SummaryHtml"))
        Check("VAL-08 UAT to Prod only for the version deployed and tested in UAT", summary.Contains("not the version deployed and tested in UAT"), summary)
    End Sub

    Sub T_PartialFailure()
        ResetMock()
        Dim cfg = Config()
        Mock("{""op"":""fault"",""contains"":""/orch/UAT/odata/QueueDefinitions"",""method"":""POST"",""status"":500,""times"":4}")
        Dim steps = Pick("UiPath", "New", "Dev to UAT", "BOT-1001")
        steps.Add(S("Submit requested"))
        steps.Add(S("Form window closed"))
        Dim res = RunForm(steps, cfg)
        Check("PART-01 queue creation keeps failing (HTTP 500 after retries): run fails, other objects still done", res.Item1 = "DeploymentFailed" AndAlso Field("SubmitStatus") = "Failed" AndAlso Field("SubmitMessage").Contains("Queue INV_Invoices") AndAlso MockState().SelectToken("orch.UAT.assets.10").Count() = 3, Field("SubmitMessage"))
        Check("PART-02 transient failures were retried (1 + 3 retries)", Calls("POST", "/orch/UAT/odata/QueueDefinitions") = 4)
        Check("PART-03 failure recorded (RES|...|FAILED|...) and audited", QueueItems("AM_DeploymentResults").Any(Function(i) i.Value(Of String)("Reference").Contains("|FAILED|")))
        Dim log0 = MockLog().Count
        Dim again = Execute(res.Item2, cfg)
        Dim after = New JArray(MockLog().Skip(log0))
        Check("PART-04 re-run resumes: queue created now; package, process and assets not changed again", again.Item1 = "Succeeded" AndAlso Calls("POST", "/orch/UAT/odata/QueueDefinitions", after) = 1 AndAlso Calls("POST", "/orch/UAT/odata/Assets", after) = 0 AndAlso Calls("PUT", "/orch/UAT/odata/Assets", after) = 0 AndAlso Calls("POST", "UploadPackage", after) = 0 AndAlso Calls("POST", "/orch/UAT/odata/Releases", after) = 0, again.Item1 & " " & again.Item2)
    End Sub

    Sub T_Rollback()
        ResetMock()
        Dim cfg = Config()
        Mock("{""op"":""set"",""path"":[""orch"",""UAT"",""releases""],""value"":[{""Id"":601,""Key"":""k"",""Name"":""InvoiceProcessing"",""ProcessKey"":""InvoiceProcessing"",""ProcessVersion"":""1.3.2"",""Description"":"""",""IsLatestVersion"":false,""_folder"":10}]}")
        Mock("{""op"":""set"",""path"":[""orch"",""UAT"",""feed"",""InvoiceProcessing""],""value"":{""1.3.2"":""NUPKG|InvoiceProcessing|1.3.2|""}}")
        Mock("{""op"":""set"",""path"":[""orch"",""UAT"",""stuckRelease""],""value"":""1.4.0""}")
        Dim steps = Pick("UiPath", "Enhancement", "Dev to UAT", "BOT-1001")
        steps.Add(S("Submit requested", "EnhancementDescription", "x", "RequestedVersion", "1.4.0"))
        steps.Add(S("Form window closed"))
        Dim res = RunForm(steps, cfg)
        Check("RB-01 process does not report the new version: verification fails, previous version restored", res.Item1 = "DeploymentFailed" AndAlso Field("SubmitMessage").Contains("previous version 1.3.2 restored") AndAlso Calls("POST", "UpdateToSpecificPackageVersion") = 2 AndAlso MockState().SelectToken("orch.UAT.releases[0].ProcessVersion").ToString() = "1.3.2", Field("SubmitMessage"))
        Check("RB-02 no success evidence recorded for a failed deployment", Not QueueItems("AM_DeploymentResults").Any(Function(i) i.Value(Of String)("Reference").EndsWith("|OK")))
    End Sub

    Sub T_ApiErrors()
        ResetMock()
        Dim cfg = Config()
        Mock("{""op"":""fault"",""contains"":""/orch/Dev/odata/Folders"",""method"":""GET"",""status"":503,""times"":2}")
        Dim steps = Pick("UiPath", "Enhancement", "Dev to UAT", "BOT-1001")
        steps.Add(S("Form window closed"))
        RunForm(steps, cfg)
        Check("API-01 HTTP 503 twice then OK: retried, details shown", Sets("LookupStatus").Contains("Found"), String.Join("|", Sets("LookupMessage")))
        ResetMock()
        Mock("{""op"":""fault"",""contains"":""/orch/UAT/odata/Folders"",""method"":""GET"",""status"":401,""times"":1}")
        RunForm(steps, cfg)
        Check("API-02 HTTP 401 once: token dropped, re-requested and the call retried", Sets("LookupStatus").Contains("Found") AndAlso Calls("POST", "/orch/UAT/identity/connect/token") = 2 AndAlso Not Sets("WarningsText").Any(Function(w) w.Contains("UAT")), String.Join("|", Sets("WarningsText")))
        ResetMock()
        Mock("{""op"":""fault"",""contains"":""/orch/Prod/odata/Folders"",""method"":""GET"",""status"":403,""times"":5,""body"":{""message"":""You do not have permission to view folders."",""errorCode"":1000}}")
        RunForm(steps, cfg)
        If Environment.GetEnvironmentVariable("AM_DEBUG") = "1" Then Console.WriteLine(String.Join(vbLf, TestHost.Logs))
        Check("API-03 HTTP 403 in Prod: reported as a Prod warning, Dev details still shown", Sets("LookupStatus").Contains("Found") AndAlso Sets("WarningsText").Any(Function(w) w.Contains("Prod") AndAlso w.Contains("permission")), String.Join("|", Sets("WarningsText")))
        ResetMock()
        TestHost.Credentials("Shared/AutomationManagement|AM_Orchestrator_Dev_App") = Tuple.Create("am-dev", "wrong-secret")
        RunForm(steps, cfg)
        TestHost.Credentials("Shared/AutomationManagement|AM_Orchestrator_Dev_App") = Tuple.Create("am-dev", "dev-secret-123")
        Dim msg = String.Join("|", Sets("LookupMessage"))
        Check("API-04 rejected client secret: clear error, secret not shown", Sets("LookupStatus").Contains("Error") AndAlso msg.Contains("rejected") AndAlso Not msg.Contains("wrong-secret"), msg)
        ResetMock()
        Mock("{""op"":""fault"",""contains"":""AM_Requests"",""method"":""GET"",""status"":500,""times"":10}")
        Mock("{""op"":""set"",""path"":[""orch"",""UAT"",""releases""],""value"":[{""Id"":601,""Key"":""k"",""Name"":""InvoiceProcessing"",""ProcessKey"":""InvoiceProcessing"",""ProcessVersion"":""1.3.2"",""Description"":"""",""IsLatestVersion"":false,""_folder"":10}]}")
        steps = Pick("UiPath", "Enhancement", "Dev to UAT", "BOT-1001")
        steps.Add(S("Submit requested", "EnhancementDescription", "x", "RequestedVersion", "1.4.0"))
        steps.Add(S("Form window closed"))
        RunForm(steps, cfg)
        Check("API-05 governance queue unreachable: nothing submitted, user told", Not Sets("SubmitStatus").Any(Function(x) x = "Submitted" OrElse x = "Deploying") AndAlso String.Join("|", Sets("SummaryHtml")).Contains("Live validation could not run"), String.Join("|", Sets("SummaryHtml")))
    End Sub

    Sub T_PowerAutomate()
        ResetMock()
        Dim cfg = Config()
        Dim steps = Pick("Power Automate", "New", "Dev to UAT", "BOT-2001")
        steps.Add(S("Submit requested"))
        steps.Add(S("Form window closed"))
        TestHost.OnEvent = Sub(t) If t = "Submit requested" Then snapshot = New Dictionary(Of String, String)(TestHost.FormData)
        Dim res = RunForm(steps, cfg)
        TestHost.OnEvent = Nothing
        Check("PA-01 fetch: solution, Dev version and cloud flows from Dataverse", snapshot("PackageName") = "PurchaseApprovals" AndAlso snapshot("ProcessName") = "Purchase Approvals" AndAlso snapshot("RequestedVersion") = "1.0.0.3" AndAlso Row(snapshot("FlowsJson"), "Purchase approval") IsNot Nothing, snapshot("FlowsJson"))
        Check("PA-02 Power Automate New shows no UiPath assets/queues/access", snapshot("AssetsJson") = "[]" AndAlso snapshot("AccessJson") = "[]")
        Dim uat = MockState().SelectToken("dv.UAT.solutions")
        Check("PA-03 Dev to UAT: managed export, async import polled to completion, UAT has 1.0.0.3 managed", res.Item1 = "Deployed" AndAlso uat.Children(Of JObject)().Any(Function(x) x.Value(Of String)("version") = "1.0.0.3" AndAlso x.Value(Of Boolean)("ismanaged")) AndAlso Calls("GET", "/dv/UAT/api/data/v9.2/asyncoperations(") >= 2, res.Item1 & " " & Field("SubmitMessage"))
        Check("PA-04 Entra token requested with the environment scope (/.default)", MockLog().Children(Of JObject)().Any(Function(e) e.Value(Of String)("path") = "/entra/tid/oauth2/v2.0/token" AndAlso e.Value(Of String)("body").Contains("dv%2FUAT%2F.default")))
        Check("PA-05 managed file and SHA-256 kept in the artifact store", File.Exists(Path.Combine(Work, "Artifacts", "PurchaseApprovals_1.0.0.3_managed.zip")) AndAlso File.Exists(Path.Combine(Work, "Artifacts", "PurchaseApprovals_1.0.0.3_managed.zip.sha256")))
        ' UAT -> Prod with approval, same file (the solution is not in Prod yet, so this is a New request)
        steps = Pick("Power Automate", "New", "UAT to Prod", "BOT-2001")
        steps.Add(S("Submit requested", "RequestedVersion", "1.0.0.3"))
        steps.Add(S("Form window closed"))
        Dim res2 = RunForm(steps, cfg)
        Check("PA-06 UAT to Prod: submitted, waits for approval", res2.Item1 = "Submitted" AndAlso Calls("POST", "/dv/Prod/") = 0, res2.Item1 & " " & Field("SubmitMessage") & String.Join("|", Sets("SummaryHtml")))
        Mock("{""op"":""queueitem"",""env"":""Dev"",""queue"":""AM_Approvals"",""reference"":" & New JValue(Left("APR|" & res2.Item2, 128)).ToString(Newtonsoft.Json.Formatting.None) & ",""content"":{""Decision"":""Approved"",""Approver"":""CORP\\change.approver"",""Comment"":""CAB-78"",""ApprovedVersion"":""1.0.0.3"",""ApprovedAtUtc"":""2026-10-11T12:40:00Z""}}")
        Dim exports0 = Calls("POST", "ExportSolution")
        ' tamper with the stored file -> refused
        Dim zip = Path.Combine(Work, "Artifacts", "PurchaseApprovals_1.0.0.3_managed.zip")
        Dim original = File.ReadAllBytes(zip)
        File.WriteAllBytes(zip, original.Concat(New Byte() {1}).ToArray())
        Dim tampered = Execute(res2.Item2, cfg)
        Check("PA-07 a changed solution file is refused (SHA-256 mismatch), Prod untouched", tampered.Item1 = "Failed" AndAlso tampered.Item2.Contains("does not match its recorded SHA-256") AndAlso Calls("POST", "/dv/Prod/api/data/v9.2/ImportSolutionAsync") = 0, tampered.Item2)
        File.WriteAllBytes(zip, original)
        Dim ok = Execute(res2.Item2, cfg)
        Check("PA-08 approved: Prod gets the same managed file UAT got (no new export)", ok.Item1 = "Succeeded" AndAlso Calls("POST", "ExportSolution") = exports0 AndAlso MockState().SelectToken("dv.Prod.solutions").Children(Of JObject)().Any(Function(x) x.Value(Of String)("version") = "1.0.0.3"), ok.Item1 & " " & ok.Item2 & ok.Item3)
        ' import failure
        ResetMock()
        Mock("{""op"":""set"",""path"":[""dv"",""UAT"",""failImport""],""value"":true}")
        steps = Pick("Power Automate", "New", "Dev to UAT", "BOT-2001")
        steps.Add(S("Submit requested"))
        steps.Add(S("Form window closed"))
        Dim res3 = RunForm(steps, cfg)
        Check("PA-09 import failure (statuscode 31): failed with Dataverse's message, not recorded as success", res3.Item1 = "DeploymentFailed" AndAlso Field("SubmitMessage").Contains("A required component is missing") AndAlso Not QueueItems("AM_DeploymentResults").Any(Function(i) i.Value(Of String)("Reference").EndsWith("|OK")), Field("SubmitMessage"))
        ' version not current in Dev
        steps = Pick("Power Automate", "New", "Dev to UAT", "BOT-2001")
        steps.Add(S("Validate requested", "RequestedVersion", "1.0.0.2"))
        steps.Add(S("Form window closed"))
        RunForm(steps, cfg)
        Check("PA-10 only the current Dev solution version can be exported", String.Join("|", Sets("SummaryHtml")).Contains("1.0.0.2"), String.Join("|", Sets("SummaryHtml")))
    End Sub

    Sub T_Secrets()
        Dim st = MockState()
        Dim items = String.Join(vbLf, {"Dev", "UAT", "Prod"}.Select(Function(e) st.SelectToken("orch." & e & ".queueItems").ToString()))
        Dim auditText = If(Directory.Exists(Path.Combine(Work, "Audit")), String.Join(vbLf, Directory.GetFiles(Path.Combine(Work, "Audit")).Select(Function(x) File.ReadAllText(x))), "")
        Dim corpus = String.Join(vbLf, AllText) & vbLf & items & vbLf & auditText
        Dim leaks = Secrets.Where(Function(x) corpus.Contains(x)).ToList()
        Check("SEC-01 no client secret, staged credential password or Dev credential in form data, logs, dialogs, audit files or governance queue items", leaks.Count = 0, String.Join(", ", leaks))
        Dim tokenLeak = System.Text.RegularExpressions.Regex.IsMatch(corpus, "mock-[0-9a-f]{32}")
        Check("SEC-02 no access token in form data, logs, audit or queue items", Not tokenLeak)
        Dim log = MockLog()
        Check("SEC-03 every API call carried a bearer token (no anonymous calls)", log.Children(Of JObject)().Where(Function(e) Not e.Value(Of String)("path").EndsWith("/token")).All(Function(e) e.Value(Of String)("auth") = "Bearer "))
        Check("SEC-04 asset reads never select credential fields", log.Children(Of JObject)().Where(Function(e) e.Value(Of String)("path").EndsWith("/odata/Assets") AndAlso e.Value(Of String)("method") = "GET").All(Function(e) Not Uri.UnescapeDataString(e.Value(Of String)("query")).Contains("Credential")))
    End Sub
End Module
