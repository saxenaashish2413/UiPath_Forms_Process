"""Assembles the deliverable: Studio project, docs, tests and verification evidence.
Usage: python3 package.py <dest dir> <form-tests.log> <workflow-tests.log> <xaml-validate.raw>"""
import json, pathlib, shutil, sys, uuid, zipfile
HERE = pathlib.Path(__file__).parent
sys.path.insert(0, str(HERE))
import xamlgen as G
import wf_framework, wf_uipath, wf_pa, wf_requests, wf_entry
for m in (wf_framework, wf_uipath, wf_pa, wf_requests, wf_entry):
    m.build()

dest = pathlib.Path(sys.argv[1])
form_log, wf_log, xaml_log = map(pathlib.Path, sys.argv[2:5])
NAME = "RPA_Automation_Management"
proj = dest / NAME
if proj.exists():
    shutil.rmtree(proj)
proj.mkdir(parents=True)

# workflows + form + config
for w in G.REGISTRY.values():
    p = proj / w.path.replace("\\", "/")
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(G.render_xaml(w), encoding="utf-8")
shutil.copy(HERE / "out/form/AutomationManagement.uiform", proj / "Form/AutomationManagement.uiform")
shutil.copytree(HERE / "config", proj / "Config")
for d in ("Data/Audit", "Data/SolutionArtifacts"):
    (proj / d).mkdir(parents=True)
    (proj / d / "README.txt").write_text("Created at run time. Keep out of source control: audit files and managed solution files are written here.\n")

STR = "System.String, System.Private.CoreLib, Version=8.0.0.0, Culture=neutral, PublicKeyToken=7cec85d7bea7798e"
def entry(path):
    w = G.REGISTRY[path]
    assert all(a.type == "S" for a in w.args), path
    return {"filePath": path, "uniqueId": str(uuid.uuid5(uuid.NAMESPACE_URL, "am/" + path)),
            "input": [{"name": a.name, "type": STR, "required": False, "hasDefault": False} for a in w.args if a.direction == "in"],
            "output": [{"name": a.name, "type": STR} for a in w.args if a.direction == "out"]}

project = {
    "name": NAME,
    "projectId": str(uuid.uuid5(uuid.NAMESPACE_URL, "am/" + NAME)),
    "description": "Automation Management: UiPath Form for UiPath and Power Automate change requests (New, Enhancement, Bug Fix), "
                   "Bot ID lookup through configuration, Orchestrator 2025.10 and Dataverse REST integration, governed Dev to UAT "
                   "and UAT to Prod deployment with approval and audit.",
    "main": "Main.xaml",
    "dependencies": {"UiPath.Excel.Activities": "[3.4.1]", "UiPath.Form.Activities": "[25.10.0]", "UiPath.System.Activities": "[26.2.7]", "UiPath.WebAPI.Activities": "[2.4.0]"},
    "webServices": [], "entitiesStores": [],
    "schemaVersion": "4.0", "studioVersion": "25.10.17.0", "projectVersion": "1.0.0",
    "runtimeOptions": {
        "autoDispose": False, "netFrameworkLazyLoading": False, "isPausable": True, "isAttended": True,
        "requiresUserInteraction": True, "supportsPersistence": False, "workflowSerialization": "DataContract",
        "excludedLoggedData": ["Private:*", "*password*", "*Password*", "*secret*", "*Secret*", "*token*", "*Token*", "*credential*", "*Credential*"],
        "executionType": "Workflow", "readyForPiP": False, "startsInPiP": False, "mustRestoreAllDependencies": True, "pipType": "ChildSession"},
    "designOptions": {
        "projectProfile": "Developement",   # UiPath's enum spelling; "Development" makes Studio 25.10 refuse the project
        "outputType": "Process",
        "libraryOptions": {"includeOriginalXaml": False, "privateWorkflows": []},
        "processOptions": {"ignoredFiles": []},
        "fileInfoCollection": [], "modernBehavior": True, "saveToCloud": False},
    "expressionLanguage": "VisualBasic",
    "entryPoints": [entry("Main.xaml"), entry("ExecuteDeployment.xaml"), entry("ApproveRequest.xaml")],
    "isTemplate": False, "templateProjectData": {}, "publishData": {}, "targetFramework": "Windows",
}
(proj / "project.json").write_text(json.dumps(project, indent=2), encoding="utf-8")

# docs/WORKFLOWS.md generated from the workflow model
DIR = {"in": "In", "out": "Out", "io": "In/Out"}
lines = ["# Workflows", "", "Generated from the same model that renders the XAML files, so arguments here match the files.", ""]
groups = {}
for w in G.REGISTRY.values():
    groups.setdefault(w.path.split("\\")[0] if "\\" in w.path else "(entry points)", []).append(w)
for g in sorted(groups, key=lambda x: (x != "(entry points)", x)):
    lines += [f"## {g}", ""]
    for w in groups[g]:
        lines += [f"### {w.path.replace(chr(92), '/')}", "", w.doc, "", "| Direction | Argument | Type | Description |", "|---|---|---|---|"]
        lines += [f"| {DIR[a.direction]} | `{a.name}` | {G.T[a.type][1]} | {a.doc.replace('|', '/')} |" for a in w.args]
        lines.append("")
(proj / "docs").mkdir()
(proj / "docs/WORKFLOWS.md").write_text("\n".join(lines), encoding="utf-8")
shutil.copy(HERE / "docs/PROJECT_README.md", proj / "README.md")

# verification evidence and the sources that produced it
ver = dest / "verification"
if ver.exists():
    shutil.rmtree(ver)
ver.mkdir()
for png in (HERE / "verification").glob("*.png"):
    shutil.copy(png, ver / png.name)
shutil.copy(form_log, ver / "form-browser-tests.log")
shutil.copy(wf_log, ver / "workflow-tests.log")
raw = xaml_log.read_text(errors="replace")
(ver / "xaml-validation.log").write_text(raw, encoding="utf-8")
src = ver / "sources"
src.mkdir()
for f in ["xamlgen.py", "vbl.py", "formacts.py", "wf_framework.py", "wf_uipath.py", "wf_pa.py", "wf_requests.py", "wf_entry.py", "build.py",
          "build_form.py", "package.py", "rebuild.sh", "validate.sh"]:
    shutil.copy(HERE / f, src / f)
shutil.copytree(HERE / "vb", src / "vb")
(src / "test").mkdir()
for f in ["mock_server.py", "Tests.vb", "TestHost.vb", "Harness.vbproj", "run_e2e.sh", "test_form.js"]:
    shutil.copy(HERE / "test" / f, src / "test" / f)
shutil.copytree(HERE / "xaml-load-check", src / "xaml-load-check", ignore=shutil.ignore_patterns("bin", "obj"))
shutil.copytree(HERE / "xaml-stubs", src / "xaml-stubs", ignore=shutil.ignore_patterns("bin", "obj"))

for f in ["README.md", "SOLUTION_GUIDE.md"]:
    shutil.copy(HERE / "docs" / f, dest / f)

# one zip with everything
z = dest / f"{NAME}.zip"
if z.exists():
    z.unlink()
with zipfile.ZipFile(z, "w", zipfile.ZIP_DEFLATED) as zf:
    for base in [proj, ver]:
        for p in sorted(base.rglob("*")):
            if p.is_file():
                zf.write(p, p.relative_to(dest).as_posix())
    for f in ["README.md", "SOLUTION_GUIDE.md"]:
        zf.write(dest / f, f)
print("packaged", sum(1 for _ in proj.rglob("*.xaml")), "XAML files ->", z, z.stat().st_size, "bytes")
