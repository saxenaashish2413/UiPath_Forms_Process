"""Form/AutomationManagement.uiform (UiPath Forms 25.10, form.io 4.14 engine).
Usage: python3 build_form.py <AutomationManagement.uiform> [plain form.io json for the browser test]

.uiform layout (UiPath.Studio.Forms.Runtime 25.10 FormSerializer): {"Metadata": {"Id", "Kind": "FormIo"}, "DesignProperties": {...}, "Data": <form.io schema>}.
The form only shows, hides, formats and collects proposals. Fetching, validation, submission and deployment are done by
Form/Automation_Form_Controller.xaml, which reads and writes the fields listed in that workflow.

Three kinds of values are kept apart on screen (legend at the top, colour per column):
  Retrieved   values read from Dev / the source environment and the current target state (read-only, blue)
  Proposed    values the requester or configuration editor proposes for the target (amber; editable only in edit mode)
  Saved       what was actually written to the target by a deployment (green; filled after deployment)

Grids: the robot writes the rows as JSON text (AssetsJson, QueuesJson, AccessJson, FlowsJson) because Set Form Fields
passes values to form.io unchanged. A 'value' logic action turns the JSON into grid rows whenever the JSON changes, and the
hidden calculated fields AssetsProposedJson / QueuesProposedJson / AccessProposedJson carry the editable columns back
as JSON text for Get Form Fields."""
import json, sys, pathlib
from formacts import FORM_ID

KEY = ("(data.AutomationTool || '') + '|' + (data.ProcessType || '') + '|' + (data.BotId || '').trim().toUpperCase() + '|' + (data.DeploymentPath || '')")
LOADED = f"var loaded = !!data.LookupKey && data.LookupKey === {KEY}; "
UIP = "data.AutomationTool === 'UiPath'"
PA = "data.AutomationTool === 'Power Automate'"
NEW = "data.ProcessType === 'New'"
CHANGE = "(data.ProcessType === 'Enhancement' || data.ProcessType === 'Bug Fix')"
EDITING = "(data.EditMode === 'Yes' && !data.SubmitStatus)"
LOCKED = "!!data.SubmitStatus"

COLOURS = {"retrieved": ("#EEF4FF", "#1D4ED8"), "proposed": ("#FFFAEB", "#B54708"), "saved": ("#ECFDF3", "#067647"), "target": ("#F2F4F7", "#344054")}


def hidden(key, label, calc=None):
    c = {"type": "hidden", "key": key, "label": label, "input": True, "tableView": False, "clearOnHide": False}
    if calc:
        c["calculateValue"] = calc
        c["calculateServer"] = False
    return c


def logic_disabled(js_when_disabled, pre=""):
    """form.io 'logic': set the component's disabled property from a JavaScript condition (re-evaluated on every change).
    pre: JavaScript statements evaluated before the condition (e.g. LOADED)."""
    return [{"name": "disable", "trigger": {"type": "javascript", "javascript": f"{pre}result = {js_when_disabled};"},
             "actions": [{"name": "disable", "type": "property", "property": {"label": "Disabled", "value": "disabled", "type": "boolean"}, "state": True}]},
            {"name": "enable", "trigger": {"type": "javascript", "javascript": f"{pre}result = !({js_when_disabled});"},
             "actions": [{"name": "enable", "type": "property", "property": {"label": "Disabled", "value": "disabled", "type": "boolean"}, "state": False}]}]


def logic_label(pairs):
    return [{"name": f"label {i}", "trigger": {"type": "javascript", "javascript": f"result = {js};"},
             "actions": [{"name": f"set label {i}", "type": "property", "property": {"label": "Label", "value": "label", "type": "string"}, "text": text}]}
            for i, (js, text) in enumerate(pairs)]


def select(key, label, values=None, custom=None, refresh=None, desc=None, required=True, cond=None, logic=None):
    c = {"type": "select", "key": key, "label": label, "input": True, "tableView": True, "widget": "choicesjs", "searchEnabled": False,
         "placeholder": "Select " + label.lower(), "validate": {"required": required}}
    if values:
        c["dataSrc"] = "values"
        c["data"] = {"values": [{"label": v, "value": v} for v in values]}
    else:
        c["dataSrc"] = "custom"
        c["data"] = {"custom": custom}
        c["valueProperty"] = "value"
        c["template"] = "<span>{{ item.label }}</span>"
    if refresh:
        c["refreshOn"] = refresh
        c["clearOnRefresh"] = False
        c["clearOnHide"] = False   # the robot sets the list and the value while the panel may still be hidden
    if desc:
        c["description"] = desc
    if cond:
        c["customConditional"] = cond
    if logic:
        c["logic"] = logic
    return c


def text(key, label, kind="retrieved", cond=None, labels=None, desc=None, editable_when=None, required=False, validate=None, clear=False, area=False, errors=None):
    c = {"type": "textarea" if area else "textfield", "key": key, "label": label, "input": True, "tableView": True, "clearOnHide": clear,
         "customClass": "am-" + kind, "attributes": {"style": "background-color:" + COLOURS[kind][0]}}
    if area:
        c.update({"rows": 3, "autoExpand": False, "showCharCount": True})
    if editable_when is None:
        c["disabled"] = True
    else:
        c["logic"] = logic_disabled(f"!({editable_when})")
    if labels:
        c["logic"] = c.get("logic", []) + logic_label(labels)
    if cond:
        c["customConditional"] = cond
    if desc:
        c["description"] = desc
    v = dict(validate or {})
    if required:
        v["required"] = True
    if v:
        c["validate"] = v
    if errors:   # per-rule messages (a customMessage would replace the 'required' message too)
        c["errors"] = errors
    return c


def html(key, content, cond=None):
    c = {"type": "htmlelement", "key": key, "tag": "div", "input": False, "tableView": False, "refreshOnChange": True, "content": content}
    if cond:
        c["customConditional"] = cond
    return c


def cols(*groups, widths=None):
    w = widths or [12 // len(groups)] * len(groups)
    return {"type": "columns", "key": "cols_" + "_".join(g[0]["key"] for g in groups if g), "input": False, "tableView": False,
            "columns": [{"components": g, "width": wi, "offset": 0, "push": 0, "pull": 0, "size": "md"} for g, wi in zip(groups, w)]}


def panel(key, title, comps, cond=None, title_logic=None):
    p = {"type": "panel", "key": key, "title": title, "input": False, "tableView": False, "collapsible": False, "theme": "default", "components": comps}
    if cond:
        p["customConditional"] = cond
    if title_logic:
        p["logic"] = [{"name": f"title {i}", "trigger": {"type": "javascript", "javascript": f"result = {js};"},
                       "actions": [{"name": f"set title {i}", "type": "property", "property": {"label": "Title", "value": "title", "type": "string"}, "text": t}]}
                      for i, (js, t) in enumerate(title_logic)]
    return p


def alert(kind, body):
    colours = {"info": ("#EEF4FF", "#B2CCFF", "#1D4ED8", "#1E3A8A"), "ok": ("#ECFDF3", "#ABEFC6", "#067647", "#054F31"),
               "warn": ("#FFFAEB", "#FEDF89", "#B54708", "#7A2E0E"), "error": ("#FEF3F2", "#FDA29B", "#B42318", "#7A271A")}[kind]
    return (f'<div style="padding:10px 14px;background:{colours[0]};border:1px solid {colours[1]};border-left:4px solid {colours[2]};'
            f'border-radius:6px;color:{colours[3]};font-size:13px;margin:4px 0 12px;">{body}</div>')


def badge(kind, label):
    bg, fg = COLOURS[kind]
    return f'<span style="display:inline-block;padding:2px 8px;border-radius:10px;background:{bg};color:{fg};font-size:12px;font-weight:600;margin-right:6px;">{label}</span>'


LINES = "{{ _.escape(%s).split('\\n').join('<br>') }}"


def rows_logic(json_key, mapping_js):
    """Grid rows from the robot's JSON text; only when that text changes, so edits in the grid are kept."""
    return [{"name": "rows from " + json_key,
             "trigger": {"type": "javascript", "javascript": f"result = instance.__amSource !== (data.{json_key} || '[]');"},
             "actions": [{"name": "set rows", "type": "value",
                          "value": f"instance.__amSource = (data.{json_key} || '[]'); var src = []; try {{ src = JSON.parse(instance.__amSource); }} catch (e) {{ src = []; }} "
                                   f"var s = function (v) {{ return v === null || v === undefined ? '' : String(v); }}; value = src.map(function (r) {{ return {mapping_js}; }});"}]}]


def col(key, label, kind="retrieved", editable=None, select_values=None, select_custom=None, hidden_col=False, width=None):
    if hidden_col:
        return {"type": "hidden", "key": key, "label": label, "input": True, "tableView": False}
    if select_values or select_custom:
        c = {"type": "select", "key": key, "label": label, "input": True, "tableView": True, "widget": "html5", "customClass": "am-" + kind}
        if select_values:
            c["dataSrc"] = "values"
            c["data"] = {"values": [{"label": v, "value": v} for v in select_values]}
        else:
            c["dataSrc"] = "custom"
            c["data"] = {"custom": select_custom}
            c["valueProperty"] = "value"
            c["template"] = "<span>{{ item.label }}</span>"
    else:
        c = {"type": "textfield", "key": key, "label": label, "input": True, "tableView": True, "customClass": "am-" + kind}
    c["attributes"] = {"style": "background-color:" + COLOURS[kind][0]}
    if editable is None:
        c["disabled"] = True
    else:
        c["logic"] = logic_disabled(f"!({editable})")
    return c


def grid(key, label, json_key, mapping_js, components, cond):
    return {"type": "datagrid", "key": key, "label": label, "input": True, "tableView": False, "clearOnHide": False,
            "disableAddingRemovingRows": True, "reorder": False, "logic": rows_logic(json_key, mapping_js),
            "customConditional": cond, "components": components}


# ---------------------------------------------------------------- header, legend, messages
header = html("header",
              '<div style="display:flex;justify-content:space-between;align-items:flex-end;padding:16px 20px;background:#fff;'
              'border:1px solid #E1E6EF;border-top:4px solid #0B3D91;border-radius:8px;margin-bottom:10px;">'
              '<div><div style="font-size:21px;font-weight:700;color:#0B3D91;">Automation Management</div>'
              '<div style="font-size:13px;color:#5B6B82;margin-top:3px;">Request, validate and promote UiPath and Power Automate automations</div></div>'
              '<div style="font-size:12px;color:#5B6B82;text-align:right;">Requested by<br><b style="color:#1F2A44;">{{ _.escape(data.RequesterName) }}</b></div></div>')

legend = html("legend", '<div style="font-size:12px;color:#5B6B82;margin:0 0 12px;">' + badge("retrieved", "Retrieved") + "read from Dev or the target, read-only "
              + badge("proposed", "Proposed") + "your proposal for the target " + badge("saved", "Saved") + "written to the target by a deployment</div>")

style = html("style", "<style>.am-retrieved input,.am-retrieved select,.am-retrieved textarea{background:#EEF4FF!important}"
             ".am-proposed input:not([disabled]),.am-proposed select:not([disabled]),.am-proposed textarea:not([disabled]){background:#FFFAEB!important;border-color:#FEC84B}"
             ".am-saved input{background:#ECFDF3!important}.am-target input{background:#F2F4F7!important}"
             ".formio-component-datagrid table{font-size:12px}.formio-component-datagrid td{padding:4px!important}</style>")

lookup_msgs = [
    html("lookupHint", alert("info", "Choose the automation tool, process type and deployment path, enter the Bot ID and click <b>Fetch Details</b>."),
         LOADED + "show = !loaded && !data.LookupKey && data.LookupStatus !== 'NotFound' && data.LookupStatus !== 'Error' && data.LookupStatus !== 'Searching';"),
    html("lookupStale", alert("info", "The selection changed. Click <b>Fetch Details</b> to load the matching details."),
         LOADED + "show = !loaded && !!data.LookupKey;"),
    html("lookupSearching", alert("info", LINES % "data.LookupMessage"), "show = data.LookupStatus === 'Searching';"),
    html("lookupFound", alert("ok", LINES % "data.LookupMessage"), LOADED + "show = loaded && data.LookupStatus === 'Found';"),
    html("lookupNotFound", alert("warn", LINES % "data.LookupMessage"), LOADED + "show = loaded && data.LookupStatus === 'NotFound';"),
    html("lookupError", alert("error", LINES % "data.LookupMessage"),
         "show = !!data.LookupMessage && (data.LookupStatus === 'Error' || (data.LookupStatus === 'NotFound' && !data.LookupKey));"),
    html("warnings", alert("warn", "<b>Warnings</b><br>" + LINES % "data.WarningsText"), LOADED + "show = loaded && !!data.WarningsText;"),
]

path_custom = ("var names = []; try { names = JSON.parse(data.DeploymentPathOptions || '[]'); } catch (e) { names = []; } "
               "values = names.map(function (n) { return { label: n, value: n }; });")
version_custom = ("var v = []; try { v = JSON.parse(data.VersionsJson || '[]'); } catch (e) { v = []; } "
                  "values = v.map(function (n) { return { label: String(n), value: String(n) }; });")
level_custom = ("var v = []; try { v = JSON.parse(data.AccessLevelOptions || '[]'); } catch (e) { v = []; } "
                "values = v.map(function (n) { return { label: n, value: n }; });")

LOCK = logic_disabled(LOCKED)

request = panel("pnlRequest", "Request", [
    cols([select("AutomationTool", "Automation Tool", ["UiPath", "Power Automate"], logic=LOCK)],
         [select("ProcessType", "Process Type", ["New", "Enhancement", "Bug Fix"], logic=LOCK)],
         [select("DeploymentPath", "Deployment Path", custom=path_custom, refresh="DeploymentPathOptions", logic=LOCK,
                 desc="UAT to Prod needs an approved request and a successful Dev to UAT deployment of the same version.")]),
    cols([{"type": "textfield", "key": "BotId", "label": "Bot ID", "input": True, "tableView": True, "placeholder": "e.g. BOT-1001",
           "validate": {"required": True, "maxLength": 50, "pattern": "^[A-Za-z0-9][A-Za-z0-9_.-]{1,49}$",
},
           "errors": {"pattern": "Bot ID must be 2-50 letters, digits or - _ ."},
           "description": "Resolved through the Bot ID mapping (Config\\BotMapping.json).", "logic": LOCK}],
         [{"type": "button", "key": "btnFetch", "label": "Fetch Details", "action": "event", "event": "fetchDetails", "theme": "primary",
           "input": True, "tableView": False, "leftIcon": "fa fa-search", "customClass": "mt-4", "logic": LOCK}],
         [], widths=[4, 3, 5]),
] + lookup_msgs)

# ---------------------------------------------------------------- process / package (retrieved)
process = panel("pnlProcess", "Process", [
    cols([text("ProcessName", "Process Name", labels=[(PA, "Solution Display Name"), (UIP, "Process Name")])],
         [text("PackageName", "Package Name", labels=[(PA, "Solution Unique Name"), (UIP, "Package Name")])]),
    text("ProcessDescription", "Description", cond="show = !!data.ProcessDescription;"),
    cols([text("DevFolder", "Dev", labels=[(PA, "Dev environment URL"), (UIP, "Dev folder")])],
         [text("UatFolder", "UAT", labels=[(PA, "UAT environment URL"), (UIP, "UAT folder")])],
         [text("ProdFolder", "Prod", labels=[(PA, "Prod environment URL"), (UIP, "Prod folder")])]),
    cols([text("DevStatus", "Dev status", kind="target")], [text("UatStatus", "UAT status", kind="target")], [text("ProdStatus", "Prod status", kind="target")]),
], LOADED + f"show = loaded && {NEW};")

package = panel("pnlPackage", "Package", [
    cols([text("PackageName_display", "Package Name", labels=[(PA, "Solution Unique Name"), (UIP, "Package Name")])],
         [text("CurrentVersion", "Version in target", kind="target",
               labels=[(PA, "Solution version in target"), (UIP, "Version deployed in target")])],
         [text("LatestDevVersion", "Latest Dev version", labels=[(PA, "Solution version in Dev"), (UIP, "Latest version in Dev feed")])]),
    text("PackageAvailability", "Package availability", labels=[(PA, "Solution availability"), (UIP, "Package availability")]),
    cols([text("DevStatus_display", "Dev status", kind="target")], [text("UatStatus_display", "UAT status", kind="target")],
         [text("ProdStatus_display", "Prod status", kind="target")]),
], LOADED + f"show = loaded && {CHANGE};")
# the package panel shows the same robot values as the process panel under *_display keys (keys must be unique in form.io)

version = panel("pnlVersion", "Version to deploy", [
    cols([select("RequestedVersion", "Version to deploy", custom=version_custom, refresh="VersionsJson", logic=LOCK,
                 desc="Dev to UAT: any version in the Dev feed. UAT to Prod: the version deployed in UAT.")],
         [html("versionNote", '<div style="font-size:12px;color:#5B6B82;margin-top:30px;">' + badge("proposed", "Proposed")
               + "{{ data.AutomationTool === 'Power Automate' ? 'Exported as a managed solution from Dev; Prod receives the same file.' : 'The package is copied between feeds unchanged; the process is created or updated to this version.' }}</div>")],
         widths=[5, 7]),
], LOADED + "show = loaded && data.LookupStatus !== 'NotFound';")

# ---------------------------------------------------------------- configuration (New + UiPath)
asset_cols = [
    col("name", "Asset"), col("type", "Type"), col("devValue", "Dev value"), col("targetValue", "Target value", "target"),
    col("targetStatus", "Target status", "target"),
    col("action", "Action", "proposed", editable=EDITING, select_values=["Create", "Update", "Keep", "Skip"]),
    col("proposedValue", "Proposed value", "proposed", editable=f"{EDITING} && row.isSecret !== true"),
    col("savedStatus", "Saved", "saved"), col("isSecret", "Secret", hidden_col=True)]
asset_map = ("{ name: s(r.name), type: s(r.type), devValue: s(r.devValue), targetValue: s(r.targetValue), targetStatus: s(r.targetStatus), "
             "action: s(r.action), proposedValue: r.isSecret === true ? '(approved secret source)' : s(r.proposedValue), savedStatus: s(r.savedStatus), isSecret: r.isSecret === true }")
queue_cols = [
    col("name", "Queue"), col("description", "Description"), col("maxRetries", "Max retries"), col("uniqueReference", "Unique ref."),
    col("targetStatus", "Target status", "target"),
    col("action", "Action", "proposed", editable=EDITING, select_values=["Create", "Update", "Keep", "Skip"]),
    col("proposedName", "Proposed name", "proposed", editable=EDITING), col("savedStatus", "Saved", "saved")]
queue_map = ("{ name: s(r.name), description: s(r.description), maxRetries: s(r.maxRetries), uniqueReference: r.uniqueReference === true ? 'Yes' : 'No', "
             "targetStatus: s(r.targetStatus), action: s(r.action), proposedName: s(r.proposedName), savedStatus: s(r.savedStatus) }")
access_cols = [
    col("name", "Account"), col("type", "Type"), col("devRoles", "Dev roles"), col("targetRoles", "Target roles", "target"),
    col("action", "Action", "proposed", editable=EDITING, select_values=["Grant", "No change"]),
    col("accessLevel", "Access level", "proposed", editable=EDITING, select_custom=level_custom),
    col("savedStatus", "Saved", "saved")]
access_map = ("{ name: s(r.name), type: s(r.type), devRoles: s(r.devRoles), targetRoles: s(r.targetRoles), action: s(r.action), "
              "accessLevel: s(r.accessLevel), savedStatus: s(r.savedStatus) }")

ROWS = "var n = 0; try { n = JSON.parse(data.%s || '[]').length; } catch (e) { n = 0; } "
configuration = panel("pnlConfiguration", "Configuration for the target", [
    html("editHint", alert("info", LINES % "data.EditMessage"), "show = !!data.EditMessage;"),
    cols([text("ProposedProcessName", "Process name in target", kind="proposed", editable_when=EDITING)],
         [text("ProposedTargetFolder", "Target folder", kind="proposed", editable_when=EDITING,
               desc="Must match the folder mapped for the target in the Bot ID mapping.")]),
    grid("AssetsGrid", "Assets", "AssetsJson", asset_map, asset_cols, ROWS % "AssetsJson" + "show = n > 0;"),
    html("noAssets", alert("info", "No assets are mapped for this Bot ID."), ROWS % "AssetsJson" + "show = n === 0;"),
    grid("QueuesGrid", "Queues", "QueuesJson", queue_map, queue_cols, ROWS % "QueuesJson" + "show = n > 0;"),
    html("noQueues", alert("info", "No queues are mapped for this Bot ID."), ROWS % "QueuesJson" + "show = n === 0;"),
    grid("AccessGrid", "Access", "AccessJson", access_map, access_cols, ROWS % "AccessJson" + "show = n > 0;"),
    html("noAccess", alert("info", "No access entries are mapped for this Bot ID."), ROWS % "AccessJson" + "show = n === 0;"),
    text("AdditionalConfig", "Additional configuration notes", kind="proposed", editable_when=EDITING, area=True, clear=True,
         validate={"maxLength": 2000}),
    {"type": "button", "key": "btnEdit", "label": "Edit Configuration", "action": "event", "event": "editConfiguration", "theme": "secondary",
     "input": True, "tableView": False, "leftIcon": "fa fa-pencil", "logic": logic_disabled(LOCKED),
     "customConditional": "show = data.CanEdit === 'Yes';"},
    html("editNotAllowed", '<div style="font-size:12px;color:#5B6B82;">Only configuration editors can change the configuration; you can review and submit it as retrieved.</div>',
         "show = data.CanEdit !== 'Yes';"),
], LOADED + f"show = loaded && {NEW} && {UIP} && data.LookupStatus !== 'NotFound';")

flows = panel("pnlFlows", "Flows in the solution", [
    grid("FlowsGrid", "Flows", "FlowsJson",
         "{ name: s(r.name), state: s(r.state), expected: r.expected === true ? 'Yes' : 'No' }",
         [col("name", "Flow"), col("state", "State in Dev"), col("expected", "Mapped for this Bot ID")], ROWS % "FlowsJson" + "show = n > 0;"),
    html("noFlows", alert("info", "No cloud flows were found in the Dev solution."), ROWS % "FlowsJson" + "show = n === 0;"),
    html("paNote", alert("warn", "Connection references and environment variables are not changed by this request. They must be set in the target "
                                 "environment (or by a deployment settings file) before the flows are turned on."), None),
], LOADED + f"show = loaded && {NEW} && {PA} && data.LookupStatus !== 'NotFound';")

change = panel("pnlChange", "Change information", [
    text("EnhancementDescription", "Enhancement Description", kind="proposed", editable_when="!" + LOCKED, required=True, area=True, clear=True,
         cond="show = data.ProcessType === 'Enhancement';", validate={"maxLength": 2000}, desc="What changes and why."),
    text("ChangeReference", "Change or Request Reference", kind="proposed", editable_when="!" + LOCKED, clear=True,
         cond="show = data.ProcessType === 'Enhancement';", validate={"pattern": "^([A-Za-z0-9][A-Za-z0-9_./-]{2,39})?$"}, errors={"pattern": "{{ field }} must be 3-40 letters, digits or - _ . /"}),
    text("BugDescription", "Bug Description", kind="proposed", editable_when="!" + LOCKED, required=True, area=True, clear=True,
         cond="show = data.ProcessType === 'Bug Fix';", validate={"maxLength": 2000}, desc="What goes wrong, steps to reproduce, expected result."),
    text("IncidentReference", "Incident or Defect Reference", kind="proposed", editable_when="!" + LOCKED, required=True, clear=True,
         cond="show = data.ProcessType === 'Bug Fix';", validate={"pattern": "^[A-Za-z0-9][A-Za-z0-9_./-]{2,39}$"}, errors={"pattern": "{{ field }} must be 3-40 letters, digits or - _ . /"}),
], LOADED + f"show = loaded && {CHANGE} && data.LookupStatus !== 'NotFound';")

review = panel("pnlReview", "Review", [
    html("summary", "{{ data.SummaryHtml }}", "show = !!data.SummaryHtml;"),
    html("submitOk", alert("ok", LINES % "data.SubmitMessage"),
         "show = !!data.SubmitMessage && ['Submitted', 'Succeeded', 'AlreadyDeployed'].indexOf(data.SubmitStatus) >= 0;"),
    html("submitBusy", alert("info", LINES % "data.SubmitMessage"), "show = !!data.SubmitMessage && data.SubmitStatus === 'Deploying';"),
    html("submitWarn", alert("warn", LINES % "data.SubmitMessage"), "show = !!data.SubmitMessage && (data.SubmitStatus === 'Duplicate' || !data.SubmitStatus);"),
    html("submitFail", alert("error", LINES % "data.SubmitMessage"), "show = !!data.SubmitMessage && (data.SubmitStatus === 'Failed' || data.SubmitStatus === 'Rejected');"),
], "show = !!data.SummaryHtml || !!data.SubmitMessage;")

# Validate / Submit: client-side check of the visible mandatory fields first (form.io marks them red), then raise the
# click.<key> event for the robot. An 'event' button would skip the check; a 'submit' button would close the window.
def checked(event):
    return ("var ok = form.checkValidity(form.data, true, form.data, false); "
            f"if (ok) {{ instance.emit('customEvent', {{ type: '{event}', component: instance.component, data: data }}); }} "
            "else { form.setPristine(false); form.redraw(); }")


NOT_READY = "(!loaded || data.LookupStatus !== 'Found' || " + LOCKED + ")"
actions = cols([{"type": "button", "key": "btnValidate", "label": "Validate", "action": "custom", "custom": checked("validateRequest"), "theme": "secondary",
                 "input": True, "tableView": False, "block": True, "logic": logic_disabled(NOT_READY, LOADED)}],
               [{"type": "button", "key": "btnSubmit", "label": "Submit Request", "action": "custom", "custom": checked("submitRequest"), "theme": "primary",
                 "input": True, "tableView": False, "block": True, "logic": logic_disabled(NOT_READY, LOADED)}],
               [{"type": "button", "key": "btnCancel", "label": "Close", "action": "event", "event": "cancelRequest", "theme": "secondary",
                 "input": True, "tableView": False, "block": True,
                 "logic": logic_label([("!!data.SubmitStatus", "Close"), ("!data.SubmitStatus", "Cancel")])}],
               [], widths=[2, 3, 2, 5])

HIDDEN = [("RequesterName", "Requester"), ("CanEdit", "Can edit configuration"), ("DeploymentPathOptions", "Deployment path options"),
          ("AccessLevelOptions", "Access level options"), ("DevEnvironment", "Dev environment"), ("LookupKey", "Lookup key"), ("LookupStatus", "Lookup status"),
          ("LookupMessage", "Lookup message"), ("VersionsJson", "Versions"), ("AssetsJson", "Assets (robot)"), ("QueuesJson", "Queues (robot)"),
          ("AccessJson", "Access (robot)"), ("FlowsJson", "Flows (robot)"), ("WarningsText", "Warnings"), ("EditMode", "Edit mode"),
          ("EditMessage", "Edit message"), ("ValidationStatus", "Validation status"), ("SummaryHtml", "Review summary"),
          ("SubmitStatus", "Submit status"), ("SubmitMessage", "Submit message"), ("RequestReference", "Request reference")]
calc = [hidden("AssetsProposedJson", "Assets proposed",
               "value = JSON.stringify((data.AssetsGrid || []).map(function (r) { return { name: r.name, action: r.action, proposedValue: r.isSecret ? '' : r.proposedValue }; }));"),
        hidden("QueuesProposedJson", "Queues proposed",
               "value = JSON.stringify((data.QueuesGrid || []).map(function (r) { return { name: r.name, action: r.action, proposedName: r.proposedName }; }));"),
        hidden("AccessProposedJson", "Access proposed",
               "value = JSON.stringify((data.AccessGrid || []).map(function (r) { return { name: r.name, action: r.action, accessLevel: r.accessLevel }; }));"),
        # display copies for the package panel (form.io keys are unique per form)
        hidden("PackageName_display", "", "value = data.PackageName || '';"), hidden("DevStatus_display", "", "value = data.DevStatus || '';"),
        hidden("UatStatus_display", "", "value = data.UatStatus || '';"), hidden("ProdStatus_display", "", "value = data.ProdStatus || '';")]

form = {"display": "form", "title": "Automation Management", "name": "automationManagement",
        "components": [hidden(k, l) for k, l in HIDDEN] + [style, header, legend, request, process, package, version, configuration, flows, change, review, actions]}

# The package panel's display copies are text fields with calculated values; give them the calculation directly
def _walk(cs):
    for c in cs:
        yield c
        yield from _walk(c.get("components", []))
        for co in c.get("columns", []):
            yield from _walk(co["components"])


for c in list(_walk(form["components"])):
    if c["key"].endswith("_display") and c["type"] == "textfield":
        c["calculateValue"] = f"value = data.{c['key'][:-8]} || '';"
form["components"] = [c for c in form["components"] if not (c["type"] == "hidden" and c["key"].endswith("_display"))] + \
                     [c for c in calc if not c["key"].endswith("_display")]

uiform = {"Metadata": {"Id": FORM_ID, "Kind": "FormIo"},
          "DesignProperties": {"Title": "Automation Management", "Width": 1180, "Height": 940, "ShowInTaskbar": True, "ShowMargin": True},
          "Data": form}

if __name__ == "__main__":
    out = pathlib.Path(sys.argv[1]); out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(uiform, indent=2, ensure_ascii=False), encoding="utf-8")
    if len(sys.argv) > 2:
        pathlib.Path(sys.argv[2]).write_text(json.dumps(form, indent=1, ensure_ascii=False), encoding="utf-8")
    top = []
    for c in _walk(form["components"]):
        top.append(c["key"])
    grid_children = {k for g in _walk(form["components"]) if g["type"] == "datagrid" for k in (x["key"] for x in g["components"])}
    dups = {k for k in top if top.count(k) > 1 and k not in grid_children}
    assert not dups, dups
    # every field the controller reads or writes exists in the form
    import re
    src = pathlib.Path(__file__).with_name("wf_entry.py").read_text()
    import wf_entry
    used = set(wf_entry.READ_FIELDS) | set(wf_entry.details_fields()) | set(re.findall(r'"(\w+)": ', src.split("def build():")[1].split("Workflow(\"Main.xaml\"")[0]))
    used = {k for k in used if k[0].isupper() and not k.startswith(("Fetch", "Deployment path", "Automation", "Process", "Edit", "Validate", "Submit", "Cancel", "Form"))} | {"SubmitStatus", "SubmitMessage", "EditMode", "EditMessage"}
    missing = sorted(k for k in used if k not in top)
    assert not missing, missing
    print(len(top), "components")
