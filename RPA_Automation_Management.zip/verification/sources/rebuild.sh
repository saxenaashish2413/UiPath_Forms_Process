#!/bin/bash
# Regenerates XAML + VB twin and compiles the test harness.
B=$(cd "$(dirname "$0")" && pwd)
cd $B && rm -rf out/proj && mkdir -p out/proj && python3 build.py out/proj out/Workflows.vb || exit 1
cp out/Workflows.vb test/ && cd test && dotnet build -nologo -v q 2>&1 | grep -E "error|rror\(s\)" | sed 's|/tmp/.*/test/||; s| \[.*||' | sort -u | head -${1:-60}
